import { memo, useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { AGENTS, type AgentId } from '@/lib/app/agents';
import type { AgentActivity } from '@/lib/app/useAgentActivity';
import { compactLine, pickFresh } from '@/lib/app/dialogue';
import { REEL, type ReelStatus } from '@/lib/app/videoStaff';
import { REEL_BREAK_BACK, REEL_BREAK_GO, REEL_BREAK_ICON, initReelRoutine, stepReel, type ReelDoing, type ReelRoutine } from '@/lib/app/reelRoutine';
import { gotoTab } from './ReelStatusBar';
import { ARGUS, BOSS, IT_STAFF, MEAL_INFO, ROOMS, SECRETARY, hasEnergy, type BreakRoutine, type MemberId, type Routine, type Phase, type Place, type Room, type TeamId } from '@/lib/app/office';

/** Phones / tablets get a lighter renderer (computed once so the helpers below can use it too). */
const COARSE =
  typeof window !== 'undefined' && ((window.matchMedia?.('(pointer: coarse)').matches ?? false) || window.innerWidth < 800);

/** Glossy clear-coat material on desktop; plain PBR on phones (clear-coat doubles the fragment cost). */
function physMat(p: THREE.MeshPhysicalMaterialParameters): THREE.MeshStandardMaterial {
  if (!COARSE) return new THREE.MeshPhysicalMaterial(p);
  const q = { ...p } as Record<string, unknown>;
  delete q.clearcoat;
  delete q.clearcoatRoughness;
  return new THREE.MeshStandardMaterial(q as THREE.MeshStandardMaterialParameters);
}

/* ------------------------------------------------------------------ *
 * World: 80 x 52 units. Percent positions from ROOMS map to world.
 * ------------------------------------------------------------------ */
const W = 80;
const D = 52;
const wx = (p: number) => ((p - 50) * W) / 100;
const wz = (p: number) => ((p - 50) * D) / 100;
const rb = (r: Room) => ({ x0: wx(r.x), x1: wx(r.x + r.w), z0: wz(r.y), z1: wz(r.y + r.h) });
const lerp = (a: number, b: number, t: number) => a + (b - a) * t;

/** Timog pakpak (south wing): Server Room · Canteen · Arcade, nasa ibaba ng orihinal na 80 x 52 na plano. */
const WING = 16;
const ZW0 = wz(ROOMS.server.y);
const ZW1 = wz(ROOMS.server.y + ROOMS.server.h);
const ZDOOR = wz(117.3);

const COLORS: Record<MemberId, string> = {
  it: IT_STAFF.color,
  argus: ARGUS.color,
  boss: BOSS.color,
  sec: SECRETARY.color,
  aria: AGENTS[0].color,
  blaze: AGENTS[1].color,
  nova: AGENTS[2].color,
  cipher: AGENTS[3].color,
};
/** Ang pangunahing team (kasama sa meeting at coffee break). */
const TEAM_IDS: TeamId[] = ['boss', 'aria', 'blaze', 'nova', 'cipher', 'sec'];
/** Lahat ng bot sa scene, kasama si Dex ng IT at si Argus ang Watchdog. */
const IDS: MemberId[] = [...TEAM_IDS, 'it', 'argus'];
const NAMES: Record<MemberId, string> = { it: IT_STAFF.name, argus: ARGUS.name, boss: BOSS.name, sec: SECRETARY.name, aria: 'Aria', blaze: 'Blaze', nova: 'Nova', cipher: 'Cipher' };

/* ------------------------------------------------------------------ *
 * Seats & navigation graph
 * ------------------------------------------------------------------ */
const TABLE_C = new THREE.Vector3(0, 0, wz(49));
const LAB_SEATS: Record<TeamId, [number, number]> = {
  boss: [0, TABLE_C.z - 3.1],
  aria: [-5.4, TABLE_C.z - 1.1],
  nova: [-5.4, TABLE_C.z + 1.3],
  blaze: [5.4, TABLE_C.z - 1.1],
  cipher: [5.4, TABLE_C.z + 1.3],
  sec: [0, TABLE_C.z + 3.1],
};
const BAR_COUNTER_Z = wz(71) + 4.8;
const BAR_Z = BAR_COUNTER_Z + 2.2;
/** Sino ang nagbabasa ng dyaryo habang nagkakape sa mini bar. */
const READERS = new Set<MemberId>(['boss', 'nova', 'cipher']);
const BAR_SEATS: Record<TeamId, [number, number]> = {
  aria: [-7.5, BAR_Z],
  nova: [-4.5, BAR_Z],
  sec: [-1.5, BAR_Z],
  boss: [1.5, BAR_Z],
  blaze: [4.5, BAR_Z],
  cipher: [7.5, BAR_Z],
};
/** Nakatayong pwesto sa Shared Brain: mga empleyado sa timog ng mesa, secretary sa hilaga. */
const DROP_SPOTS: Record<TeamId, [number, number]> = {
  boss: [0, TABLE_C.z - 3.3],
  sec: [-2.6, TABLE_C.z - 3.3],
  aria: [-3.6, TABLE_C.z + 3.1],
  nova: [-1.2, TABLE_C.z + 3.1],
  blaze: [1.2, TABLE_C.z + 3.1],
  cipher: [3.6, TABLE_C.z + 3.1],
};
/** Canteen: dalawang mahabang mesa (hilaga at timog ng aisle). Ang hilagang hanay ay nakaharap sa hilaga, ang timog ay nakaharap sa timog. */
const DINE_ROW = 1.9;
const DINE_XS = [-4.5, -1.5, 1.5, 4.5];
const DINE_TABLE_Z = [ZDOOR - 3.7, ZDOOR + 3.7];
const DINE_SEATS: Record<MemberId, [number, number]> = {
  boss: [DINE_XS[0], ZDOOR - DINE_ROW],
  sec: [DINE_XS[1], ZDOOR - DINE_ROW],
  aria: [DINE_XS[2], ZDOOR - DINE_ROW],
  blaze: [DINE_XS[3], ZDOOR - DINE_ROW],
  nova: [DINE_XS[0], ZDOOR + DINE_ROW],
  it: [DINE_XS[1], ZDOOR + DINE_ROW],
  argus: [DINE_XS[3], ZDOOR + DINE_ROW], // placeholder lang: hindi umaalis sa office si Argus
  cipher: [DINE_XS[2], ZDOOR + DINE_ROW],
};
/** Arcade: mga makina sa hilaga at timog na pader; nakatayo ang naglalaro sa harap nito. */
const ARCADE_NORTH_XS = [22.4, 25.8, 29.2, 32.6];
const ARCADE_SOUTH_XS = [23.6, 27.6, 31.6];
const ARCADE_OWNERS: MemberId[] = ['aria', 'blaze', 'nova', 'cipher', 'boss', 'sec', 'it'];
const PLAY_SPOTS: Record<MemberId, [number, number]> = {
  aria: [ARCADE_NORTH_XS[0], ZW0 + 2.9],
  blaze: [ARCADE_NORTH_XS[1], ZW0 + 2.9],
  nova: [ARCADE_NORTH_XS[2], ZW0 + 2.9],
  cipher: [ARCADE_NORTH_XS[3], ZW0 + 2.9],
  boss: [ARCADE_SOUTH_XS[0], ZW1 - 2.9],
  sec: [ARCADE_SOUTH_XS[1], ZW1 - 2.9],
  it: [ARCADE_SOUTH_XS[2], ZW1 - 2.9],
  argus: [ARCADE_SOUTH_XS[2], ZW1 - 2.9], // placeholder lang: hindi naglalaro si Argus
};

/** Pwesto ng secretary sa tabi ng upuan ng boss kapag nag-uulat. */
const BRIEF_SPOT: [number, number] = (() => {
  const r = rb(ROOMS.boss);
  return [3.0, r.z0 + 0.4 * (r.z1 - r.z0) + 2.2];
})();

function officeDesk(id: MemberId) {
  if (id === 'argus') {
    // desk ni Argus: nakaharap sa CCTV wall sa hilagang pader ng office niya
    const r = rb(ROOMS.argus);
    const deskZ = r.z0 + 2.6;
    return { cx: (r.x0 + r.x1) / 2, deskZ, seatZ: deskZ + 1.65 };
  }
  if (id === 'it') {
    // desk ni Dex sa loob ng Server Room (nasa pagitan ng mga rack)
    const r = rb(ROOMS.server);
    return { cx: (r.x0 + r.x1) / 2 + 0.8, deskZ: ZDOOR - 1.4, seatZ: ZDOOR + 0.25 };
  }
  if (id === 'sec') {
    const r = rb(ROOMS.boss);
    const deskZ = r.z0 + 0.4 * (r.z1 - r.z0) + 1.0;
    return { cx: 7.6, deskZ, seatZ: deskZ + 1.65 };
  }
  if (id === 'boss') {
    const r = rb(ROOMS.boss);
    return { cx: 0, deskZ: r.z0 + 0.4 * (r.z1 - r.z0), seatZ: r.z0 + 0.4 * (r.z1 - r.z0) + 1.75 };
  }
  const r = rb(ROOMS[id]);
  const cx = (r.x0 + r.x1) / 2;
  const deskZ = r.z0 + 0.34 * (r.z1 - r.z0);
  return { cx, deskZ, seatZ: deskZ + 1.65 };
}

/** Nakatayo si Dex sa tabi ng desk ng empleyadong inaayusan niya, sa gilid na malapit sa pinto ng office. */
function fixSpot(tgt: TeamId): THREE.Vector3 {
  const d = officeDesk(tgt);
  const side = tgt === 'blaze' || tgt === 'cipher' ? -1 : 1;
  return new THREE.Vector3(d.cx + side * 3.0, 0, d.seatZ + 0.1);
}

function spotOf(id: MemberId, place: Place, tgt: TeamId | null = null): THREE.Vector3 {
  if (id === 'argus') {
    if (place === 'lab') return new THREE.Vector3(ARGUS_LAB_SEAT[0], 0, ARGUS_LAB_SEAT[1]);
    if (place === 'rest') { const r = rb(ROOMS.argus); return new THREE.Vector3(r.x0 + 4.6, 0, r.z1 - 1.05); } // idlip sa sofa ng HQ niya
    const dk = officeDesk('argus');
    return new THREE.Vector3(dk.cx, 0, dk.seatZ);
  }
  if (id === 'it' && place === 'fix' && tgt) return fixSpot(tgt);
  if (place === 'rest' && id !== 'it' && id !== 'boss' && id !== 'sec') {
    // idlip sa sofa ng sariling office (nasa timog na pader, nakaharap sa hilaga)
    const d = officeDesk(id);
    return new THREE.Vector3(d.cx, 0, rb(ROOMS[id]).z1 - 1.05);
  }
  if (place === 'dine') return new THREE.Vector3(DINE_SEATS[id][0], 0, DINE_SEATS[id][1]);
  if (place === 'play') return new THREE.Vector3(PLAY_SPOTS[id][0], 0, PLAY_SPOTS[id][1]);
  if (id === 'it') {
    const dk = officeDesk('it');
    return new THREE.Vector3(dk.cx, 0, dk.seatZ);
  }
  if (place === 'lab') return new THREE.Vector3(LAB_SEATS[id][0], 0, LAB_SEATS[id][1]);
  if (place === 'bar') return new THREE.Vector3(BAR_SEATS[id][0], 0, BAR_SEATS[id][1]);
  if (place === 'drop') return new THREE.Vector3(DROP_SPOTS[id][0], 0, DROP_SPOTS[id][1]);
  if (place === 'brief') return new THREE.Vector3(BRIEF_SPOT[0], 0, BRIEF_SPOT[1]);
  const d = officeDesk(id);
  return new THREE.Vector3(d.cx, 0, d.seatZ);
}

const NODE_PCT: Record<string, [number, number]> = {
  aD: [26, 22], nD: [26, 78], bD: [74, 22], cD: [74, 78], bossD: [50, 27],
  L1: [29.5, 22], L2: [29.5, 31], L3: [29.5, 49], L4: [29.5, 67], L5: [29.5, 78], L6: [29.5, 84],
  R1: [70.5, 22], R2: [70.5, 31], R3: [70.5, 49], R4: [70.5, 67], R5: [70.5, 78], R6: [70.5, 84],
  H1: [50, 31], H2: [50, 67],
  labL: [33, 49], labR: [67, 49], barL: [33, 84], barR: [67, 84],
  // timog pakpak: dulo ng hallway at mga pinto ng Server Room, Canteen at Arcade
  L8: [29.5, 117.3], R8: [70.5, 117.3], sD: [26, 117.3], dnL: [33, 117.3], dnR: [67, 117.3], arD: [74, 117.3],
  // pinto ng office ni Argus (kanang hallway, sa pagitan nina Blaze at Cipher)
  argD: [74, 50],
};
const EDGES: [string, string][] = [
  ['aD', 'L1'], ['nD', 'L5'], ['bD', 'R1'], ['cD', 'R5'],
  ['L1', 'L2'], ['L2', 'L3'], ['L3', 'L4'], ['L4', 'L5'], ['L5', 'L6'],
  ['R1', 'R2'], ['R2', 'R3'], ['R3', 'R4'], ['R4', 'R5'], ['R5', 'R6'],
  ['L2', 'H1'], ['H1', 'R2'], ['L4', 'H2'], ['H2', 'R4'], ['bossD', 'H1'],
  ['L3', 'labL'], ['R3', 'labR'], ['L6', 'barL'], ['R6', 'barR'],
  ['L6', 'L8'], ['R6', 'R8'], ['L8', 'sD'], ['L8', 'dnL'], ['R8', 'dnR'], ['R8', 'arD'],
  ['dnL', 'dnR'], // aisle ng Canteen: shortcut sa pagitan ng kaliwa at kanang hallway
  ['argD', 'R3'],
];
const NODES: Record<string, THREE.Vector3> = {};
Object.entries(NODE_PCT).forEach(([k, [x, y]]) => (NODES[k] = new THREE.Vector3(wx(x), 0, wz(y))));
const ADJ: Record<string, string[]> = {};
EDGES.forEach(([a, b]) => {
  (ADJ[a] ||= []).push(b);
  (ADJ[b] ||= []).push(a);
});

function entryNode(id: MemberId, place: Place, tgt: TeamId | null = null): string {
  if (id === 'argus') return place === 'lab' ? 'labR' : 'argD';
  if (id === 'it' && place === 'fix' && tgt) return tgt === 'boss' || tgt === 'sec' ? 'bossD' : { aria: 'aD', nova: 'nD', blaze: 'bD', cipher: 'cD' }[tgt];
  if (id === 'it') return place === 'dine' ? 'dnL' : place === 'play' ? 'arD' : 'sD';
  if (place === 'play') return 'arD';
  const left = id === 'aria' || id === 'nova' || id === 'boss' || id === 'sec';
  if (place === 'dine') return left ? 'dnL' : 'dnR';
  if (place === 'lab' || place === 'drop') return left ? 'labL' : 'labR';
  if (place === 'bar') return left ? 'barL' : 'barR';
  if (place === 'brief') return 'bossD';
  return { aria: 'aD', nova: 'nD', blaze: 'bD', cipher: 'cD', boss: 'bossD', sec: 'bossD' }[id];
}

function nearestNode(p: THREE.Vector3): string {
  let best = 'L3';
  let bd = Infinity;
  for (const [k, v] of Object.entries(NODES)) {
    const d = (v.x - p.x) ** 2 + (v.z - p.z) ** 2;
    if (d < bd) { bd = d; best = k; }
  }
  return best;
}

function graphPath(from: string, to: string): string[] {
  const dist: Record<string, number> = { [from]: 0 };
  const prev: Record<string, string> = {};
  const todo = new Set(Object.keys(NODES));
  while (todo.size) {
    let u: string | null = null;
    todo.forEach((k) => { if (dist[k] !== undefined && (u === null || dist[k] < dist[u])) u = k; });
    if (u === null) break;
    todo.delete(u);
    if (u === to) break;
    for (const v of ADJ[u] ?? []) {
      const nd = dist[u] + NODES[u].distanceTo(NODES[v]);
      if (dist[v] === undefined || nd < dist[v]) { dist[v] = nd; prev[v] = u; }
    }
  }
  const out = [to];
  while (out[0] !== from && prev[out[0]]) out.unshift(prev[out[0]]);
  return out;
}

const LAB_DETOUR = () => new THREE.Vector3(-4.4, 0, TABLE_C.z - 3.4);
const SEC_LAB_DETOUR = () => new THREE.Vector3(-7.5, 0, TABLE_C.z + 3.6);
/** Reel and Fixo join the meetings too: two extra chairs on the south side of the table. */
const LAB_SEATS_EXTRA = { reel: [-2.9, TABLE_C.z + 2.6], maint: [2.9, TABLE_C.z + 2.6] } as const;
const LAB_SOUTH_EAST = () => new THREE.Vector3(7.5, 0, TABLE_C.z + 3.6);
/** Si Argus ay sumasama rin sa meeting: upuan sa hilagang-silangan ng mesa (katapat ng upuan ni Reel/Fixo sa timog). */
const ARGUS_LAB_SEAT = [2.9, TABLE_C.z - 2.6] as const;
const LAB_NORTH_EAST = () => new THREE.Vector3(7.5, 0, TABLE_C.z - 3.6);
/** Daan papunta/mula sa sofa ng HQ ni Argus: iikot sa coffee table. */
const argusSofaWay = () => { const r = rb(ROOMS.argus); return new THREE.Vector3(r.x0 + 6.4, 0, r.z1 - 2.4); };

/** Mga puntong nasa loob ng kwarto (mula sa pinto papunta sa upuan) para hindi tumagos sa mesa o makina. */
function interior(id: MemberId, place: Place, tgt: TeamId | null = null): THREE.Vector3[] {
  // sa opisina ni Boss at ni Mira: lakad muna pababa mula sa pinto, saka pumunta sa gilid ng desk (hindi tumatagos sa upuan)
  if (id === 'it' && place === 'fix' && (tgt === 'boss' || tgt === 'sec')) return [new THREE.Vector3(fixSpot(tgt).x, 0, NODES.bossD.z - 0.8)];
  if (place === 'dine') return [new THREE.Vector3(DINE_SEATS[id][0], 0, ZDOOR)];
  if (place === 'play') return [new THREE.Vector3(PLAY_SPOTS[id][0], 0, ZDOOR)];
  return [];
}

function routeTo(id: MemberId, from: THREE.Vector3, fromPlace: Place, place: Place, midWalk: boolean, fromTgt: TeamId | null = null, toTgt: TeamId | null = null): THREE.Vector3[] {
  // desk ↔ sofa sa iisang office: diretso lang, hindi na lalabas ng pinto
  if (!midWalk && ((fromPlace === 'office' && place === 'rest') || (fromPlace === 'rest' && place === 'office'))) return id === 'argus' ? [argusSofaWay(), spotOf(id, place, toTgt)] : [spotOf(id, place, toTgt)];
  // leave through the door of the room we were in (or the nearest node if we were already walking)
  const start = midWalk ? nearestNode(from) : entryNode(id, fromPlace, fromTgt);
  const end = entryNode(id, place, toTgt);
  const pts: THREE.Vector3[] = [];
  if (!midWalk) interior(id, fromPlace, fromTgt).reverse().forEach((v) => pts.push(v));
  if (id === 'argus' && !midWalk && fromPlace === 'rest') pts.push(argusSofaWay());
  if (id === 'argus' && fromPlace === 'lab' && !midWalk) pts.push(LAB_NORTH_EAST());
  if (id === 'boss' && fromPlace === 'lab' && !midWalk) pts.push(LAB_DETOUR());
  if (id === 'sec' && fromPlace === 'lab' && !midWalk) pts.push(SEC_LAB_DETOUR());
  graphPath(start, end).forEach((k) => pts.push(NODES[k].clone()));
  if (id === 'argus' && place === 'lab') pts.push(LAB_NORTH_EAST());
  if (id === 'boss' && place === 'lab') pts.push(LAB_DETOUR());
  if (id === 'sec' && place === 'lab') pts.push(SEC_LAB_DETOUR());
  interior(id, place, toTgt).forEach((v) => pts.push(v));
  pts.push(spotOf(id, place, toTgt));
  return pts;
}

/* ------------------------------------------------------------------ *
 * Mesh helpers
 * ------------------------------------------------------------------ */
const mat = (color: THREE.ColorRepresentation, rough = 0.7, metal = 0.05) =>
  new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal });
const glowMat = (color: THREE.ColorRepresentation, intensity = 1.2) =>
  new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: intensity, roughness: 0.4 });

function box(parent: THREE.Object3D, w: number, h: number, d: number, m: THREE.Material, x = 0, y = 0, z = 0, shadow = true) {
  const mesh = new THREE.Mesh(new THREE.BoxGeometry(w, h, d), m);
  mesh.position.set(x, y, z);
  mesh.castShadow = shadow;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}
function cyl(parent: THREE.Object3D, rt: number, rb2: number, h: number, m: THREE.Material, x = 0, y = 0, z = 0, seg = 20) {
  const mesh = new THREE.Mesh(new THREE.CylinderGeometry(rt, rb2, h, seg), m);
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}
function sphere(parent: THREE.Object3D, r: number, m: THREE.Material, x = 0, y = 0, z = 0) {
  const mesh = new THREE.Mesh(new THREE.SphereGeometry(r, 16, 12), m);
  mesh.position.set(x, y, z);
  mesh.castShadow = true;
  parent.add(mesh);
  return mesh;
}

function canvasTex(w: number, h: number, draw: (c: CanvasRenderingContext2D) => void) {
  const cv = document.createElement('canvas');
  cv.width = w;
  cv.height = h;
  const c = cv.getContext('2d')!;
  draw(c);
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 4;
  return { cv, c, t };
}


/** Fine grain used as a bump map so carpets and rugs look woven instead of flat. */
let fabricBump: THREE.CanvasTexture | null = null;
function fabricBumpTex(): THREE.CanvasTexture {
  if (fabricBump) return fabricBump;
  const { t, c } = canvasTex(128, 128, (c2) => {
    c2.fillStyle = '#808080';
    c2.fillRect(0, 0, 128, 128);
    const img = c2.getImageData(0, 0, 128, 128);
    for (let i = 0; i < img.data.length; i += 4) {
      const x = (i / 4) % 128;
      const y = Math.floor(i / 4 / 128);
      const weave = ((x + (y % 2) * 2) % 4 < 2 ? 22 : -22) + (Math.random() - 0.5) * 70;
      const v = Math.max(0, Math.min(255, 128 + weave));
      img.data[i] = img.data[i + 1] = img.data[i + 2] = v;
    }
    c2.putImageData(img, 0, 0);
  });
  void c;
  t.colorSpace = THREE.NoColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(26, 26);
  fabricBump = t;
  return t;
}
const carpetMat = (color: THREE.ColorRepresentation) =>
  new THREE.MeshStandardMaterial({ color, roughness: 0.96, metalness: 0, bumpMap: fabricBumpTex(), bumpScale: 0.6 });

/** Soft round shadow under a character, so feet always look planted on the floor. */
let blobTex: THREE.CanvasTexture | null = null;
function contactShadow(parent: THREE.Object3D, size: number) {
  if (!blobTex) {
    blobTex = canvasTex(128, 128, (c) => {
      const g = c.createRadialGradient(64, 64, 4, 64, 64, 62);
      g.addColorStop(0, 'rgba(0,0,0,0.55)');
      g.addColorStop(0.55, 'rgba(0,0,0,0.22)');
      g.addColorStop(1, 'rgba(0,0,0,0)');
      c.fillStyle = g;
      c.fillRect(0, 0, 128, 128);
    }).t;
  }
  const m = new THREE.Mesh(new THREE.PlaneGeometry(size, size), new THREE.MeshBasicMaterial({ map: blobTex, transparent: true, depthWrite: false, toneMapped: false }));
  m.rotation.x = -Math.PI / 2;
  m.position.y = 0.1;
  m.renderOrder = 2;
  parent.add(m);
  return m;
}

/* ------------------------------------------------------------------ *
 * Furniture
 * ------------------------------------------------------------------ */
interface Screen { c: CanvasRenderingContext2D; t: THREE.CanvasTexture; color: string }

function makeDesk(parent: THREE.Object3D, x: number, z: number, accent: string, dual: boolean, screens: Screen[]) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  const wood = mat(dual ? '#6b4423' : '#5a3d2b', 0.55);
  const w = dual ? 4.6 : 3.4;
  box(g, w, 0.14, 1.7, wood, 0, 1.05, 0);
  box(g, 0.14, 1.0, 1.6, mat('#2a1b13'), -w / 2 + 0.1, 0.5, 0);
  box(g, 0.14, 1.0, 1.6, mat('#2a1b13'), w / 2 - 0.1, 0.5, 0);
  box(g, w - 0.3, 0.7, 0.08, mat('#2a1b13'), 0, 0.65, -0.7);
  box(g, w, 0.035, 0.035, glowMat(accent, 1.6), 0, 0.98, 0.86, false);
  const monX = dual ? [-1.2, 1.2] : [0];
  monX.forEach((mx) => {
    cyl(g, 0.09, 0.09, 0.42, mat('#15181f', 0.4, 0.6), mx, 1.33, -0.35);
    cyl(g, 0.4, 0.45, 0.05, mat('#15181f', 0.4, 0.6), mx, 1.14, -0.35);
    box(g, 1.75, 1.0, 0.07, mat('#0c0f15', 0.3, 0.5), mx, 2.0, -0.4);
    const { c, t } = canvasTex(192, 108, () => undefined);
    const screen = new THREE.Mesh(new THREE.PlaneGeometry(1.65, 0.9), new THREE.MeshBasicMaterial({ map: t, toneMapped: false }));
    screen.position.set(mx, 2.0, -0.36);
    g.add(screen);
    screens.push({ c, t, color: accent });
  });
  box(g, 1.1, 0.04, 0.38, mat('#10141c', 0.4, 0.4), 0, 1.14, 0.4);
  box(g, 1.1, 0.012, 0.38, glowMat(accent, 0.9), 0, 1.165, 0.4, false);
  box(g, 0.2, 0.05, 0.3, mat('#10141c'), 1.0, 1.14, 0.45);
  cyl(g, 0.12, 0.1, 0.24, mat('#f3f4f6', 0.4), w / 2 - 0.5, 1.24, 0.1);
  // desk lamp
  cyl(g, 0.16, 0.2, 0.05, mat('#222833'), -w / 2 + 0.45, 1.15, -0.2);
  cyl(g, 0.025, 0.025, 0.7, mat('#222833'), -w / 2 + 0.45, 1.5, -0.2);
  const head = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.28, 16), glowMat('#ffd9a0', 1.1));
  head.position.set(-w / 2 + 0.6, 1.88, -0.1);
  head.rotation.z = 0.5;
  g.add(head);
  parent.add(g);
}

function makeChair(parent: THREE.Object3D, x: number, z: number, color: string, rotY = 0) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rotY;
  const m = mat(color, 0.8);
  box(g, 1.15, 0.16, 1.1, m, 0, 0.85, 0);
  box(g, 1.1, 1.15, 0.14, m, 0, 1.45, 0.55);
  cyl(g, 0.07, 0.07, 0.6, mat('#0c0f15', 0.3, 0.7), 0, 0.5, 0);
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI * 2;
    box(g, 0.7, 0.06, 0.1, mat('#0c0f15', 0.3, 0.7), Math.cos(a) * 0.3, 0.22, Math.sin(a) * 0.3).rotation.y = -a;
  }
  parent.add(g);
}

function makePlant(parent: THREE.Object3D, x: number, z: number, s = 1) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.scale.setScalar(s);
  cyl(g, 0.5, 0.38, 0.8, mat('#e5e7eb', 0.5), 0, 0.4, 0);
  cyl(g, 0.46, 0.46, 0.05, mat('#3b2a1c'), 0, 0.8, 0);
  const greens = ['#2f9e5a', '#3fb86d', '#238a4a'];
  for (let i = 0; i < 9; i++) {
    const a = (i / 9) * Math.PI * 2;
    const leaf = sphere(g, 0.42, mat(greens[i % 3], 0.8), Math.cos(a) * 0.35, 1.3 + (i % 3) * 0.3, Math.sin(a) * 0.35);
    leaf.scale.set(1, 1.5, 0.7);
    leaf.rotation.y = a;
  }
  parent.add(g);
}

function makeShelf(parent: THREE.Object3D, x: number, z: number, rotY = 0, w = 2.8) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rotY;
  const m = mat('#3b2a1e', 0.6);
  box(g, w, 3.4, 0.6, m, 0, 1.7, 0);
  for (let s = 0; s < 4; s++) {
    box(g, w - 0.2, 0.06, 0.55, mat('#4b3626'), 0, 0.4 + s * 0.8, 0.02);
    let px = -w / 2 + 0.25;
    while (px < w / 2 - 0.35) {
      const bw = 0.12 + Math.random() * 0.16;
      const bh = 0.45 + Math.random() * 0.25;
      box(g, bw, bh, 0.4, mat(new THREE.Color().setHSL(Math.random(), 0.55, 0.45)), px + bw / 2, 0.43 + s * 0.8 + bh / 2, 0.06, false);
      px += bw + 0.03;
    }
  }
  parent.add(g);
}

function makeSofa(parent: THREE.Object3D, x: number, z: number, rotY: number, color: string, w = 3.6) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rotY;
  const m = mat(color, 0.9);
  box(g, w, 0.7, 1.4, m, 0, 0.55, 0);
  box(g, w, 1.1, 0.35, m, 0, 1.25, -0.55);
  box(g, 0.35, 0.95, 1.4, m, -w / 2 + 0.17, 0.95, 0);
  box(g, 0.35, 0.95, 1.4, m, w / 2 - 0.17, 0.95, 0);
  box(g, w - 0.8, 0.22, 1.0, mat(color, 0.95), 0, 1.0, 0.1);
  parent.add(g);
}

function makeCabinet(parent: THREE.Object3D, x: number, z: number, rotY = 0) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rotY;
  box(g, 1.3, 2.0, 0.8, mat('#5b6577', 0.5, 0.3), 0, 1.0, 0);
  [0.5, 1.0, 1.5].forEach((y) => box(g, 0.5, 0.06, 0.04, mat('#cbd5e1', 0.3, 0.8), 0, y, 0.42, false));
  parent.add(g);
}

function makeRug(parent: THREE.Object3D, x: number, z: number, w: number, d: number, color: string) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, 0.04, d), carpetMat(color));
  m.position.set(x, 0.07, z);
  m.receiveShadow = true;
  parent.add(m);
  const edge = new THREE.Mesh(new THREE.BoxGeometry(w - 0.4, 0.045, d - 0.4), carpetMat(new THREE.Color(color).multiplyScalar(0.7)));
  edge.position.set(x, 0.075, z);
  parent.add(edge);
}

function makeArt(parent: THREE.Object3D, x: number, y: number, z: number, w: number, h: number, hue: number, rotY = 0) {
  const { t } = canvasTex(128, 128, (c) => {
    const g = c.createLinearGradient(0, 0, 128, 128);
    g.addColorStop(0, `hsl(${hue},70%,55%)`);
    g.addColorStop(1, `hsl(${(hue + 60) % 360},70%,30%)`);
    c.fillStyle = g;
    c.fillRect(0, 0, 128, 128);
    c.fillStyle = 'rgba(255,255,255,0.18)';
    c.beginPath(); c.arc(80, 50, 30, 0, 6.28); c.fill();
    c.fillRect(10, 90, 100, 14);
  });
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.rotation.y = rotY;
  box(g, w + 0.12, h + 0.12, 0.08, mat('#111827'), 0, 0, 0, false);
  const p = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: t }));
  p.position.z = 0.05;
  g.add(p);
  parent.add(g);
}

function rbox(parent: THREE.Object3D, w: number, h: number, d: number, r: number, m: THREE.Material, x = 0, y = 0, z = 0, shadow = true) {
  const mesh = new THREE.Mesh(new RoundedBoxGeometry(w, h, d, 3, r), m);
  mesh.position.set(x, y, z);
  mesh.castShadow = shadow;
  mesh.receiveShadow = true;
  parent.add(mesh);
  return mesh;
}

function makeRunner(parent: THREE.Object3D, x: number, z: number, w: number, d: number, color: string) {
  const m = new THREE.Mesh(new THREE.BoxGeometry(w, 0.03, d), carpetMat(color));
  m.position.set(x, 0.02, z);
  m.receiveShadow = true;
  parent.add(m);
}

function makeGuide(parent: THREE.Object3D, x: number, z: number, w: number, d: number, color: string) {
  box(parent, w, 0.02, d, glowMat(color, 1.2), x, 0.045, z, false);
}

function makeCoffeeTable(parent: THREE.Object3D, x: number, z: number, w = 2.6, d = 1.3, rotY = 0) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rotY;
  box(g, w, 0.1, d, mat('#d9c7a6', 0.4), 0, 0.72, 0);
  ([[-1, -1], [1, -1], [-1, 1], [1, 1]] as [number, number][]).forEach(([sx, sz]) =>
    box(g, 0.08, 0.7, 0.08, mat('#222833', 0.4, 0.6), sx * (w / 2 - 0.15), 0.35, sz * (d / 2 - 0.15), false));
  cyl(g, 0.12, 0.1, 0.18, mat('#ffffff', 0.4), -w * 0.2, 0.85, 0);
  box(g, 0.5, 0.04, 0.35, mat('#38bdf8', 0.5), w * 0.15, 0.79, 0.05, false);
  parent.add(g);
}

function makeFloorLamp(parent: THREE.Object3D, x: number, z: number, color = '#ffd9a0') {
  cyl(parent, 0.28, 0.3, 0.06, mat('#222833', 0.4, 0.6), x, 0.03, z);
  cyl(parent, 0.04, 0.04, 3.0, mat('#222833', 0.4, 0.6), x, 1.5, z, 8);
  const shade = new THREE.Mesh(
    new THREE.CylinderGeometry(0.3, 0.42, 0.55, 16, 1, true),
    new THREE.MeshStandardMaterial({ color, emissive: color, emissiveIntensity: 0.9, side: THREE.DoubleSide }),
  );
  shade.position.set(x, 3.1, z);
  parent.add(shade);
}

function makeCooler(parent: THREE.Object3D, x: number, z: number, rotY = 0) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rotY;
  box(g, 0.9, 1.5, 0.9, mat('#e5e7eb', 0.4), 0, 0.75, 0);
  cyl(g, 0.34, 0.34, 0.85, physMat({ color: '#93c5fd', transparent: true, opacity: 0.55, roughness: 0.1 }), 0, 1.95, 0);
  box(g, 0.16, 0.1, 0.04, glowMat('#38bdf8', 1.4), -0.17, 1.2, 0.46, false);
  box(g, 0.16, 0.1, 0.04, glowMat('#f87171', 1.4), 0.17, 1.2, 0.46, false);
  parent.add(g);
}

function makePrinter(parent: THREE.Object3D, x: number, z: number, rotY = 0) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rotY;
  box(g, 2.0, 1.0, 1.2, mat('#374151', 0.5, 0.3), 0, 0.5, 0);
  rbox(g, 1.6, 0.6, 1.0, 0.1, mat('#e5e7eb', 0.4, 0.1), 0, 1.3, 0);
  box(g, 1.2, 0.05, 0.7, mat('#0b0f17'), 0, 1.62, 0.05, false);
  box(g, 0.35, 0.07, 0.04, glowMat('#34d399', 1.6), 0.5, 1.38, 0.52, false);
  parent.add(g);
}

function makeRack(parent: THREE.Object3D, x: number, z: number, rotY = 0, leds?: THREE.Mesh[]) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rotY;
  box(g, 1.3, 3.2, 1.1, mat('#12161f', 0.4, 0.5), 0, 1.6, 0);
  const ledColors = ['#34d399', '#38bdf8', '#fbbf24'];
  for (let i = 0; i < 8; i++) {
    box(g, 1.1, 0.18, 0.04, mat('#1c2230', 0.4, 0.5), 0, 0.4 + i * 0.36, 0.56, false);
    for (let k = 0; k < 3; k++) {
      const led = box(g, 0.06, 0.06, 0.03, glowMat(ledColors[(i + k) % 3], 1.6), -0.35 + k * 0.14, 0.4 + i * 0.36, 0.59, false);
      leds?.push(led);
    }
  }
  parent.add(g);
}

function makeDeskPlant(parent: THREE.Object3D, x: number, y: number, z: number, s = 1) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.scale.setScalar(s);
  cyl(g, 0.22, 0.17, 0.3, mat('#f3f4f6', 0.5), 0, 0.15, 0);
  ([[0, 0.55, 0], [0.14, 0.45, 0.05], [-0.14, 0.48, -0.04]] as [number, number, number][]).forEach(([px, py, pz]) =>
    sphere(g, 0.18, mat('#2f9e5a', 0.8), px, py, pz));
  parent.add(g);
}

/** Bangko (bar stool) sa mini bar. Seat top = 0.93, kapantay ng upuan ng mga bot. */
function makeStool(parent: THREE.Object3D, x: number, z: number, color: THREE.ColorRepresentation) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  const chrome = mat('#aeb6c2', 0.25, 0.9);
  cyl(g, 0.46, 0.46, 0.16, mat(color, 0.75), 0, 0.85, 0);
  cyl(g, 0.4, 0.4, 0.05, chrome, 0, 0.74, 0);
  cyl(g, 0.06, 0.06, 0.72, chrome, 0, 0.38, 0, 10);
  const foot = new THREE.Mesh(new THREE.TorusGeometry(0.33, 0.03, 8, 24), chrome);
  foot.rotation.x = Math.PI / 2;
  foot.position.y = 0.36;
  g.add(foot);
  cyl(g, 0.42, 0.46, 0.06, mat('#1a1410', 0.5, 0.4), 0, 0.03, 0);
  parent.add(g);
}

/** Texture ng dyaryo (masthead, larawan, mga column ng text). */
const paperTexCache: THREE.CanvasTexture[] = [];
function newspaperTex(variant = 0): THREE.CanvasTexture {
  const v = ((variant % 3) + 3) % 3;
  if (paperTexCache[v]) return paperTexCache[v];
  const names = ['ANG BALITA', 'DIYARYONG BAYAN', 'DAILY BYTES'];
  const heads = ['BREAKING: KAPE, TUMAAS!', 'BOT NG OPISINA, VIRAL', 'IDEA, PUMASOK SA PORTAL'];
  const { t } = canvasTex(256, 320, (c) => {
    c.fillStyle = '#efe9d8';
    c.fillRect(0, 0, 256, 320);
    c.fillStyle = '#1f2937';
    c.textAlign = 'center';
    c.font = 'bold 28px serif';
    c.fillText(names[v], 128, 38);
    c.fillRect(12, 48, 232, 3);
    c.font = 'bold 15px serif';
    c.fillText(heads[v], 128, 72);
    c.fillStyle = '#9ca3af';
    c.fillRect(14, 86, 104, 78);
    c.fillStyle = '#6b7280';
    c.fillRect(24, 124, 84, 30);
    c.fillStyle = '#4b5563';
    for (let i = 0; i < 6; i++) c.fillRect(128, 90 + i * 13, 112, 5);
    for (let col = 0; col < 3; col++) {
      for (let i = 0; i < 11; i++) c.fillRect(14 + col * 80, 178 + i * 12, 70 - ((i * 7 + col * 5) % 20), 4);
    }
  });
  paperTexCache[v] = t;
  return t;
}

/** Report folder ng secretary (buod ng mga idea). */
let reportTexCache: THREE.CanvasTexture | null = null;
function reportTex(): THREE.CanvasTexture {
  if (reportTexCache) return reportTexCache;
  const { t } = canvasTex(256, 320, (c) => {
    c.fillStyle = '#fdf2f8';
    c.fillRect(0, 0, 256, 320);
    c.fillStyle = '#db2777';
    c.fillRect(0, 0, 256, 52);
    c.fillStyle = '#ffffff';
    c.font = 'bold 22px sans-serif';
    c.textAlign = 'center';
    c.fillText('IDEA SUMMARY', 128, 34);
    c.textAlign = 'left';
    c.font = '20px sans-serif';
    for (let i = 0; i < 5; i++) {
      c.fillStyle = '#be185d';
      c.fillText('💡', 14, 100 + i * 44);
      c.fillStyle = '#9d174d';
      c.fillRect(50, 82 + i * 44, 180 - ((i * 23) % 60), 6);
      c.fillStyle = '#f9a8d4';
      c.fillRect(50, 96 + i * 44, 140 - ((i * 17) % 40), 4);
    }
  });
  reportTexCache = t;
  return t;
}

/** Nakalatag na dyaryo (nakatupi) sa counter o mesa. */
function makeNewspaperFlat(parent: THREE.Object3D, x: number, y: number, z: number, rotY: number, variant = 0) {
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.rotation.y = rotY;
  box(g, 0.95, 0.03, 1.2, mat('#e9e3d1', 0.9), 0, 0.015, 0, false);
  box(g, 0.95, 0.03, 1.2, mat('#ddd6c1', 0.9), 0.05, 0.045, 0.04, false).rotation.y = 0.12;
  const top = new THREE.Mesh(new THREE.PlaneGeometry(0.95, 1.2), new THREE.MeshBasicMaterial({ map: newspaperTex(variant), toneMapped: false }));
  top.rotation.x = -Math.PI / 2;
  top.rotation.z = 0.12;
  top.position.set(0.05, 0.063, 0.04);
  g.add(top);
  parent.add(g);
}

/**
 * Malaking umiilaw na bilog (hologram) sa ibabaw ng mesa ng Shared Brain.
 * - drop(): lumilipad ang idea card ng empleyado papasok sa gitna ng bilog
 * - collect(): kinukuha ng secretary ang mga idea (lumilipad palabas papunta sa kanya)
 * - kapag meeting, naglalabas ng idea card ang bawat nakaupong bot (loop)
 */
function makeIdeaPortal(parent: THREE.Object3D, cx: number, cz: number) {
  const Y = 2.9;
  const R = 4.1; // mas malaking bilog (dati 2.5)
  const GR = 2.5; // radius ng globe hologram
  const GY = Y + 4.3; // taas ng gitna ng globe
  const violet = '#a78bfa';
  const g = new THREE.Group();
  g.position.set(cx, 0, cz);
  parent.add(g);

  // emitter sa mesa
  cyl(g, 0.75, 0.9, 0.14, mat('#1b1430', 0.3, 0.7), 0, 1.25, 0);
  const padRing = new THREE.Mesh(new THREE.TorusGeometry(0.78, 0.035, 8, 40), glowMat(violet, 2));
  padRing.rotation.x = Math.PI / 2;
  padRing.position.y = 1.33;
  g.add(padRing);

  // sinag mula sa mesa papunta sa bilog
  const beamMat = new THREE.MeshBasicMaterial({ color: violet, transparent: true, opacity: 0.16, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide, toneMapped: false });
  const beam = new THREE.Mesh(new THREE.CylinderGeometry(R * 0.55, 0.75, Y - 1.33, 48, 1, true), beamMat);
  beam.position.y = (Y + 1.33) / 2;
  g.add(beam);

  // malaking bilog (dalawang disc na magkasalungat ang ikot)
  const discTexA = canvasTex(512, 512, (c) => {
    const m = 256;
    const grd = c.createRadialGradient(m, m, 10, m, m, 246);
    grd.addColorStop(0, 'rgba(167,139,250,0.55)');
    grd.addColorStop(0.6, 'rgba(124,58,237,0.2)');
    grd.addColorStop(1, 'rgba(124,58,237,0.05)');
    c.fillStyle = grd;
    c.beginPath(); c.arc(m, m, 246, 0, Math.PI * 2); c.fill();
    c.strokeStyle = 'rgba(221,214,254,0.95)';
    c.lineWidth = 7;
    c.beginPath(); c.arc(m, m, 244, 0, Math.PI * 2); c.stroke();
    c.lineWidth = 2;
    [214, 170, 120].forEach((r) => { c.beginPath(); c.arc(m, m, r, 0, Math.PI * 2); c.stroke(); });
    for (let i = 0; i < 72; i++) {
      const a = (i / 72) * Math.PI * 2;
      const r2 = i % 6 === 0 ? 204 : 218;
      c.beginPath(); c.moveTo(m + Math.cos(a) * 230, m + Math.sin(a) * 230); c.lineTo(m + Math.cos(a) * r2, m + Math.sin(a) * r2); c.stroke();
    }
    c.setLineDash([14, 10]);
    c.beginPath(); c.arc(m, m, 192, 0, Math.PI * 2); c.stroke();
    c.setLineDash([]);
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2;
      c.beginPath(); c.moveTo(m + Math.cos(a) * 60, m + Math.sin(a) * 60); c.lineTo(m + Math.cos(a) * 118, m + Math.sin(a) * 118); c.stroke();
    }
    c.fillStyle = 'rgba(221,214,254,0.9)';
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      c.fillRect(m + Math.cos(a) * 150 - 9, m + Math.sin(a) * 150 - 9, 18, 18);
    }
  });
  const discTexB = canvasTex(512, 512, (c) => {
    const m = 256;
    c.strokeStyle = 'rgba(196,181,253,0.95)';
    c.lineCap = 'round';
    c.lineWidth = 12;
    for (let i = 0; i < 4; i++) {
      const a0 = (i / 4) * Math.PI * 2 + 0.2;
      c.beginPath(); c.arc(m, m, 236, a0, a0 + 1.0); c.stroke();
    }
    c.lineWidth = 5;
    for (let i = 0; i < 6; i++) {
      const a0 = (i / 6) * Math.PI * 2;
      c.beginPath(); c.arc(m, m, 200, a0, a0 + 0.55); c.stroke();
    }
  });
  const discMat = (tex: THREE.CanvasTexture) => new THREE.MeshBasicMaterial({ map: tex, transparent: true, side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false, opacity: 0.6 });
  const matA = discMat(discTexA.t);
  const matB = discMat(discTexB.t);
  const spinA = new THREE.Group();
  const spinB = new THREE.Group();
  spinA.position.y = Y;
  spinB.position.y = Y + 0.05;
  const discA = new THREE.Mesh(new THREE.CircleGeometry(R, 64), matA);
  const discB = new THREE.Mesh(new THREE.CircleGeometry(R * 0.9, 64), matB);
  discA.rotation.x = -Math.PI / 2;
  discB.rotation.x = -Math.PI / 2;
  spinA.add(discA);
  spinB.add(discB);
  g.add(spinA, spinB);

  // umiilaw na gilid ng bilog
  const rim = new THREE.Mesh(new THREE.TorusGeometry(R, 0.05, 10, 80), glowMat('#c4b5fd', 2.2));
  rim.rotation.x = Math.PI / 2;
  rim.position.y = Y;
  g.add(rim);
  const rim2 = new THREE.Mesh(new THREE.TorusGeometry(R * 0.55, 0.03, 10, 60), glowMat(violet, 1.8));
  rim2.rotation.x = Math.PI / 2;
  rim2.position.y = Y;
  g.add(rim2);

  // orb ng idea sa gitna (dito pumapasok ang mga idea)
  const orbMat = new THREE.MeshStandardMaterial({ color: '#ede9fe', emissive: '#a78bfa', emissiveIntensity: 2, transparent: true, opacity: 0.85 });
  const orb = new THREE.Mesh(new THREE.SphereGeometry(0.5, 24, 18), orbMat);
  orb.position.y = GY;
  g.add(orb);
  const core = new THREE.Mesh(new THREE.SphereGeometry(0.22, 14, 12), new THREE.MeshBasicMaterial({ color: '#ffffff', toneMapped: false }));
  core.position.copy(orb.position);
  g.add(core);


  /* ================= GLOBE HOLOGRAM (world map + mga node) ================= */
  const UP = new THREE.Vector3(0, 1, 0);
  const ll2v = (lon: number, lat: number, r = 1) => {
    const phi = ((lon + 180) * Math.PI) / 180;
    const th = (lat * Math.PI) / 180;
    return new THREE.Vector3(-Math.cos(phi) * Math.cos(th) * r, Math.sin(th) * r, Math.sin(phi) * Math.cos(th) * r);
  };
  // magaspang na hugis ng mga kontinente [lon, lat]
  const LAND: [number, number][][] = [
    [[-168, 66], [-140, 70], [-95, 72], [-65, 60], [-55, 48], [-70, 42], [-80, 32], [-80, 25], [-90, 29], [-97, 26], [-105, 22], [-95, 16], [-85, 12], [-78, 8], [-85, 10], [-105, 20], [-118, 32], [-124, 42], [-125, 50], [-140, 60]],
    [[-55, 60], [-45, 60], [-20, 70], [-20, 82], [-60, 82], [-70, 76]],
    [[-78, 8], [-62, 10], [-50, 0], [-35, -6], [-40, -22], [-48, -28], [-58, -38], [-66, -50], [-72, -54], [-74, -40], [-71, -20], [-81, -5]],
    [[-10, 36], [-9, 43], [-2, 48], [5, 52], [8, 57], [5, 62], [15, 69], [30, 71], [40, 66], [40, 55], [30, 45], [28, 41], [22, 37], [12, 38], [5, 43], [-5, 36]],
    [[-17, 21], [-10, 30], [-5, 36], [10, 37], [32, 31], [43, 12], [51, 12], [40, -5], [40, -16], [35, -25], [20, -35], [18, -32], [12, -18], [9, -1], [8, 5], [-8, 4], [-17, 14]],
    [[28, 41], [40, 55], [40, 66], [60, 70], [100, 77], [140, 72], [180, 68], [165, 60], [140, 52], [142, 46], [130, 36], [122, 30], [120, 22], [108, 10], [104, 1], [98, 8], [92, 20], [80, 8], [73, 18], [68, 24], [57, 25], [48, 30], [36, 36]],
    [[35, 30], [48, 30], [57, 25], [59, 22], [52, 16], [43, 12], [35, 28]],
    [[114, -22], [122, -18], [136, -12], [142, -11], [153, -26], [150, -37], [140, -38], [131, -31], [115, -34]],
    [[117, 7], [126, 9], [125, 1], [118, -3], [110, 0]], // Borneo/Pilipinas area
    [[119, 18], [122, 18.5], [124, 12], [126, 7], [122, 6], [120, 13]], // Pilipinas
    [[95, 5], [105, -6], [114, -8], [106, -2]], // Sumatra/Java
  ];
  const inPoly = (poly: [number, number][], x: number, y: number) => {
    let inside = false;
    for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
      const [xi, yi] = poly[i];
      const [xj, yj] = poly[j];
      if (yi > y !== yj > y && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
    }
    return inside;
  };
  const MW = 2048;
  const MH = 1024;
  const mapTex = canvasTex(MW, MH, (c) => {
    c.fillStyle = 'rgba(40,14,110,0.30)';
    c.fillRect(0, 0, MW, MH);
    c.strokeStyle = 'rgba(196,181,253,0.7)';
    c.lineWidth = 2.5;
    for (let lon = -180; lon <= 180; lon += 15) { const x = ((lon + 180) / 360) * MW; c.beginPath(); c.moveTo(x, 0); c.lineTo(x, MH); c.stroke(); }
    for (let lat = -75; lat <= 75; lat += 15) { const y = ((90 - lat) / 180) * MH; c.beginPath(); c.moveTo(0, y); c.lineTo(MW, y); c.stroke(); }
    c.strokeStyle = 'rgba(255,255,255,0.95)';
    c.lineWidth = 4;
    const ey = MH / 2; c.beginPath(); c.moveTo(0, ey); c.lineTo(MW, ey); c.stroke();
    c.shadowColor = '#c4b5fd';
    c.shadowBlur = 12;
    c.fillStyle = 'rgba(245,243,255,1)';
    const step = 13;
    for (let y = step / 2; y < MH; y += step) {
      const lat = 90 - (y / MH) * 180;
      for (let x = step / 2; x < MW; x += step) {
        const lon = (x / MW) * 360 - 180;
        if (LAND.some((pl) => inPoly(pl, lon, lat))) { c.beginPath(); c.arc(x, y, 3.8, 0, Math.PI * 2); c.fill(); }
      }
    }
  });
  const additive = { transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false } as const;
  const globeRoot = new THREE.Group();
  globeRoot.position.y = GY;
  globeRoot.rotation.z = 0.32;
  g.add(globeRoot);
  const spin = new THREE.Group();
  globeRoot.add(spin);
  const mapMat = new THREE.MeshBasicMaterial({ map: mapTex.t, side: THREE.DoubleSide, opacity: 1, ...additive });
  spin.add(new THREE.Mesh(new THREE.SphereGeometry(GR, COARSE ? 44 : 72, COARSE ? 32 : 54), mapMat));
  const shellMat = new THREE.MeshBasicMaterial({ color: '#7c3aed', opacity: 0.2, ...additive });
  globeRoot.add(new THREE.Mesh(new THREE.SphereGeometry(GR * 0.985, 40, 30), shellMat));
  const atmoMat = new THREE.MeshBasicMaterial({ color: '#c4b5fd', opacity: 0.2, side: THREE.BackSide, ...additive });
  globeRoot.add(new THREE.Mesh(new THREE.SphereGeometry(GR * 1.1, 40, 30), atmoMat));

  // nakakasilaw na halo (laging nakaharap sa camera)
  const haloTex = canvasTex(256, 256, (c) => {
    const gr = c.createRadialGradient(128, 128, 0, 128, 128, 128);
    gr.addColorStop(0, 'rgba(255,255,255,1)');
    gr.addColorStop(0.18, 'rgba(233,223,255,0.85)');
    gr.addColorStop(0.5, 'rgba(139,92,246,0.35)');
    gr.addColorStop(1, 'rgba(139,92,246,0)');
    c.fillStyle = gr;
    c.fillRect(0, 0, 256, 256);
  });
  const halo = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloTex.t, opacity: 0.7, ...additive }));
  halo.position.y = GY;
  g.add(halo);
  const flare = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloTex.t, opacity: 0.8, color: '#ffffff', ...additive }));
  flare.position.y = GY;
  g.add(flare);
  const globeLight = new THREE.PointLight('#a78bfa', 0, 46, 1.4);
  globeLight.position.y = GY;
  if (!COARSE) g.add(globeLight); // phones: the halo sprite already glows, a 13th real light is what made the GPU choke

  // scanning ring na dumadaan pataas-pababa sa globe
  const scan = new THREE.Mesh(new THREE.TorusGeometry(GR * 1.02, 0.03, 8, 96), new THREE.MeshBasicMaterial({ color: '#ffffff', opacity: 0.95, ...additive }));
  scan.rotation.x = Math.PI / 2;
  globeRoot.add(scan);
  // orbit rings + satellites
  const orbits = [
    { r: GR * 1.4, tilt: [1.2, 0.2], speed: 0.7, color: '#67e8f9' },
    { r: GR * 1.65, tilt: [0.5, -0.4], speed: -0.45, color: '#f0abfc' },
  ].map((o) => {
    const holder = new THREE.Group();
    holder.rotation.set(o.tilt[0], 0, o.tilt[1]);
    globeRoot.add(holder);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(o.r, 0.022, 8, 120), new THREE.MeshBasicMaterial({ color: o.color, opacity: 0.7, ...additive }));
    ring.rotation.x = Math.PI / 2;
    holder.add(ring);
    const arm = new THREE.Group();
    holder.add(arm);
    const sat = new THREE.Mesh(new THREE.SphereGeometry(0.13, 12, 10), new THREE.MeshBasicMaterial({ color: o.color, toneMapped: false }));
    sat.position.x = o.r;
    arm.add(sat);
    const satGlow = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloTex.t, color: o.color, opacity: 0.9, ...additive }));
    satGlow.scale.setScalar(0.9);
    satGlow.position.x = o.r;
    arm.add(satGlow);
    return { arm, speed: o.speed };
  });
  // haligi ng liwanag mula sa bilog papunta sa globe
  const pillarMat = new THREE.MeshBasicMaterial({ color: '#c4b5fd', opacity: 0.2, side: THREE.DoubleSide, ...additive });
  const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.5, 1.9, GY - GR - Y, 40, 1, true), pillarMat);
  pillar.position.y = (Y + GY - GR) / 2;
  g.add(pillar);

  // mga node: pop-up + tumatangkad na tower + pulse ring
  const CITIES: { lon: number; lat: number; color: string; perm?: boolean }[] = [
    { lon: 121, lat: 14.5, color: '#fde68a', perm: true }, // Manila / Pilipinas
    { lon: -74, lat: 40.7, color: '#67e8f9' }, { lon: 0, lat: 51.5, color: '#f0abfc' }, { lon: 139.7, lat: 35.7, color: '#c4b5fd' },
    { lon: 151, lat: -33.9, color: '#67e8f9' }, { lon: -46.6, lat: -23.5, color: '#f0abfc' }, { lon: 55.3, lat: 25.2, color: '#c4b5fd' },
    { lon: 18.4, lat: -33.9, color: '#67e8f9' }, { lon: -118, lat: 34, color: '#f0abfc' }, { lon: 103.8, lat: 1.35, color: '#c4b5fd' },
    { lon: 37.6, lat: 55.7, color: '#67e8f9' }, { lon: 72.9, lat: 19, color: '#f0abfc' }, { lon: 13.4, lat: 52.5, color: '#c4b5fd' },
    { lon: -99, lat: 19.4, color: '#67e8f9' }, { lon: 127, lat: 37.5, color: '#f0abfc' }, { lon: 3.4, lat: 6.5, color: '#c4b5fd' },
  ];
  const nodes = CITIES.map((cty, i) => {
    const n = ll2v(cty.lon, cty.lat, 1);
    const grp = new THREE.Group();
    grp.position.copy(n).multiplyScalar(GR);
    grp.quaternion.setFromUnitVectors(UP, n);
    spin.add(grp);
    const big = !!cty.perm;
    const dot = new THREE.Mesh(new THREE.SphereGeometry(big ? 0.13 : 0.085, 14, 12), new THREE.MeshBasicMaterial({ color: '#ffffff', toneMapped: false }));
    grp.add(dot);
    const dotGlow = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloTex.t, color: cty.color, opacity: 0.95, ...additive }));
    grp.add(dotGlow);
    const tg = new THREE.CylinderGeometry(big ? 0.05 : 0.035, big ? 0.075 : 0.055, 1, 10, 1, true);
    tg.translate(0, 0.5, 0);
    const tower = new THREE.Mesh(tg, new THREE.MeshBasicMaterial({ color: cty.color, opacity: 0.9, side: THREE.DoubleSide, ...additive }));
    grp.add(tower);
    const cap = new THREE.Mesh(new THREE.SphereGeometry(big ? 0.15 : 0.1, 12, 10), new THREE.MeshBasicMaterial({ color: '#ffffff', toneMapped: false }));
    grp.add(cap);
    const capGlow = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloTex.t, color: cty.color, opacity: 1, ...additive }));
    cap.add(capGlow);
    const pulse = new THREE.Mesh(new THREE.RingGeometry(0.1, 0.14, 32), new THREE.MeshBasicMaterial({ color: cty.color, opacity: 0, side: THREE.DoubleSide, ...additive }));
    pulse.rotation.x = -Math.PI / 2;
    pulse.position.y = 0.02;
    grp.add(pulse);
    return { dot, dotGlow, tower, cap, capGlow, pulse, big, perm: big, h: big ? 1.9 : 0.55 + ((i * 37) % 10) / 10 * 0.9, off: (i * 0.137) % 1 };
  });
  // mga arc ng koneksyon + lumilipad na liwanag
  const LINKS: [number, number][] = [[0, 3], [0, 9], [0, 4], [0, 6], [0, 8], [0, 2], [1, 2], [2, 6], [3, 8], [5, 15], [1, 13], [11, 6]];
  const arcs = LINKS.map(([a, b], i) => {
    const na = ll2v(CITIES[a].lon, CITIES[a].lat, 1);
    const nb = ll2v(CITIES[b].lon, CITIES[b].lat, 1);
    const mid = na.clone().add(nb).normalize().multiplyScalar(GR * (1.12 + na.distanceTo(nb) * 0.32));
    const curve = new THREE.QuadraticBezierCurve3(na.clone().multiplyScalar(GR), mid, nb.clone().multiplyScalar(GR));
    const line = new THREE.Line(new THREE.BufferGeometry().setFromPoints(curve.getPoints(56)), new THREE.LineBasicMaterial({ color: CITIES[b].color, opacity: 0.55, ...additive }));
    spin.add(line);
    const glowSp = new THREE.Sprite(new THREE.SpriteMaterial({ map: haloTex.t, color: '#ffffff', opacity: 1, ...additive }));
    glowSp.scale.setScalar(0.42);
    spin.add(glowSp);
    return { curve, line, glowSp, off: (i * 0.173) % 1, speed: 0.16 + (i % 4) * 0.04 };
  });
  const tmpV = new THREE.Vector3();
  const clamp01 = (x: number) => Math.min(1, Math.max(0, x));
  const outBack = (x: number) => { const c1 = 1.9; const c3 = c1 + 1; return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2); };
  const outCubic = (x: number) => 1 - Math.pow(1 - x, 3);
  const inCubic = (x: number) => x * x * x;

  // idea cards
  const cardTex: Partial<Record<MemberId, THREE.CanvasTexture>> = {};
  const texFor = (id: MemberId) => {
    const hit = cardTex[id];
    if (hit) return hit;
    const { t } = canvasTex(128, 96, (c) => {
      c.fillStyle = COLORS[id];
      c.beginPath(); c.roundRect(4, 4, 120, 88, 16); c.fill();
      c.strokeStyle = '#ffffff';
      c.lineWidth = 5;
      c.beginPath(); c.roundRect(4, 4, 120, 88, 16); c.stroke();
      c.font = '56px sans-serif';
      c.textAlign = 'center';
      c.textBaseline = 'middle';
      c.fillText('💡', 64, 52);
    });
    cardTex[id] = t;
    return t;
  };
  const pool: THREE.Sprite[] = [];
  for (let i = 0; i < 16; i++) {
    const sp = new THREE.Sprite(new THREE.SpriteMaterial({ transparent: true, toneMapped: false, depthWrite: false }));
    sp.visible = false;
    g.add(sp);
    pool.push(sp);
  }
  const acquire = (id: MemberId) => {
    const sp = pool.find((q) => !q.userData.busy);
    if (!sp) return null;
    sp.userData.busy = true;
    (sp.material as THREE.SpriteMaterial).map = texFor(id);
    (sp.material as THREE.SpriteMaterial).needsUpdate = true;
    return sp;
  };
  interface Flight { sprite: THREE.Sprite; kind: 'in' | 'out'; from: THREE.Vector3; to: THREE.Vector3; t0: number; dur: number; started: boolean }
  const flights: Flight[] = [];
  const endV = new THREE.Vector3(0, GY, 0);
  let stored = 0;

  // idea cards habang may meeting (isa kada nakaupong miyembro, paulit-ulit)
  const ids = (Object.keys(LAB_SEATS) as TeamId[]).filter((id) => id !== 'sec');
  const loopCards = ids.map((id, i) => {
    const sprite = new THREE.Sprite(new THREE.SpriteMaterial({ map: texFor(id), transparent: true, toneMapped: false, depthWrite: false }));
    sprite.visible = false;
    g.add(sprite);
    return { id, sprite, off: i * 0.72, fired: false };
  });

  let energy = 0;
  let flash = 0;
  const CYCLE = 3.6;
  const FLY = 0.5;
  const startV = new THREE.Vector3();

  return {
    /** Ilalagay ng empleyado ang idea niya sa hologram. */
    drop(id: MemberId, x: number, z: number, now: number) {
      const sp = acquire(id);
      if (!sp) return;
      flights.push({ sprite: sp, kind: 'in', from: new THREE.Vector3(x - cx, 3.3, z - cz), to: endV.clone(), t0: now + 0.35, dur: 1.4, started: false });
    },
    /** Kinukuha ng secretary ang mga naka-store na idea para basahin. */
    collect(x: number, z: number, now: number) {
      const n = Math.max(2, Math.min(6, stored));
      const order: MemberId[] = ['aria', 'blaze', 'nova', 'cipher', 'aria', 'blaze'];
      for (let i = 0; i < n; i++) {
        const sp = acquire(order[i]);
        if (!sp) break;
        flights.push({ sprite: sp, kind: 'out', from: endV.clone(), to: new THREE.Vector3(x - cx, 3.1, z - cz), t0: now + 0.3 + i * 0.5, dur: 1.3, started: false });
      }
    },
    update(t: number, dt: number, meeting: boolean, seated: Set<MemberId>) {
      energy += ((meeting ? 1 : 0) - energy) * Math.min(1, dt * 3);
      flash = Math.max(0, flash - dt * 2.2);
      spinA.rotation.y = t * (0.25 + 0.55 * energy);
      spinB.rotation.y = -t * (0.4 + 0.9 * energy);
      const glow = Math.min(1, energy + stored * 0.08);
      matA.opacity = Math.min(1, 0.6 + 0.35 * glow + flash * 0.25);
      matB.opacity = Math.min(1, 0.5 + 0.4 * glow + flash * 0.25);
      beamMat.opacity = 0.14 + 0.16 * glow + flash * 0.12;
      orb.position.y = GY + Math.sin(t * 2) * 0.1;
      core.position.y = orb.position.y;
      orb.scale.setScalar(0.7 + 0.6 * energy + stored * 0.07 + flash * 0.5 + Math.sin(t * 4) * 0.05 * glow);
      core.scale.setScalar(0.8 + flash * 1.2);
      orbMat.emissiveIntensity = 1.6 + glow * 1.2 + flash * 2;

      // ===== globe hologram =====
      spin.rotation.y = t * (0.2 + 0.4 * energy);
      globeRoot.position.y = GY + Math.sin(t * 1.3) * 0.12;
      const pulseBeat = 0.5 + 0.5 * Math.sin(t * 2.4);
      halo.position.y = flare.position.y = globeRoot.position.y;
      halo.scale.setScalar(GR * (5.6 + 0.8 * pulseBeat + 1.2 * flash + 0.8 * glow));
      (halo.material as THREE.SpriteMaterial).opacity = Math.min(1, 0.6 + 0.2 * pulseBeat + 0.2 * glow + 0.3 * flash);
      flare.scale.setScalar(GR * (1.8 + 0.5 * pulseBeat + 1.4 * flash));
      (flare.material as THREE.SpriteMaterial).opacity = Math.min(1, 0.55 + 0.25 * pulseBeat + 0.4 * flash);
      mapMat.opacity = Math.min(1, 0.9 + 0.1 * pulseBeat);
      shellMat.opacity = 0.16 + 0.08 * pulseBeat + 0.12 * glow + 0.15 * flash;
      atmoMat.opacity = 0.18 + 0.1 * pulseBeat + 0.12 * flash;
      pillarMat.opacity = 0.16 + 0.12 * glow + 0.1 * pulseBeat + 0.15 * flash;
      globeLight.position.y = globeRoot.position.y;
      globeLight.intensity = 22 + 28 * glow + 45 * flash + 8 * pulseBeat;
      const sh = Math.sin(t * 0.8) * GR * 0.96;
      scan.position.y = sh;
      scan.scale.setScalar(Math.max(0.05, Math.sqrt(1 - (sh / (GR * 1.02)) ** 2)));
      orbits.forEach((o) => { o.arm.rotation.y = t * o.speed; });

      const rate = 0.2 * (0.9 + 0.8 * energy);
      nodes.forEach((nd, i) => {
        const u = nd.perm ? 0.5 : (((t * rate + nd.off) % 1) + 1) % 1;
        const popIn = clamp01(u / 0.1);
        const popOut = 1 - clamp01((u - 0.88) / 0.12);
        const ds = nd.perm ? 1.5 + 0.2 * Math.sin(t * 3) : Math.max(0, outBack(popIn)) * popOut;
        const grow = nd.perm
          ? 0.65 + 0.35 * Math.sin(t * 1.4)
          : outCubic(clamp01((u - 0.08) / 0.4)) * (1 - inCubic(clamp01((u - 0.7) / 0.25)));
        const hh = Math.max(0.001, nd.h * grow);
        nd.dot.scale.setScalar(Math.max(0.001, ds) * (1 + 0.15 * Math.sin(t * 6 + i)));
        nd.dotGlow.scale.setScalar(0.5 * Math.max(0.001, ds) * (nd.big ? 1.8 : 1));
        nd.tower.scale.y = hh;
        nd.tower.visible = grow > 0.01;
        nd.cap.position.y = hh;
        nd.cap.scale.setScalar(Math.max(0.001, ds) * (0.9 + 0.3 * Math.sin(t * 5 + i * 1.7)));
        nd.capGlow.scale.setScalar(0.8 * (nd.big ? 1.6 : 1));
        const pv = nd.perm ? (t * 0.7) % 1 : u < 0.55 ? (u * 3.2) % 1 : 1;
        const pm = nd.pulse.material as THREE.MeshBasicMaterial;
        nd.pulse.scale.setScalar((nd.big ? 1.4 : 1) * (1 + pv * 7));
        pm.opacity = pv >= 1 ? 0 : (1 - pv) * 0.9 * (nd.perm ? 1 : popIn);
      });
      arcs.forEach((a, i) => {
        const u = (((t * a.speed + a.off) % 1) + 1) % 1;
        a.curve.getPoint(u, tmpV);
        a.glowSp.position.copy(tmpV);
        a.glowSp.scale.setScalar(0.36 + 0.14 * Math.sin(t * 8 + i));
        (a.line.material as THREE.LineBasicMaterial).opacity = Math.min(1, 0.45 + 0.3 * glow + 0.15 * Math.sin(t * 2 + i) + 0.2 * flash);
      });

      // drop / collect flights
      for (let k = flights.length - 1; k >= 0; k--) {
        const f = flights[k];
        const p = (t - f.t0) / f.dur;
        if (p < 0) { f.sprite.visible = false; continue; }
        if (!f.started) {
          f.started = true;
          if (f.kind === 'out') { stored = Math.max(0, stored - 1); flash = Math.max(flash, 0.5); }
        }
        if (p >= 1) {
          if (f.kind === 'in') { stored = Math.min(8, stored + 1); flash = 1; }
          f.sprite.visible = false;
          f.sprite.userData.busy = false;
          flights.splice(k, 1);
          continue;
        }
        const e = p * p * (3 - 2 * p);
        f.sprite.position.lerpVectors(f.from, f.to, e);
        f.sprite.position.y += Math.sin(Math.PI * p) * 0.9;
        const s = f.kind === 'in' ? 1 - 0.75 * e : 0.35 + 0.65 * Math.sin(Math.PI * 0.5 * e);
        f.sprite.scale.set(0.95 * s, 0.7 * s, 1);
        f.sprite.visible = true;
      }

      // meeting loop cards
      loopCards.forEach((cd) => {
        const u = ((((t + cd.off) % CYCLE) + CYCLE) % CYCLE) / CYCLE;
        if (meeting && seated.has(cd.id) && u < FLY) {
          const p = u / FLY;
          const e = p * p * (3 - 2 * p);
          const [sx, sz] = LAB_SEATS[cd.id];
          startV.set(sx - cx, 3.4, sz - cz);
          cd.sprite.position.lerpVectors(startV, endV, e);
          cd.sprite.position.y += Math.sin(Math.PI * p) * 0.9;
          const s = 1 - 0.75 * e;
          cd.sprite.scale.set(0.95 * s, 0.7 * s, 1);
          cd.sprite.visible = true;
          if (p > 0.95 && !cd.fired) { cd.fired = true; flash = 1; }
        } else {
          cd.sprite.visible = false;
          cd.fired = false;
        }
      });
    },
  };
}

function makeBoard(parent: THREE.Object3D, x: number, y: number, z: number, w: number, h: number, rotY: number, title: string, color: string, chart = false) {
  const { t } = canvasTex(512, 256, (c) => {
    c.fillStyle = '#f8fafc';
    c.fillRect(0, 0, 512, 256);
    c.fillStyle = color;
    c.fillRect(0, 0, 512, 46);
    c.fillStyle = '#ffffff';
    c.font = 'bold 28px sans-serif';
    c.fillText(title, 16, 34);
    if (chart) {
      [60, 110, 80, 150, 120, 170, 140].forEach((bh, i) => {
        c.fillStyle = i % 2 ? color : '#94a3b8';
        c.fillRect(40 + i * 62, 232 - bh * 0.95, 40, bh * 0.95);
      });
    } else {
      ['#fde68a', '#fbcfe8', '#bae6fd', '#bbf7d0', '#fed7aa', '#ddd6fe'].forEach((col, i) => {
        const nx = 24 + (i % 3) * 160;
        const ny = 66 + Math.floor(i / 3) * 94;
        c.fillStyle = col;
        c.fillRect(nx, ny, 140, 80);
        c.fillStyle = '#94a3b8';
        c.fillRect(nx + 12, ny + 20, 90, 5);
        c.fillRect(nx + 12, ny + 38, 64, 5);
      });
    }
  });
  const g = new THREE.Group();
  g.position.set(x, y, z);
  g.rotation.y = rotY;
  box(g, w + 0.2, h + 0.2, 0.08, mat('#cbd5e1', 0.3, 0.6), 0, 0, 0, false);
  const p = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: t, toneMapped: false }));
  p.position.z = 0.05;
  g.add(p);
  parent.add(g);
}

function makeNeon(parent: THREE.Object3D, x: number, y: number, z: number, w: number, h: number, text: string, glow: string, fill = '#fff7e6') {
  const hpx = Math.round((512 * h) / w);
  const { t } = canvasTex(512, hpx, (c) => {
    c.fillStyle = '#0b0e14';
    c.fillRect(0, 0, 512, hpx);
    c.shadowColor = glow;
    c.shadowBlur = 24;
    c.fillStyle = fill;
    c.font = `bold ${Math.round(hpx * 0.55)}px sans-serif`;
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.fillText(text, 256, hpx / 2 + 3);
  });
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: t, toneMapped: false }));
  m.position.set(x, y, z);
  parent.add(m);
}


/* ------------------------------------------------------------------ *
 * Arcade room: mga makina na may umaandar na laro sa screen
 * ------------------------------------------------------------------ */
interface ArcadeScreen { c: CanvasRenderingContext2D; t: THREE.CanvasTexture; hue: number; seed: number }

function makeArcadeCabinet(parent: THREE.Object3D, x: number, z: number, rotY: number, hue: number, title: string, screens: ArcadeScreen[]) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rotY;
  g.scale.setScalar(0.92);
  const col = new THREE.Color().setHSL(hue / 360, 0.9, 0.55);
  const body = mat('#191433', 0.5, 0.25);
  const trim = glowMat(col, 1.5);
  // ibabang katawan + itaas na lalagyan ng screen (nakaharap sa +z)
  box(g, 1.8, 1.5, 1.5, body, 0, 0.75, 0);
  box(g, 1.8, 1.7, 1.1, body, 0, 2.35, -0.2);
  // control deck na may joystick at mga button
  const deck = box(g, 1.8, 0.14, 0.9, mat('#232046', 0.4, 0.3), 0, 1.58, 0.55);
  deck.rotation.x = 0.22;
  cyl(g, 0.04, 0.04, 0.3, mat('#cbd5e1', 0.3, 0.8), -0.45, 1.8, 0.58, 8);
  sphere(g, 0.1, glowMat('#ef4444', 1.2), -0.45, 1.98, 0.58);
  ['#fde047', '#38bdf8', '#f472b6'].forEach((bc, i) => cyl(g, 0.08, 0.08, 0.05, glowMat(bc, 1.4), 0.1 + i * 0.28, 1.7, 0.62 - (i % 2) * 0.08));
  // screen
  box(g, 1.62, 1.25, 0.03, mat('#07050f', 0.3, 0.4), 0, 2.4, 0.343, false);
  const { c, t } = canvasTex(128, 96, () => undefined);
  const scr = new THREE.Mesh(new THREE.PlaneGeometry(1.45, 1.1), new THREE.MeshBasicMaterial({ map: t, toneMapped: false }));
  scr.position.set(0, 2.4, 0.362);
  g.add(scr);
  screens.push({ c, t, hue, seed: x * 0.37 + z });
  // marquee na umiilaw
  box(g, 1.8, 0.42, 1.0, body, 0, 3.4, -0.1);
  const mq = canvasTex(256, 64, (cx) => {
    cx.fillStyle = '#07050f';
    cx.fillRect(0, 0, 256, 64);
    cx.shadowColor = col.getStyle();
    cx.shadowBlur = 14;
    cx.fillStyle = '#ffffff';
    cx.font = 'bold 38px sans-serif';
    cx.textAlign = 'center';
    cx.textBaseline = 'middle';
    cx.fillText(title, 128, 34);
  });
  const mqm = new THREE.Mesh(new THREE.PlaneGeometry(1.7, 0.34), new THREE.MeshBasicMaterial({ map: mq.t, toneMapped: false }));
  mqm.position.set(0, 3.4, 0.405);
  g.add(mqm);
  // ilaw sa gilid at ilalim
  [-0.92, 0.92].forEach((sx) => box(g, 0.04, 3.1, 1.3, trim, sx, 1.85, -0.05, false));
  box(g, 1.5, 0.05, 0.04, trim, 0, 0.12, 0.76, false);
  parent.add(g);
}

function drawArcade(s: ArcadeScreen, t: number, active: boolean) {
  const c = s.c;
  c.fillStyle = '#05030c';
  c.fillRect(0, 0, 128, 96);
  const col = `hsl(${s.hue},90%,62%)`;
  c.textAlign = 'center';
  if (!active) {
    // attract mode
    c.fillStyle = col;
    c.globalAlpha = 0.3 + 0.5 * Math.abs(Math.sin(t * 2 + s.seed));
    c.font = 'bold 15px monospace';
    c.fillText('INSERT', 64, 42);
    c.fillText('COIN', 64, 60);
    c.globalAlpha = 1;
  } else {
    // simpleng space-shooter
    const shift = Math.sin(t * 1.6 + s.seed) * 14;
    for (let r = 0; r < 3; r++) for (let k = 0; k < 6; k++) {
      c.fillStyle = r % 2 ? col : '#fde047';
      c.fillRect(18 + k * 16 + shift, 16 + r * 12, 9, 6);
    }
    const px = 64 + Math.sin(t * 2.4 + s.seed * 2) * 40;
    c.fillStyle = '#34d399';
    c.fillRect(px - 6, 82, 12, 5);
    c.fillRect(px - 2, 78, 4, 4);
    c.fillStyle = '#ffffff';
    c.fillRect(px - 1, 76 - ((t * 60 + s.seed * 10) % 58), 2, 6);
    c.font = 'bold 9px monospace';
    c.textAlign = 'left';
    c.fillStyle = '#ffffff';
    c.fillText(`SCORE ${String(Math.floor(t * 37 + s.seed * 100) % 99999).padStart(5, '0')}`, 4, 10);
  }
  s.t.needsUpdate = true;
}

function makeClawMachine(parent: THREE.Object3D, x: number, z: number, rotY: number) {
  const g = new THREE.Group();
  g.position.set(x, 0, z);
  g.rotation.y = rotY;
  box(g, 2.2, 1.0, 2.0, mat('#7c3aed', 0.45, 0.2), 0, 0.5, 0);
  const glass = physMat({ color: '#bfe3ff', transparent: true, opacity: 0.2, roughness: 0.05, depthWrite: false, side: THREE.DoubleSide });
  const cage = new THREE.Mesh(new THREE.BoxGeometry(2.1, 2.0, 1.9), glass);
  cage.position.set(0, 2.0, 0);
  g.add(cage);
  [-1, 1].forEach((sx) => [-1, 1].forEach((sz) => box(g, 0.12, 2.0, 0.12, mat('#1b1530'), sx * 1.05, 2.0, sz * 0.95, false)));
  box(g, 2.2, 0.35, 2.0, glowMat('#f472b6', 1.1), 0, 3.2, 0, false);
  // mga premyo
  const prize = ['#f87171', '#fbbf24', '#34d399', '#60a5fa', '#c084fc', '#f472b6'];
  for (let i = 0; i < 12; i++) sphere(g, 0.26, mat(prize[i % prize.length], 0.8), -0.75 + (i % 4) * 0.5, 1.25 + (i > 7 ? 0.35 : 0), -0.6 + Math.floor(i / 4) * 0.55);
  // claw
  cyl(g, 0.03, 0.03, 0.9, mat('#cbd5e1', 0.3, 0.8), 0.2, 2.65, 0.1, 8);
  [0, 1, 2].forEach((k) => {
    const a = (k / 3) * Math.PI * 2;
    const prong = new THREE.Mesh(new THREE.ConeGeometry(0.05, 0.4, 6), mat('#cbd5e1', 0.3, 0.8));
    prong.position.set(0.2 + Math.cos(a) * 0.14, 2.05, 0.1 + Math.sin(a) * 0.14);
    prong.rotation.z = Math.PI;
    g.add(prong);
  });
  // control
  box(g, 1.2, 0.12, 0.5, mat('#232046', 0.4, 0.3), 0, 1.05, 1.1);
  sphere(g, 0.09, glowMat('#ef4444', 1.2), -0.3, 1.18, 1.1);
  cyl(g, 0.1, 0.1, 0.05, glowMat('#fde047', 1.4), 0.3, 1.12, 1.1);
  parent.add(g);
}

/* ------------------------------------------------------------------ *
 * Canteen: mesa, plato at menu board
 * ------------------------------------------------------------------ */
function makeCanteenTable(parent: THREE.Object3D, x: number, z: number, len: number, depth: number) {
  box(parent, len, 0.14, depth, mat('#8a5a35', 0.5), x, 1.05, z);
  box(parent, len - 0.3, 0.02, depth - 0.3, mat('#efe3c8', 0.6), x, 1.13, z, false);
  [-1, 1].forEach((sx) => [-1, 1].forEach((sz) => box(parent, 0.14, 1.0, 0.14, mat('#2a1b13'), x + sx * (len / 2 - 0.3), 0.5, z + sz * (depth / 2 - 0.2))));
}

function makePlateSet(parent: THREE.Object3D, x: number, z: number, variant: number) {
  const viand = ['#b45309', '#dc2626', '#65a30d', '#f59e0b'][variant % 4];
  cyl(parent, 0.38, 0.3, 0.05, mat('#f8fafc', 0.3), x, 1.17, z);
  const rice = sphere(parent, 0.19, mat('#fffdf5', 0.7), x - 0.1, 1.26, z);
  rice.scale.y = 0.6;
  cyl(parent, 0.15, 0.15, 0.08, mat(viand, 0.7), x + 0.12, 1.23, z + 0.04);
  cyl(parent, 0.12, 0.1, 0.22, mat('#ffffff', 0.4), x + 0.55, 1.25, z - 0.12);
  box(parent, 0.04, 0.012, 0.32, mat('#cbd5e1', 0.3, 0.8), x - 0.5, 1.15, z, false);
}

function menuBoardTex(): THREE.CanvasTexture {
  const { t } = canvasTex(1024, 256, (c) => {
    c.fillStyle = '#17120d';
    c.fillRect(0, 0, 1024, 256);
    c.strokeStyle = '#fb923c';
    c.lineWidth = 6;
    c.strokeRect(8, 8, 1008, 240);
    c.fillStyle = '#fed7aa';
    c.font = 'bold 40px sans-serif';
    c.textAlign = 'center';
    c.fillText('🍽️ CANTEEN MENU', 512, 56);
    const dishes: Record<string, string> = { breakfast: 'Tapsilog · Pandesal · Kape', lunch: 'Adobo · Sinigang · Kanin', dinner: 'Tinola · Pancit · Prutas' };
    (['breakfast', 'lunch', 'dinner'] as const).forEach((m, i) => {
      const x = 176 + i * 336;
      c.fillStyle = '#fb923c';
      c.font = 'bold 34px sans-serif';
      c.fillText(`${MEAL_INFO[m].emoji} ${MEAL_INFO[m].label.toUpperCase()}`, x, 118);
      c.fillStyle = '#fde68a';
      c.font = 'bold 30px sans-serif';
      c.fillText(MEAL_INFO[m].time, x, 164);
      c.fillStyle = '#e7d3b0';
      c.font = '24px sans-serif';
      c.fillText(dishes[m], x, 206);
    });
  });
  return t;
}

/* ------------------------------------------------------------------ *
 * Walls with door gaps
 * ------------------------------------------------------------------ */
type Gap = { at: number; w: number };
function wallLine(parent: THREE.Object3D, x0: number, z0: number, x1: number, z1: number, gaps: Gap[], tint: string) {
  const horizontal = Math.abs(z1 - z0) < 1e-6;
  const L = horizontal ? x1 - x0 : z1 - z0;
  const sorted = [...gaps].sort((a, b) => a.at - b.at);
  const pieces: [number, number][] = [];
  let cur = 0;
  sorted.forEach((g) => {
    if (g.at - g.w / 2 > cur) pieces.push([cur, g.at - g.w / 2]);
    cur = g.at + g.w / 2;
  });
  if (cur < L) pieces.push([cur, L]);
  const base = mat('#1d2432', 0.5, 0.2);
  const rail = mat(tint, 0.4, 0.5);
  const glass = physMat({ color: '#a8d4ff', transparent: true, opacity: 0.16, roughness: 0.05, metalness: 0, side: THREE.DoubleSide, depthWrite: false });
  pieces.forEach(([a, b]) => {
    const len = b - a;
    if (len < 0.05) return;
    const mid = (a + b) / 2;
    const cx = horizontal ? x0 + mid : x0;
    const cz = horizontal ? z0 : z0 + mid;
    const sx = horizontal ? len : 0.3;
    const sz = horizontal ? 0.3 : len;
    box(parent, sx, 0.8, sz, base, cx, 0.4, cz);
    const gl = new THREE.Mesh(new THREE.BoxGeometry(horizontal ? len : 0.06, 2.3, horizontal ? 0.06 : len), glass);
    gl.position.set(cx, 1.95, cz);
    parent.add(gl);
    box(parent, sx, 0.12, sz, rail, cx, 3.14, cz, false);
  });
  // posts at every piece end
  pieces.forEach(([a, b]) => [a, b].forEach((t) => {
    box(parent, 0.3, 3.2, 0.3, rail, horizontal ? x0 + t : x0, 1.6, horizontal ? z0 : z0 + t);
  }));
}

function doorLight(parent: THREE.Object3D, x: number, z: number, horizontalDoor: boolean, w: number, color: string) {
  box(parent, horizontalDoor ? w : 0.18, 0.1, horizontalDoor ? 0.18 : w, glowMat(color, 1.8), x, 3.0, z, false);
}

/* ------------------------------------------------------------------ *
 * Characters
 * ------------------------------------------------------------------ */
interface Bot {
  id: MemberId;
  group: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
  cup: THREE.Mesh;
  /** handheld console / pagkain: lalabas lang kapag nag-break sa desk (si Argus) */
  console: THREE.Group;
  plate: THREE.Group;
  readPaper: THREE.Group;
  eyes: THREE.Mesh[];
  spin: THREE.Object3D[];
  orb: THREE.Mesh | null;
  pos: THREE.Vector3;
  path: THREE.Vector3[];
  place: Place;
  /** si Dex lang: kaninong office siya nag-aayos (kapag place === 'fix') */
  fix: TeamId | null;
  yaw: number;
  walking: boolean;
}

/** Maliit na lunch box (kanin, ulam at kutsara) na hawak habang kumakain sa desk. */
function makeFoodPlate() {
  const g = new THREE.Group();
  rbox(g, 0.9, 0.1, 0.6, 0.04, mat('#f8fafc', 0.4), 0, 0, 0);
  cyl(g, 0.2, 0.24, 0.16, mat('#fefce8', 0.7), -0.2, 0.12, 0, 12);
  rbox(g, 0.3, 0.1, 0.28, 0.04, mat('#b45309', 0.7), 0.25, 0.08, 0.05, false);
  sphere(g, 0.07, mat('#65a30d', 0.7), 0.3, 0.16, -0.08);
  box(g, 0.04, 0.03, 0.4, mat('#cfd6e2', 0.3, 0.7), 0.05, 0.1, 0.1, false);
  g.rotation.x = -0.25;
  return g;
}

function makeBot(id: MemberId): Bot {
  const color = COLORS[id];
  const boss = id === 'boss';
  const g = new THREE.Group();
  g.userData.id = id;
  g.scale.setScalar(boss ? 1.22 : 1.15);

  const suit = new THREE.MeshStandardMaterial({
    color: boss ? '#241a14' : new THREE.Color(color).multiplyScalar(0.42),
    roughness: 0.45,
    metalness: 0.25,
  });
  const shell = physMat({ color: '#eef2f8', roughness: 0.2, metalness: 0.4, clearcoat: 1, clearcoatRoughness: 0.12, envMapIntensity: 1.2 });
  const metal = mat('#cfd6e2', 0.3, 0.7);
  const dark = mat('#0b0f17', 0.4, 0.3);
  const pants = mat('#1b2130', 0.6, 0.1);
  const gloss = physMat({ color: '#05080f', roughness: 0.06, metalness: 0.85, clearcoat: 1, clearcoatRoughness: 0.05, envMapIntensity: 1.6 });
  const trim = mat(boss ? '#fbbf24' : color, 0.3, 0.7);
  const gold = mat('#fbbf24', 0.25, 0.9);
  const eyes: THREE.Mesh[] = [];
  const spin: THREE.Object3D[] = [];
  let orb: THREE.Mesh | null = null;

  // torso, pelvis, belt
  rbox(g, 1.02, 1.1, 0.62, 0.2, suit, 0, 1.52, 0);
  rbox(g, 0.9, 0.3, 0.56, 0.1, dark, 0, 0.98, 0);
  rbox(g, 1.04, 0.1, 0.66, 0.04, trim, 0, 1.1, 0, false);
  rbox(g, 0.2, 0.14, 0.05, 0.03, boss ? gold : glowMat(color, 1.4), 0, 1.1, 0.33, false);
  // shoulders
  sphere(g, 0.2, suit, -0.66, 1.95, 0);
  sphere(g, 0.2, suit, 0.66, 1.95, 0);
  // chest emblem
  if (id === 'cipher') {
    const sh = new THREE.Shape();
    sh.moveTo(-0.2, 0.2); sh.lineTo(0.2, 0.2); sh.lineTo(0.2, -0.04);
    sh.quadraticCurveTo(0.2, -0.2, 0, -0.3);
    sh.quadraticCurveTo(-0.2, -0.2, -0.2, -0.04);
    sh.closePath();
    const shield = new THREE.Mesh(new THREE.ExtrudeGeometry(sh, { depth: 0.04, bevelEnabled: false }), glowMat(color, 1.8));
    shield.position.set(0, 1.68, 0.31);
    g.add(shield);
  } else if (id === 'argus') {
    // mata sa dibdib: si Argus ay ang may "daang mata"
    const sclera = new THREE.Mesh(new THREE.SphereGeometry(0.17, 16, 12), mat('#f8fafc', 0.3));
    sclera.scale.set(1.5, 0.85, 0.3);
    sclera.position.set(0, 1.62, 0.32);
    g.add(sclera);
    sphere(g, 0.085, glowMat(color, 2.2), 0, 1.62, 0.36);
    sphere(g, 0.04, dark, 0, 1.62, 0.41);
  } else if (boss) {
    rbox(g, 0.2, 0.15, 0.05, 0.04, mat('#b91c1c', 0.5), 0, 1.96, 0.33, false);
    rbox(g, 0.18, 0.62, 0.04, 0.03, mat('#b91c1c', 0.5), 0, 1.58, 0.33, false);
    sphere(g, 0.07, gold, -0.3, 1.78, 0.32);
    rbox(g, 0.34, 0.08, 0.3, 0.03, gold, -0.62, 2.1, 0);
    rbox(g, 0.34, 0.08, 0.3, 0.03, gold, 0.62, 2.1, 0);
  } else {
    const core = cyl(g, 0.14, 0.14, 0.05, glowMat(color, 2), 0, 1.62, 0.32);
    core.rotation.x = Math.PI / 2;
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.025, 8, 24), metal);
    ring.position.set(0, 1.62, 0.32);
    g.add(ring);
  }
  // collar + neck
  cyl(g, 0.3, 0.34, 0.1, trim, 0, 2.03, 0);
  cyl(g, 0.14, 0.14, 0.2, dark, 0, 2.1, 0);

  // head
  rbox(g, 1.08, 0.86, 0.92, 0.3, shell, 0, 2.55, 0);
  rbox(g, 0.9, 0.5, 0.1, 0.2, gloss, 0, 2.54, 0.43, false);
  [-0.2, 0.2].forEach((ex) => eyes.push(rbox(g, 0.17, 0.2, 0.05, 0.06, glowMat(color, 2.6), ex, 2.58, 0.5, false)));
  const smile = new THREE.Mesh(new THREE.TorusGeometry(0.1, 0.016, 6, 14, Math.PI), glowMat(color, 1.8));
  smile.rotation.z = Math.PI;
  smile.position.set(0, 2.46, 0.5);
  g.add(smile);
  [-1, 1].forEach((sx) => {
    cyl(g, 0.2, 0.2, 0.14, mat(color, 0.35, 0.6), sx * 0.6, 2.55, 0).rotation.z = Math.PI / 2;
    cyl(g, 0.1, 0.1, 0.17, glowMat(color, 1.2), sx * 0.6, 2.55, 0).rotation.z = Math.PI / 2;
  });

  // role accessories
  if (boss) {
    cyl(g, 0.4, 0.36, 0.2, gold, 0, 3.08, 0, 16);
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      const px = Math.cos(a) * 0.36;
      const pz = Math.sin(a) * 0.36;
      const spike = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.34, 6), gold);
      spike.position.set(px, 3.33, pz);
      spike.castShadow = true;
      g.add(spike);
      sphere(g, 0.05, glowMat(i % 2 ? '#ef4444' : '#38bdf8', 1.6), px, 3.54, pz);
    }
    sphere(g, 0.07, glowMat('#ef4444', 2), 0, 3.08, 0.4);
    const mono = new THREE.Mesh(new THREE.TorusGeometry(0.15, 0.018, 8, 20), gold);
    mono.position.set(0.2, 2.58, 0.5);
    g.add(mono);
    rbox(g, 1.15, 1.7, 0.05, 0.02, mat('#7f1d1d', 0.7), 0, 1.35, -0.34, false);
  } else if (id === 'aria') {
    const beret = cyl(g, 0.52, 0.5, 0.14, mat('#047857', 0.8), -0.06, 3.02, 0, 20);
    beret.rotation.z = 0.12;
    orb = sphere(g, 0.09, glowMat(color, 2.4), -0.06, 3.15, 0);
    const pen = cyl(g, 0.035, 0.035, 0.55, mat('#fbbf24', 0.5), 0.45, 3.1, -0.05, 8);
    pen.rotation.z = -0.35;
    const tip = new THREE.Mesh(new THREE.ConeGeometry(0.035, 0.1, 8), mat('#f472b6', 0.5));
    tip.position.set(0.55, 3.38, -0.05);
    tip.rotation.z = -0.35;
    g.add(tip);
  } else if (id === 'blaze') {
    cyl(g, 0.04, 0.04, 0.3, metal, 0, 3.1, 0, 8);
    const pivot = new THREE.Group();
    pivot.position.set(0, 3.3, 0);
    g.add(pivot);
    spin.push(pivot);
    const dish = new THREE.Mesh(
      new THREE.SphereGeometry(0.4, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2),
      new THREE.MeshStandardMaterial({ color: '#e5e7eb', roughness: 0.3, metalness: 0.6, side: THREE.DoubleSide }),
    );
    dish.rotation.x = Math.PI - 0.5;
    dish.castShadow = true;
    pivot.add(dish);
    orb = sphere(pivot, 0.07, glowMat(color, 2.4), 0, 0.3, -0.08);
  } else if (id === 'nova') {
    const arch = new THREE.Mesh(new THREE.TorusGeometry(0.62, 0.045, 8, 28, Math.PI), mat('#1b2130', 0.4, 0.5));
    arch.position.set(0, 2.45, 0);
    g.add(arch);
    const a = new THREE.Vector3(0.6, 2.42, 0.1);
    const b = new THREE.Vector3(0.28, 2.3, 0.52);
    const boom = cyl(g, 0.025, 0.025, a.distanceTo(b), mat('#1b2130', 0.4, 0.5), 0, 0, 0, 8);
    boom.position.copy(a).add(b).multiplyScalar(0.5);
    boom.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), b.clone().sub(a).normalize());
    sphere(g, 0.07, glowMat(color, 2), b.x, b.y, b.z);
    cyl(g, 0.03, 0.03, 0.35, metal, 0, 3.15, 0, 8);
    orb = sphere(g, 0.1, glowMat(color, 2.4), 0, 3.42, 0);
    const pivot = new THREE.Group();
    pivot.position.set(0, 3.42, 0);
    g.add(pivot);
    const ring = new THREE.Mesh(new THREE.TorusGeometry(0.22, 0.015, 6, 24), glowMat(color, 1.4));
    ring.rotation.x = Math.PI / 2 + 0.5;
    pivot.add(ring);
    spin.push(pivot);
  } else if (id === 'sec') {
    // buhok, bun, ribbon, salamin at bow tie
    const hairM = mat('#3b1f2b', 0.55, 0.1);
    const hair = new THREE.Mesh(new THREE.SphereGeometry(0.58, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2), hairM);
    hair.scale.set(1, 0.7, 0.95);
    hair.position.set(0, 2.74, -0.02);
    hair.castShadow = true;
    g.add(hair);
    sphere(g, 0.24, hairM, 0, 3.2, -0.1);
    const ribbon = glowMat(color, 1.3);
    [-1, 1].forEach((sx) => {
      const w = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.26, 8), ribbon);
      w.rotation.z = -sx * Math.PI / 2;
      w.position.set(sx * 0.14, 3.18, -0.1);
      g.add(w);
    });
    sphere(g, 0.06, ribbon, 0, 3.18, -0.1);
    const frame = glowMat('#fbcfe8', 1.4);
    [-0.2, 0.2].forEach((ex) => {
      const lens = new THREE.Mesh(new THREE.TorusGeometry(0.15, 0.022, 8, 20), frame);
      lens.position.set(ex, 2.58, 0.53);
      g.add(lens);
    });
    box(g, 0.1, 0.02, 0.02, frame, 0, 2.6, 0.53, false);
    rbox(g, 0.3, 0.14, 0.06, 0.03, ribbon, 0, 1.98, 0.34, false);
  } else if (id === 'argus') {
    // watchdog: matulis na tainga ng guard dog, kwintas na may tag, at singsing ng mga matang umiikot sa ulo
    const earM = mat('#1b2130', 0.5, 0.2);
    [-1, 1].forEach((sx) => {
      const ear = new THREE.Mesh(new THREE.ConeGeometry(0.17, 0.58, 4), earM);
      ear.position.set(sx * 0.36, 3.12, -0.04);
      ear.rotation.z = -sx * 0.22;
      ear.rotation.y = Math.PI / 4;
      ear.castShadow = true;
      g.add(ear);
      const inner = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.4, 4), glowMat(color, 0.9));
      inner.position.set(sx * 0.37, 3.08, 0.03);
      inner.rotation.z = -sx * 0.22;
      inner.rotation.y = Math.PI / 4;
      g.add(inner);
    });
    const tag = cyl(g, 0.07, 0.07, 0.02, gold, 0, 1.88, 0.35, 14);
    tag.rotation.x = Math.PI / 2;
    const eyeRing = new THREE.Group();
    eyeRing.position.set(0, 3.55, 0);
    g.add(eyeRing);
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const ex = Math.cos(a) * 0.46;
      const ez = Math.sin(a) * 0.46;
      sphere(eyeRing, 0.085, mat('#f8fafc', 0.3), ex, 0, ez);
      sphere(eyeRing, 0.05, glowMat(color, 2.4), Math.cos(a) * 0.53, 0, Math.sin(a) * 0.53);
    }
    spin.push(eyeRing);
    orb = sphere(g, 0.07, glowMat(color, 2.4), 0, 3.26, 0);
  } else if (id === 'it') {
    // nakabaliktad na cap, cyan na salamin at ethernet-cable antenna (si Dex ng IT)
    const capM = mat('#0f172a', 0.6, 0.1);
    const dome = new THREE.Mesh(new THREE.SphereGeometry(0.56, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2), capM);
    dome.scale.set(1, 0.75, 1);
    dome.position.set(0, 2.86, 0);
    dome.castShadow = true;
    g.add(dome);
    box(g, 0.8, 0.05, 0.4, mat(color, 0.4, 0.5), 0, 2.9, -0.62, false);
    const itFrame = glowMat(color, 1.6);
    [-0.2, 0.2].forEach((ex) => {
      const lens = new THREE.Mesh(new THREE.TorusGeometry(0.15, 0.02, 8, 20), itFrame);
      lens.position.set(ex, 2.58, 0.53);
      g.add(lens);
    });
    box(g, 0.1, 0.02, 0.02, itFrame, 0, 2.6, 0.53, false);
    const cable = cyl(g, 0.025, 0.025, 0.5, mat('#38bdf8', 0.5), 0.34, 3.22, -0.1, 8);
    cable.rotation.z = -0.25;
    orb = sphere(g, 0.08, glowMat('#34d399', 2.2), 0.46, 3.5, -0.1);
  } else {
    [0.3, 0.44, 0.3].forEach((h, i) => {
      const fin = new THREE.Mesh(new THREE.ConeGeometry(0.1, h, 6), glowMat(color, 1.6));
      fin.position.set(0, 2.98 + h / 2 - 0.02, (i - 1) * 0.24);
      g.add(fin);
    });
  }

  // legs and arms pivot at hip / shoulder
  const mkLimb = (x: number, y: number, len: number, rad: number, m: THREE.Material) => {
    const l = new THREE.Group();
    l.position.set(x, y, 0);
    const mesh = new THREE.Mesh(new THREE.CapsuleGeometry(rad, Math.max(0.01, len - rad * 2), 4, 10), m);
    mesh.position.y = -len / 2;
    mesh.castShadow = true;
    l.add(mesh);
    g.add(l);
    return l;
  };
  const legL = mkLimb(-0.28, 0.98, 0.95, 0.17, pants);
  const legR = mkLimb(0.28, 0.98, 0.95, 0.17, pants);
  const armL = mkLimb(-0.66, 1.95, 0.85, 0.12, suit);
  const armR = mkLimb(0.66, 1.95, 0.85, 0.12, suit);
  const shoe = mat(boss ? '#120d0a' : '#e5e7eb', 0.4, 0.2);
  [legL, legR].forEach((l) => rbox(l, 0.4, 0.2, 0.58, 0.09, shoe, 0, -0.93, 0.09));
  [armL, armR].forEach((a) => sphere(a, 0.15, shell, 0, -0.85, 0));
  const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.11, 0.26, 12), mat('#ffffff', 0.4));
  cup.position.set(0, -0.9, 0.12);
  cup.visible = false;
  armR.add(cup);
  // handheld console at pagkain (para sa break sa desk)
  const consoleG = new THREE.Group();
  consoleG.position.set(0, 1.6, 0.8);
  consoleG.rotation.x = -0.5;
  rbox(consoleG, 1.2, 0.12, 0.62, 0.04, dark, 0, 0, 0);
  const consoleScr = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 0.4), glowMat(color, 1.1));
  consoleScr.position.set(0, 0.07, 0);
  consoleScr.rotation.x = -Math.PI / 2;
  consoleG.add(consoleScr);
  consoleG.visible = false;
  g.add(consoleG);
  const plateG = makeFoodPlate();
  plateG.position.set(0, 1.5, 0.75);
  plateG.visible = false;
  g.add(plateG);
  // dyaryo na hawak habang nagkakape (lalabas lang sa mini bar para sa mga nagbabasa)
  const readPaper = new THREE.Group();
  const readPaperMesh = new THREE.Mesh(new THREE.PlaneGeometry(1.0, 1.15), new THREE.MeshBasicMaterial({ map: id === 'sec' ? reportTex() : newspaperTex(IDS.indexOf(id)), side: THREE.DoubleSide, toneMapped: false }));
  readPaper.add(readPaperMesh);
  readPaper.position.set(-0.2, 1.75, 0.86);
  readPaper.rotation.x = -0.15;
  readPaper.visible = false;
  g.add(readPaper);

  // ---- extra detail: armor, joints, glowing trim, hands, vents ----
  const accent = glowMat(boss ? '#fbbf24' : color, 1.6);
  // shoulder armor plates
  [-1, 1].forEach((sx) => {
    rbox(g, 0.4, 0.14, 0.5, 0.06, trim, sx * 0.68, 2.12, 0);
    rbox(g, 0.3, 0.05, 0.4, 0.03, accent, sx * 0.68, 2.2, 0, false);
  });
  // chest vents + side panel lights
  [-0.28, 0.28].forEach((vx) => {
    for (let i = 0; i < 3; i++) rbox(g, 0.18, 0.025, 0.04, 0.01, dark, vx, 1.28 + i * 0.07, 0.32, false);
  });
  [-0.5, 0.5].forEach((px) => box(g, 0.025, 0.5, 0.2, accent, px, 1.52, 0.2, false));
  // neck rings
  [2.06, 2.14].forEach((ny) => cyl(g, 0.17, 0.17, 0.025, metal, 0, ny, 0, 14));
  // head: visor rim, chin guard and cheek lights
  rbox(g, 0.98, 0.58, 0.04, 0.22, metal, 0, 2.54, 0.4, false);
  rbox(g, 0.5, 0.1, 0.3, 0.04, metal, 0, 2.17, 0.32, false);
  [-1, 1].forEach((sx) => box(g, 0.02, 0.16, 0.06, accent, sx * 0.54, 2.7, 0.26, false));
  // back jet vents with a glow
  [-0.25, 0.25].forEach((vx) => {
    cyl(g, 0.11, 0.14, 0.3, dark, vx, 1.6, -0.38, 10);
    cyl(g, 0.08, 0.08, 0.04, glowMat(color, 2.2), vx, 1.42, -0.38, 10);
  });
  // elbows, forearm bands, knees, shin trim, glowing soles
  [armL, armR].forEach((a) => {
    sphere(a, 0.14, metal, 0, -0.45, 0);
    cyl(a, 0.145, 0.145, 0.07, trim, 0, -0.65, 0, 12);
    rbox(a, 0.12, 0.1, 0.12, 0.03, shell, 0, -0.95, 0.04, false); // hand palm block
    box(a, 0.05, 0.12, 0.06, shell, -0.09, -0.92, 0.07, false); // thumb
  });
  [legL, legR].forEach((l) => {
    sphere(l, 0.18, metal, 0, -0.48, 0);
    cyl(l, 0.185, 0.185, 0.06, trim, 0, -0.72, 0, 12);
    box(l, 0.04, 0.3, 0.04, accent, 0, -0.3, 0.17, false);
    rbox(l, 0.36, 0.03, 0.54, 0.01, accent, 0, -1.02, 0.09, false);
  });

  // back plate with the member's name (the camera mostly sees bots from behind)
  const plate = canvasTex(256, 96, (c) => {
    c.clearRect(0, 0, 256, 96);
    c.fillStyle = 'rgba(8,12,20,0.92)';
    c.beginPath();
    c.roundRect(4, 4, 248, 88, 22);
    c.fill();
    c.strokeStyle = color;
    c.lineWidth = 5;
    c.stroke();
    c.fillStyle = boss ? '#fde68a' : '#f8fafc';
    c.font = 'bold 54px sans-serif';
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.fillText(NAMES[id], 128, 52);
  });
  const pm = new THREE.Mesh(new THREE.PlaneGeometry(0.82, 0.31), new THREE.MeshBasicMaterial({ map: plate.t, transparent: true, toneMapped: false }));
  pm.position.set(0, 1.72, boss ? -0.38 : -0.325);
  pm.rotation.y = Math.PI;
  g.add(pm);
  [-0.3, 0.3].forEach((sx) => box(g, 0.05, 0.45, 0.03, glowMat(color, 1.4), sx, 1.2, -0.325, false));

  return { id, group: g, legL, legR, armL, armR, cup, console: consoleG, plate: plateG, readPaper, eyes, spin, orb, pos: new THREE.Vector3(), path: [], place: 'office', fix: null, yaw: Math.PI, walking: false };
}


/* ------------------------------------------------------------------ *
 * Maintenance bot "Fixo": not part of the team meetings. He patrols the hallways all day, mopping the floor and
 * fixing things (lights, doors, the coffee machine), with a "wet floor" sign where he works.
 * ------------------------------------------------------------------ */
const MAINT = { id: 'maint', name: 'Fixo', role: 'Office Maintenance', color: '#f97316' } as const;
const MAINT_STOPS = ['L2', 'L3', 'L4', 'H1', 'H2', 'R2', 'R3', 'R4', 'labL', 'labR', 'barL', 'barR', 'L6', 'R6', 'L1', 'R1', 'L8', 'R8', 'sD', 'dnL', 'dnR', 'arD'];
const MAINT_FIX_STOPS = new Set(['labL', 'labR', 'barL', 'barR', 'L1', 'R1', 'L6', 'R6', 'sD', 'dnL', 'dnR', 'arD']);
const MAINT_MOP_LINES = ['Nililinis ko ang hallway! 🧹', 'Basa pa ang sahig, ingat po! ⚠️', 'Kinis na ng sahig, Boss! ✨', 'Walis, walis, mop, mop! 🫧', 'Ang kintab na ng sahig! 🌟', 'Pakilaktawan muna po ang basa 🚧', 'Walang alikabok sa akin! 🧼', 'Isa pang punas, tapos na! 🧽', 'Amoy lemon na ang opisina 🍋', 'Tuyo na rin mamaya, Boss! 💨'];
const MAINT_FIX_LINES = ['Inaayos ko ang ilaw! 💡', 'Sandali, hihigpitan ko lang ang turnilyo 🔧', 'Check ko ang aircon, ayos na! ❄️', 'Kinukumpuni ang pinto 🚪', 'Preno ng kape machine, ayos na! ☕', 'Pinapalitan ko ang bumbilya 💡', 'Nilagyan ko ng langis ang bisagra 🔩', 'Inaayos ang tagas ng gripo 🚰', 'Ayos na ang upuan, Boss! 🪑', 'Chine-check ang mga kable ⚡', 'Pinapantay ko ang mesa 📐'];

interface MaintBot {
  group: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
  eyes: THREE.Mesh[];
  mop: THREE.Group;
  wrench: THREE.Group;
  bucket: THREE.Group;
  sign: THREE.Group;
  pos: THREE.Vector3;
  path: THREE.Vector3[];
  yaw: number;
  task: 'mop' | 'fix' | null;
  until: number;
  stop: string;
}

function makeMaintBot(): MaintBot {
  const color = MAINT.color;
  const g = new THREE.Group();
  g.userData.id = 'maint';
  g.scale.setScalar(1.12);
  const suit = mat('#c2410c', 0.55, 0.15);
  const shell = physMat({ color: '#f5f1e8', roughness: 0.3, metalness: 0.3, clearcoat: 0.7 });
  const dark = mat('#0b0f17', 0.4, 0.3);
  const pants = mat('#1e3a5f', 0.6, 0.1);
  const gloss = new THREE.MeshStandardMaterial({ color: '#05080f', roughness: 0.12, metalness: 0.75 });
  const metal = mat('#cfd6e2', 0.3, 0.7);
  const hat = mat('#facc15', 0.4, 0.2);
  const eyes: THREE.Mesh[] = [];

  // torso with a hi-vis stripe, pelvis and tool belt
  rbox(g, 1.02, 1.1, 0.62, 0.2, suit, 0, 1.52, 0);
  rbox(g, 1.06, 0.12, 0.66, 0.04, mat('#fde047', 0.4, 0.1), 0, 1.35, 0, false);
  rbox(g, 1.06, 0.12, 0.66, 0.04, mat('#fde047', 0.4, 0.1), 0, 1.7, 0, false);
  rbox(g, 0.9, 0.3, 0.56, 0.1, dark, 0, 0.98, 0);
  rbox(g, 1.08, 0.14, 0.7, 0.04, mat('#78350f', 0.7), 0, 1.1, 0, false);
  [-0.38, 0.38].forEach((x) => rbox(g, 0.16, 0.26, 0.12, 0.03, mat('#9ca3af', 0.4, 0.6), x, 0.95, 0.36, false));
  cyl(g, 0.04, 0.04, 0.34, metal, 0.5, 0.9, 0.38, 8).rotation.z = 0.2;
  sphere(g, 0.2, suit, -0.66, 1.95, 0);
  sphere(g, 0.2, suit, 0.66, 1.95, 0);
  // chest badge: a gear
  const gear = new THREE.Mesh(new THREE.TorusGeometry(0.17, 0.05, 6, 8), glowMat(color, 1.8));
  gear.position.set(0, 1.55, 0.32);
  g.add(gear);
  cyl(g, 0.3, 0.34, 0.1, hat, 0, 2.03, 0);
  cyl(g, 0.14, 0.14, 0.2, dark, 0, 2.1, 0);

  // head + hard hat with a lamp
  rbox(g, 1.08, 0.86, 0.92, 0.3, shell, 0, 2.55, 0);
  rbox(g, 0.9, 0.5, 0.1, 0.2, gloss, 0, 2.54, 0.43, false);
  [-0.2, 0.2].forEach((ex) => eyes.push(rbox(g, 0.17, 0.2, 0.05, 0.06, glowMat(color, 2.6), ex, 2.58, 0.5, false)));
  const smile = new THREE.Mesh(new THREE.TorusGeometry(0.1, 0.016, 6, 14, Math.PI), glowMat(color, 1.8));
  smile.rotation.z = Math.PI;
  smile.position.set(0, 2.46, 0.5);
  g.add(smile);
  [-1, 1].forEach((sx) => {
    cyl(g, 0.2, 0.2, 0.14, mat(color, 0.35, 0.6), sx * 0.6, 2.55, 0).rotation.z = Math.PI / 2;
  });
  const dome = new THREE.Mesh(new THREE.SphereGeometry(0.62, 20, 10, 0, Math.PI * 2, 0, Math.PI / 2), hat);
  dome.position.set(0, 2.92, 0);
  dome.castShadow = true;
  g.add(dome);
  cyl(g, 0.7, 0.7, 0.07, hat, 0, 2.93, 0.05, 24);
  rbox(g, 0.2, 0.14, 0.14, 0.04, glowMat('#fff7c2', 2.2), 0, 3.05, 0.6, false);

  const mkLimb = (x: number, y: number, len: number, rad: number, m: THREE.Material) => {
    const l = new THREE.Group();
    l.position.set(x, y, 0);
    const mesh = new THREE.Mesh(new THREE.CapsuleGeometry(rad, Math.max(0.01, len - rad * 2), 4, 10), m);
    mesh.position.y = -len / 2;
    mesh.castShadow = true;
    l.add(mesh);
    g.add(l);
    return l;
  };
  const legL = mkLimb(-0.28, 0.98, 0.95, 0.17, pants);
  const legR = mkLimb(0.28, 0.98, 0.95, 0.17, pants);
  const armL = mkLimb(-0.66, 1.95, 0.85, 0.12, suit);
  const armR = mkLimb(0.66, 1.95, 0.85, 0.12, suit);
  const boot = mat('#3b2a1a', 0.6, 0.1);
  [legL, legR].forEach((l) => rbox(l, 0.4, 0.2, 0.58, 0.09, boot, 0, -0.93, 0.09));
  const glove = mat('#fde047', 0.6);
  [armL, armR].forEach((a) => sphere(a, 0.15, glove, 0, -0.85, 0));

  // mop in the right hand
  const mop = new THREE.Group();
  mop.position.set(0, -0.85, 0.15);
  cyl(mop, 0.04, 0.04, 2.6, mat('#a16207', 0.6), 0, -0.9, 0.2, 8);
  const head = box(mop, 0.9, 0.12, 0.3, mat('#e5e7eb', 0.9), 0, -2.2, 0.2, false);
  head.rotation.x = 0.1;
  armR.add(mop);
  // wrench in the right hand (shown instead of the mop while fixing)
  const wrench = new THREE.Group();
  wrench.position.set(0, -0.9, 0.2);
  cyl(wrench, 0.06, 0.06, 0.8, metal, 0, -0.25, 0, 8);
  const jaw = new THREE.Mesh(new THREE.TorusGeometry(0.16, 0.06, 6, 10, Math.PI * 1.5), metal);
  jaw.position.set(0, -0.72, 0);
  wrench.add(jaw);
  wrench.visible = false;
  armR.add(wrench);

  // bucket (beside him while mopping) and a "wet floor" sign (placed in the world)
  const bucket = new THREE.Group();
  const bk = cyl(bucket, 0.38, 0.28, 0.55, mat('#2563eb', 0.5, 0.2), 0, 0.28, 0, 14);
  bk.castShadow = true;
  cyl(bucket, 0.33, 0.33, 0.04, mat('#7dd3fc', 0.2, 0.1), 0, 0.5, 0, 14);
  bucket.position.set(1.1, 0, 0.5);
  bucket.visible = false;
  g.add(bucket);

  const sign = new THREE.Group();
  const panelL = box(sign, 0.8, 1.1, 0.06, mat('#facc15', 0.45, 0.1), -0.0, 0.62, 0.2, false);
  panelL.rotation.x = -0.22;
  const panelR = box(sign, 0.8, 1.1, 0.06, mat('#facc15', 0.45, 0.1), 0, 0.62, -0.2, false);
  panelR.rotation.x = 0.22;
  const warn = canvasTex(128, 160, (c) => {
    c.fillStyle = '#facc15';
    c.fillRect(0, 0, 128, 160);
    c.fillStyle = '#111827';
    c.font = 'bold 76px sans-serif';
    c.textAlign = 'center';
    c.fillText('⚠', 64, 84);
    c.font = 'bold 26px sans-serif';
    c.fillText('WET', 64, 124);
    c.fillText('FLOOR', 64, 152);
  });
  const face = new THREE.Mesh(new THREE.PlaneGeometry(0.72, 0.9), new THREE.MeshBasicMaterial({ map: warn.t, toneMapped: false }));
  face.position.set(0, 0.62, 0.26);
  face.rotation.x = -0.22;
  sign.add(face);
  sign.visible = false;

  // back plate with the name
  const plate = canvasTex(256, 96, (c) => {
    c.clearRect(0, 0, 256, 96);
    c.fillStyle = 'rgba(8,12,20,0.92)';
    c.beginPath();
    c.roundRect(4, 4, 248, 88, 22);
    c.fill();
    c.strokeStyle = color;
    c.lineWidth = 5;
    c.stroke();
    c.fillStyle = '#f8fafc';
    c.font = 'bold 54px sans-serif';
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.fillText(MAINT.name, 128, 52);
  });
  const pm = new THREE.Mesh(new THREE.PlaneGeometry(0.82, 0.31), new THREE.MeshBasicMaterial({ map: plate.t, transparent: true, toneMapped: false }));
  pm.position.set(0, 1.72, -0.325);
  pm.rotation.y = Math.PI;
  g.add(pm);

  const start = NODES.L4.clone();
  return { group: g, legL, legR, armL, armR, eyes, mop, wrench, bucket, sign, pos: start, path: [], yaw: Math.PI, task: null, until: 0, stop: 'L4' };
}

/* ------------------------------------------------------------------ *
 * Video editor "Reel": nakaupo sa sariling table sa Server Room (office ni Dex), may holo timeline sa ibabaw ng desk.
 * What he does follows the real video jobs (working / waiting for approval / problem / idle) -
 * nothing here is invented, and he is not part of the team meetings or the walking graph.
 * ------------------------------------------------------------------ */
/** Si Reel ay nasa Server Room na (office ni Dex): sariling table sa hilagang-silangang sulok, malapit sa pinto. */
const REEL_DESK = (() => {
  const r = rb(ROOMS.server);
  const cx = r.x1 - 3.4;
  const seatZ = ZDOOR - 1.7;
  return { cx, seatZ, deskZ: seatZ - 1.65 };
})();
const REEL_HOME = new THREE.Vector3(REEL_DESK.cx, 0, REEL_DESK.seatZ);

interface ReelBot {
  /** stationary root (holo editing table lives here) */
  group: THREE.Group;
  /** the figure itself: walks to the meeting table */
  body: THREE.Group;
  legL: THREE.Group;
  legR: THREE.Group;
  armL: THREE.Group;
  armR: THREE.Group;
  eyes: THREE.Mesh[];
  clapper: THREE.Group;
  mug: THREE.Group;
  console: THREE.Group;
  food: THREE.Group;
  zzz: THREE.Mesh;
  screen: THREE.Mesh;
  playhead: THREE.Mesh;
}

function makeReelBot(): ReelBot {
  const color = REEL.color;
  const root = new THREE.Group();
  root.userData.id = 'reel';
  root.scale.setScalar(1.12);
  const g = new THREE.Group();
  g.userData.id = 'reel';
  root.add(g);
  const suit = mat('#2a2140', 0.5, 0.2);
  const shell = physMat({ color: '#f5f1e8', roughness: 0.25, metalness: 0.35, clearcoat: 0.8 });
  const dark = mat('#0b0f17', 0.4, 0.3);
  const pants = mat('#161b2b', 0.6, 0.1);
  const gloss = new THREE.MeshStandardMaterial({ color: '#05080f', roughness: 0.12, metalness: 0.75 });
  const metal = mat('#cfd6e2', 0.3, 0.7);
  const accent = mat(color, 0.4, 0.3);
  const eyes: THREE.Mesh[] = [];

  // torso with an accent stripe, pelvis and belt
  rbox(g, 1.02, 1.1, 0.62, 0.2, suit, 0, 1.52, 0);
  rbox(g, 1.06, 0.1, 0.66, 0.04, accent, 0, 1.8, 0, false);
  rbox(g, 0.9, 0.3, 0.56, 0.1, dark, 0, 0.98, 0);
  rbox(g, 1.08, 0.1, 0.7, 0.04, accent, 0, 1.1, 0, false);
  sphere(g, 0.2, suit, -0.66, 1.95, 0);
  sphere(g, 0.2, suit, 0.66, 1.95, 0);
  // chest badge: a film reel
  const badge = new THREE.Mesh(new THREE.TorusGeometry(0.17, 0.05, 6, 14), glowMat(color, 1.8));
  badge.position.set(0, 1.55, 0.32);
  g.add(badge);
  cyl(g, 0.05, 0.05, 0.06, dark, 0, 1.55, 0.33, 8).rotation.x = Math.PI / 2;
  [0, 1, 2].forEach((i) => {
    const a = (i / 3) * Math.PI * 2 + Math.PI / 2;
    sphere(g, 0.03, dark, Math.cos(a) * 0.1, 1.55 + Math.sin(a) * 0.1, 0.34);
  });

  // head with a glossy visor, glowing eyes and a smile
  rbox(g, 1.08, 0.86, 0.92, 0.3, shell, 0, 2.55, 0);
  rbox(g, 0.9, 0.5, 0.1, 0.2, gloss, 0, 2.54, 0.43, false);
  [-0.2, 0.2].forEach((ex) => eyes.push(rbox(g, 0.17, 0.2, 0.05, 0.06, glowMat(color, 2.6), ex, 2.58, 0.5, false)));
  const smile = new THREE.Mesh(new THREE.TorusGeometry(0.1, 0.016, 6, 14, Math.PI), glowMat(color, 1.8));
  smile.rotation.z = Math.PI;
  smile.position.set(0, 2.46, 0.5);
  g.add(smile);
  // headphones: band over the head, two ear cups and a little mic
  const band = new THREE.Mesh(new THREE.TorusGeometry(0.6, 0.05, 8, 24, Math.PI), dark);
  band.position.set(0, 2.55, 0);
  g.add(band);
  [-1, 1].forEach((sx) => {
    cyl(g, 0.22, 0.22, 0.16, dark, sx * 0.6, 2.55, 0).rotation.z = Math.PI / 2;
    cyl(g, 0.14, 0.14, 0.2, glowMat(color, 1.2), sx * 0.6, 2.55, 0, 14).rotation.z = Math.PI / 2;
  });
  cyl(g, 0.02, 0.02, 0.5, dark, -0.58, 2.4, 0.3, 6).rotation.x = Math.PI / 2;
  sphere(g, 0.045, glowMat(color, 1.6), -0.58, 2.4, 0.56);

  const mkLimb = (x: number, y: number, len: number, rad: number, m: THREE.Material) => {
    const l = new THREE.Group();
    l.position.set(x, y, 0);
    const mesh = new THREE.Mesh(new THREE.CapsuleGeometry(rad, Math.max(0.01, len - rad * 2), 4, 10), m);
    mesh.position.y = -len / 2;
    mesh.castShadow = true;
    l.add(mesh);
    g.add(l);
    return l;
  };
  const legL = mkLimb(-0.28, 0.98, 0.95, 0.17, pants);
  const legR = mkLimb(0.28, 0.98, 0.95, 0.17, pants);
  const armL = mkLimb(-0.66, 1.95, 0.85, 0.12, suit);
  const armR = mkLimb(0.66, 1.95, 0.85, 0.12, suit);
  const boot = mat('#1f1a2e', 0.6, 0.1);
  [legL, legR].forEach((l) => rbox(l, 0.4, 0.2, 0.58, 0.09, boot, 0, -0.93, 0.09));
  [armL, armR].forEach((a) => sphere(a, 0.15, accent, 0, -0.85, 0));

  // clapperboard in the right hand (only while he has nothing to edit)
  const clapper = new THREE.Group();
  clapper.position.set(0, -0.95, 0.24);
  box(clapper, 0.62, 0.44, 0.06, dark, 0, 0, 0, false);
  box(clapper, 0.62, 0.12, 0.07, mat('#f8fafc', 0.5), 0, 0.29, 0, false);
  [0, 1, 2].forEach((i) => box(clapper, 0.1, 0.12, 0.075, accent, -0.2 + i * 0.2, 0.29, 0, false));
  [-0.06, 0.08].forEach((y) => box(clapper, 0.5, 0.03, 0.07, metal, 0, y, 0, false));
  armR.add(clapper);

  // holo timeline hovering over his desk (the desk itself is built in the Server Room; he faces north)
  const holo = new THREE.Group();
  holo.rotation.y = Math.PI;
  root.add(holo);
  const tl = canvasTex(256, 160, (c) => {
    c.fillStyle = 'rgba(8,12,24,0.92)';
    c.fillRect(0, 0, 256, 160);
    c.strokeStyle = color;
    c.lineWidth = 6;
    c.strokeRect(3, 3, 250, 154);
    c.fillStyle = 'rgba(248,250,252,0.35)';
    for (let x = 14; x < 246; x += 16) c.fillRect(x, 14, 2, x % 64 === 14 ? 12 : 7);
    const clips: [number, number, number, string][] = [
      [14, 70, 0, color], [90, 60, 0, '#38bdf8'], [158, 84, 0, '#f472b6'],
      [14, 44, 1, '#a78bfa'], [66, 90, 1, color], [162, 80, 1, '#34d399'],
      [14, 110, 2, '#38bdf8'], [130, 112, 2, '#fbbf24'],
    ];
    clips.forEach(([x, w, row, col]) => {
      c.fillStyle = col;
      c.globalAlpha = 0.85;
      c.beginPath();
      c.roundRect(x, 40 + row * 38, w, 28, 6);
      c.fill();
    });
    c.globalAlpha = 1;
  });
  const screen = new THREE.Mesh(
    new THREE.PlaneGeometry(1.3, 0.82),
    new THREE.MeshBasicMaterial({ map: tl.t, transparent: true, opacity: 0.3, side: THREE.DoubleSide, toneMapped: false, depthWrite: false }),
  );
  screen.position.set(0, 1.55, 0.85);
  screen.rotation.x = -1.0;
  holo.add(screen);
  const playhead = new THREE.Mesh(
    new THREE.PlaneGeometry(0.025, 0.8),
    new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.3, side: THREE.DoubleSide, toneMapped: false, depthWrite: false }),
  );
  playhead.position.set(-0.58, 0, 0.01);
  screen.add(playhead);

  // coffee mug (in the right hand while on a coffee break)
  const mug = new THREE.Group();
  mug.position.set(0, -0.95, 0.24);
  cyl(mug, 0.14, 0.13, 0.24, mat('#f8fafc', 0.4), 0, 0, 0, 14);
  cyl(mug, 0.12, 0.12, 0.02, mat('#4a2c1a', 0.5), 0, 0.12, 0, 14);
  const handle = new THREE.Mesh(new THREE.TorusGeometry(0.07, 0.02, 6, 10, Math.PI), mat('#f8fafc', 0.4));
  handle.position.set(0.14, 0, 0);
  handle.rotation.z = -Math.PI / 2;
  mug.add(handle);
  mug.visible = false;
  armR.add(mug);

  // handheld game console (both hands, in front of his chest while playing)
  const gameBox = new THREE.Group();
  gameBox.position.set(0, 1.6, 0.8);
  gameBox.rotation.x = -0.5;
  rbox(gameBox, 1.2, 0.12, 0.62, 0.04, dark, 0, 0, 0);
  const gameScreen = new THREE.Mesh(new THREE.PlaneGeometry(0.7, 0.4), glowMat(color, 1.1));
  gameScreen.position.set(0, 0.07, 0);
  gameScreen.rotation.x = -Math.PI / 2;
  gameBox.add(gameScreen);
  gameBox.visible = false;
  g.add(gameBox);

  // lunch box (both hands, in front of his chest while eating)
  const food = makeFoodPlate();
  food.position.set(0, 1.5, 0.75);
  food.visible = false;
  g.add(food);

  // zzz (floating above his head while he naps)
  const zzzTex = canvasTex(128, 128, (c) => {
    c.clearRect(0, 0, 128, 128);
    c.fillStyle = '#e0e7ff';
    c.font = 'bold 84px sans-serif';
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.fillText('z', 64, 66);
  });
  const zzz = new THREE.Mesh(
    new THREE.PlaneGeometry(0.6, 0.6),
    new THREE.MeshBasicMaterial({ map: zzzTex.t, transparent: true, depthWrite: false, toneMapped: false }),
  );
  zzz.position.set(0.6, 3.3, 0);
  zzz.visible = false;
  g.add(zzz);

  // back plate with the name
  const plate = canvasTex(256, 96, (c) => {
    c.clearRect(0, 0, 256, 96);
    c.fillStyle = 'rgba(8,12,20,0.92)';
    c.beginPath();
    c.roundRect(4, 4, 248, 88, 22);
    c.fill();
    c.strokeStyle = color;
    c.lineWidth = 5;
    c.stroke();
    c.fillStyle = '#f8fafc';
    c.font = 'bold 54px sans-serif';
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.fillText(REEL.name, 128, 52);
  });
  const pm = new THREE.Mesh(new THREE.PlaneGeometry(0.82, 0.31), new THREE.MeshBasicMaterial({ map: plate.t, transparent: true, toneMapped: false }));
  pm.position.set(0, 1.72, -0.325);
  pm.rotation.y = Math.PI;
  g.add(pm);

  root.position.copy(REEL_HOME);
  return { group: root, body: g, legL, legR, armL, armR, eyes, clapper, mug, console: gameBox, food, zzz, screen, playhead };
}

/* ------------------------------------------------------------------ *
 * Component
 * ------------------------------------------------------------------ */
interface Props {
  activity: Record<AgentId, AgentActivity>;
  places: Record<MemberId, Place>;
  speech: Partial<Record<MemberId, string>>;
  phase: Phase;
  /** kaninong office pumupunta si Dex (IT) para mag-ayos; null kapag nasa Server Room */
  itTarget?: TeamId | null;
  /** sino ang may sirang internet/computer (pula ang monitor hanggang maayos) */
  broken?: TeamId | null;
  isNight: boolean;
  /** energy at ginagawa (trabaho / kape / laro / idlip) ng bawat AI employee */
  routine?: Record<AgentId, Routine>;
  /** energy at ginagawa ni Argus (kape / laro / idlip / kain) */
  argus?: BreakRoutine;
  /** Reel (video editor): his pose follows the real video jobs; null/undefined = idle */
  reel?: ReelStatus | null;
  /** Boss talks to Reel or Fixo (they are not sim members): a one-off speech bubble over their head */
  callout?: { who: 'reel' | 'fixo'; text: string; n: number } | null;
  onSelect: (id: AgentId) => void;
  onBossClick: () => void;
  /** click kay Boss: buksan ang "Kausapin si Boss" (si Ms. Mira ay brainstorm pa rin) */
  onBossTalk?: () => void;
  /** called when the phone's GPU gave the canvas back after losing it (the office is rebuilt) */
  onContextRestored?: () => void;
  /** called once, right after the first frame is on screen */
  onReady?: () => void;
}

const ACT_BUBBLE_MS = 5000;

const ROOM_LABELS: { key: string; text: string; sub: string; color: string; x: number; z: number }[] = [];

function Office3D({ activity, places, speech, phase, itTarget = null, broken = null, isNight, routine, argus, reel = null, callout = null, onSelect, onBossClick, onBossTalk, onContextRestored, onReady }: Props) {
  const hostRef = useRef<HTMLDivElement>(null);
  const tagRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const roomRefs = useRef<Record<string, HTMLDivElement | null>>({});
  const maintBubble = useRef<HTMLDivElement | null>(null);
  const reelBubble = useRef<HTMLDivElement | null>(null);
  const reelBarRef = useRef<HTMLDivElement | null>(null);
  const reelDoingRef = useRef<HTMLSpanElement | null>(null);
  const [hint, setHint] = useState(true);
  const [phone, setPhone] = useState(() => (typeof window !== 'undefined' ? window.innerWidth < 640 : false));
  const phoneRef = useRef(phone);
  phoneRef.current = phone;
  useEffect(() => {
    const onResize = () => setPhone(window.innerWidth < 640);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);
  // work/idle bubbles only stay a few seconds, then hide so they stop covering the office
  const [, setBubbleTick] = useState(0);
  const seenBubble = useRef<Record<string, { text: string; at: number }>>({});
  const expireIn = useRef(Infinity);
  expireIn.current = Infinity;
  useEffect(() => {
    if (!Number.isFinite(expireIn.current)) return;
    const t = window.setTimeout(() => setBubbleTick((n) => n + 1), expireIn.current + 60);
    return () => window.clearTimeout(t);
  });
  useEffect(() => {
    const t = window.setTimeout(() => setHint(false), 7000);
    return () => window.clearTimeout(t);
  }, []);
  const live = useRef({ activity, places, speech, phase, itTarget, broken, isNight, argus, reel, callout, onSelect, onBossClick, onBossTalk });
  live.current = { activity, places, speech, phase, itTarget, broken, isNight, argus, reel, callout, onSelect, onBossClick, onBossTalk };
  const restoreRef = useRef(onContextRestored);
  restoreRef.current = onContextRestored;
  const readyRef = useRef(onReady);
  readyRef.current = onReady;

  if (ROOM_LABELS.length === 0) {
    AGENTS.forEach((a) => {
      const r = rb(ROOMS[a.id]);
      ROOM_LABELS.push({ key: a.id, text: `🔒 ${a.name}'s Office`, sub: a.role, color: a.color, x: (r.x0 + r.x1) / 2, z: r.z0 });
    });
    const bo = rb(ROOMS.boss);
    ROOM_LABELS.push({ key: 'boss', text: '👑 Boss Office', sub: `${BOSS.name} · ${BOSS.role}`, color: BOSS.color, x: 0, z: bo.z0 });
    ROOM_LABELS.push({ key: 'lab', text: '🧠 Shared Brain', sub: 'Lessons · Meeting room', color: '#a78bfa', x: 0, z: rb(ROOMS.lab).z0 });
    ROOM_LABELS.push({ key: 'bar', text: '☕ Mini Bar', sub: 'Kape at kwentuhan', color: '#fb923c', x: 0, z: rb(ROOMS.bar).z1 });
    const sv = rb(ROOMS.server);
    ROOM_LABELS.push({ key: 'server', text: '🖥️ Server Room', sub: `${IT_STAFF.name} · ${IT_STAFF.role}`, color: IT_STAFF.color, x: (sv.x0 + sv.x1) / 2, z: sv.z0 });
    ROOM_LABELS.push({ key: 'canteen', text: '🍽️ Canteen', sub: 'Almusal 7AM · Tanghalian 12NN · Hapunan 6PM', color: '#f59e0b', x: 0, z: rb(ROOMS.canteen).z0 });
    const ag = rb(ROOMS.argus);
    ROOM_LABELS.push({ key: 'argus', text: '👁️ Argus HQ', sub: `${ARGUS.name} · ${ARGUS.role}`, color: ARGUS.color, x: (ag.x0 + ag.x1) / 2, z: ag.z0 });
    const ac = rb(ROOMS.arcade);
    ROOM_LABELS.push({ key: 'arcade', text: '🕹️ Arcade', sub: 'Pampa-relax ng team', color: '#c084fc', x: (ac.x0 + ac.x1) / 2, z: ac.z0 });
  }

  useEffect(() => {
    const host = hostRef.current!;
    const scene = new THREE.Scene();
    // near = 4 (was 0.5): the camera never gets closer than ~24 units, and a larger near plane stops the floor / carpet / glass z-fighting (flicker) on phones with a 16-bit depth buffer
    const camera = new THREE.PerspectiveCamera(38, 1, 4, 300);
    // Android / phones: lighter rendering so the office stays smooth (desktop keeps full quality)
    const coarse = COARSE;
    const maxPR = coarse ? 1.5 : 2;
    const basePR = Math.min(window.devicePixelRatio || 1, maxPR);
    let curPR = basePR;
    const renderer = new THREE.WebGLRenderer({
      antialias: !coarse || (window.devicePixelRatio || 1) <= 1.25,
      alpha: false,
      stencil: false,
      powerPreference: coarse ? 'default' : 'high-performance',
    });
    renderer.setPixelRatio(curPR);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = coarse ? THREE.PCFShadowMap : THREE.PCFSoftShadowMap;
    // phones: refresh the shadow map every 2nd frame (the bots move slowly, nobody sees it)
    renderer.shadowMap.autoUpdate = !coarse;
    renderer.shadowMap.needsUpdate = true;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    // image-based lighting: glass, metal, the glossy floor and the bots' shells pick up soft room reflections
    const pmrem = new THREE.PMREMGenerator(renderer);
    const envMap = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envMap;
    scene.environmentIntensity = 0.45;
    scene.fog = new THREE.Fog('#101624', 130, 290);
    host.prepend(renderer.domElement);
    renderer.domElement.style.display = 'block';
    renderer.domElement.style.width = '100%';
    renderer.domElement.style.height = '100%';

    const controls = new OrbitControls(camera, renderer.domElement);
    controls.target.set(0, 0, 1.5 + WING / 2);
    controls.enablePan = false;
    controls.enableDamping = true;
    controls.dampingFactor = 0.08;
    controls.minPolarAngle = 0.35;
    controls.maxPolarAngle = 1.2;
    controls.minAzimuthAngle = -0.85;
    controls.maxAzimuthAngle = 0.85;
    controls.minDistance = 24;
    controls.maxDistance = 190;
    // phones: one-finger vertical swipe keeps scrolling the page; sideways = rotate; two fingers = zoom
    renderer.domElement.style.touchAction = 'pan-y';
    controls.touches = { ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN };

    /* ---- lights ---- */
    const hemi = new THREE.HemisphereLight('#dbe8ff', '#202636', 0.9);
    scene.add(hemi);
    const sun = new THREE.DirectionalLight('#fff1d6', 1.5);
    sun.position.set(-26, 62, 36 + WING / 2);
    sun.target.position.set(0, 0, WING / 2);
    scene.add(sun.target);
    sun.castShadow = true;
    const shadowRes = coarse ? 1024 : 4096;
    sun.shadow.mapSize.set(shadowRes, shadowRes);
    sun.shadow.camera.left = -54;
    sun.shadow.camera.right = 54;
    sun.shadow.camera.top = 52;
    sun.shadow.camera.bottom = -52;
    sun.shadow.camera.near = 1;
    sun.shadow.camera.far = 170;
    sun.shadow.bias = -0.0004;
    sun.shadow.normalBias = 0.03;
    scene.add(sun);
    // 12 real point lights made every pixel of every material run 12 light loops: on Android the GPU stalled
    // (the whole screen flashed / the WebGL context was lost). Phones now get a soft additive floor glow instead.
    const roomLights: { intensity: number }[] = [];
    let glowTex: THREE.CanvasTexture | null = null;
    const addRoomLight = (x: number, z: number, color: string) => {
      if (coarse) {
        if (!glowTex) {
          glowTex = canvasTex(128, 128, (c) => {
            const gr = c.createRadialGradient(64, 64, 0, 64, 64, 64);
            gr.addColorStop(0, 'rgba(255,255,255,0.9)');
            gr.addColorStop(0.45, 'rgba(255,255,255,0.35)');
            gr.addColorStop(1, 'rgba(255,255,255,0)');
            c.fillStyle = gr;
            c.fillRect(0, 0, 128, 128);
          }).t;
        }
        const gm = new THREE.MeshBasicMaterial({ map: glowTex, color, transparent: true, opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending, toneMapped: false, fog: false });
        const gp = new THREE.Mesh(new THREE.PlaneGeometry(30, 22), gm);
        gp.rotation.x = -Math.PI / 2;
        gp.position.set(x, 0.14, z);
        scene.add(gp);
        roomLights.push({
          get intensity() { return gm.opacity * 120; },
          set intensity(v: number) { gm.opacity = Math.min(0.5, v / 120); },
        });
        return;
      }
      const l = new THREE.PointLight(color, 0, 36, 1.5);
      l.position.set(x, 5.5, z);
      scene.add(l);
      roomLights.push(l);
    };

    /* ---- floor & building shell ---- */
    // polished oak planks (each plank a little different, with grain and gaps)
    const floorTex = canvasTex(1024, 1024, (c) => {
      c.fillStyle = '#2a1f17';
      c.fillRect(0, 0, 1024, 1024);
      const rows = 8;
      const rh = 1024 / rows;
      for (let r = 0; r < rows; r++) {
        let x = -((r * 173) % 340);
        while (x < 1024) {
          const len = 300 + ((r * 97 + x) % 5) * 22;
          const tone = 0.82 + Math.random() * 0.3;
          c.fillStyle = `rgb(${Math.round(104 * tone)},${Math.round(72 * tone)},${Math.round(46 * tone)})`;
          c.fillRect(x + 1.5, r * rh + 1.5, len - 3, rh - 3);
          c.globalAlpha = 0.16;
          for (let k = 0; k < 14; k++) {
            c.strokeStyle = Math.random() > 0.5 ? '#2b1a0e' : '#c79a6a';
            c.lineWidth = 1;
            const gy = r * rh + 4 + Math.random() * (rh - 8);
            c.beginPath();
            c.moveTo(x + 3, gy);
            c.bezierCurveTo(x + len * 0.3, gy + (Math.random() - 0.5) * 6, x + len * 0.65, gy + (Math.random() - 0.5) * 6, x + len - 3, gy + (Math.random() - 0.5) * 3);
            c.stroke();
          }
          c.globalAlpha = 1;
          x += len;
        }
      }
    });
    floorTex.t.wrapS = floorTex.t.wrapT = THREE.RepeatWrapping;
    floorTex.t.repeat.set(7, 4.6 * ((D + 4 + WING) / (D + 4)));
    floorTex.t.anisotropy = coarse ? 2 : 8;
    const floor = new THREE.Mesh(
      new THREE.BoxGeometry(W + 4, 0.4, D + 4 + WING),
      coarse
        ? new THREE.MeshStandardMaterial({ map: floorTex.t, roughness: 0.5, metalness: 0.0 })
        : physMat({ map: floorTex.t, roughness: 0.42, metalness: 0.0, clearcoat: 0.55, clearcoatRoughness: 0.22 }),
    );
    floor.position.set(0, -0.2, WING / 2);
    floor.receiveShadow = true;
    scene.add(floor);
    box(scene, W + 5, 0.3, 0.5, mat('#0d111a'), 0, 0.1, D / 2 + 2.2 + WING);
    // skyline back wall
    const sky = canvasTex(2048, 256, (c) => {
      const g = c.createLinearGradient(0, 0, 0, 256);
      g.addColorStop(0, '#2c6cc4');
      g.addColorStop(1, '#bcd8ff');
      c.fillStyle = g;
      c.fillRect(0, 0, 2048, 256);
      for (let i = 0; i < 52; i++) {
        const bw = 30 + Math.random() * 50;
        const bh = 60 + Math.random() * 130;
        const bx = i * 40 + Math.random() * 10;
        c.fillStyle = `rgb(${50 + Math.random() * 30},${64 + Math.random() * 30},${96 + Math.random() * 30})`;
        c.fillRect(bx, 256 - bh, bw, bh);
        c.fillStyle = 'rgba(255,225,150,0.85)';
        for (let y = 256 - bh + 8; y < 250; y += 14) for (let x = bx + 5; x < bx + bw - 6; x += 12) if (Math.random() > 0.55) c.fillRect(x, y, 5, 7);
      }
    });
    const skyMat = new THREE.MeshBasicMaterial({ map: sky.t, toneMapped: false, fog: false });
    const back = new THREE.Mesh(new THREE.PlaneGeometry(W + 4, 16), skyMat);
    back.position.set(0, 8.5, -D / 2 - 2);
    scene.add(back);
    box(scene, W + 4, 0.3, 0.4, mat('#0d111a'), 0, 0.4, -D / 2 - 1.9);
    // big window frame in front of the skyline: mullions, a sill and a top rail
    const frameMat = mat('#1a2233', 0.35, 0.6);
    for (let i = -4; i <= 4; i++) box(scene, 0.32, 16, 0.3, frameMat, i * 9.6, 8.5, -D / 2 - 1.85, false);
    box(scene, W + 4, 0.4, 0.4, frameMat, 0, 16.4, -D / 2 - 1.85, false);
    box(scene, W + 4, 0.35, 0.5, frameMat, 0, 4.6, -D / 2 - 1.85, false);
    box(scene, W + 4, 0.5, 0.9, mat('#e8e1d4', 0.4, 0.1), 0, 0.5, -D / 2 - 1.6);
    // dust motes drifting in the light
    const moteCount = 140;
    const motePos = new Float32Array(moteCount * 3);
    for (let i = 0; i < moteCount; i++) {
      motePos[i * 3] = (Math.random() - 0.5) * W * 0.9;
      motePos[i * 3 + 1] = 1 + Math.random() * 11;
      motePos[i * 3 + 2] = (Math.random() - 0.5) * (D + WING) * 0.9 + WING / 2;
    }
    const moteGeo = new THREE.BufferGeometry();
    moteGeo.setAttribute('position', new THREE.BufferAttribute(motePos, 3));
    const motes = new THREE.Points(moteGeo, new THREE.PointsMaterial({ color: '#fff6e0', size: 0.14, transparent: true, opacity: 0.3, depthWrite: false, sizeAttenuation: true }));
    scene.add(motes);

    /* ---- rooms ---- */
    const screens: Record<string, Screen[]> = {};
    const addRoom = (key: AgentId | 'boss' | 'lab' | 'bar' | 'server' | 'canteen' | 'arcade' | 'argus', color: string, carpet: string, gaps: { top?: Gap[]; bottom?: Gap[]; left?: Gap[]; right?: Gap[] }, skip: ('top' | 'bottom')[] = []) => {
      const r = rb(ROOMS[key]);
      const g = new THREE.Group();
      scene.add(g);
      const pad = new THREE.Mesh(new THREE.BoxGeometry(r.x1 - r.x0, 0.08, r.z1 - r.z0), carpetMat(carpet));
      pad.position.set((r.x0 + r.x1) / 2, 0.04, (r.z0 + r.z1) / 2);
      pad.receiveShadow = true;
      g.add(pad);
      // skip = mga pader na hati sa katabing kwarto (walang doble para hindi mag-flicker)
      if (!skip.includes('top')) wallLine(g, r.x0, r.z0, r.x1, r.z0, gaps.top ?? [], color);
      if (!skip.includes('bottom')) wallLine(g, r.x0, r.z1, r.x1, r.z1, gaps.bottom ?? [], color);
      wallLine(g, r.x0, r.z0, r.x0, r.z1, gaps.left ?? [], color);
      wallLine(g, r.x1, r.z0, r.x1, r.z1, gaps.right ?? [], color);
      addRoomLight((r.x0 + r.x1) / 2, (r.z0 + r.z1) / 2 + 1, key === 'bar' ? '#ffb066' : key === 'canteen' ? '#ffd9a0' : key === 'server' ? '#a5e8ff' : key === 'arcade' ? '#e0b3ff' : key === 'argus' ? '#ffd1d9' : '#ffe9c7');
      return { r, g };
    };
    const doorW = 3.4;

    const serverLeds: THREE.Mesh[] = [];
    const arcadeScreens: ArcadeScreen[] = [];
    const argusFeeds: Screen[] = [];
    const foodSteam: { m: THREE.Mesh; x: number; z: number }[] = [];
    let portal: ReturnType<typeof makeIdeaPortal> | null = null;
    const buildAll = () => {
      /* ---------------- hallways (runners, guide lights, plants, logo) ---------------- */
      const hall = new THREE.Group();
      scene.add(hall);
      const cxL = wx(29.5);
      const cxR = wx(70.5);
      const zTop = wz(3);
      const zBot = wz(97);
      const zMid = (zTop + zBot) / 2;
      [cxL, cxR].forEach((cx) => {
        makeRunner(hall, cx, zMid, 4.2, zBot - zTop, '#283246');
        makeGuide(hall, cx - 2.0, zMid, 0.1, zBot - zTop, '#38bdf8');
        makeGuide(hall, cx + 2.0, zMid, 0.1, zBot - zTop, '#38bdf8');
      });
      [wz(31), wz(67)].forEach((z) => {
        makeRunner(hall, 0, z, cxR - cxL, 3.0, '#283246');
        makeGuide(hall, 0, z - 1.4, cxR - cxL, 0.1, '#38bdf8');
        makeGuide(hall, 0, z + 1.4, cxR - cxL, 0.1, '#38bdf8');
      });
      const logo = canvasTex(1024, 256, (c) => {
        c.clearRect(0, 0, 1024, 256);
        c.fillStyle = 'rgba(251,191,36,0.9)';
        c.font = 'bold 150px sans-serif';
        c.textAlign = 'center';
        c.textBaseline = 'middle';
        c.fillText(`${BOSS.name} HQ`, 512, 130);
      });
      const logoMesh = new THREE.Mesh(new THREE.PlaneGeometry(10, 2.5), new THREE.MeshBasicMaterial({ map: logo.t, transparent: true, toneMapped: false, depthWrite: false }));
      logoMesh.rotation.x = -Math.PI / 2;
      logoMesh.position.set(0, 0.06, wz(31));
      hall.add(logoMesh);
      [-22, -6.4, 7.2, 22.6].forEach((z) => {
        makePlant(hall, cxL - 2.4, z, 0.9);
        makePlant(hall, cxR + 2.4, z, 0.9);
      });

      /* ---------------- left lounge (between Aria and Nova) ---------------- */
      const lxc = wx(14.5);
      makeRug(hall, lxc, 0, 11.5, 6.8, '#2e3a55');
      makeSofa(hall, lxc - 4.6, 0, Math.PI / 2, '#3b4f7a', 4.4);
      makeSofa(hall, lxc + 4.6, 0, -Math.PI / 2, '#3b4f7a', 4.4);
      makeCoffeeTable(hall, lxc, 0, 2.8, 1.4, Math.PI / 2);
      makePlant(hall, lxc - 7.8, -3.4, 1.3);
      makePlant(hall, lxc - 7.8, 3.4, 1.3);
      makeFloorLamp(hall, lxc + 7.6, -3.6);
      makeFloorLamp(hall, lxc + 7.6, 3.6);
      addRoomLight(lxc, 0, '#ffe9c7');

      /* ---------------- Argus HQ (Watchdog) — nasa pagitan nina Blaze at Cipher, ang pinto ay nakaharap sa kanang hallway ---------------- */
      {
        const ar0 = rb(ROOMS.argus);
        const doorCenter = (ar0.z0 + ar0.z1) / 2;
        const { r, g } = addRoom('argus', ARGUS.color, '#2b1a24', { left: [{ at: doorCenter - ar0.z0, w: doorW }] }, ['top', 'bottom']);
        const d = officeDesk('argus');
        const faceIn = -Math.PI / 2;

        // desk ni Argus (dalawang monitor) nakaharap sa CCTV wall
        makeRug(g, d.cx, d.deskZ + 1.5, 9.5, 5.4, new THREE.Color(ARGUS.color).multiplyScalar(0.22).getStyle());
        const asc: Screen[] = [];
        makeDesk(g, d.cx, d.deskZ, ARGUS.color, true, asc);
        screens.argus = asc;
        makeChair(g, d.cx, d.seatZ, '#2a1620');

        // CCTV wall sa hilagang pader: apat na camera, isa para sa bawat bot (nagbabago ayon sa totoong status nila)
        AGENTS.forEach((a, i) => {
          const fx = d.cx + (i - 1.5) * 2.62;
          const fz = r.z0 + 0.26;
          box(g, 2.5, 1.45, 0.08, mat('#0c0f15', 0.3, 0.5), fx, 2.2, fz, false);
          const { c, t } = canvasTex(192, 108, () => undefined);
          const feed = new THREE.Mesh(new THREE.PlaneGeometry(2.38, 1.34), new THREE.MeshBasicMaterial({ map: t, toneMapped: false }));
          feed.position.set(fx, 2.2, fz + 0.05);
          g.add(feed);
          argusFeeds.push({ c, t, color: a.color });
          // pulang REC light sa ibabaw ng bawat camera
          serverLeds.push(box(g, 0.14, 0.14, 0.06, glowMat('#ef4444', 1.6), fx + 1.0, 3.0, fz + 0.02, false));
        });
        // ilaw na umiikot-kumikislap sa ibabaw ng cabinet (alerto ng Watchdog)
        const beacon = box(g, 0.4, 0.4, 0.4, glowMat('#ef4444', 1.6), r.x1 - 1.0, 2.3, r.z0 + 2.6, false);
        serverLeds.push(beacon);

        // silangang pader: board ng na-miss + cabinets
        makeBoard(g, r.x1 - 0.2, 2.0, 0.7, 3.6, 1.7, faceIn, 'MISSED ITEMS', ARGUS.color, false);
        makeCabinet(g, r.x1 - 1.0, r.z0 + 1.1, faceIn);
        makeCabinet(g, r.x1 - 1.0, r.z0 + 2.6, faceIn);

        // lounge corner (timog pader): sofa + coffee table
        makeRug(g, r.x0 + 4.6, r.z1 - 3.0, 6.4, 4.0, '#3a2330');
        makeSofa(g, r.x0 + 4.6, r.z1 - 1.1, Math.PI, '#5a2f3f', 4.6);
        makeCoffeeTable(g, r.x0 + 4.6, r.z1 - 3.4);
        makeFloorLamp(g, r.x0 + 7.6, r.z1 - 1.0);

        // higaan ng aso ng watchdog 🐕 at buto
        cyl(g, 1.0, 1.1, 0.28, mat('#7f1d1d', 0.8), d.cx + 2.2, 0.18, r.z1 - 2.0, 24);
        cyl(g, 0.78, 0.78, 0.3, mat('#fecdd3', 0.9), d.cx + 2.2, 0.22, r.z1 - 2.0, 24);
        cyl(g, 0.07, 0.07, 0.55, mat('#f5f5f4', 0.6), d.cx + 2.2, 0.42, r.z1 - 2.0, 10).rotation.z = Math.PI / 2;
        [-0.28, 0.28].forEach((bx) => sphere(g, 0.12, mat('#f5f5f4', 0.6), d.cx + 2.2 + bx, 0.42, r.z1 - 2.0));

        // printer at cooler
        makePrinter(g, d.cx + 5.4, r.z1 - 0.9, Math.PI);
        makeCooler(g, r.x1 - 1.0, r.z1 - 1.0, Math.PI);

        // plants
        makePlant(g, r.x0 + 1.0, r.z0 + 1.2, 1.1);
        makePlant(g, r.x0 + 1.0, r.z1 - 0.9, 1.1);
        doorLight(g, r.x0, doorCenter, false, doorW, ARGUS.color);
      }

      /* ---------------- private offices ---------------- */
      const TITLES: Record<AgentId, string> = { aria: 'CONTENT PLAN', blaze: 'POST SCHEDULE', nova: 'INVITE RADAR', cipher: 'ANALYTICS' };
      AGENTS.forEach((a) => {
        const leftSide = a.id === 'aria' || a.id === 'nova';
        const rr = rb(ROOMS[a.id]);
        const doorCenter = (rr.z0 + rr.z1) / 2;
        const gaps = leftSide ? { right: [{ at: doorCenter - rr.z0, w: doorW }] } : { left: [{ at: doorCenter - rr.z0, w: doorW }] };
        const { r, g } = addRoom(a.id, a.color, leftSide ? '#27324a' : '#2a3347', gaps);
        const d = officeDesk(a.id);
        const ix = (o: number) => (leftSide ? r.x0 + o : r.x1 - o); // distance in from the outer wall
        const ox = (o: number) => (leftSide ? r.x1 - o : r.x0 + o); // distance in from the door-side wall
        const faceIn = leftSide ? Math.PI / 2 : -Math.PI / 2;
        const hue = (a.id.charCodeAt(0) * 37) % 360;

        // work zone
        makeRug(g, d.cx, d.deskZ + 1.5, 9.5, 6.4, new THREE.Color(a.color).multiplyScalar(0.22).getStyle());
        const sc: Screen[] = [];
        makeDesk(g, d.cx, d.deskZ, a.color, false, sc);
        screens[a.id] = sc;
        makeChair(g, d.cx, d.seatZ, '#1a2030');

        // back wall: credenza, art, shelves
        box(g, 6.6, 1.1, 1.0, mat('#3b2a1e', 0.55), d.cx, 0.55, r.z0 + 0.9);
        box(g, 6.8, 0.08, 1.1, mat('#6b4d38', 0.4), d.cx, 1.14, r.z0 + 0.9);
        makeDeskPlant(g, d.cx - 2.5, 1.18, r.z0 + 0.9);
        box(g, 0.6, 0.18, 0.4, mat(a.color, 0.6), d.cx + 1.8, 1.27, r.z0 + 0.9, false);
        box(g, 0.5, 0.16, 0.36, mat('#e5e7eb', 0.6), d.cx + 1.85, 1.44, r.z0 + 0.9, false);
        makeArt(g, d.cx, 2.45, r.z0 + 0.2, 3.4, 1.2, hue);
        makeShelf(g, r.x0 + 2.2, r.z0 + 0.6);
        makeShelf(g, r.x1 - 2.2, r.z0 + 0.6);

        // outer wall: themed board + cabinets
        makeBoard(g, ix(0.2), 2.0, d.deskZ + 1.2, 5.2, 2.2, faceIn, TITLES[a.id], a.color, a.id === 'cipher');
        makeCabinet(g, ix(1.0), d.deskZ + 5.4, faceIn);
        makeCabinet(g, ix(1.0), d.deskZ + 6.9, faceIn);

        // lounge corner
        makeRug(g, d.cx, r.z1 - 3.2, 10.5, 4.8, '#243049');
        makeSofa(g, d.cx, r.z1 - 1.1, Math.PI, '#33425e', 4.6);
        makeCoffeeTable(g, d.cx, r.z1 - 3.7);
        makeSofa(g, d.cx - 3.7, r.z1 - 3.7, Math.PI / 2, '#3d4d6b', 1.9);
        makeSofa(g, d.cx + 3.7, r.z1 - 3.7, -Math.PI / 2, '#3d4d6b', 1.9);
        makeFloorLamp(g, ix(1.4), r.z1 - 3.4);

        // plants
        makePlant(g, ix(1.0), r.z0 + 1.9, 1.1);
        makePlant(g, ix(1.0), r.z1 - 1.0, 1.2);
        makePlant(g, ox(1.0), r.z0 + 1.6, 1.0);
        makePlant(g, ox(1.0), r.z1 - 1.0, 1.2);

        if (a.id === 'cipher') {
          makeRack(g, ix(4.9), r.z0 + 1.2, 0);
          makeRack(g, ox(4.9), r.z0 + 1.2, 0);
        }
        doorLight(g, leftSide ? r.x1 : r.x0, doorCenter, false, doorW, a.color);
      });

      /* ---------------- boss office ---------------- */
      const bo = rb(ROOMS.boss);
      const bossGroup = addRoom('boss', BOSS.color, '#3a2c1f', { bottom: [{ at: (bo.x1 - bo.x0) / 2, w: doorW }] });
      const bg = bossGroup.g;
      const bd = officeDesk('boss');
      makeRug(bg, 0, bd.deskZ + 1.7, 11, 6, '#4a2f1b');
      const bsc: Screen[] = [];
      makeDesk(bg, 0, bd.deskZ, BOSS.color, true, bsc);
      screens.boss = bsc;
      makeChair(bg, 0, bd.seatZ, '#2a1a10');
      // desk ng secretary (Ms. Mira) sa tabi ng boss
      const sd = officeDesk('sec');
      const ssc: Screen[] = [];
      makeDesk(bg, sd.cx, sd.deskZ, SECRETARY.color, false, ssc);
      screens.sec = ssc;
      makeChair(bg, sd.cx, sd.seatZ, '#3b1f33');
      makeRug(bg, sd.cx, sd.deskZ + 1.4, 5.6, 4.6, '#3a1f33');
      const plate = canvasTex(256, 64, (c) => {
        c.fillStyle = '#831843';
        c.fillRect(0, 0, 256, 64);
        c.fillStyle = '#fbcfe8';
        c.font = 'bold 26px sans-serif';
        c.textAlign = 'center';
        c.textBaseline = 'middle';
        c.fillText('SECRETARY', 128, 34);
      });
      const plateMesh = new THREE.Mesh(new THREE.PlaneGeometry(1.4, 0.35), new THREE.MeshBasicMaterial({ map: plate.t, toneMapped: false }));
      plateMesh.rotation.y = Math.PI;
      plateMesh.position.set(sd.cx, 0.65, sd.deskZ - 0.75);
      bg.add(plateMesh);
      makeDeskPlant(bg, sd.cx + 1.3, 1.12, sd.deskZ - 0.3, 0.9);
      makeBoard(bg, bo.x1 - 0.3, 2.2, sd.deskZ + 0.2, 3.4, 1.4, -Math.PI / 2, '📅 MEETINGS & PLANS', SECRETARY.color, false);
      [bo.x0 + 2.2, bo.x0 + 5.6, bo.x1 - 5.6, bo.x1 - 2.2].forEach((x) => makeShelf(bg, x, bo.z0 + 0.6, 0, 3.2));
      box(bg, 7.4, 1.1, 1.0, mat('#3b2a1e', 0.55), 0, 0.55, bo.z0 + 0.9);
      box(bg, 7.6, 0.08, 1.1, mat('#7a5a3a', 0.35), 0, 1.14, bo.z0 + 0.9);
      makeNeon(bg, 0, 2.45, bo.z0 + 0.25, 6.4, 1.3, `👑 ${BOSS.name}`, '#f59e0b', '#fde68a');
      // trophies on the credenza
      cyl(bg, 0.18, 0.3, 0.12, mat('#fbbf24', 0.25, 0.9), 2.9, 1.25, bo.z0 + 0.9);
      cyl(bg, 0.28, 0.08, 0.35, mat('#fbbf24', 0.25, 0.9), 2.9, 1.5, bo.z0 + 0.9);
      cyl(bg, 0.18, 0.3, 0.12, mat('#fbbf24', 0.25, 0.9), -2.9, 1.25, bo.z0 + 0.9);
      cyl(bg, 0.28, 0.08, 0.35, mat('#fbbf24', 0.25, 0.9), -2.9, 1.5, bo.z0 + 0.9);
      // lounge (left) + globe (right)
      makeRug(bg, bo.x0 + 3.8, bo.z1 - 3.2, 8, 4.4, '#4a2f1b');
      makeSofa(bg, bo.x0 + 3.4, bo.z1 - 1.1, Math.PI, '#6b4a2a', 4.4);
      makeCoffeeTable(bg, bo.x0 + 3.4, bo.z1 - 3.5, 2.4, 1.2);
      makeFloorLamp(bg, bo.x0 + 1.0, bo.z0 + 2.4);
      cyl(bg, 0.5, 0.6, 0.15, mat('#fbbf24', 0.3, 0.8), bo.x1 - 3.2, 0.08, bo.z1 - 2.2);
      cyl(bg, 0.06, 0.06, 1.4, mat('#fbbf24', 0.3, 0.8), bo.x1 - 3.2, 0.8, bo.z1 - 2.2, 8);
      sphere(bg, 0.8, new THREE.MeshStandardMaterial({ color: '#2563eb', roughness: 0.4, metalness: 0.2 }), bo.x1 - 3.2, 2.0, bo.z1 - 2.2);
      makePlant(bg, bo.x1 - 1.0, bo.z1 - 1.0, 1.4);
      makePlant(bg, bo.x1 - 1.0, bo.z0 + 1.8, 1.2);
      makePlant(bg, bo.x0 + 1.0, bo.z1 - 1.0, 1.2);
      doorLight(bg, 0, bo.z1, true, doorW, BOSS.color);

      /* ---------------- idea lab ---------------- */
      const lb = rb(ROOMS.lab);
      const labCenterZ = (lb.z0 + lb.z1) / 2;
      const lab = addRoom('lab', '#a78bfa', '#2d2744', { left: [{ at: labCenterZ - lb.z0, w: doorW }], right: [{ at: labCenterZ - lb.z0, w: doorW }] });
      makeRug(lab.g, 0, TABLE_C.z, 15, 9, '#3a2f5c');
      const tableTop = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 0.16, 40), mat('#3d2f4f', 0.35, 0.2));
      tableTop.scale.set(4.2, 1, 2.1);
      tableTop.position.set(0, 1.1, TABLE_C.z);
      tableTop.castShadow = true;
      tableTop.receiveShadow = true;
      lab.g.add(tableTop);
      cyl(lab.g, 0.6, 0.9, 1.05, mat('#201832', 0.4, 0.4), 0, 0.55, TABLE_C.z);
      const ring = new THREE.Mesh(new THREE.TorusGeometry(1, 0.02, 8, 60), glowMat('#a78bfa', 1.8));
      ring.rotation.x = Math.PI / 2;
      ring.scale.set(4.2, 2.1, 1);
      ring.position.set(0, 1.19, TABLE_C.z);
      lab.g.add(ring);
      portal = makeIdeaPortal(lab.g, 0, TABLE_C.z);
      TEAM_IDS.forEach((id) => {
        const [sx, sz] = LAB_SEATS[id];
        const dir = new THREE.Vector3(TABLE_C.x - sx, 0, TABLE_C.z - sz);
        makeChair(lab.g, sx, sz, '#2b2142', Math.atan2(-dir.x, -dir.z));
      });
      // upuan ni Argus sa meeting (hilagang-silangan ng mesa)
      {
        const [ax, az] = ARGUS_LAB_SEAT;
        const dir = new THREE.Vector3(TABLE_C.x - ax, 0, TABLE_C.z - az);
        makeChair(lab.g, ax, az, '#2b2142', Math.atan2(-dir.x, -dir.z));
      }
      // extra chairs so Reel and Fixo sit down in meetings too
      (['reel', 'maint'] as const).forEach((k) => {
        const [sx, sz] = LAB_SEATS_EXTRA[k];
        const dir = new THREE.Vector3(TABLE_C.x - sx, 0, TABLE_C.z - sz);
        makeChair(lab.g, sx, sz, '#2b2142', Math.atan2(-dir.x, -dir.z));
      });
      const wb = canvasTex(512, 256, (c) => {
        c.fillStyle = '#f8fafc';
        c.fillRect(0, 0, 512, 256);
        c.fillStyle = '#6d28d9';
        c.font = 'bold 34px sans-serif';
        c.fillText('IDEA LAB', 20, 52);
        c.strokeStyle = '#94a3b8';
        c.lineWidth = 3;
        [[30, 90, 200], [30, 130, 300], [30, 170, 160]].forEach(([x, y, w]) => { c.beginPath(); c.moveTo(x, y); c.lineTo(x + w, y); c.stroke(); });
        ['#fde68a', '#fbcfe8', '#bae6fd', '#bbf7d0'].forEach((col, i) => { c.fillStyle = col; c.fillRect(300 + (i % 2) * 90, 80 + Math.floor(i / 2) * 80, 74, 66); });
      });
      const board = new THREE.Mesh(new THREE.PlaneGeometry(7.6, 2.3), new THREE.MeshBasicMaterial({ map: wb.t, toneMapped: false }));
      board.position.set(0, 1.95, lb.z0 + 0.25);
      lab.g.add(board);
      box(lab.g, 7.8, 2.5, 0.08, mat('#cbd5e1', 0.3, 0.6), 0, 1.95, lb.z0 + 0.2, false);
      makeSofa(lab.g, -6.2, lb.z1 - 1.1, Math.PI, '#3b2f5c', 4.6);
      makeSofa(lab.g, 6.2, lb.z1 - 1.1, Math.PI, '#3b2f5c', 4.6);
      makeFloorLamp(lab.g, lb.x0 + 1.2, lb.z0 + 1.6, '#c4b5fd');
      makeFloorLamp(lab.g, lb.x1 - 1.2, lb.z0 + 1.6, '#c4b5fd');
      makePlant(lab.g, lb.x0 + 1.0, lb.z1 - 1.0, 1.2);
      makePlant(lab.g, lb.x1 - 1.0, lb.z1 - 1.0, 1.2);
      doorLight(lab.g, lb.x0, labCenterZ, false, doorW, '#a78bfa');
      doorLight(lab.g, lb.x1, labCenterZ, false, doorW, '#a78bfa');

      /* ---------------- mini bar ---------------- */
      const mb = rb(ROOMS.bar);
      const barDoorZ = wz(84);
      const bar = addRoom('bar', '#fb923c', '#3b2a22', { left: [{ at: barDoorZ - mb.z0, w: doorW }], right: [{ at: barDoorZ - mb.z0, w: doorW }] });
      const counterZ = BAR_COUNTER_Z;
      box(bar.g, 17.6, 1.3, 1.4, mat('#6b3f22', 0.5), 0, 0.65, counterZ);
      box(bar.g, 18, 0.14, 1.7, mat('#e7d3b0', 0.3, 0.1), 0, 1.37, counterZ);
      box(bar.g, 17.6, 0.04, 0.04, glowMat('#fb923c', 1.8), 0, 0.12, counterZ + 0.72, false);
      // back counter, shelf, fridges
      box(bar.g, 17.6, 1.2, 0.9, mat('#4a2b18', 0.6), 0, 0.6, mb.z0 + 0.8);
      box(bar.g, 15, 0.08, 0.5, mat('#e7d3b0'), 0, 1.9, mb.z0 + 0.4);
      for (let i = 0; i < 12; i++) cyl(bar.g, 0.14, 0.12, 0.26, mat(new THREE.Color().setHSL(i / 12, 0.5, 0.7), 0.4), -6.6 + i * 1.2, 2.08, mb.z0 + 0.4);
      box(bar.g, 1.6, 3.2, 1.2, mat('#c8d0dc', 0.3, 0.7), mb.x1 - 1.3, 1.6, mb.z0 + 1.1);
      box(bar.g, 1.6, 3.2, 1.2, mat('#c8d0dc', 0.3, 0.7), mb.x0 + 1.3, 1.6, mb.z0 + 1.1);
      // coffee machine
      const cm = new THREE.Group();
      cm.position.set(-1.2, 1.44, counterZ);
      box(cm, 1.3, 1.1, 0.8, mat('#1a1d26', 0.3, 0.6), 0, 0.55, 0);
      box(cm, 0.5, 0.25, 0.04, glowMat('#34d399', 1.6), 0.25, 0.8, 0.42, false);
      box(cm, 0.14, 0.14, 0.04, glowMat('#ef4444', 1.8), -0.3, 0.8, 0.42, false);
      cyl(cm, 0.09, 0.09, 0.3, mat('#9ca3af', 0.3, 0.8), 0, 0.35, 0.3);
      bar.g.add(cm);
      [-7.4, -6.6, -3.4, -2.6, 0.2, 0.9, 2.8, 4.0, 4.8, 6.4, 7.6].forEach((x, i) => {
        cyl(bar.g, 0.17, 0.13, 0.3, mat(i % 2 ? '#ffffff' : '#fb923c', 0.4), x, 1.6, counterZ + (i % 2 ? 0.25 : -0.15));
      });
      [3.4, 3.8].forEach((x) => { const tr = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.09, 10, 18), mat('#e0a458', 0.6)); tr.rotation.x = Math.PI / 2; tr.position.set(x, 1.5, counterZ); bar.g.add(tr); });
      cyl(bar.g, 0.3, 0.38, 0.5, mat('#9ca3af', 0.25, 0.9), 5.4, 1.7, counterZ);
      makeNeon(bar.g, 0, 2.75, mb.z0 + 0.2, 5.4, 1.0, '☕ MINI BAR', '#fb923c', '#fed7aa');
      // bangko sa harap ng counter (kung saan sila umuupo habang nagkakape)
      TEAM_IDS.forEach((id) => makeStool(bar.g, BAR_SEATS[id][0], BAR_SEATS[id][1], new THREE.Color(COLORS[id]).multiplyScalar(0.8)));
      // mga dyaryo sa counter
      makeNewspaperFlat(bar.g, -5.0, 1.44, counterZ + 0.1, 0.25, 0);
      makeNewspaperFlat(bar.g, 1.9, 1.44, counterZ + 0.1, -0.2, 1);
      // bistro tables + stools
      [-9.6, 9.6].forEach((x) => {
        const tz = mb.z1 - 3.2;
        cyl(bar.g, 0.8, 0.8, 0.1, mat('#e7d3b0'), x, 1.7, tz);
        cyl(bar.g, 0.1, 0.1, 1.6, mat('#222'), x, 0.85, tz);
        makeNewspaperFlat(bar.g, x, 1.75, tz, x < 0 ? 0.5 : -0.4, x < 0 ? 2 : 1);
        [-1.3, 1.3].forEach((dx) => {
          cyl(bar.g, 0.35, 0.3, 0.12, mat('#fb923c', 0.5), x + dx, 1.25, tz);
          cyl(bar.g, 0.06, 0.06, 1.2, mat('#222'), x + dx, 0.62, tz, 8);
        });
      });
      makePlant(bar.g, mb.x0 + 1.0, mb.z1 - 1.0, 1.2);
      makePlant(bar.g, mb.x1 - 1.0, mb.z1 - 1.0, 1.2);
      doorLight(bar.g, mb.x0, barDoorZ, false, doorW, '#fb923c');
      doorLight(bar.g, mb.x1, barDoorZ, false, doorW, '#fb923c');

      /* ================= TIMOG PAKPAK: Server Room · Canteen · Arcade ================= */
      // pagpapahaba ng dalawang hallway papunta sa timog pakpak
      const hallS = new THREE.Group();
      scene.add(hallS);
      const zA = wz(97);
      const zMidS = (zA + ZW1) / 2;
      [cxL, cxR].forEach((cx) => {
        makeRunner(hallS, cx, zMidS, 4.2, ZW1 - zA, '#283246');
        makeGuide(hallS, cx - 2.0, zMidS, 0.1, ZW1 - zA, '#38bdf8');
        makeGuide(hallS, cx + 2.0, zMidS, 0.1, ZW1 - zA, '#38bdf8');
        makePlant(hallS, cx - 2.4, ZW0 + 2.2, 0.9);
        makePlant(hallS, cx + 2.4, ZW1 - 1.4, 0.9);
      });

      /* ---------------- Server Room (IT) ---------------- */
      const sr = rb(ROOMS.server);
      const serverRoom = addRoom('server', IT_STAFF.color, '#14202c', { right: [{ at: ZDOOR - sr.z0, w: doorW }] });
      const sg = serverRoom.g;
      // mga cable tray na umiilaw sa sahig
      [sr.z0 + 3.4, ZDOOR + 3.2].forEach((zz) => makeGuide(sg, (sr.x0 + sr.x1) / 2, zz, sr.x1 - sr.x0 - 1.2, 0.07, IT_STAFF.color));
      // mga server rack sa hilagang pader at kanlurang pader
      for (let i = 0; i < 6; i++) makeRack(sg, sr.x0 + 2.0 + i * 1.7, sr.z0 + 1.1, 0, serverLeds);
      for (let i = 0; i < 5; i++) makeRack(sg, sr.x0 + 1.1, sr.z0 + 4.4 + i * 1.7, Math.PI / 2, serverLeds);
      // desk ni Dex
      const itd = officeDesk('it');
      makeRug(sg, itd.cx, itd.deskZ + 1.4, 7.2, 5.0, '#12303d');
      const isc: Screen[] = [];
      makeDesk(sg, itd.cx, itd.deskZ, IT_STAFF.color, true, isc);
      screens.it = isc;
      makeChair(sg, itd.cx, itd.seatZ, '#0f2a36');
      // bagong table ni Reel (video editor) sa tabi ng pinto, hilagang-silangan ng Server Room
      makeRug(sg, REEL_DESK.cx, REEL_DESK.deskZ + 1.2, 5.0, 4.2, new THREE.Color(REEL.color).multiplyScalar(0.2).getStyle());
      const rsc: Screen[] = [];
      makeDesk(sg, REEL_DESK.cx, REEL_DESK.deskZ, REEL.color, false, rsc);
      makeChair(sg, REEL_DESK.cx, REEL_DESK.seatZ, '#2a2140');
      rsc.forEach(({ c, t }) => {
        // nakatigil na timeline sa monitor niya (ang gumagalaw na holo timeline ay nasa ibabaw ng desk)
        c.fillStyle = '#0b1020';
        c.fillRect(0, 0, 192, 108);
        ([[10, 20, 80, REEL.color], [96, 20, 60, '#38bdf8'], [10, 52, 50, '#a78bfa'], [66, 52, 100, REEL.color], [10, 84, 120, '#f472b6']] as [number, number, number, string][]).forEach(([x, y, w, col]) => {
          c.fillStyle = col;
          c.globalAlpha = 0.85;
          c.fillRect(x, y, w, 18);
        });
        c.globalAlpha = 1;
        t.needsUpdate = true;
      });
      // workbench sa timog pader: laptop, ekstrang monitor, toolbox
      const wbZ = sr.z1 - 1.0;
      const wbX = sr.x0 + 6.4;
      box(sg, 7.0, 1.1, 1.3, mat('#2b3646', 0.5, 0.3), wbX, 0.55, wbZ);
      box(sg, 7.2, 0.1, 1.45, mat('#9aa7b8', 0.35, 0.5), wbX, 1.15, wbZ);
      box(sg, 1.2, 0.07, 0.8, mat('#10141c', 0.4, 0.5), wbX - 2.4, 1.24, wbZ);
      box(sg, 1.2, 0.8, 0.05, glowMat('#22d3ee', 0.8), wbX - 2.4, 1.65, wbZ - 0.4, false).rotation.x = -0.15;
      box(sg, 1.2, 0.9, 0.08, mat('#0c0f15', 0.3, 0.5), wbX - 0.6, 1.65, wbZ - 0.3).rotation.x = -0.1;
      box(sg, 1.2, 0.9, 0.08, mat('#0c0f15', 0.3, 0.5), wbX + 0.9, 1.65, wbZ - 0.3).rotation.x = -0.1;
      box(sg, 1.1, 0.4, 0.6, mat('#dc2626', 0.5, 0.3), wbX + 2.5, 1.4, wbZ);
      const spool = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.12, 8, 20), mat('#38bdf8', 0.6));
      spool.rotation.x = Math.PI / 2;
      spool.position.set(wbX + 1.7, 1.34, wbZ + 0.1);
      sg.add(spool);
      // cooling (CRAC) unit
      box(sg, 2.4, 2.8, 1.2, mat('#e5e7eb', 0.4, 0.3), sr.x1 - 1.8, 1.4, sr.z1 - 1.0);
      box(sg, 2.0, 1.2, 0.04, mat('#1f2937', 0.5, 0.4), sr.x1 - 1.8, 1.8, sr.z1 - 0.38, false);
      box(sg, 2.0, 0.06, 0.04, glowMat('#38bdf8', 1.6), sr.x1 - 1.8, 2.7, sr.z1 - 0.38, false);
      // status board sa silangang pader (sa hilaga ng pinto)
      makeBoard(sg, sr.x1 - 0.3, 2.1, sr.z0 + 2.7, 3.6, 1.7, -Math.PI / 2, 'SERVER STATUS', '#0891b2', true);
      makePlant(sg, sr.x1 - 1.0, ZDOOR + 2.6, 1.0);
      doorLight(sg, sr.x1, ZDOOR, false, doorW, IT_STAFF.color);

      /* ---------------- Canteen (almusal · tanghalian · hapunan) ---------------- */
      const cr = rb(ROOMS.canteen);
      const canteen = addRoom('canteen', '#f59e0b', '#3a2c22', { left: [{ at: ZDOOR - cr.z0, w: doorW }], right: [{ at: ZDOOR - cr.z0, w: doorW }] });
      const cg = canteen.g;
      // serving counter na may mga ulam
      box(cg, 17, 1.2, 1.1, mat('#6b3f22', 0.5), 0, 0.6, cr.z0 + 0.8);
      box(cg, 17.4, 0.12, 1.3, mat('#e7d3b0', 0.3, 0.1), 0, 1.26, cr.z0 + 0.8);
      box(cg, 17, 0.04, 0.04, glowMat('#fb923c', 1.8), 0, 0.12, cr.z0 + 1.38, false);
      ['#b45309', '#dc2626', '#65a30d', '#f59e0b', '#7c2d12', '#fde68a', '#16a34a'].forEach((fc, i) => {
        const tx = -7.2 + i * 2.4;
        box(cg, 1.9, 0.16, 0.8, mat('#aeb6c2', 0.25, 0.9), tx, 1.38, cr.z0 + 0.8);
        box(cg, 1.7, 0.1, 0.62, mat(fc, 0.7), tx, 1.47, cr.z0 + 0.8, false);
      });
      box(cg, 17, 0.7, 0.04, physMat({ color: '#bfe3ff', transparent: true, opacity: 0.18, roughness: 0.05, depthWrite: false }), 0, 1.85, cr.z0 + 1.3, false);
      const menu = new THREE.Mesh(new THREE.PlaneGeometry(12, 3), new THREE.MeshBasicMaterial({ map: menuBoardTex(), toneMapped: false }));
      menu.position.set(0, 2.9, cr.z0 + 0.22);
      cg.add(menu);
      box(cg, 12.3, 3.3, 0.06, mat('#2a1b13', 0.5), 0, 2.9, cr.z0 + 0.16, false);
      box(cg, 1.6, 3.2, 1.2, mat('#c8d0dc', 0.3, 0.7), cr.x0 + 1.3, 1.6, cr.z0 + 1.1);
      box(cg, 1.6, 3.2, 1.2, mat('#c8d0dc', 0.3, 0.7), cr.x1 - 1.3, 1.6, cr.z0 + 1.1);
      makeCooler(cg, cr.x0 + 3.4, cr.z0 + 1.0);
      // dalawang mahabang mesa (hilaga at timog ng aisle) + mga upuan + plato
      DINE_TABLE_Z.forEach((tz, row) => {
        makeCanteenTable(cg, 0, tz, 12.4, 1.7);
        const plateZ = tz + (row === 0 ? 0.3 : -0.3);
        DINE_XS.forEach((sx, i) => {
          makeChair(cg, sx, row === 0 ? ZDOOR - DINE_ROW : ZDOOR + DINE_ROW, '#9a5b25', row === 0 ? 0 : Math.PI);
          makePlateSet(cg, sx, plateZ, i + row * 2);
          const sm = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 8), new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0, depthWrite: false }));
          sm.position.set(sx, 1.5, plateZ);
          cg.add(sm);
          foodSteam.push({ m: sm, x: sx, z: plateZ });
        });
        // pitcher, tinapay at sawsawan sa gitna ng mesa
        cyl(cg, 0.2, 0.17, 0.5, mat('#bae6fd', 0.3), 0, 1.4, tz);
        const bread = new THREE.Mesh(new THREE.SphereGeometry(0.4, 14, 8, 0, Math.PI * 2, 0, Math.PI / 2), mat('#b7793c', 0.8));
        bread.position.set(-3.0, 1.15, tz);
        cg.add(bread);
        [2.9, 3.2].forEach((bx, k) => cyl(cg, 0.08, 0.08, 0.3, mat(k ? '#7c2d12' : '#1f2937', 0.4), bx, 1.3, tz));
      });
      makePlant(cg, cr.x0 + 1.0, cr.z1 - 1.0, 1.2);
      makePlant(cg, cr.x1 - 1.0, cr.z1 - 1.0, 1.2);
      makeFloorLamp(cg, cr.x0 + 1.2, cr.z1 - 3.0);
      makeFloorLamp(cg, cr.x1 - 1.2, cr.z1 - 3.0);
      doorLight(cg, cr.x0, ZDOOR, false, doorW, '#f59e0b');
      doorLight(cg, cr.x1, ZDOOR, false, doorW, '#f59e0b');

      /* ---------------- Arcade (pampa-relax) ---------------- */
      const ar = rb(ROOMS.arcade);
      const arcade = addRoom('arcade', '#c084fc', '#1c1230', { left: [{ at: ZDOOR - ar.z0, w: doorW }] });
      const ag = arcade.g;
      [ZDOOR - 1.9, ZDOOR + 1.9].forEach((zz) => makeGuide(ag, (ar.x0 + ar.x1) / 2, zz, ar.x1 - ar.x0 - 1.0, 0.08, '#e879f9'));
      makeRug(ag, (ar.x0 + ar.x1) / 2 - 0.5, ZDOOR, 13, 4.4, '#2a1a4a');
      const titles = ['GALAXY', 'TURBO', 'NINJA', 'BLOCKS', 'BOXING', 'RACER', 'JUMP!'];
      // pagkakasunod: aria, blaze, nova, cipher (hilaga) · boss, sec, it (timog) — kapareho ng ARCADE_OWNERS
      ARCADE_NORTH_XS.forEach((x, i) => makeArcadeCabinet(ag, x, ar.z0 + 1.3, 0, [300, 190, 50, 130][i], titles[i], arcadeScreens));
      ARCADE_SOUTH_XS.forEach((x, i) => makeArcadeCabinet(ag, x, ar.z1 - 1.3, Math.PI, [10, 260, 90][i], titles[4 + i], arcadeScreens));
      makeClawMachine(ag, ar.x1 - 1.4, ZDOOR - 3.0, -Math.PI / 2);
      makeClawMachine(ag, ar.x1 - 1.4, ZDOOR + 3.0, -Math.PI / 2);
      // mga pouf sa tabi ng pinto
      [ZDOOR - 3.8, ZDOOR + 3.8].forEach((pz, i) => {
        cyl(ag, 0.6, 0.62, 0.7, mat(i ? '#ec4899' : '#38bdf8', 0.9), ar.x0 + 1.3, 0.4, pz);
        sphere(ag, 0.55, mat(i ? '#f472b6' : '#7dd3fc', 0.9), ar.x0 + 1.3, 0.8, pz).scale.y = 0.5;
      });
      makePlant(ag, ar.x0 + 1.0, ar.z0 + 1.2, 1.1);
      doorLight(ag, ar.x0, ZDOOR, false, doorW, '#c084fc');
    };
    buildAll();

    // steam above coffee machine
    const steam: THREE.Mesh[] = [];
    for (let i = 0; i < 4; i++) {
      const s = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 8), new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.0, depthWrite: false }));
      s.position.set(-1.2, 3, BAR_COUNTER_Z);
      scene.add(s);
      steam.push(s);
    }

    /* ---- characters ---- */
    const bots: Record<string, Bot> = {};
    IDS.forEach((id) => {
      const b = makeBot(id);
      b.pos.copy(spotOf(id, 'office'));
      b.group.position.copy(b.pos);
      b.group.rotation.y = Math.PI;
      scene.add(b.group);
      contactShadow(b.group, id === 'boss' ? 2.3 : 2.0);
      bots[id] = b;
    });
    const maint = makeMaintBot();
    maint.group.position.copy(maint.pos);
    scene.add(maint.group);
    contactShadow(maint.group, 1.9);
    scene.add(maint.sign);
    const reelBot = makeReelBot();
    scene.add(reelBot.group);
    contactShadow(reelBot.group, 1.9);
    let reelKey = '';
    let reelShownAt = 0;
    let reelBubbleUntil = 0;
    let calloutSeen = 0;
    let maintHoldUntil = 0; // Fixo keeps his bubble while Boss is talking to him
    let maintMeet = false; // Fixo is walking to / sitting at the meeting table
    let maintSeated = false;
    const reelPos = REEL_HOME.clone();
    let reelPath: THREE.Vector3[] = [];
    let reelWantLab = false;
    let reelSeated = false;
    let reelYaw = 0;
    let reelR: ReelRoutine = initReelRoutine();
    let reelDoing: ReelDoing = 'work';
    let reelBarKey = '';
    let reelDoingKey = '';
    const botGroups = [...IDS.map((id) => bots[id].group), maint.group, reelBot.group];

    /* ---- sizing ---- */
    let inited = false;
    let lastDist = 84 * 1.12;
    let hostW = host.clientWidth || 600;
    let hostH = host.clientHeight || 380;
    const resize = () => {
      const w = host.clientWidth || 600;
      const h = host.clientHeight || 380;
      if (inited && Math.abs(w - hostW) < 2 && Math.abs(h - hostH) < 2) return;
      hostW = w;
      hostH = h;
      renderer.setSize(w, h, false);
      camera.aspect = w / h;
      const narrow = camera.aspect < 1.45 ? 1.45 / camera.aspect : 1;
      const dist = 84 * 1.12 * Math.min(1.9, narrow);
      const dir = new THREE.Vector3(0, 0.78, 0.9).normalize();
      if (!inited) {
        camera.position.copy(controls.target).addScaledVector(dir, dist);
        inited = true;
        lastDist = dist;
      } else if (dist !== lastDist) {
        // phone rotated / window resized: keep the whole office in frame, keep the user's angle
        const off = camera.position.clone().sub(controls.target);
        const next = THREE.MathUtils.clamp(off.length() * (dist / lastDist), controls.minDistance, controls.maxDistance);
        camera.position.copy(controls.target).addScaledVector(off.normalize(), next);
        lastDist = dist;
      }
      camera.updateProjectionMatrix();
      renderer.render(scene, camera); // repaint right away: setSize clears the canvas, which looked like a blink
    };
    resize();
    let resizeRaf = 0;
    const ro = new ResizeObserver(() => {
      cancelAnimationFrame(resizeRaf);
      resizeRaf = requestAnimationFrame(resize);
    });
    ro.observe(host);

    /* ---- picking ---- */
    const ray = new THREE.Raycaster();
    const ndc = new THREE.Vector2();
    const pick = (e: PointerEvent): MemberId | 'maint' | 'reel' | null => {
      const rect = renderer.domElement.getBoundingClientRect();
      ndc.set(((e.clientX - rect.left) / rect.width) * 2 - 1, -((e.clientY - rect.top) / rect.height) * 2 + 1);
      ray.setFromCamera(ndc, camera);
      const hit = ray.intersectObjects(botGroups, true)[0];
      if (!hit) return null;
      let o: THREE.Object3D | null = hit.object;
      while (o && o.userData.id === undefined) o = o.parent;
      return (o?.userData.id as MemberId | 'maint' | 'reel') ?? null;
    };
    let downX = 0;
    let downY = 0;
    const onDown = (e: PointerEvent) => { downX = e.clientX; downY = e.clientY; };
    const onUp = (e: PointerEvent) => {
      if (Math.hypot(e.clientX - downX, e.clientY - downY) > 5) return;
      const id = pick(e);
      if (!id || id === 'maint') return;
      if (id === 'reel') { gotoTab('studio'); return; } // click Reel -> open the Video Editor
      if (id === 'boss') (live.current.onBossTalk ?? live.current.onBossClick)();
      else if (id === 'sec') live.current.onBossClick();
      else if (id === 'it' || id === 'argus') return; // si Dex at si Argus ay walang inspector drawer
      else live.current.onSelect(id);
    };
    const onMove = (e: PointerEvent) => {
      renderer.domElement.style.cursor = pick(e) ? 'pointer' : 'grab';
    };
    renderer.domElement.addEventListener('pointerdown', onDown);
    renderer.domElement.addEventListener('pointerup', onUp);
    renderer.domElement.addEventListener('pointermove', onMove);

    /* ---- GPU context loss ---- */
    let ctxLost = false;
    const onCtxLost = (e: Event) => { e.preventDefault(); ctxLost = true; }; // tells the browser we want the canvas back
    const onCtxBack = () => restoreRef.current?.();
    renderer.domElement.addEventListener('webglcontextlost', onCtxLost);
    renderer.domElement.addEventListener('webglcontextrestored', onCtxBack);

    /* ---- loop ---- */
    let raf = 0;
    let visible = true;
    const io = new IntersectionObserver(([e]) => { visible = e.isIntersecting; });
    io.observe(host);
    let last = performance.now();
    let night = live.current.isNight ? 1 : 0;
    let screenClock = 0;
    let perfAcc = 0;
    let perfN = 0;
    const tmp = new THREE.Vector3();
    const bgColor = new THREE.Color(0x121824);
    scene.background = bgColor;
    const sunDayCol = new THREE.Color('#fff1d6');
    const sunNightCol = new THREE.Color('#8fa8ff');
    const dropped: Record<string, boolean> = {};

    const wrap = (a: number) => { while (a > Math.PI) a -= Math.PI * 2; while (a < -Math.PI) a += Math.PI * 2; return a; };

    // only touch the DOM when a value really changed (17 overlay elements x 60 fps of redundant style writes = jank on Android)
    const lastTf = new WeakMap<HTMLElement, string>();
    const lastOp = new WeakMap<HTMLElement, string>();
    const setTf = (el: HTMLElement, v: string) => { if (lastTf.get(el) !== v) { lastTf.set(el, v); el.style.transform = v; } };
    const setOp = (el: HTMLElement, v: string) => { if (lastOp.get(el) !== v) { lastOp.set(el, v); el.style.opacity = v; } };
    let warm = 0;
    let frameNo = 0;
    let firstDone = false;

    const frame = (now: number) => {
      raf = requestAnimationFrame(frame);
      if (!visible || document.hidden || ctxLost) { last = now; return; }
      const rawDt = (now - last) / 1000;
      const dt = Math.min(rawDt, 0.05);
      last = now;
      const t = now / 1000;
      // auto-quality ladder: if the phone can't hold ~30fps -> lower resolution, then drop shadows, then lower again
      // (the first 60 frames are ignored: shader compilation makes them slow on every device)
      if (warm < 60) {
        warm++;
      } else {
        perfAcc += rawDt;
        perfN++;
      }
      if (perfN >= 90) {
        const avg = perfAcc / perfN;
        perfAcc = 0;
        perfN = 0;
        if (avg > 0.034) {
          if (curPR > 1) {
            curPR = Math.max(1, curPR - 0.25);
            renderer.setPixelRatio(curPR);
            renderer.setSize(hostW, hostH, false);
          } else if (sun.castShadow) {
            sun.castShadow = false;
          } else if (curPR > 0.8) {
            curPR = 0.8;
            renderer.setPixelRatio(curPR);
            renderer.setSize(hostW, hostH, false);
          }
        }
      }
      if (coarse) renderer.shadowMap.needsUpdate = (frameNo++ & 1) === 0;
      const L = live.current;
      night += ((L.isNight ? 1 : 0) - night) * Math.min(1, dt * 1.2);

      hemi.intensity = coarse ? lerp(1.12, 0.5, night) : lerp(0.95, 0.32, night);
      sun.intensity = lerp(1.5, 0.25, night);
      sun.color.copy(sunDayCol).lerp(sunNightCol, night); // was a hard switch at night=0.5 -> a visible colour pop
      roomLights.forEach((l) => { l.intensity = lerp(9, 60, night); });
      skyMat.color.setScalar(lerp(1, 0.32, night));
      scene.environmentIntensity = lerp(0.5, 0.14, night);
      (scene.fog as THREE.Fog).color.setRGB(lerp(0.2, 0.03, night), lerp(0.26, 0.04, night), lerp(0.36, 0.08, night));
      (motes.material as THREE.PointsMaterial).opacity = lerp(0.32, 0.12, night);
      for (let i = 0; i < moteCount; i++) {
        motePos[i * 3 + 1] += Math.sin(t * 0.4 + i) * 0.004 + 0.002;
        motePos[i * 3] += Math.cos(t * 0.3 + i * 1.7) * 0.004;
        if (motePos[i * 3 + 1] > 12) motePos[i * 3 + 1] = 1;
      }
      moteGeo.attributes.position.needsUpdate = true;
      bgColor.setRGB(lerp(0.07, 0.02, night), lerp(0.09, 0.03, night), lerp(0.14, 0.06, night));

      // camera first, so the name tags are projected with the same camera that is rendered (no lag / jitter)
      controls.update();
      camera.updateMatrixWorld();

      // bots
      IDS.forEach((id) => {
        const b = bots[id];
        const target = L.places[id];
        const fixTgt: TeamId | null = id === 'it' && target === 'fix' ? L.itTarget : null;
        if (b.place !== target || b.fix !== fixTgt) {
          const prev = b.place;
          const prevFix = b.fix;
          const midWalk = b.path.length > 0;
          b.place = target;
          b.fix = fixTgt;
          b.path = routeTo(id, b.pos, prev, target, midWalk, prevFix, fixTgt);
        }
        b.walking = b.path.length > 0;
        if (b.walking) {
          const next = b.path[0];
          tmp.subVectors(next, b.pos);
          tmp.y = 0;
          const dist = tmp.length();
          const step = 11 * dt;
          if (dist <= step) { b.pos.copy(next); b.path.shift(); }
          else { tmp.normalize(); b.pos.addScaledVector(tmp, step); b.yaw = Math.atan2(tmp.x, tmp.z); }
        }
        let faceYaw = b.yaw;
        if (!b.walking) {
          if (b.place === 'lab' || b.place === 'drop') faceYaw = Math.atan2(TABLE_C.x - b.pos.x, TABLE_C.z - b.pos.z);
          else if (b.place === 'brief') faceYaw = Math.atan2(bots.boss.pos.x - b.pos.x, bots.boss.pos.z - b.pos.z);
          else if (b.place === 'dine') faceYaw = DINE_SEATS[id][1] < ZDOOR ? Math.PI : 0;
          else if (b.place === 'play') faceYaw = PLAY_SPOTS[id][1] < ZDOOR ? Math.PI : 0;
          else if (b.place === 'fix' && b.fix) { const fd = officeDesk(b.fix); faceYaw = Math.atan2(fd.cx - b.pos.x, fd.deskZ - b.pos.z); }
          else if (id === 'boss' && b.place === 'office' && bots.sec.place === 'brief' && !bots.sec.walking) faceYaw = Math.atan2(bots.sec.pos.x - b.pos.x, bots.sec.pos.z - b.pos.z);
          else faceYaw = Math.PI;
        }
        const cur = b.group.rotation.y;
        b.group.rotation.y = cur + wrap(faceYaw - cur) * Math.min(1, dt * 9);
        const seated = !b.walking && (b.place === 'office' || b.place === 'rest' || b.place === 'lab' || b.place === 'bar' || b.place === 'dine');
        // Argus: kape / laro / kain ay sa desk lang niya (ang idlip ay sa sofa, place 'rest')
        const argusDoing = id === 'argus' && !b.walking && b.place === 'office' ? L.argus?.doing ?? 'work' : 'work';
        const hop = !b.walking && b.place === 'play' ? Math.abs(Math.sin(t * 5 + id.length * 2)) * 0.07 : 0;
        b.group.position.set(b.pos.x, b.walking ? Math.abs(Math.sin(t * 14)) * 0.12 : hop, b.pos.z);
        const swing = Math.sin(t * 14) * 0.7;
        const isStaff = id === 'boss' || id === 'sec' || id === 'it' || id === 'argus';
        const activeStatus = isStaff ? true : L.activity[id as AgentId].status !== 'idle' && L.activity[id as AgentId].status !== 'paused';
        b.legL.rotation.x = b.walking ? swing : seated ? -1.5 : 0;
        b.legR.rotation.x = b.walking ? -swing : seated ? -1.5 : 0;
        if (b.walking) {
          b.armL.rotation.x = -swing * 0.8;
          b.armR.rotation.x = swing * 0.8;
        } else if (b.place === 'office' && argusDoing === 'coffee') {
          b.armL.rotation.x = -0.6;
          b.armR.rotation.x = -2.0 + Math.max(0, Math.sin(t * 1.6)) * -0.25;
        } else if (b.place === 'office' && argusDoing === 'game') {
          b.armL.rotation.x = -1.2 + Math.sin(t * 14) * 0.08;
          b.armR.rotation.x = -1.2 + Math.sin(t * 14 + 1.5) * 0.08;
        } else if (b.place === 'office' && argusDoing === 'eat') {
          b.armL.rotation.x = -1.0;
          b.armR.rotation.x = -1.9 + Math.sin(t * 3) * 0.3;
        } else if (b.place === 'office') {
          const k = activeStatus ? 1 : 0.15;
          b.armL.rotation.x = -1.15 + Math.sin(t * 19) * 0.12 * k;
          b.armR.rotation.x = -1.15 + Math.cos(t * 17) * 0.12 * k;
        } else if (b.place === 'rest') {
          // nakaupo at nakasandal, nakapatong ang mga kamay sa tiyan; dahan-dahang humihinga
          b.armL.rotation.x = -0.55 + Math.sin(t * 1.1 + id.length) * 0.03;
          b.armR.rotation.x = -0.55 + Math.sin(t * 1.1 + id.length + 0.4) * 0.03;
        } else if (b.place === 'dine') {
          // kumakain: ang kanang braso ay paulit-ulit na papunta sa bibig
          b.armL.rotation.x = -0.85 + Math.sin(t * 1.7 + id.length) * 0.05;
          b.armR.rotation.x = -1.25 + Math.sin(t * 3.1 + id.length * 1.3) * 0.35;
        } else if (b.place === 'play') {
          // naglalaro: gumagalaw ang dalawang kamay sa joystick at mga button
          b.armL.rotation.x = -1.05 + Math.sin(t * 8 + id.length) * 0.18;
          b.armR.rotation.x = -1.2 + Math.cos(t * 10 + id.length) * 0.22;
        } else if (b.place === 'fix') {
          // nag-aayos: nakayuko ang dalawang kamay sa keyboard / cable, mabilis ang kanang kamay
          b.armL.rotation.x = -1.05 + Math.sin(t * 6) * 0.1;
          b.armR.rotation.x = -1.3 + Math.sin(t * 12) * 0.3;
        } else if (b.place === 'bar') {
          b.armL.rotation.x = READERS.has(id) ? -1.35 + Math.sin(t * 1.3 + id.length) * 0.03 : 0.05;
          b.armR.rotation.x = -1.3 + Math.sin(t * 2) * 0.1;
        } else if (b.place === 'drop' || b.place === 'brief') {
          if (id === 'sec') {
            b.armL.rotation.x = -1.35 + Math.sin(t * 1.3) * 0.03;
            b.armR.rotation.x = -1.0 + Math.sin(t * 5) * 0.2;
          } else {
            b.armL.rotation.x = -0.3;
            b.armR.rotation.x = -1.2 + Math.sin(t * 3 + id.length) * 0.25;
          }
        } else {
          b.armL.rotation.x = -0.6;
          b.armR.rotation.x = -0.6 + Math.sin(t * 2.5 + id.length) * 0.35;
        }
        b.cup.visible = ((b.place === 'bar' || b.place === 'dine') && !b.walking) || argusDoing === 'coffee';
        b.console.visible = argusDoing === 'game';
        b.plate.visible = argusDoing === 'eat';
        const reading = !b.walking && ((b.place === 'bar' && READERS.has(id)) || (id === 'sec' && (b.place === 'drop' || b.place === 'brief')));
        b.readPaper.visible = reading;
        if (reading) {
          b.readPaper.rotation.x = -0.15 + Math.sin(t * 1.3 + id.length) * 0.03;
          b.readPaper.rotation.z = Math.sin(t * 0.7 + id.length * 2) * 0.03;
        }
        const bi = IDS.indexOf(id);
        const blinkPhase = (t + bi * 1.7) % 4.2;
        const asleep = !b.walking && b.place === 'rest';
        b.eyes.forEach((e) => { e.scale.y = asleep || blinkPhase > 4.08 ? 0.1 : 1; });
        b.spin.forEach((s, k) => { s.rotation.y = t * (1.6 + k * 0.5); });
        if (b.orb) (b.orb.material as THREE.MeshStandardMaterial).emissiveIntensity = 1.9 + Math.sin(t * 3 + bi) * 0.8;
        // tags
        const tag = tagRefs.current[id];
        if (tag) {
          tmp.set(b.pos.x, 4.7, b.pos.z).project(camera);
          const sx = Math.round((tmp.x * 0.5 + 0.5) * hostW);
          const sy = Math.round((-tmp.y * 0.5 + 0.5) * hostH);
          setTf(tag, `translate3d(${sx}px, ${sy}px, 0) translate(-50%, -100%)`);
          setOp(tag, tmp.z < 1 ? '1' : '0');
        }
      });

      // maintenance bot: patrols, mops and fixes things
      {
        const m = maint;
        const bubble = maintBubble.current;
        // meetings: Fixo walks to his chair at the table and sits; afterwards he goes back to patrolling
        {
          const meetingNow = L.phase === 'meeting';
          if (meetingNow && !maintMeet) {
            maintMeet = true;
            maintSeated = false;
            m.task = null;
            m.sign.visible = false;
            const [sx, sz] = LAB_SEATS_EXTRA.maint;
            m.path = [...graphPath(nearestNode(m.pos), 'labR').map((k) => NODES[k].clone()), LAB_SOUTH_EAST(), new THREE.Vector3(sx, 0, sz)];
            m.until = Infinity;
            if (bubble && now >= maintHoldUntil) bubble.style.display = 'none';
          } else if (!meetingNow && maintMeet) {
            maintMeet = false;
            const options = MAINT_STOPS.filter((k) => k !== m.stop);
            const dest = options[Math.floor(Math.random() * options.length)];
            const from = maintSeated ? 'labR' : nearestNode(m.pos);
            m.path = [...(maintSeated ? [LAB_SOUTH_EAST()] : []), ...graphPath(from, dest).map((k) => NODES[k].clone())];
            m.stop = dest;
            m.until = Infinity;
            maintSeated = false;
          }
        }
        // Boss talks to Fixo / Reel: show the reply over their head (3.8s)
        if (L.callout && L.callout.n !== calloutSeen) {
          calloutSeen = L.callout.n;
          const cb = L.callout.who === 'reel' ? reelBubble.current : maintBubble.current;
          if (cb) {
            cb.textContent = compactLine(L.callout.text, phoneRef.current ? 40 : 80);
            cb.style.display = 'block';
            if (L.callout.who === 'reel') { reelShownAt = now; reelBubbleUntil = now + 3800; } else maintHoldUntil = now + 3800;
          }
        }
        if (m.path.length === 0 && now >= m.until) {
          // finished a job: say goodbye to the sign and pick the next stop
          m.task = null;
          m.sign.visible = false;
          const options = MAINT_STOPS.filter((k) => k !== m.stop);
          const dest = options[Math.floor(Math.random() * options.length)];
          m.path = graphPath(nearestNode(m.pos), dest).map((k) => NODES[k].clone());
          m.stop = dest;
          m.until = Infinity;
          if (bubble && now >= maintHoldUntil) bubble.style.display = 'none';
        }
        const walking = m.path.length > 0;
        if (walking) {
          const next = m.path[0];
          tmp.subVectors(next, m.pos);
          tmp.y = 0;
          const dist = tmp.length();
          const step = 7 * dt;
          if (dist <= step) {
            m.pos.copy(next);
            m.path.shift();
            if (m.path.length === 0 && maintMeet) {
              maintSeated = true; // reached his chair
            } else if (m.path.length === 0) {
              // arrived: start a job here
              m.task = MAINT_FIX_STOPS.has(m.stop) ? 'fix' : 'mop';
              m.until = now + 6500 + Math.random() * 3500;
              const lines = m.task === 'mop' ? MAINT_MOP_LINES : MAINT_FIX_LINES;
              if (bubble) {
                bubble.textContent = compactLine(pickFresh(lines), phoneRef.current ? 40 : 80);
                bubble.style.display = 'block';
              }
              if (m.task === 'mop') {
                m.sign.position.set(m.pos.x + 1.8, 0, m.pos.z + 0.6);
                m.sign.visible = true;
              }
            }
          } else {
            tmp.normalize();
            m.pos.addScaledVector(tmp, step);
            m.yaw = Math.atan2(tmp.x, tmp.z);
          }
        }
        const working = !walking && m.task !== null;
        const faceYaw = maintSeated ? Math.atan2(TABLE_C.x - m.pos.x, TABLE_C.z - m.pos.z) : working ? (m.task === 'mop' ? 0 : Math.PI) : m.yaw;
        m.group.rotation.y += wrap(faceYaw - m.group.rotation.y) * Math.min(1, dt * 8);
        m.group.position.set(m.pos.x, walking ? Math.abs(Math.sin(t * 12)) * 0.1 : 0, m.pos.z);
        const sw = Math.sin(t * 12) * 0.6;
        m.legL.rotation.x = walking ? sw : maintSeated ? -1.5 : 0;
        m.legR.rotation.x = walking ? -sw : maintSeated ? -1.5 : 0;
        m.mop.visible = m.task !== 'fix';
        m.wrench.visible = m.task === 'fix';
        m.bucket.visible = m.task === 'mop' && !walking;
        if (walking) {
          m.armL.rotation.x = -sw * 0.8;
          m.armR.rotation.x = -0.5 + sw * 0.3;
        } else if (maintSeated) {
          m.armL.rotation.x = -0.6;
          m.armR.rotation.x = -0.6 + Math.sin(t * 2.5) * 0.35;
        } else if (m.task === 'mop') {
          m.armL.rotation.x = -0.7 + Math.sin(t * 3.2) * 0.25;
          m.armR.rotation.x = -0.8 + Math.sin(t * 3.2 + 0.6) * 0.45;
          m.mop.rotation.z = Math.sin(t * 3.2) * 0.3;
        } else if (m.task === 'fix') {
          m.armL.rotation.x = -1.3;
          m.armR.rotation.x = -1.4 + Math.sin(t * 9) * 0.45;
        } else {
          m.armL.rotation.x = 0.05;
          m.armR.rotation.x = 0.05;
        }
        if (walking || m.task !== 'mop') m.mop.rotation.z = 0;
        const blink = (t + 2.3) % 4.2;
        m.eyes.forEach((e) => { e.scale.y = blink > 4.08 ? 0.1 : 1; });
        const mt = tagRefs.current.maint;
        if (mt) {
          tmp.set(m.pos.x, 4.7, m.pos.z).project(camera);
          setTf(mt, `translate3d(${Math.round((tmp.x * 0.5 + 0.5) * hostW)}px, ${Math.round((-tmp.y * 0.5 + 0.5) * hostH)}px, 0) translate(-50%, -100%)`);
          setOp(mt, tmp.z < 1 ? '1' : '0');
        }
      }

      // Reel (video editor): his pose follows the real video jobs; his energy and breaks are his own (reelRoutine.ts)
      {
        const r = reelBot;
        const st = L.reel;
        const state = st ? st.state : 'idle';
        const bubble = reelBubble.current;
        const showBubble = (text: string, ms: number) => {
          if (!bubble) return;
          bubble.textContent = compactLine(text, phoneRef.current ? 40 : 80);
          bubble.style.display = 'block';
          reelShownAt = now;
          reelBubbleUntil = now + ms;
        };
        reelR = stepReel(reelR, dt, state);
        const key = st ? `${st.state}|${st.bubble}` : '';
        if (reelR.doing !== reelDoing) {
          // break started or ended: say it once
          if (reelR.doing === 'work') showBubble(pickFresh(REEL_BREAK_BACK), ACT_BUBBLE_MS);
          else showBubble(pickFresh(REEL_BREAK_GO[reelR.doing]), ACT_BUBBLE_MS);
          reelDoing = reelR.doing;
        }
        if (key !== reelKey) {
          reelKey = key;
          if (st && reelDoing === 'work') showBubble(st.bubble, ACT_BUBBLE_MS);
        } else if (st && reelDoing === 'work' && (state === 'waiting' || state === 'problem') && now - reelShownAt > 45000) {
          // something needs the boss: remind him now and then
          showBubble(st.bubble, ACT_BUBBLE_MS);
        }
        if (bubble && bubble.style.display !== 'none' && now >= reelBubbleUntil) bubble.style.display = 'none';

        // meetings: Reel leaves his edit station, walks to his chair and sits; afterwards he walks back
        const meetingNow = L.phase === 'meeting';
        if (meetingNow !== reelWantLab) {
          reelWantLab = meetingNow;
          const midWalk = reelPath.length > 0;
          const [sx, sz] = LAB_SEATS_EXTRA.reel;
          if (meetingNow) {
            reelPath = [...graphPath(nearestNode(reelPos), 'labL').map((k) => NODES[k].clone()), SEC_LAB_DETOUR(), new THREE.Vector3(sx, 0, sz)];
          } else {
            const home = nearestNode(REEL_HOME);
            const lead = reelSeated && !midWalk ? [SEC_LAB_DETOUR()] : [];
            const from = reelSeated && !midWalk ? 'labL' : nearestNode(reelPos);
            reelPath = [...lead, ...graphPath(from, home).map((k) => NODES[k].clone()), REEL_HOME.clone()];
          }
          reelSeated = false;
        }
        const walkingR = reelPath.length > 0;
        if (walkingR) {
          const next = reelPath[0];
          tmp.subVectors(next, reelPos);
          tmp.y = 0;
          const dist = tmp.length();
          const step = 11 * dt;
          if (dist <= step) {
            reelPos.copy(next);
            reelPath.shift();
            if (reelPath.length === 0) reelSeated = reelWantLab;
          } else {
            tmp.normalize();
            reelPos.addScaledVector(tmp, step);
            reelYaw = Math.atan2(tmp.x, tmp.z);
          }
        }
        const atHome = !walkingR && !reelSeated;
        const rSwing = Math.sin(t * 14) * 0.7;
        const faceYawR = walkingR ? reelYaw : reelSeated ? Math.atan2(TABLE_C.x - reelPos.x, TABLE_C.z - reelPos.z) : Math.PI;
        r.body.position.set((reelPos.x - REEL_HOME.x) / 1.12, walkingR ? (Math.abs(Math.sin(t * 14)) * 0.12) / 1.12 : 0, (reelPos.z - REEL_HOME.z) / 1.12);
        // nakaupo sa sariling desk kapag nasa home (at sa meeting chair kapag naka-upo roon)
        r.legL.rotation.x = walkingR ? rSwing : -1.5;
        r.legR.rotation.x = walkingR ? -rSwing : -1.5;

        const onBreak = reelDoing !== 'work';
        let aL = 0.05;
        let aR = 0.05;
        let aRz = 0;
        let lean = 0;
        let wobble = 0;
        let eyeOpen = 1;
        if (reelDoing === 'coffee') {
          // sip: hand up to the mouth and back
          aR = -2.0 + Math.max(0, Math.sin(t * 1.6)) * -0.25;
          aL = 0.15;
        } else if (reelDoing === 'game') {
          // thumbs tapping on the console
          aL = -1.2 + Math.sin(t * 14) * 0.08;
          aR = -1.2 + Math.sin(t * 14 + 1.5) * 0.08;
        } else if (reelDoing === 'eat') {
          // kumakain: kanang kamay papunta sa bibig, hawak ng kaliwa ang lunch box
          aL = -1.0;
          aR = -1.9 + Math.sin(t * 3) * 0.3;
        } else if (reelDoing === 'rest') {
          aL = 0.3;
          aR = 0.3;
          lean = -0.28;
          eyeOpen = 0.1;
        } else if (state === 'working') {
          aL = -1.25 + Math.sin(t * 8) * 0.14;
          aR = -1.3 + Math.sin(t * 9 + 1) * 0.18;
        } else if (state === 'waiting') {
          aR = -2.7;
          aRz = Math.sin(t * 7) * 0.4;
        } else if (state === 'problem') {
          aL = -2.3 + Math.sin(t * 12) * 0.12;
          aR = -2.3 + Math.sin(t * 12 + 1) * 0.12;
          wobble = Math.sin(t * 14) * 0.05;
        } else {
          const beat = t % 6;
          aR = beat > 4.6 && beat < 5.4 ? -0.9 + Math.sin(beat * 18) * 0.25 : -0.35;
        }
        if (walkingR) {
          aL = -rSwing * 0.8; aR = rSwing * 0.8; aRz = 0; lean = 0; wobble = 0;
        } else if (reelSeated) {
          aL = -0.6; aR = -0.6 + Math.sin(t * 2.5) * 0.35; aRz = 0; lean = 0; wobble = 0;
        }
        const k = Math.min(1, dt * 10);
        r.armL.rotation.x += (aL - r.armL.rotation.x) * k;
        r.armR.rotation.x += (aR - r.armR.rotation.x) * k;
        r.armR.rotation.z += (aRz - r.armR.rotation.z) * k;
        r.body.rotation.x += (lean - r.body.rotation.x) * Math.min(1, dt * 4);
        r.body.rotation.y += wrap(faceYawR + (atHome ? Math.sin(t * 1.4) * 0.03 : 0) - r.body.rotation.y) * Math.min(1, dt * 9);
        r.body.rotation.z = wobble;
        r.clapper.visible = !onBreak && state === 'idle' && atHome;
        r.mug.visible = reelDoing === 'coffee' && atHome;
        r.console.visible = reelDoing === 'game' && atHome;
        r.food.visible = reelDoing === 'eat' && atHome;
        r.zzz.visible = reelDoing === 'rest' && atHome;
        if (r.zzz.visible) {
          r.zzz.position.y = 3.3 + Math.sin(t * 2) * 0.06;
          (r.zzz.material as THREE.MeshBasicMaterial).opacity = 0.55 + 0.4 * Math.sin(t * 2.5);
        }
        const op = state === 'working' ? 0.92 : state === 'idle' ? 0.3 : 0.7;
        const sm = r.screen.material as THREE.MeshBasicMaterial;
        const pm2 = r.playhead.material as THREE.MeshBasicMaterial;
        sm.opacity += ((onBreak ? 0.12 : op) - sm.opacity) * Math.min(1, dt * 6);
        pm2.opacity = sm.opacity;
        sm.color.setHex(state === 'problem' && !onBreak ? 0xff8a8a : 0xffffff);
        if (state === 'working' && !onBreak) r.playhead.position.x = -0.58 + ((t * 0.22) % 1) * 1.16;
        const rBlink = (t + 0.9) % 4.6;
        const blinkScale = rBlink > 4.48 ? 0.1 : 1;
        r.eyes.forEach((e) => { e.scale.y = eyeOpen < 1 ? eyeOpen : blinkScale; });

        // energy bar and break icon in the name tag (written straight to the DOM, like the other bots)
        const barKey = `${Math.round(reelR.energy)}`;
        if (barKey !== reelBarKey && reelBarRef.current) {
          reelBarKey = barKey;
          const e = Math.round(reelR.energy);
          reelBarRef.current.style.width = `${Math.max(4, e)}%`;
          reelBarRef.current.style.background = e > 60 ? '#34d399' : e > 30 ? '#fbbf24' : '#f87171';
          reelBarRef.current.parentElement!.title = `Energy ${e}%`;
        }
        const doingKey = reelDoing;
        if (doingKey !== reelDoingKey && reelDoingRef.current) {
          reelDoingKey = doingKey;
          reelDoingRef.current.textContent = doingKey === 'work' ? '' : ` ${REEL_BREAK_ICON[doingKey]}`;
        }

        const rt = tagRefs.current.reel;
        if (rt) {
          tmp.set(reelPos.x, 4.7, reelPos.z).project(camera);
          setTf(rt, `translate3d(${Math.round((tmp.x * 0.5 + 0.5) * hostW)}px, ${Math.round((-tmp.y * 0.5 + 0.5) * hostH)}px, 0) translate(-50%, -100%)`);
          setOp(rt, tmp.z < 1 ? '1' : '0');
        }
      }

      // room labels
      ROOM_LABELS.forEach((rl) => {
        const el = roomRefs.current[rl.key];
        if (!el) return;
        tmp.set(rl.x, 3.5, rl.z).project(camera);
        setTf(el, `translate3d(${Math.round((tmp.x * 0.5 + 0.5) * hostW)}px, ${Math.round((-tmp.y * 0.5 + 0.5) * hostH)}px, 0) translate(-50%, -50%)`);
      });

      // monitors (~12 fps)
      screenClock += dt;
      if (screenClock > (coarse ? 0.16 : 0.08)) {
        screenClock = 0;
        IDS.forEach((id) => {
          const away = bots[id].place !== 'office';
          const act = id === 'boss' || id === 'sec' || id === 'it' || id === 'argus' ? !away : !away && L.activity[id as AgentId].status !== 'idle' && L.activity[id as AgentId].status !== 'paused';
          screens[id]?.forEach((s, si) => {
            const c = s.c;
            c.fillStyle = away ? '#05070b' : '#07101c';
            c.fillRect(0, 0, 192, 108);
            if (away) { s.t.needsUpdate = true; return; }
            if (L.broken === id) {
              // may sira ang internet/computer: pulang error screen hanggang maayos ni Dex
              c.fillStyle = '#3b0a0a';
              c.fillRect(0, 0, 192, 108);
              c.fillStyle = Math.sin(t * 5) > 0 ? '#f87171' : '#7f1d1d';
              c.font = 'bold 54px sans-serif';
              c.textAlign = 'center';
              c.textBaseline = 'middle';
              c.fillText('!', 96, 38);
              c.font = 'bold 14px sans-serif';
              c.fillStyle = '#fecaca';
              c.fillText('NO SIGNAL / ERROR', 96, 82);
              s.t.needsUpdate = true;
              return;
            }
            const speed = act ? 26 : 6;
            for (let r = 0; r < 12; r++) {
              const y = ((r * 10 + t * speed + si * 17) % 120) - 8;
              const len = 30 + ((r * 53 + si * 11) % 90);
              const ind = ((r * 7) % 3) * 12;
              c.fillStyle = r % 3 === 0 ? s.color : r % 3 === 1 ? '#e2e8f0' : '#a78bfa';
              c.globalAlpha = act ? 0.9 : 0.4;
              c.fillRect(10 + ind, y, len, 4);
            }
            c.globalAlpha = 1;
            c.fillStyle = s.color;
            for (let b2 = 0; b2 < 6; b2++) {
              const h = 6 + (Math.sin(t * (act ? 3 : 1) + b2 * 1.3) * 0.5 + 0.5) * 22;
              c.fillRect(130 + b2 * 9, 100 - h, 6, h);
            }
            s.t.needsUpdate = true;
          });
        });
        // CCTV wall ni Argus: bawat camera ay nakatutok sa office ng isang bot (totoong status ang pinapakita)
        argusFeeds.forEach((s, i) => {
          const ag = AGENTS[i];
          const act = L.activity[ag.id];
          const st = act ? act.status : 'idle';
          const down = L.broken === ag.id;
          const c = s.c;
          c.fillStyle = down ? '#2a0a0a' : '#06090f';
          c.fillRect(0, 0, 192, 108);
          // grid + gumagalaw na scanline
          c.strokeStyle = 'rgba(148,163,184,0.10)';
          c.lineWidth = 1;
          for (let gx = 0; gx <= 192; gx += 24) { c.beginPath(); c.moveTo(gx, 0); c.lineTo(gx, 108); c.stroke(); }
          for (let gy = 0; gy <= 108; gy += 27) { c.beginPath(); c.moveTo(0, gy); c.lineTo(192, gy); c.stroke(); }
          if (!down) {
            // maliit na desk at monitor ng bot: gumagalaw ang laman kapag aktibo siya
            c.fillStyle = 'rgba(30,41,59,0.9)';
            c.fillRect(46, 66, 100, 10);
            c.fillStyle = st === 'paused' ? '#334155' : ag.color;
            c.globalAlpha = st === 'idle' || st === 'paused' ? 0.35 : 0.9;
            c.fillRect(70, 38, 52, 26);
            c.globalAlpha = 1;
            if (st !== 'idle' && st !== 'paused') {
              c.fillStyle = '#0b0e14';
              for (let r2 = 0; r2 < 4; r2++) c.fillRect(75, 42 + r2 * 6, 14 + ((r2 * 17 + Math.floor(t * 6)) % 30), 3);
            }
          }
          c.fillStyle = 'rgba(255,255,255,0.07)';
          c.fillRect(0, ((t * 38 + i * 24) % 128) - 10, 192, 6);
          // teksto: pangalan ng camera, REC dot, status at oras
          c.textBaseline = 'top';
          c.textAlign = 'left';
          c.font = 'bold 12px sans-serif';
          c.fillStyle = '#e2e8f0';
          c.fillText(`CAM ${i + 1} · ${ag.name.toUpperCase()}`, 8, 7);
          c.fillStyle = Math.sin(t * 3 + i) > 0 ? '#ef4444' : '#7f1d1d';
          c.beginPath();
          c.arc(178, 13, 4, 0, Math.PI * 2);
          c.fill();
          c.textBaseline = 'bottom';
          c.font = 'bold 12px sans-serif';
          c.fillStyle = down ? '#f87171' : st === 'idle' ? '#94a3b8' : st === 'paused' ? '#fbbf24' : '#34d399';
          c.fillText(down ? 'NO SIGNAL' : st === 'idle' ? 'IDLE' : st === 'paused' ? 'PAUSED' : 'ACTIVE', 8, 102);
          c.textAlign = 'right';
          c.font = '10px sans-serif';
          c.fillStyle = '#94a3b8';
          c.fillText(new Date().toTimeString().slice(0, 8), 186, 102);
          s.t.needsUpdate = true;
        });
        // arcade: umiilaw ang laro kapag may naglalaro; "INSERT COIN" kapag wala
        arcadeScreens.forEach((as, i) => {
          const owner = bots[ARCADE_OWNERS[i]];
          drawArcade(as, t, !!owner && owner.place === 'play' && !owner.walking);
        });
        // blinking LEDs ng mga server rack
        serverLeds.forEach((led, i) => {
          (led.material as THREE.MeshStandardMaterial).emissiveIntensity = Math.sin(t * (3 + (i % 5)) + i * 1.9) > 0.1 ? 1.8 : 0.25;
        });
      }

      // steam + hologram
      steam.forEach((s, i) => {
        const f = (t * 0.45 + i / steam.length) % 1;
        s.position.y = 3.0 + f * 1.6;
        s.position.x = -1.2 + Math.sin(t * 2 + i) * 0.15;
        s.scale.setScalar(0.6 + f);
        (s.material as THREE.MeshBasicMaterial).opacity = L.phase === 'coffee' ? 0.35 * (1 - f) : 0;
      });
      foodSteam.forEach((fs, i) => {
        const f = (t * 0.4 + i * 0.37) % 1;
        fs.m.position.set(fs.x + Math.sin(t * 1.8 + i) * 0.1, 1.35 + f * 1.1, fs.z);
        fs.m.scale.setScalar(0.5 + f);
        const eating = L.phase === 'meal' && IDS.some((id) => bots[id].place === 'dine' && !bots[id].walking);
        (fs.m.material as THREE.MeshBasicMaterial).opacity = eating ? 0.3 * (1 - f) : 0;
      });
      const labSeated = new Set<MemberId>();
      IDS.forEach((id) => {
        const b = bots[id];
        if (b.place === 'lab' && !b.walking) labSeated.add(id);
        // empleyado: ilalagay ang idea sa hologram habang sinasabi ito · secretary: kinukuha ang mga idea para basahin
        if (b.place === 'drop' && !b.walking && !dropped[id]) {
          if (id === 'sec') { dropped[id] = true; portal?.collect(b.pos.x, b.pos.z, t); }
          else if (L.speech[id]) { dropped[id] = true; portal?.drop(id, b.pos.x, b.pos.z, t); }
        }
        if (b.place !== 'drop') dropped[id] = false;
      });
      portal?.update(t, dt, L.phase === 'meeting', labSeated);

      renderer.render(scene, camera);
      if (!firstDone) { firstDone = true; readyRef.current?.(); }
    };
    raf = requestAnimationFrame(frame);

    return () => {
      cancelAnimationFrame(raf);
      cancelAnimationFrame(resizeRaf);
      renderer.domElement.removeEventListener('webglcontextlost', onCtxLost);
      renderer.domElement.removeEventListener('webglcontextrestored', onCtxBack);
      io.disconnect();
      ro.disconnect();
      renderer.domElement.removeEventListener('pointerdown', onDown);
      renderer.domElement.removeEventListener('pointerup', onUp);
      renderer.domElement.removeEventListener('pointermove', onMove);
      controls.dispose();
      scene.traverse((o) => {
        const m = o as THREE.Mesh;
        if (m.geometry) m.geometry.dispose();
        const mt = m.material as THREE.Material | THREE.Material[] | undefined;
        if (Array.isArray(mt)) mt.forEach((x) => x.dispose());
        else mt?.dispose();
      });
      envMap.dispose();
      pmrem.dispose();
      renderer.dispose();
      renderer.domElement.remove();
    };
  }, []);

  return (
    <div ref={hostRef} className="office-host absolute inset-0 overflow-hidden" style={{ background: '#0b0e14' }}>
      {/* room labels */}
      {ROOM_LABELS.map((rl) => (
        <div
          key={rl.key}
          ref={(el) => { roomRefs.current[rl.key] = el; }}
          className="pointer-events-none absolute left-0 top-0 z-10 flex flex-col items-center"
          style={{ willChange: 'transform' }}
        >
          <span
            className="whitespace-nowrap rounded-full border px-2 py-0.5 text-[9px] font-bold uppercase tracking-wider sm:text-[10px]"
            style={{ borderColor: `${rl.color}88`, background: 'rgba(10,14,22,0.72)', color: rl.color, boxShadow: `0 0 12px ${rl.color}55` }}
          >
            {rl.text}
          </span>
          <span className="mt-0.5 hidden whitespace-nowrap text-[9px] text-slate-400 sm:block">{rl.sub}</span>
        </div>
      ))}
      {/* member tags + bubbles */}
      {IDS.map((id) => {
        const place = places[id];
        const isLead = id === 'boss' || id === 'sec';
        const isStaff = isLead || id === 'it' || id === 'argus';
        const act = isStaff ? null : activity[id as AgentId];
        let bubble: string | undefined = speech[id];
        if (!bubble && place === 'office' && act && act.bubble) {
          const nowMs = Date.now();
          const rec = seenBubble.current[id];
          if (!rec || rec.text !== act.bubble) seenBubble.current[id] = { text: act.bubble, at: nowMs };
          const age = nowMs - seenBubble.current[id].at;
          if (age < ACT_BUBBLE_MS) {
            bubble = act.bubble;
            expireIn.current = Math.min(expireIn.current, ACT_BUBBLE_MS - age);
          }
        }
        // Boss, Ms. Mira, Dex at Argus ay hindi kasama sa energy system (walang energy bar o break)
        const rt: { energy: number; doing: ReelDoing } | undefined = id === 'argus' ? argus : isStaff || !hasEnergy(id) ? undefined : routine?.[id as AgentId];
        const onBreak = !!rt && rt.doing !== 'work';
        const busy = id === 'it' || id === 'argus' ? true : isLead ? phase !== 'work' : !onBreak && !!act && act.status !== 'idle' && act.status !== 'paused';
        return (
          <div
            key={id}
            ref={(el) => { tagRefs.current[id] = el; }}
            className="pointer-events-none absolute left-0 top-0 z-20 flex flex-col items-center gap-1"
            style={{ willChange: 'transform', zIndex: speech[id] ? 40 : 20 }}
          >
            {bubble && (
              <div
                className={`w-max rounded-md border bg-[#141821]/75 px-1 py-px text-[9px] leading-[1.15] text-slate-100 shadow sm:rounded-lg sm:bg-[#141821]/95 sm:px-2.5 sm:py-1.5 sm:text-[11px] sm:leading-snug ${id === 'boss' && speech.boss ? 'max-w-[min(150px,42vw)] sm:max-w-[260px]' : 'max-w-[min(92px,27vw)] sm:max-w-[200px]'}`}
                style={{ borderColor: `${COLORS[id]}88` }}
              >
                {/* ang live na sagot ni Boss sa owner ay hindi pinuputol nang todo: mababasa pa rin ang buong sagot */}
                <span className={id === 'boss' && speech.boss ? 'line-clamp-5' : 'line-clamp-2 sm:line-clamp-3'}>{compactLine(bubble, id === 'boss' && speech.boss ? (phone ? 110 : 180) : phone ? 38 : 80)}</span>
              </div>
            )}
            <div
              className="flex items-center gap-1 rounded-full border bg-[#141821]/95 px-1.5 py-px text-[9px] font-semibold text-white sm:px-2 sm:py-0.5 sm:text-[10px]"
              style={{ borderColor: `${COLORS[id]}88` }}
            >
              <span className={`h-1.5 w-1.5 rounded-full ${busy ? 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.9)]' : 'bg-slate-500'}`} />
              {id === 'boss' ? '👑 ' : id === 'sec' ? '🗂️ ' : id === 'it' ? '🖥️ ' : id === 'argus' ? '👁️ ' : ''}{NAMES[id]}{rt && rt.doing !== 'work' ? ` ${REEL_BREAK_ICON[rt.doing]}` : ''}
            </div>
            {rt && (
              <div className="h-1 w-9 overflow-hidden rounded-full bg-black/60 ring-1 ring-white/10 sm:w-12" title={`Energy ${rt.energy}%`}>
                <div
                  className="h-full rounded-full"
                  style={{ width: `${Math.max(4, rt.energy)}%`, background: rt.energy > 60 ? '#34d399' : rt.energy > 30 ? '#fbbf24' : '#f87171', transition: 'width 0.9s linear, background 0.9s' }}
                />
              </div>
            )}
          </div>
        );
      })}
      {/* maintenance bot tag + bubble */}
      <div
        ref={(el) => { tagRefs.current.maint = el; }}
        className="pointer-events-none absolute left-0 top-0 z-20 flex flex-col items-center gap-1"
        style={{ willChange: 'transform' }}
      >
        <div
          ref={maintBubble}
          className="w-max max-w-[min(92px,27vw)] rounded-md border bg-[#141821]/75 px-1 py-px text-[9px] leading-[1.15] text-slate-100 shadow sm:max-w-[200px] sm:rounded-lg sm:bg-[#141821]/95 sm:px-2.5 sm:py-1.5 sm:text-[11px] sm:leading-snug"
          style={{ borderColor: `${MAINT.color}88`, display: 'none' }}
        />
        <div
          className="flex items-center gap-1 rounded-full border bg-[#141821]/95 px-1.5 py-px text-[9px] font-semibold text-white sm:px-2 sm:py-0.5 sm:text-[10px]"
          style={{ borderColor: `${MAINT.color}88` }}
        >
          <span className="h-1.5 w-1.5 rounded-full bg-orange-400 shadow-[0_0_6px_rgba(251,146,60,0.9)]" />
          🛠️ {MAINT.name} <span className="hidden font-normal text-slate-400 sm:inline">· {MAINT.role}</span>
        </div>
      </div>
      {/* Reel (video editor) tag + bubble */}
      <div
        ref={(el) => { tagRefs.current.reel = el; }}
        className="pointer-events-none absolute left-0 top-0 z-20 flex flex-col items-center gap-1"
        style={{ willChange: 'transform' }}
      >
        <div
          ref={reelBubble}
          className="w-max max-w-[min(92px,27vw)] rounded-md border bg-[#141821]/75 px-1 py-px text-[9px] leading-[1.15] text-slate-100 shadow sm:max-w-[200px] sm:rounded-lg sm:bg-[#141821]/95 sm:px-2.5 sm:py-1.5 sm:text-[11px] sm:leading-snug"
          style={{ borderColor: `${REEL.color}88`, display: 'none' }}
        />
        <div
          className="flex items-center gap-1 rounded-full border bg-[#141821]/95 px-1.5 py-px text-[9px] font-semibold text-white sm:px-2 sm:py-0.5 sm:text-[10px]"
          style={{ borderColor: `${REEL.color}88` }}
        >
          <span
            className={`h-1.5 w-1.5 rounded-full ${reel?.state === 'working' ? 'bg-sky-400' : reel?.state === 'waiting' ? 'bg-amber-400' : reel?.state === 'problem' ? 'bg-red-400' : 'bg-slate-500'}`}
          />
          {REEL.emoji} {REEL.name}<span ref={reelDoingRef} /> <span className="hidden font-normal text-slate-400 sm:inline">· {reel?.label ?? REEL.role}</span>
        </div>
        <div className="h-1 w-9 overflow-hidden rounded-full bg-black/60 ring-1 ring-white/10 sm:w-12" title="Energy">
          <div ref={reelBarRef} className="h-full rounded-full" style={{ width: '100%', transition: 'width 0.9s linear, background 0.9s' }} />
        </div>
      </div>
      {hint && <div className="pointer-events-none absolute bottom-2 left-2 z-10 max-w-[75%] rounded-full bg-black/60 px-2.5 py-1 text-[9px] leading-tight text-slate-300 sm:left-auto sm:right-3 sm:max-w-none sm:text-[10px]">
        Hila pakaliwa/kanan para umikot · 2 daliri para mag-zoom · tap ang bot
      </div>}
    </div>
  );
}

function Office3DRoot(props: Props) {
  const [gen, setGen] = useState(0);
  const [mount, setMount] = useState(false);
  const [ready, setReady] = useState(false);
  const [veil, setVeil] = useState(true);
  // build the (heavy, synchronous) 3D scene only after the page has painted once, so the phone never shows a frozen white/black screen
  useEffect(() => {
    const id = window.setTimeout(() => setMount(true), 80);
    return () => window.clearTimeout(id);
  }, []);
  useEffect(() => {
    if (!ready) { setVeil(true); return; }
    const id = window.setTimeout(() => setVeil(false), 650);
    return () => window.clearTimeout(id);
  }, [ready]);
  return (
    <>
      {mount && (
        <Office3D
          key={gen}
          {...props}
          onContextRestored={() => { setReady(false); setGen((g) => g + 1); }}
          onReady={() => setReady(true)}
        />
      )}
      {veil && (
        <div
          className={`pointer-events-none absolute inset-0 z-30 flex flex-col items-center justify-center gap-3 bg-[#0b0e14] transition-opacity duration-500 ${ready ? 'opacity-0' : 'opacity-100'}`}
        >
          <span className="office-spinner" aria-hidden="true" />
          <p className="text-[11px] font-medium text-slate-400">Binubuo ang 3D office…</p>
        </div>
      )}
    </>
  );
}

export default memo(
  Office3DRoot,
  (a, b) => a.activity === b.activity && a.places === b.places && a.speech === b.speech && a.phase === b.phase && a.itTarget === b.itTarget && a.broken === b.broken && a.isNight === b.isNight && a.routine === b.routine && a.argus === b.argus && a.reel?.state === b.reel?.state && a.reel?.label === b.reel?.label && a.reel?.bubble === b.reel?.bubble && a.callout === b.callout,
);
