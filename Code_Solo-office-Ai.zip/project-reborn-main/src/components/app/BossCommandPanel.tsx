import { useCallback, useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, MessageSquare, Mic, Pencil, Phone, PhoneOff, Send, Sparkles, Square, Trash2, Volume2, VolumeX, X } from 'lucide-react';
import { BOSS } from '@/lib/app/office';
import type { BossCmd, CmdStep } from '@/lib/app/office';
import {
  COMMAND_MAX, COMMAND_PLATFORMS, fetchBossCommands, issueBossCommand, revokeBossCommand, validateCommand,
  type BossCommand, type CommandMode, type CommandPlatform,
} from '@/lib/app/bossCommand';
import { isGoodbye, mergePlan, nowConfirm, parseAfterCall, parseNowCall, planConfirm, planIsEmpty, planSummary, type AfterCallPlan } from '@/lib/app/callActions';
import { askBoss, BOSS_GREETINGS, type ChatSource, type ChatTurn, type ProposedCommand } from '@/lib/app/bossChat';
import { cancelSpeech, detectLang, hasNativeVoice, isEcho, speak, startListening, sttSupported, ttsSupported, type Listener, type VoiceLang } from '@/lib/app/voice';

const PRESETS = [
  'Gawing mas maikli at diretso ang lahat ng caption.',
  'Maging mas friendly at magalang ang tono ng lahat ng reply.',
  'Huwag mag-invite ng higit sa isang beses sa iisang user.',
];

interface Msg { id: string; who: 'me' | 'boss' | 'sys'; text: string; cmd?: ProposedCommand }
interface Applied { cmdId: string; mode: CommandMode; state: 'sending' | 'applied' | 'failed'; local?: boolean; error?: string }

const SOURCE_LABEL: Record<ChatSource, string> = { server: 'AI · server', browser: 'AI · browser key', offline: 'offline mode', report: 'ulat · totoong datos' };

// mga sagot gamit ang boses kapag may nakabinbing utos na naghihintay ng sagot mo
// mga nakahandang sagot ni Boss sa dalawang wika
const CANNED: Record<VoiceLang, { cancelled: string; meeting: string; desk: string; sayIt: string; confirm: string; bye: string }> = {
  'fil-PH': {
    cancelled: 'Sige, boss, kinansela ko ang utos.',
    meeting: 'Sige, boss! Ipapatawag ko ang team sa meeting.',
    desk: 'Sige, boss! Iaanunsyo ko sa team sa mga desk nila.',
    sayIt: 'Sabihin mo lang: meeting, sa desk, o huwag.',
    confirm: 'Sige, boss. Ipatupad ko ba ito sa team? 👇',
    bye: 'Sige, boss! Gagawin ko na agad ang pinag-usapan natin. Ingat!',
  },
  'en-US': {
    cancelled: 'Okay, boss, I cancelled that order.',
    meeting: "Okay, boss! I'll call the team to a meeting.",
    desk: "Okay, boss! I'll announce it to the team at their desks.",
    sayIt: 'Just say: meeting, desk, or no.',
    confirm: 'Okay, boss. Should I apply this to the team? 👇',
    bye: "Okay, boss! I'll start on what we talked about right away. Take care!",
  },
};

const NO = /\b(hindi|huwag|wag|cancel|ayaw|wala|no|stop)\b/i;
const YES = /\b(oo|opo|sige|ipatupad|apply|yes|go|ok|okay|ituloy|tuloy|sure|ayos)\b/i;
const MEETING = /(meeting|patawag|ipatawag|tawag|team|lahat)/i;
const DESK = /(desk|mensahe|message|text)/i;

function status(a: Applied, step: CmdStep | undefined): { tone: string; text: string } {
  if (a.state === 'sending') return { tone: 'text-slate-300', text: 'Sandali, sine-save ko ang utos… ⏳' };
  if (a.state === 'failed') return { tone: 'text-amber-300', text: `⚠️ Hindi ko ito naipatupad: ${a.error ?? 'may problema sa server'}` };
  if (step === 'done') {
    return a.local
      ? { tone: 'text-emerald-300', text: '✅ Naipatupad na sa team (sa browser na ito lang). Para masunod ng totoong bots, i-connect ang Supabase.' }
      : { tone: 'text-emerald-300', text: '✅ Naipatupad na sa team. Susundin ito ng lahat ng bot sa susunod nilang post, reply at invite.' };
  }
  if (step === 'active') return { tone: 'text-sky-300', text: a.mode === 'call' ? '📣 Pinapatawag ko na ang team sa meeting…' : '📩 Inaanunsyo ko na sa team…' };
  return { tone: 'text-violet-300', text: '📥 Naka-save na! Ianunsyo ko sa team sa susunod na pagkakataon.' };
}

export default function BossCommandPanel({
  open, onClose, steps, onSend, onBossSay, onAfterCall, statusText = '',
}: {
  open: boolean;
  onClose: () => void;
  steps: Record<string, CmdStep>;
  onSend: (c: BossCmd) => void;
  onBossSay: (text: string, ms?: number) => void;
  /** pagkatapos ng usapan: isinasagawa ni Boss ang sinabi mo (meeting, kausapin ang mga tao) */
  onAfterCall: (plan: AfterCallPlan) => void;
  /** live na kalagayan ng team (para masagot ni Boss ang "ano ang ginagawa ni Aria?") */
  statusText?: string;
}) {
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [applied, setApplied] = useState<Record<string, Applied>>({});
  const [dismissed, setDismissed] = useState<Set<string>>(new Set());
  const [text, setText] = useState('');
  const [platform, setPlatform] = useState<CommandPlatform>('all');
  const [thinking, setThinking] = useState(false);
  const [source, setSource] = useState<ChatSource | null>(null);
  const [active, setActive] = useState<BossCommand[]>([]);
  const [err, setErr] = useState<string | null>(null);
  // voice call
  const [callOn, setCallOn] = useState(false);
  const [listening, setListening] = useState(false);
  const [speaking, setSpeaking] = useState(false);
  const [interim, setInterim] = useState('');
  const [voiceOut, setVoiceOut] = useState(true);
  const [lang, setLang] = useState<VoiceLang>('fil-PH');
  const [caption, setCaption] = useState(''); // ang kasalukuyang sinasabi ni Boss (kita rin sa loob ng panel, dahil tinatakpan ng panel ang 3D office sa phone)
  const [, setVoicesTick] = useState(0); // para mag-render ulit kapag na-load na ang mga boses ng device

  const endRef = useRef<HTMLDivElement | null>(null);
  const noteRef = useRef<string | null>(null);
  const greeted = useRef(false);
  const idRef = useRef(0);
  const nid = () => `m${++idRef.current}`;

  // pinakabagong halaga para sa mga callback ng mikropono (hindi sila dapat gumamit ng lumang state)
  const msgsRef = useRef<Msg[]>([]); msgsRef.current = msgs;
  const appliedRef = useRef(applied); appliedRef.current = applied;
  const dismissedRef = useRef(dismissed); dismissedRef.current = dismissed;
  const activeRef = useRef(active); activeRef.current = active;
  const statusRef = useRef(statusText); statusRef.current = statusText;
  const langRef = useRef(lang); langRef.current = lang;
  const voiceOutRef = useRef(voiceOut); voiceOutRef.current = voiceOut;
  const planRef = useRef<AfterCallPlan | null>(null); // mga gagawin pagkatapos ng usapan
  const onAfterCallRef = useRef(onAfterCall); onAfterCallRef.current = onAfterCall;
  const callRef = useRef(false);
  const busyRef = useRef(false); // nag-iisip o nagsasalita si Boss
  const listenerRef = useRef<Listener | null>(null);
  const heardRef = useRef<(t: string) => Promise<void>>(async () => undefined);
  const loopRef = useRef<() => void>(() => undefined);

  const reload = useCallback(() => { void fetchBossCommands().then(setActive); }, []);
  const captionTimer = useRef<number | undefined>(undefined);
  // caption sa ulo ni Boss (3D office) at sa loob ng panel: mananatili hangga't binabasa pa, hindi biglang mawawala
  const bossLine = useCallback((t: string) => {
    const ms = Math.min(16000, 3200 + t.length * 80);
    onBossSay(t, ms);
    setCaption(t);
    window.clearTimeout(captionTimer.current);
    captionTimer.current = window.setTimeout(() => setCaption((c) => (c === t ? '' : c)), ms);
  }, [onBossSay]);

  const stopListening = () => {
    listenerRef.current?.stop();
    listenerRef.current = null;
    setListening(false);
    setInterim('');
  };

  const endCall = useCallback(() => {
    callRef.current = false;
    busyRef.current = false;
    listenerRef.current?.stop();
    listenerRef.current = null;
    cancelSpeech();
    setCallOn(false);
    setListening(false);
    setSpeaking(false);
    setInterim('');
  }, []);

  /** Tapos na ang usapan: ginagawa na ni Boss ang mga sinabi mong gagawin pagkatapos. */
  const flushPlan = useCallback((announce: boolean) => {
    const plan = planRef.current;
    planRef.current = null;
    if (planIsEmpty(plan)) return;
    onAfterCallRef.current(plan!);
    if (announce) setMsgs((p) => [...p, { id: `m${++idRef.current}`, who: 'sys', text: `Sinimulan na ni Boss: ${planSummary(plan!)}` }]);
  }, []);

  const hangUp = useCallback(() => {
    endCall();
    flushPlan(true); // ibinaba ang tawag: gagawin na ni Boss agad ang pinag-usapan
  }, [endCall, flushPlan]);
  const hangAfterRef = useRef(false); // nagpaalam ang owner: ibababa ang tawag pagkatapos magsalita ni Boss

  // sinasagot ni Boss ang tawag pagbukas ng panel; ibinababa ang tawag pagsara
  useEffect(() => {
    if (!open) { endCall(); flushPlan(false); return; }
    reload();
    if (!greeted.current) {
      greeted.current = true;
      setMsgs([{ id: nid(), who: 'boss', text: BOSS_GREETINGS[langRef.current] }]);
    }
    bossLine(BOSS_GREETINGS[langRef.current]);
  }, [open, reload, bossLine, endCall, flushPlan]);
  useEffect(() => {
    if (!ttsSupported()) return;
    const bump = () => setVoicesTick((n) => n + 1);
    window.speechSynthesis.addEventListener?.('voiceschanged', bump);
    return () => window.speechSynthesis.removeEventListener?.('voiceschanged', bump);
  }, []);
  // lumipat ng tab / na-unmount ang panel habang may nakabinbing plano: ilipat ito sa durable queue, hindi mawawala
  useEffect(() => () => { endCall(); flushPlan(false); }, [endCall, flushPlan]);
  // walang tawag (nag-type lang) at may nakabinbing plano: gagawin ni Boss 30 segundo pagkatapos ng huling usapan, kahit hindi mo pa isinasara ang panel
  useEffect(() => {
    if (!open || callOn || planIsEmpty(planRef.current)) return;
    const t = window.setTimeout(() => flushPlan(true), 30_000);
    return () => window.clearTimeout(t);
  }, [msgs, open, callOn, flushPlan]);
  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' }); }, [msgs, thinking, steps, applied, interim]);

  const push = (m: Omit<Msg, 'id'>) => setMsgs((p) => [...p, { ...m, id: nid() }]);

  const speakNow = async (t: string, l: VoiceLang = langRef.current) => {
    if (!voiceOutRef.current || !ttsSupported()) return;
    setSpeaking(true);
    await speak(t, l);
    setSpeaking(false);
  };

  /** Sinusundan ni Boss ang wika mo: Tagalog ang sinabi → Tagalog ang sagot at boses; English → English. */
  const adoptLang = (said: string): VoiceLang => {
    const l = detectLang(said) ?? langRef.current; // hindi malinaw ("ok")? ang kasalukuyang wika pa rin
    langRef.current = l;
    setLang(l);
    return l;
  };

  /** May utos na gagawin PAGKATAPOS ng usapan? ("pagkatapos natin mag-usap, mag-set ka ng meeting at kausapin mo si Reel…") */
  const tryAfterCall = (said: string, l: VoiceLang): string | null => {
    const found = parseAfterCall(said);
    if (!found) return null;
    planRef.current = mergePlan(planRef.current, found);
    const r = planConfirm(found, l);
    push({ who: 'me', text: said });
    push({ who: 'boss', text: r });
    bossLine(r);
    return r;
  };

  /** Utos na gagawin NGAYON DIN ("magpatawag ka ng meeting sa buong team"): sinisimulan agad, hindi na dumadaan sa AI. */
  const tryNowCall = (said: string, l: VoiceLang): string | null => {
    const found = parseNowCall(said);
    if (!found) return null;
    const r = nowConfirm(found, l);
    push({ who: 'me', text: said });
    push({ who: 'boss', text: r });
    push({ who: 'sys', text: `Sinimulan na ni Boss: ${planSummary(found)}` });
    bossLine(r);
    onAfterCallRef.current(found);
    return r;
  };

  /** Nagpaalam ang owner at may nakabinbing utos ("pagkatapos ng usapan…"): sasagot si Boss, ibababa ang tawag, at gagawin agad ang plano. */
  const tryGoodbye = (said: string, l: VoiceLang): string | null => {
    if (planIsEmpty(planRef.current) || !isGoodbye(said)) return null;
    const r = CANNED[l].bye;
    push({ who: 'me', text: said });
    push({ who: 'boss', text: r });
    bossLine(r);
    hangAfterRef.current = true;
    return r;
  };

  /** Isang palitan ng usapan: ang sinabi mo → sagot ni Boss (AI o offline). Ibinabalik ang sagot at ang bersyong babasahin nang malakas. */
  const chatTurn = async (t: string, l: VoiceLang): Promise<{ reply: string; spoken: string }> => {
    const history: ChatTurn[] = [
      ...msgsRef.current.filter((m) => m.who !== 'sys').map((m) => ({ role: (m.who === 'me' ? 'user' : 'boss') as ChatTurn['role'], text: m.text })),
      { role: 'user', text: t },
    ];
    push({ who: 'me', text: t });
    setThinking(true);
    const a = await askBoss(history, activeRef.current.map((c) => c.text), statusRef.current, l);
    setThinking(false);
    setSource(a.source);
    if (a.note && a.note !== noteRef.current) { noteRef.current = a.note; push({ who: 'sys', text: a.note }); }
    push({ who: 'boss', text: a.reply, cmd: a.command ?? undefined });
    bossLine(a.reply);
    // naintindihan ng AI na utos ito sa office (meeting / kausapin ang mga tao) kahit hindi ito nahuli ng mga pattern
    if (a.action && !a.command) {
      const plan: AfterCallPlan = { meeting: a.action.meeting, people: a.action.people };
      if (a.action.when === 'now') {
        push({ who: 'sys', text: `Sinimulan na ni Boss: ${planSummary(plan)}` });
        onAfterCallRef.current(plan);
      } else {
        planRef.current = mergePlan(planRef.current, plan);
      }
    }
    return { reply: a.reply, spoken: a.command ? `${a.reply} ${CANNED[l].sayIt}` : a.reply };
  };

  const apply = async (m: Msg, mode: CommandMode) => {
    if (!m.cmd || appliedRef.current[m.id]) return;
    const bad = validateCommand(m.cmd.text);
    if (bad) { setErr(bad); return; }
    setErr(null);
    const cmdId = `cmd-${Date.now()}`;
    appliedRef.current = { ...appliedRef.current, [m.id]: { cmdId, mode, state: 'sending' } };
    setApplied(appliedRef.current);
    const res = await issueBossCommand(m.cmd.text, m.cmd.platform);
    setApplied((p) => ({ ...p, [m.id]: { cmdId, mode, state: res.applied ? 'applied' : 'failed', local: res.local, error: res.error } }));
    onSend({ id: cmdId, text: m.cmd.text, mode, applied: res.applied, local: res.local, error: res.error }); // gagalaw ang 3D office
    if (res.applied) reload();
  };

  /** Ang sinabi mo gamit ang boses: sagot sa nakabinbing utos ("sige", "meeting", "huwag") o normal na tanong. */
  const handleUtterance = async (said: string, l: VoiceLang): Promise<string> => {
    // una sa lahat: paalam o utos na gagawin pagkatapos ng usapan (hindi ito sagot sa nakabinbing utos)
    const bye = tryGoodbye(said, l);
    if (bye) return bye;
    const after = tryAfterCall(said, l) ?? tryNowCall(said, l);
    if (after) return after;
    const pending = [...msgsRef.current].reverse().find((m) => m.who === 'boss' && m.cmd && !appliedRef.current[m.id] && !dismissedRef.current.has(m.id));
    if (pending) {
      if (NO.test(said)) {
        setDismissed((p) => new Set(p).add(pending.id));
        const r = CANNED[l].cancelled;
        push({ who: 'me', text: said });
        push({ who: 'boss', text: r });
        bossLine(r);
        return r;
      }
      if (DESK.test(said) || MEETING.test(said) || YES.test(said)) {
        const mode: CommandMode = DESK.test(said) ? 'message' : 'call';
        const r = mode === 'call' ? CANNED[l].meeting : CANNED[l].desk;
        push({ who: 'me', text: said });
        push({ who: 'boss', text: r });
        bossLine(r);
        void apply(pending, mode);
        return r;
      }
    }
    return (await chatTurn(said, l)).spoken;
  };

  // narinig ka ni Boss: sasagot siya (boses), tapos makikinig ulit
  heardRef.current = async (t: string) => {
    const said = t.replace(/\s+/g, ' ').trim();
    if (!said || busyRef.current) return;
    // echo: narinig ng mikropono ang boses ni Boss mismo (speaker) → huwag ituring na sinabi mo
    const lastBoss = [...msgsRef.current].reverse().find((m) => m.who === 'boss')?.text;
    if (lastBoss && isEcho(said, lastBoss)) return;
    busyRef.current = true;
    stopListening();
    const l = adoptLang(said);
    const spoken = await handleUtterance(said, l);
    if (callRef.current) { await speakNow(spoken, l); await new Promise((res) => window.setTimeout(res, 700)); } // hayaang mawala ang echo bago makinig ulit
    busyRef.current = false;
    if (hangAfterRef.current) { hangAfterRef.current = false; hangUp(); return; }
    if (callRef.current) loopRef.current();
  };

  loopRef.current = () => {
    if (!callRef.current || busyRef.current || listenerRef.current) return;
    const l = startListening(langRef.current, {
      onInterim: setInterim,
      onFinal: (t) => { void heardRef.current(t); },
      onEnd: () => {
        listenerRef.current = null;
        setListening(false);
        setInterim('');
        if (callRef.current && !busyRef.current) window.setTimeout(() => loopRef.current(), 300);
      },
      onError: (code) => {
        if (code === 'not-allowed' || code === 'service-not-allowed') {
          setErr('Hindi pinayagan ang mikropono. Payagan ito sa browser (icon ng lock sa address bar), tapos tawagan ulit si Boss.');
          endCall();
        } else if (code === 'language-not-supported') {
          setErr('Hindi suportado ng browser mo ang wikang ito. Subukan ang English (EN).');
          endCall();
        } else if (code === 'network') {
          setErr('Walang koneksyon sa speech service ng browser (kailangan ng internet sa pakikinig). Subukan ulit.');
          endCall();
        } else if (code === 'audio-capture') {
          setErr('Walang mikroponong makita. Ikonekta ito at subukan ulit.');
          endCall();
        }
        // 'no-speech' / 'aborted': normal, magre-restart ang pakikinig
      },
    });
    listenerRef.current = l;
    setListening(l !== null);
    if (!l) {
      setErr('Hindi sinusuportahan ng browser na ito ang pakikinig. Gamitin ang Chrome, Edge o Safari (o mag-type na lang).');
      endCall();
    }
  };

  const startCall = async () => {
    if (callRef.current) return;
    if (!sttSupported()) {
      setErr('Hindi sinusuportahan ng browser na ito ang pakikinig. Gamitin ang Chrome, Edge o Safari (o mag-type na lang).');
      return;
    }
    setErr(null);
    callRef.current = true;
    busyRef.current = true;
    setCallOn(true);
    bossLine(BOSS_GREETINGS[langRef.current]);
    await speakNow(BOSS_GREETINGS[langRef.current]);
    busyRef.current = false;
    if (callRef.current) loopRef.current();
  };

  /** Pinipigilan ang pagsasalita ni Boss para ikaw naman ang magsalita. */
  const interrupt = () => cancelSpeech();

  const toggleVoiceOut = () => {
    if (voiceOut) cancelSpeech();
    setVoiceOut(!voiceOut);
  };

  const toggleLang = () => {
    setLang((l) => (l === 'fil-PH' ? 'en-US' : 'fil-PH'));
    langRef.current = langRef.current === 'fil-PH' ? 'en-US' : 'fil-PH';
    if (callRef.current && !busyRef.current) stopListening(); // magre-restart gamit ang bagong wika
  };

  const sendChat = async () => {
    const t = text.replace(/\s+/g, ' ').trim();
    if (!t || thinking || busyRef.current) return;
    setErr(null);
    setText('');
    busyRef.current = true;
    stopListening();
    const l = adoptLang(t);
    const bye = tryGoodbye(t, l);
    const after = bye ? null : (tryAfterCall(t, l) ?? tryNowCall(t, l));
    const quick = bye ?? after;
    const r = quick ? { reply: quick, spoken: quick } : await chatTurn(t, l);
    if (callRef.current) await speakNow(r.spoken, l);
    busyRef.current = false;
    if (hangAfterRef.current) { hangAfterRef.current = false; hangUp(); return; }
    if (callRef.current) loopRef.current();
  };

  // "Gawing utos": diretso ang isinulat bilang utos, kahit hindi dumaan sa AI
  const proposeDirect = () => {
    const bad = validateCommand(text);
    if (bad) { setErr(bad); return; }
    setErr(null);
    const t = text.replace(/\s+/g, ' ').trim();
    setText('');
    push({ who: 'me', text: `📣 Utos: ${t}` });
    const reply = CANNED[detectLang(t) ?? 'fil-PH'].confirm;
    push({ who: 'boss', text: reply, cmd: { text: t, platform } });
    bossLine(reply);
  };

  const edit = (m: Msg) => {
    if (!m.cmd) return;
    setText(m.cmd.text);
    setDismissed((p) => new Set(p).add(m.id));
  };

  const revoke = async (c: BossCommand) => {
    setActive((p) => p.filter((x) => x.id !== c.id));
    try { await revokeBossCommand(c.id); } catch (e) { setErr((e as Error).message); reload(); }
  };

  const stateText = !callOn ? 'Online' : thinking ? 'Nag-iisip…' : speaking ? 'Nagsasalita…' : listening ? 'Nakikinig…' : 'On call';

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div className="fixed inset-0 z-[60] bg-black/25 sm:bg-black/20" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} onClick={onClose} />
          <motion.div
            className="fixed right-0 top-0 z-[70] flex w-full max-w-md flex-col border-l border-white/[0.08] bg-[#141821] shadow-2xl"
            style={{ height: 'calc(100dvh / var(--ui-zoom, 1))', paddingTop: 'env(safe-area-inset-top)', paddingBottom: 'env(safe-area-inset-bottom)', paddingRight: 'env(safe-area-inset-right)' }}
            initial={{ x: '100%' }} animate={{ x: 0 }} exit={{ x: '100%' }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
          >
            {/* header */}
            <div className="flex items-start justify-between gap-2 border-b border-white/[0.06] px-5 py-3.5">
              <div className="flex min-w-0 items-center gap-3">
                <span className={`relative flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-amber-500/15 text-lg ${speaking ? 'ring-2 ring-amber-400/70' : ''}`}>
                  👑
                  <span className={`absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-[#141821] ${callOn ? 'bg-emerald-400' : 'bg-slate-500'}`} />
                </span>
                <div className="min-w-0">
                  <h4 className="truncate font-semibold text-white">{BOSS.name}</h4>
                  <p className="truncate text-[11px] text-slate-400">{stateText}{source ? ` · ${SOURCE_LABEL[source]}` : ''}</p>
                </div>
              </div>
              <div className="flex shrink-0 items-center gap-1">
                <button type="button" onClick={toggleLang} title="Wika ng boses (awtomatiko: sinusundan ang wika mo)" aria-label="Wika ng boses" className="flex h-11 min-w-[44px] sm:h-9 sm:min-w-[40px] items-center justify-center rounded-lg px-2 text-[11px] font-bold text-slate-300 hover:bg-white/[0.06]">
                  {lang === 'fil-PH' ? 'FIL' : 'EN'}
                </button>
                <button type="button" onClick={toggleVoiceOut} title={voiceOut ? 'I-mute ang boses ni Boss' : 'I-unmute ang boses ni Boss'} aria-label="Boses ni Boss" className="flex h-11 w-11 sm:h-9 sm:w-9 items-center justify-center rounded-lg text-slate-300 hover:bg-white/[0.06]">
                  {voiceOut ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4 text-slate-500" />}
                </button>
                <button type="button" onClick={onClose} aria-label="Isara" className="flex h-11 w-11 sm:h-9 sm:w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-white/[0.06] hover:text-white">
                  <X className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* live caption: ang sinasabi ni Boss ngayon (kita kahit natatakpan ng panel ang 3D office) */}
            {caption && (
              <div aria-live="polite" className="border-b border-amber-400/20 bg-amber-500/10 px-5 py-2 text-[13px] leading-snug text-amber-100">
                <span className="mr-1.5 text-[10px] font-bold uppercase tracking-wide text-amber-300/80">Code Solo</span>
                {caption}
              </div>
            )}

            {/* active commands */}
            {active.length > 0 && (
              <details className="border-b border-white/[0.06] px-5 py-2 text-xs">
                <summary className="cursor-pointer select-none text-slate-400 hover:text-slate-200">Mga utos na sinusunod ng team ({active.length})</summary>
                <ul className="mt-2 max-h-36 space-y-1.5 overflow-y-auto">
                  {active.map((c) => (
                    <li key={c.id} className="flex items-start gap-2 rounded-lg bg-white/[0.03] px-3 py-2 text-slate-300">
                      <span className="min-w-0 flex-1">{c.text}<span className="ml-1 text-slate-500">· {c.platform === 'all' ? 'lahat' : c.platform}{c.id.startsWith('local-') ? ' · local' : ''}</span></span>
                      <button type="button" onClick={() => void revoke(c)} title="Bawiin ang utos" aria-label="Bawiin ang utos" className="shrink-0 rounded p-2.5 text-slate-500 hover:bg-rose-500/10 hover:text-rose-300">
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </li>
                  ))}
                </ul>
              </details>
            )}

            {/* chat */}
            <div className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
              {msgs.map((m) => {
                if (m.who === 'sys') return <p key={m.id} className="mx-auto max-w-[90%] text-center text-[10.5px] leading-snug text-slate-500">ℹ️ {m.text}</p>;
                if (m.who === 'me') {
                  return <div key={m.id} className="ml-10 rounded-2xl rounded-tr-sm bg-emerald-500/15 px-3 py-2 text-sm text-emerald-50">{m.text}</div>;
                }
                const ap = applied[m.id];
                const st = ap ? status(ap, steps[ap.cmdId]) : null;
                return (
                  <div key={m.id} className="mr-6 space-y-1.5">
                    <div className="rounded-2xl rounded-tl-sm bg-white/[0.06] px-3 py-2 text-sm leading-relaxed text-slate-100">
                      <span className="mr-1">👑</span>{m.text}
                    </div>
                    {m.cmd && !dismissed.has(m.id) && (
                      <div className="rounded-xl border border-amber-400/25 bg-amber-500/[0.07] p-3">
                        <p className="mb-1 flex items-center gap-1 text-[10px] font-semibold uppercase tracking-wide text-amber-300/80">
                          <Sparkles className="h-3 w-3" /> Bagong utos · {m.cmd.platform === 'all' ? 'lahat ng platform' : m.cmd.platform}
                        </p>
                        <p className="text-sm leading-relaxed text-amber-50">{m.cmd.text}</p>
                        {st ? (
                          <p className={`mt-2 text-xs leading-relaxed ${st.tone}`}>{st.text}</p>
                        ) : (
                          <div className="mt-2.5 grid grid-cols-[1fr_1fr_auto] gap-1.5">
                            <button type="button" onClick={() => void apply(m, 'call')} className="flex min-h-[44px] items-center justify-center gap-1 rounded-lg bg-amber-500 px-2 py-1.5 text-xs font-semibold text-amber-950 hover:bg-amber-400">
                              <Phone className="h-3.5 w-3.5" /> Meeting
                            </button>
                            <button type="button" onClick={() => void apply(m, 'message')} className="flex min-h-[44px] items-center justify-center gap-1 rounded-lg bg-white/[0.1] px-2 py-1.5 text-xs font-semibold text-slate-100 hover:bg-white/[0.16]">
                              <MessageSquare className="h-3.5 w-3.5" /> Sa desk
                            </button>
                            <button type="button" onClick={() => edit(m)} title="Baguhin ang utos" aria-label="Baguhin ang utos" className="flex min-h-[36px] w-9 items-center justify-center rounded-lg text-slate-400 hover:bg-white/[0.08] hover:text-white">
                              <Pencil className="h-3.5 w-3.5" />
                            </button>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
              {interim && <div className="ml-10 rounded-2xl rounded-tr-sm bg-emerald-500/[0.07] px-3 py-2 text-sm italic text-emerald-100/70">🎤 {interim}</div>}
              {thinking && (
                <div className="mr-6 inline-flex items-center gap-1.5 rounded-2xl rounded-tl-sm bg-white/[0.06] px-3 py-2 text-xs text-slate-400">
                  👑 nag-iisip <span className="flex gap-0.5"><i className="h-1 w-1 animate-bounce rounded-full bg-slate-400" /><i className="h-1 w-1 animate-bounce rounded-full bg-slate-400 [animation-delay:120ms]" /><i className="h-1 w-1 animate-bounce rounded-full bg-slate-400 [animation-delay:240ms]" /></span>
                </div>
              )}
              <div ref={endRef} />
            </div>

            {/* voice call bar */}
            <div className="border-t border-white/[0.06] px-4 pt-3">
              {!callOn ? (
                <button
                  type="button" onClick={() => void startCall()}
                  className="flex min-h-[44px] w-full items-center justify-center gap-2 rounded-xl bg-emerald-500 px-3 py-2 text-sm font-bold text-emerald-950 transition-colors hover:bg-emerald-400"
                >
                  <Phone className="h-4 w-4" /> Tawagan si Boss (voice)
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  <div className={`flex min-h-[44px] flex-1 items-center gap-2 rounded-xl border px-3 py-2 text-xs ${listening ? 'border-emerald-400/40 bg-emerald-500/10 text-emerald-200' : speaking ? 'border-amber-400/40 bg-amber-500/10 text-amber-200' : 'border-white/[0.08] bg-white/[0.03] text-slate-400'}`}>
                    {thinking ? <Loader2 className="h-4 w-4 animate-spin" /> : speaking ? <Volume2 className="h-4 w-4 animate-pulse" /> : <Mic className={`h-4 w-4 ${listening ? 'animate-pulse' : ''}`} />}
                    {thinking ? 'Nag-iisip si Boss…' : speaking ? 'Nagsasalita si Boss…' : listening ? 'Nakikinig… magsalita ka na' : 'Sandali…'}
                  </div>
                  {speaking && (
                    <button type="button" onClick={interrupt} title="Pigilan si Boss para ikaw ang magsalita" className="flex min-h-[44px] items-center gap-1 rounded-xl bg-white/[0.08] px-3 text-xs font-semibold text-slate-100 hover:bg-white/[0.14]">
                      <Square className="h-3.5 w-3.5" /> Pigil
                    </button>
                  )}
                  <button type="button" onClick={hangUp} title="Ibaba ang tawag" aria-label="Ibaba ang tawag" className="flex min-h-[44px] items-center gap-1 rounded-xl bg-rose-500 px-3 text-xs font-bold text-white hover:bg-rose-400">
                    <PhoneOff className="h-4 w-4" />
                  </button>
                </div>
              )}
              {!sttSupported() && !callOn && (
                <p className="mt-1.5 text-[10.5px] text-amber-300/80">Hindi sinusuportahan ng browser na ito ang voice (gamitin ang Chrome, Edge o Safari). Gumagana pa rin ang pag-type.</p>
              )}
              {ttsSupported() && !hasNativeVoice(lang) && (
                <p className="mt-1.5 text-[10.5px] text-amber-300/80">
                  {lang === 'fil-PH'
                    ? 'Walang Filipino na boses ang device mo, kaya kakaiba ang bigkas ng Tagalog ni Boss. I-install ang “Filipino” sa Text-to-speech settings ng phone/PC (Android: Settings > Text-to-speech > Google > Install voice data).'
                    : 'Walang English na boses ang device mo. Mag-install ng voice sa Text-to-speech settings.'}
                </p>
              )}
            </div>

            {/* composer */}
            <div className="space-y-2.5 p-4 pt-2.5">
              <div className="no-scrollbar -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-0.5">
                {PRESETS.map((p) => (
                  <button key={p} type="button" onClick={() => setText(p)} className="shrink-0 rounded-full border border-white/[0.08] px-2.5 py-1 text-[11px] text-slate-400 hover:border-amber-400/30 hover:text-amber-200">
                    {p.length > 34 ? `${p.slice(0, 33)}…` : p}
                  </button>
                ))}
              </div>
              <textarea
                value={text}
                onChange={(e) => setText(e.target.value.slice(0, COMMAND_MAX))}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.shiftKey && window.matchMedia('(min-width: 640px)').matches) { e.preventDefault(); void sendChat(); }
                }}
                rows={2}
                placeholder="O mag-type kay Boss… (hal. “Gawing mas friendly ang tono ng mga reply”)"
                className="w-full resize-none rounded-lg border border-white/[0.08] bg-white/[0.03] px-3 py-2 text-[16px] leading-relaxed text-white placeholder-slate-500 outline-none focus:border-amber-500/50 sm:text-sm"
              />
              {err && <p className="text-xs text-rose-300">{err}</p>}
              <div className="flex items-center gap-2">
                <select
                  value={platform}
                  onChange={(e) => setPlatform(e.target.value as CommandPlatform)}
                  aria-label="Platform ng utos"
                  title="Platform (para sa “Gawing utos”)"
                  className="min-w-0 rounded-lg border border-white/[0.08] bg-white/[0.03] px-2 py-2 text-xs text-slate-200 outline-none [&>option]:bg-[#141821]"
                >
                  {COMMAND_PLATFORMS.map((p) => <option key={p} value={p}>{p === 'all' ? 'Lahat' : p}</option>)}
                </select>
                <button type="button" disabled={!text.trim() || thinking} onClick={proposeDirect} className="min-h-[40px] flex-1 rounded-lg bg-white/[0.08] px-3 py-2 text-xs font-semibold text-slate-100 hover:bg-white/[0.14] disabled:opacity-40">
                  📣 Gawing utos
                </button>
                <button type="button" disabled={!text.trim() || thinking} onClick={() => void sendChat()} className="flex min-h-[40px] flex-1 items-center justify-center gap-1.5 rounded-lg bg-amber-500 px-3 py-2 text-sm font-semibold text-amber-950 hover:bg-amber-400 disabled:opacity-40">
                  {thinking ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />} Send
                </button>
              </div>
              <p className="text-[10.5px] leading-snug text-slate-500">
                Sa voice call, sabihin lang ang tanong o utos mo. Kapag may utos, sabihin ang <b>“meeting”</b>, <b>“sa desk”</b> o <b>“huwag”</b>. Ang utos ay nagiging Core Guardrail na binabasa ng lahat ng bot. Pwede ring sabihin: <b>“pagkatapos natin mag-usap, mag-set ka ng meeting at kausapin mo sina Reel, Cipher, Argus, Nova, Aria at Blaze”</b>, at gagawin ito ni Boss pagbaba ng tawag.
              </p>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
