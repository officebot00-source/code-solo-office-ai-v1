import { useCallback, useEffect, useRef, useState, type CSSProperties, type ReactNode } from 'react';
import { Brain, CalendarClock, Eye, Gamepad2, Radio, Settings, Sparkles, UserPlus, Zap, type LucideIcon } from 'lucide-react';
import type { BotLog } from '@/lib/app/types';
import { db, subscribeLogs } from '@/lib/app/db';

/* ------------------------------------------------------------------ */
/* LiveSkin = the "Holo-Circuit" look for every tab EXCEPT Dashboard.   */
/*  - LiveStage : wrapper (ambient aurora + data-flow constellation +   */
/*                card spotlight) that restyles every .surface inside   */
/*  - TabHero   : per-tab animated hero (reactor, live clock, waveform, */
/*                live bot-log ticker)                                  */
/* Nothing here wraps the WebGL office, and no ancestor transforms.     */
/* ------------------------------------------------------------------ */

export type LiveTabId = 'games' | 'studio' | 'scheduler' | 'invites' | 'brain' | 'watchdog' | 'settings';

interface Theme {
  title: string;
  tag: string;
  sub: string;
  icon: LucideIcon;
  a: string;
  b: string;
}

const THEMES: Record<LiveTabId, Theme> = {
  games: { title: 'Game Profiles', tag: 'ARCADE GRID', sub: 'Lahat ng laro na nilalabas ng mga bot, nasa isang lugar.', icon: Gamepad2, a: '#a78bfa', b: '#f0abfc' },
  studio: { title: 'AI Content Studio', tag: 'CREATOR LAB', sub: 'Gumawa ng caption, post at video habang buhay ang AI.', icon: Sparkles, a: '#fbbf24', b: '#fb7185' },
  scheduler: { title: 'Scheduler', tag: 'TIME ENGINE', sub: 'Ang pila ng mga post — tumatakbo kahit tulog ka.', icon: CalendarClock, a: '#38bdf8', b: '#22d3ee' },
  invites: { title: 'Auto-Invite Bot', tag: 'OUTREACH RADAR', sub: 'Nagbabantay ng comments at nagpapadala ng invite.', icon: UserPlus, a: '#34d399', b: '#a3e635' },
  brain: { title: 'Shared Brain', tag: 'NEURAL CORE', sub: 'Ang natututunan ng lahat ng bot, pinagsasama-sama.', icon: Brain, a: '#e879f9', b: '#818cf8' },
  watchdog: { title: 'Watchdog (Argus)', tag: 'ARGUS WATCH', sub: 'Laging may nakamasid sa mga bot at sa mga error.', icon: Eye, a: '#fb923c', b: '#f87171' },
  settings: { title: 'API Settings', tag: 'CONTROL BAY', sub: 'Mga susi at koneksyon ng buong opisina.', icon: Settings, a: '#2dd4bf', b: '#94a3b8' },
};

export const isLiveTab = (t: string): t is LiveTabId => t in THEMES;

const prefersReducedMotion = () =>
  typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

function rgba(hex: string, alpha: number) {
  const n = parseInt(hex.slice(1), 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${alpha})`;
}

function useNow(ms = 1000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), ms);
    return () => window.clearInterval(t);
  }, [ms]);
  return now;
}

/* ------------------------------------------------------------------ */
/* Data-flow constellation (canvas, ~30fps, pauses when hidden)         */
/* ------------------------------------------------------------------ */

function Constellation({ a, b }: { a: string; b: string }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const cv = ref.current;
    const ctx = cv?.getContext('2d');
    if (!cv || !ctx) return;
    const reduce = prefersReducedMotion();
    const dpr = Math.min(1.5, window.devicePixelRatio || 1);
    const LINK = 140;
    let w = 0;
    let h = 0;
    let nodes: { x: number; y: number; vx: number; vy: number; r: number; ph: number }[] = [];
    let packets: { i: number; j: number; t: number; sp: number }[] = [];
    const pointer = { x: -9999, y: -9999 };
    let raf = 0;
    let last = 0;
    let spawn = 0;

    const resize = () => {
      w = cv.clientWidth;
      h = cv.clientHeight;
      cv.width = Math.max(1, Math.floor(w * dpr));
      cv.height = Math.max(1, Math.floor(h * dpr));
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const count = Math.round(Math.min(48, Math.max(16, (w * h) / 24000)));
      nodes = Array.from({ length: count }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.28,
        vy: (Math.random() - 0.5) * 0.28,
        r: 1 + Math.random() * 1.7,
        ph: Math.random() * Math.PI * 2,
      }));
      packets = [];
      if (reduce) draw(0);
    };

    const neighbours = (i: number) => {
      const out: number[] = [];
      const n = nodes[i];
      if (!n) return out;
      nodes.forEach((m, j) => {
        if (j !== i && Math.hypot(m.x - n.x, m.y - n.y) < LINK) out.push(j);
      });
      return out;
    };

    function draw(time: number) {
      ctx!.clearRect(0, 0, w, h);
      // links
      for (let i = 0; i < nodes.length; i++) {
        const p = nodes[i]!;
        for (let j = i + 1; j < nodes.length; j++) {
          const q = nodes[j]!;
          const d = Math.hypot(p.x - q.x, p.y - q.y);
          if (d < LINK) {
            ctx!.strokeStyle = rgba(a, (1 - d / LINK) * 0.2);
            ctx!.lineWidth = 1;
            ctx!.beginPath();
            ctx!.moveTo(p.x, p.y);
            ctx!.lineTo(q.x, q.y);
            ctx!.stroke();
          }
        }
      }
      // data packets travelling along links
      for (const k of packets) {
        const p = nodes[k.i];
        const q = nodes[k.j];
        if (!p || !q) continue;
        const x = p.x + (q.x - p.x) * k.t;
        const y = p.y + (q.y - p.y) * k.t;
        const tx = p.x + (q.x - p.x) * Math.max(0, k.t - 0.16);
        const ty = p.y + (q.y - p.y) * Math.max(0, k.t - 0.16);
        const g = ctx!.createLinearGradient(tx, ty, x, y);
        g.addColorStop(0, rgba(b, 0));
        g.addColorStop(1, rgba(b, 0.95));
        ctx!.strokeStyle = g;
        ctx!.lineWidth = 2;
        ctx!.beginPath();
        ctx!.moveTo(tx, ty);
        ctx!.lineTo(x, y);
        ctx!.stroke();
        ctx!.fillStyle = rgba(b, 1);
        ctx!.beginPath();
        ctx!.arc(x, y, 2.2, 0, Math.PI * 2);
        ctx!.fill();
      }
      // nodes
      for (const n of nodes) {
        const pulse = 0.5 + 0.5 * Math.sin(time / 900 + n.ph);
        ctx!.fillStyle = rgba(a, 0.25 + pulse * 0.5);
        ctx!.beginPath();
        ctx!.arc(n.x, n.y, n.r + pulse * 0.8, 0, Math.PI * 2);
        ctx!.fill();
      }
    }

    const frame = (time: number) => {
      raf = requestAnimationFrame(frame);
      if (document.hidden || time - last < 32) return; // ~30fps keeps phones cool
      const dt = Math.min(2, (time - last) / 16.7);
      last = time;
      for (const n of nodes) {
        const dx = pointer.x - n.x;
        const dy = pointer.y - n.y;
        const d = Math.hypot(dx, dy);
        if (d < 160 && d > 1) {
          n.vx += (dx / d) * 0.012;
          n.vy += (dy / d) * 0.012;
        }
        n.vx *= 0.995;
        n.vy *= 0.995;
        n.x += n.vx * dt;
        n.y += n.vy * dt;
        if (n.x < -10) n.x = w + 10;
        if (n.x > w + 10) n.x = -10;
        if (n.y < -10) n.y = h + 10;
        if (n.y > h + 10) n.y = -10;
      }
      spawn -= dt;
      if (spawn <= 0 && packets.length < 16) {
        spawn = 14 + Math.random() * 18;
        const i = Math.floor(Math.random() * nodes.length);
        const near = neighbours(i);
        if (near.length) packets.push({ i, j: near[Math.floor(Math.random() * near.length)]!, t: 0, sp: 0.012 + Math.random() * 0.012 });
      }
      for (const k of packets) k.t += k.sp * dt;
      packets = packets.filter((k) => k.t < 1);
      draw(time);
    };

    const onMove = (e: PointerEvent) => {
      const r = cv.getBoundingClientRect();
      pointer.x = e.clientX - r.left;
      pointer.y = e.clientY - r.top;
    };
    const onLeave = () => {
      pointer.x = -9999;
      pointer.y = -9999;
    };

    resize();
    window.addEventListener('resize', resize);
    if (!reduce) {
      window.addEventListener('pointermove', onMove, { passive: true });
      window.addEventListener('pointerleave', onLeave);
      raf = requestAnimationFrame(frame);
    }
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener('resize', resize);
      window.removeEventListener('pointermove', onMove);
      window.removeEventListener('pointerleave', onLeave);
    };
  }, [a, b]);

  return <canvas ref={ref} className="lv-canvas" aria-hidden="true" />;
}

/* ------------------------------------------------------------------ */
/* Live feed hook: last bot log + events/min (shared by the hero)       */
/* ------------------------------------------------------------------ */

function useLiveFeed() {
  const [last, setLast] = useState<BotLog | null>(null);
  const [perMin, setPerMin] = useState(0);
  const [burst, setBurst] = useState(false);
  const stamps = useRef<number[]>([]);
  const burstTimer = useRef(0);

  useEffect(() => {
    let alive = true;
    db.listLogs(5)
      .then((rows) => {
        if (alive && rows[0]) setLast((cur) => cur ?? rows[0]!);
      })
      .catch(() => undefined);
    const unsub = subscribeLogs((row) => {
      if (!alive) return;
      setLast(row);
      stamps.current.push(Date.now());
      setBurst(true);
      window.clearTimeout(burstTimer.current);
      burstTimer.current = window.setTimeout(() => setBurst(false), 1600);
    });
    const t = window.setInterval(() => {
      const cut = Date.now() - 60000;
      stamps.current = stamps.current.filter((s) => s > cut);
      setPerMin(stamps.current.length);
    }, 2000);
    return () => {
      alive = false;
      unsub();
      window.clearInterval(t);
      window.clearTimeout(burstTimer.current);
    };
  }, []);

  return { last, perMin, burst };
}

/* ------------------------------------------------------------------ */
/* Hero                                                                 */
/* ------------------------------------------------------------------ */

const LEVEL_DOT: Record<string, string> = {
  info: '#38bdf8',
  success: '#34d399',
  warning: '#fbbf24',
  error: '#f87171',
};

function ago(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  if (s < 5) return 'ngayon lang';
  if (s < 60) return `${s}s ang nakalipas`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ang nakalipas`;
  return `${Math.floor(m / 60)}h ang nakalipas`;
}

const EQ_BARS = Array.from({ length: 22 }, (_, i) => ({
  d: -((i * 137) % 900) / 1000,
  s: 0.9 + ((i * 53) % 70) / 100,
  lo: 0.18 + ((i * 29) % 20) / 100,
}));

function TabHero({ tab, autoPilot, games }: { tab: LiveTabId; autoPilot: boolean; games: number }) {
  const th = THEMES[tab];
  const Icon = th.icon;
  const now = useNow(1000);
  const { last, perMin, burst } = useLiveFeed();
  const d = new Date(now);
  const time = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

  return (
    <section className="lv-hero fade-up" aria-label={th.title}>
      <span className="lv-hero-spin" aria-hidden="true" />
      <div className="lv-hero-in">
        <span className="lv-aur lv-aur-a" aria-hidden="true" />
        <span className="lv-aur lv-aur-b" aria-hidden="true" />
        <span className="lv-hero-grid" aria-hidden="true" />
        <span className="lv-hero-scan" aria-hidden="true" />

        <div className="relative flex flex-wrap items-center justify-between gap-4 p-4 sm:p-6">
          <div className="flex min-w-0 items-center gap-4">
            {/* reactor */}
            <div className="lv-reactor" aria-hidden="true">
              <svg viewBox="0 0 80 80">
                <circle className="lv-ring lv-ring-1" cx="40" cy="40" r="35" />
                <circle className="lv-ring lv-ring-2" cx="40" cy="40" r="27" />
                <g className="lv-orbit">
                  <circle cx="40" cy="5" r="2.6" fill="var(--lv-b)" />
                </g>
                <g className="lv-orbit lv-orbit-rev">
                  <circle cx="40" cy="13" r="1.8" fill="var(--lv-a)" />
                </g>
              </svg>
              <span className="lv-core">
                <Icon className="h-5 w-5" />
              </span>
            </div>
            <div className="min-w-0">
              <p className="lv-tag">
                <span className="lv-tag-dot" /> {th.tag}
              </p>
              <h2 className="lv-title mt-1 text-xl font-extrabold tracking-tight sm:text-2xl">{th.title}</h2>
              <p className="mt-1 max-w-md text-xs leading-relaxed text-slate-400 sm:text-sm">{th.sub}</p>
            </div>
          </div>

          <div className="flex w-full flex-col items-stretch gap-3 sm:w-auto sm:items-end">
            <div className="flex items-center justify-between gap-4 sm:justify-end">
              <div className="lv-eq" data-burst={burst ? '1' : '0'} aria-hidden="true">
                {EQ_BARS.map((b, i) => (
                  <i key={i} style={{ ['--d' as string]: `${b.d}s`, ['--s' as string]: `${b.s}s`, ['--lo' as string]: b.lo } as CSSProperties} />
                ))}
              </div>
              <p className="font-mono text-2xl font-bold tabular-nums tracking-tight text-white sm:text-3xl" aria-label="Current time">
                {time}
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2 sm:justify-end">
              <span className={`lv-chip ${autoPilot ? 'lv-chip-on' : ''}`}>
                <span className="relative flex h-2 w-2">
                  {autoPilot && <span className="dash-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400" />}
                  <span className={`relative inline-flex h-2 w-2 rounded-full ${autoPilot ? 'bg-emerald-400' : 'bg-slate-500'}`} />
                </span>
                {autoPilot ? 'Auto-Pilot 24/7' : 'Auto-Pilot OFF'}
              </span>
              <span className="lv-chip lv-chip-sky">
                <Radio className="h-3 w-3" /> {perMin} events/min
              </span>
              <span className="lv-chip lv-chip-violet">
                <Zap className="h-3 w-3" /> {games} game{games === 1 ? '' : 's'}
              </span>
            </div>
          </div>
        </div>

        {/* live ticker */}
        <div className="lv-ticker">
          <span className="lv-live">
            <span className="relative flex h-1.5 w-1.5">
              <span className="dash-ping absolute inline-flex h-full w-full rounded-full bg-red-400" />
              <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-red-400" />
            </span>
            LIVE
          </span>
          {last ? (
            <p key={last.id} className="lv-ticker-msg dash-slide-in">
              <span className="lv-ticker-dot" style={{ background: LEVEL_DOT[last.level] ?? '#38bdf8' }} />
              <span className="min-w-0 flex-1 truncate">{last.message}</span>
              <span className="shrink-0 font-mono text-[10px] text-slate-500">{ago(now - new Date(last.created_at).getTime())}</span>
            </p>
          ) : (
            <p className="lv-ticker-msg text-slate-500">Naghihintay ng bot activity…</p>
          )}
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* Stage                                                                */
/* ------------------------------------------------------------------ */

export function LiveStage({ tab, autoPilot, games, children }: { tab: LiveTabId; autoPilot: boolean; games: number; children: ReactNode }) {
  const th = THEMES[tab];

  // cursor-follow spotlight on whichever card the pointer is over
  const onPointerMove = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    const el = (e.target as HTMLElement).closest?.('.surface') as HTMLElement | null;
    if (!el) return;
    const r = el.getBoundingClientRect();
    el.style.setProperty('--mx', `${e.clientX - r.left}px`);
    el.style.setProperty('--my', `${e.clientY - r.top}px`);
  }, []);

  return (
    <div
      className="live-skin"
      style={{ ['--lv-a' as string]: th.a, ['--lv-b' as string]: th.b, ['--lv-a-soft' as string]: rgba(th.a, 0.18), ['--lv-b-soft' as string]: rgba(th.b, 0.14) } as CSSProperties}
      onPointerMove={onPointerMove}
    >
      <div className="lv-ambient" aria-hidden="true">
        <span className="lv-amb lv-amb-a" />
        <span className="lv-amb lv-amb-b" />
        <Constellation a={th.a} b={th.b} />
      </div>
      <div className="lv-content">
        <TabHero tab={tab} autoPilot={autoPilot} games={games} />
        <div className="lv-stack mt-5">{children}</div>
      </div>
    </div>
  );
}
