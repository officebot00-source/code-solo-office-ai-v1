import { useEffect, useState } from 'react';
import { recordClick, type VariantKey } from '@/lib/app/ab';

/** /go/:campaignId/a|b — logs the click, then redirects to the real game URL. */
export default function GoRedirect() {
  const [error, setError] = useState('');
  useEffect(() => {
    const [, , campaign, v] = window.location.pathname.split('/');
    const variant = v === 'b' ? 'b' : ('a' as VariantKey);
    const platform = new URLSearchParams(window.location.search).get('src') ?? 'direct';
    const dest = recordClick(campaign, variant, platform);
    if (dest) window.location.replace(dest);
    else setError('This tracking link is unknown or expired.');
  }, []);
  return (
    <div className="flex min-h-screen items-center justify-center bg-[#0b0e14] text-sm text-slate-300">
      {error || 'Redirecting you to the game…'}
    </div>
  );
}
