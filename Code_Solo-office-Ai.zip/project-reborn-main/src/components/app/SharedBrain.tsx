import { Suspense, lazy, useCallback, useMemo, useState } from 'react';
import {
  Archive, ArchiveRestore, Brain, Check, Clock, Flame, Lock, MessageSquareText, Plus, Radio, RefreshCw, Search,
  ShieldCheck, Sparkles, Trash2, TrendingUp, Users, X, Zap, type LucideIcon,
} from 'lucide-react';
import { BOT_STYLE, num, timeAgo, useBrain, type ActionLog, type BrainBot, type BrainRule } from '@/lib/app/brain';
import { isSupabaseConfigured } from '@/lib/app/supabase';
import { Button, Card, EmptyState, Input, Select, TextArea, Toggle } from './ui-kit';
import BrainMap from './BrainMap';

// three.js is only fetched when the 3D map is actually shown
const BrainMap3D = lazy(() => import('./BrainMap3D'));
const MAP_VIEW_KEY = 'sb_map_view';

const CATS: Record<string, { label: string; icon: LucideIcon; chip: string; text: string }> = {
  winning_hook: { label: 'Winning Hook', icon: Flame, chip: 'border-amber-400/25 bg-amber-500/10 text-amber-300', text: 'text-amber-300' },
  best_timing: { label: 'Best Timing', icon: Clock, chip: 'border-sky-400/25 bg-sky-500/10 text-sky-300', text: 'text-sky-300' },
  invite_script: { label: 'Invite Script', icon: MessageSquareText, chip: 'border-pink-400/25 bg-pink-500/10 text-pink-300', text: 'text-pink-300' },
  ban_guardrail: { label: 'Guardrail', icon: ShieldCheck, chip: 'border-rose-400/25 bg-rose-500/10 text-rose-300', text: 'text-rose-300' },
  audience_insight: { label: 'Audience Insight', icon: Users, chip: 'border-violet-400/25 bg-violet-500/10 text-violet-300', text: 'text-violet-300' },
};
const catOf = (c: string) => CATS[c] ?? { label: c, icon: Sparkles, chip: 'border-white/10 bg-white/5 text-slate-300', text: 'text-slate-300' };
const PLATFORMS = ['facebook', 'twitter', 'discord', 'telegram'];
const confColor = (c: number) => (c < 0.4 ? '#f87171' : c < 0.65 ? '#fbbf24' : '#34d399');
const scoreColor = (s: number) => (s >= 60 ? 'text-emerald-300' : s >= 30 ? 'text-amber-300' : 'text-rose-300');

type Tab = 'learned' | 'core' | 'review' | 'archived';

function Stat({ icon: Icon, label, value, tone }: { icon: LucideIcon; label: string; value: string | number; tone: string }) {
  return (
    <div className="surface rounded-xl p-3.5">
      <div className="flex items-center gap-2 text-[11px] font-medium text-slate-400">
        <span className={`flex h-6 w-6 items-center justify-center rounded-lg bg-white/[0.05] ${tone}`}><Icon className="h-3.5 w-3.5" /></span>
        {label}
      </div>
      <p className="mt-2 text-2xl font-bold tabular-nums tracking-tight text-white">{value}</p>
    </div>
  );
}

function RuleCard({ rule, bot, flashing, onApprove, onReject, onRestore, onArchive, onDelete, busy }: {
  rule: BrainRule; bot?: BrainBot; flashing: boolean; busy: boolean;
  onApprove: () => void; onReject: () => void; onRestore: () => void; onArchive: () => void; onDelete: () => void;
}) {
  const cat = catOf(rule.category), Icon = cat.icon;
  const conf = Math.round(num(rule.confidence_score) * 100);
  const pending = rule.status === 'pending_review', archived = rule.status === 'deprecated';
  const st = bot ? BOT_STYLE[bot.name] : undefined;
  return (
    <div
      className={`surface fade-up relative flex flex-col rounded-xl p-4 transition-[box-shadow,transform,border-color] duration-500 hover:-translate-y-0.5 hover:border-white/[0.14] ${
        flashing ? 'ring-2 ring-violet-400/70 shadow-[0_0_26px_rgba(167,139,250,0.4)]' : ''
      } ${rule.is_core_guardrail ? 'border-amber-400/25' : ''} ${archived ? 'opacity-60' : ''}`}
    >
      {rule.is_core_guardrail && <span className="absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-amber-300/60 to-transparent" />}
      <div className="flex flex-wrap items-center gap-1.5">
        <span className={`inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[11px] font-semibold ${cat.chip}`}><Icon className="h-3 w-3" />{cat.label}</span>
        <span className="rounded-full border border-white/[0.08] bg-white/[0.04] px-2 py-0.5 text-[11px] text-slate-300">{rule.platform === 'all' ? 'All platforms' : rule.platform}</span>
        {rule.is_core_guardrail && <span className="inline-flex items-center gap-1 rounded-full border border-amber-400/30 bg-amber-500/10 px-2 py-0.5 text-[11px] font-semibold text-amber-300"><Lock className="h-3 w-3" />Admin rule</span>}
        {pending && <span className="rounded-full border border-sky-400/30 bg-sky-500/10 px-2 py-0.5 text-[11px] font-semibold text-sky-300">Needs review</span>}
        {archived && <span className="rounded-full border border-white/10 bg-white/5 px-2 py-0.5 text-[11px] text-slate-400">Archived</span>}
      </div>
      <h4 className="mt-2.5 text-sm font-semibold leading-snug text-white">{rule.title}</h4>
      <p className="mt-1.5 text-[13px] leading-relaxed text-slate-300">{rule.insight_rule}</p>

      {!rule.is_core_guardrail && (
        <div className="mt-3">
          <div className="flex items-center justify-between text-[11px] text-slate-400">
            <span>Confidence</span><b className="text-white">{conf}%</b>
          </div>
          <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-white/[0.06]">
            <div className="h-full rounded-full transition-all duration-700" style={{ width: `${conf}%`, background: `linear-gradient(90deg, ${confColor(num(rule.confidence_score))}99, ${confColor(num(rule.confidence_score))})` }} />
          </div>
        </div>
      )}

      <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-white/[0.06] pt-3 text-[11px] text-slate-500">
        <span className="flex min-w-0 items-center gap-1.5">
          <span className="flex h-5 w-5 items-center justify-center rounded-full text-[11px]" style={{ background: `${st?.color ?? '#64748b'}26` }}>{st?.emoji ?? '👤'}</span>
          <span className="truncate" style={{ color: st?.color }}>{bot?.name ?? 'Admin'}</span>
          <span>· nagamit {rule.usage_count}×</span>
          <span>· {timeAgo(rule.updated_at)}</span>
        </span>
        <span className="flex items-center gap-1">
          {pending && (<>
            <button type="button" disabled={busy} onClick={onApprove} className="inline-flex items-center gap-1 rounded-md bg-emerald-500/15 px-2.5 py-2.5 sm:px-2 sm:py-1 font-semibold text-emerald-300 hover:bg-emerald-500/25 disabled:opacity-50"><Check className="h-3 w-3" />Approve</button>
            <button type="button" disabled={busy} onClick={onReject} className="inline-flex items-center gap-1 rounded-md bg-rose-500/10 px-2.5 py-2.5 sm:px-2 sm:py-1 font-semibold text-rose-300 hover:bg-rose-500/20 disabled:opacity-50"><X className="h-3 w-3" />Reject</button>
          </>)}
          {!pending && !archived && !rule.is_core_guardrail && (
            <button type="button" disabled={busy} onClick={onArchive} title="Alisin sa rotation" className="inline-flex items-center gap-1 rounded-md px-2.5 py-2.5 sm:px-2 sm:py-1 text-slate-400 hover:bg-white/[0.06] hover:text-white disabled:opacity-50"><Archive className="h-3 w-3" />Archive</button>
          )}
          {archived && (
            <button type="button" disabled={busy} onClick={onRestore} className="inline-flex items-center gap-1 rounded-md px-2.5 py-2.5 sm:px-2 sm:py-1 text-emerald-300 hover:bg-emerald-500/10 disabled:opacity-50"><ArchiveRestore className="h-3 w-3" />Restore</button>
          )}
          {(archived || rule.is_core_guardrail) && (
            <button type="button" disabled={busy} onClick={onDelete} title="Burahin" className="inline-flex items-center rounded-md p-2.5 sm:p-1 text-slate-500 hover:bg-rose-500/10 hover:text-rose-300 disabled:opacity-50"><Trash2 className="h-3.5 w-3.5" /></button>
          )}
        </span>
      </div>
    </div>
  );
}

function LearningCurve({ logs }: { logs: ActionLog[] }) {
  const days = useMemo(() => {
    const out: { label: string; avg: number | null; n: number }[] = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - i);
      const next = d.getTime() + 86_400_000;
      const rows = logs.filter((l) => l.action_type !== 'invite' && new Date(l.created_at).getTime() >= d.getTime() && new Date(l.created_at).getTime() < next);
      out.push({ label: d.toLocaleDateString([], { weekday: 'short' }), avg: rows.length ? rows.reduce((s, r) => s + num(r.performance_score), 0) / rows.length : null, n: rows.length });
    }
    return out;
  }, [logs]);
  const any = days.some((d) => d.avg !== null);
  return (
    <div>
      <div className="flex h-28 items-end gap-2">
        {days.map((d) => (
          <div key={d.label} className="flex h-full flex-1 flex-col items-center justify-end gap-1" title={d.avg === null ? 'Walang data' : `${Math.round(d.avg)} avg · ${d.n} actions`}>
            <div className="flex w-full flex-1 items-end">
              <div className="w-full rounded-t-md transition-all duration-700" style={{ height: d.avg === null ? '4%' : `${Math.max(6, d.avg)}%`, background: d.avg === null ? 'rgba(255,255,255,0.06)' : 'linear-gradient(180deg,#a78bfa,#34d399)' }} />
            </div>
            <span className="text-[10px] text-slate-500">{d.label}</span>
          </div>
        ))}
      </div>
      {!any && <p className="mt-2 text-center text-[11px] text-slate-500">Wala pang resulta. Lalabas dito kapag may na-score na post o reply.</p>}
    </div>
  );
}

export default function SharedBrain() {
  const b = useBrain();
  const [tab, setTab] = useState<Tab>('learned');
  const [mapView, setMapView] = useState<'3d' | '2d'>(() => {
    try { return localStorage.getItem(MAP_VIEW_KEY) === '2d' ? '2d' : '3d'; } catch { return '3d'; }
  });
  const [map3dFailed, setMap3dFailed] = useState(false);
  const pickView = (v: '3d' | '2d') => {
    setMapView(v);
    try { localStorage.setItem(MAP_VIEW_KEY, v); } catch { /* private mode */ }
  };
  const on3dFail = useCallback(() => { setMap3dFailed(true); setMapView('2d'); }, []);
  const [cat, setCat] = useState('all');
  const [platform, setPlatform] = useState('all');
  const [sort, setSort] = useState('confidence');
  const [q, setQ] = useState('');
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState<{ tone: 'ok' | 'err'; text: string } | null>(null);
  const [adding, setAdding] = useState(false);
  const [form, setForm] = useState({ category: 'winning_hook', platform: 'all', title: '', insight_rule: '', core: false });

  const botById = useMemo(() => Object.fromEntries(b.bots.map((x) => [x.id, x])), [b.bots]);
  const ruleById = useMemo(() => Object.fromEntries(b.rules.map((x) => [x.id, x])), [b.rules]);

  const counts = useMemo(() => {
    const learned = b.rules.filter((r) => r.status === 'approved' && !r.is_core_guardrail);
    const dayAgo = Date.now() - 86_400_000;
    return {
      learned: learned.length,
      core: b.rules.filter((r) => r.is_core_guardrail && r.status === 'approved').length,
      review: b.rules.filter((r) => r.status === 'pending_review').length,
      archived: b.rules.filter((r) => r.status === 'deprecated').length,
      avg: learned.length ? Math.round((learned.reduce((s, r) => s + num(r.confidence_score), 0) / learned.length) * 100) : 0,
      applied: b.rules.reduce((s, r) => s + num(r.usage_count), 0),
      today: b.events.filter((e) => new Date(e.created_at).getTime() > dayAgo).length,
    };
  }, [b.rules, b.events]);

  const shown = useMemo(() => {
    const needle = q.trim().toLowerCase();
    const list = b.rules.filter((r) => {
      if (tab === 'learned' && !(r.status === 'approved' && !r.is_core_guardrail)) return false;
      if (tab === 'core' && !(r.is_core_guardrail && r.status === 'approved')) return false;
      if (tab === 'review' && r.status !== 'pending_review') return false;
      if (tab === 'archived' && r.status !== 'deprecated') return false;
      if (cat !== 'all' && r.category !== cat) return false;
      if (platform !== 'all' && r.platform !== platform && r.platform !== 'all') return false;
      if (needle && !`${r.title} ${r.insight_rule}`.toLowerCase().includes(needle)) return false;
      return true;
    });
    return list.sort((x, y) =>
      sort === 'newest' ? +new Date(y.created_at) - +new Date(x.created_at)
      : sort === 'used' ? y.usage_count - x.usage_count
      : num(y.confidence_score) - num(x.confidence_score));
  }, [b.rules, tab, cat, platform, sort, q]);

  const botStats = useMemo(() => {
    const m: Record<string, { rules: number; actions: number; avg: number | null }> = {};
    for (const bot of b.bots) {
      const mine = b.logs.filter((l) => l.bot_id === bot.id && l.action_type !== 'invite');
      m[bot.id] = {
        rules: b.rules.filter((r) => r.source_bot_id === bot.id && r.status === 'approved').length,
        actions: b.logs.filter((l) => l.bot_id === bot.id).length,
        avg: mine.length ? Math.round(mine.reduce((s, l) => s + num(l.performance_score), 0) / mine.length) : null,
      };
    }
    return m;
  }, [b.bots, b.logs, b.rules]);

  const run = async (fn: () => Promise<unknown>, ok?: string) => {
    setBusy(true); setNote(null);
    try { await fn(); if (ok) setNote({ tone: 'ok', text: ok }); }
    catch (e) { setNote({ tone: 'err', text: (e as Error).message }); }
    finally { setBusy(false); }
  };
  const reflect = () => run(async () => {
    const r = await b.reflect();
    setNote({ tone: r.ok ? 'ok' : 'err', text: r.ok
      ? `Tapos na si Cipher: ${r.pending ?? 0} resulta na-analyze · +${r.new_rules ?? 0} bagong rule · ${r.reinforced ?? 0} pinalakas · ${r.weakened ?? 0} pinahina`
      : r.error ?? 'Hindi natapos ang reflection' });
  });
  const save = () => run(async () => {
    if (form.title.trim().length < 6) throw new Error('Masyadong maikli ang title (min 6 na letra).');
    if (form.insight_rule.trim().length < 20) throw new Error('Masyadong maikli ang rule (min 20 na letra).');
    if (form.insight_rule.length > 400) throw new Error('Max 400 na letra ang rule.');
    await b.addRule(form);
    setForm({ category: 'winning_hook', platform: 'all', title: '', insight_rule: '', core: false });
    setAdding(false);
  }, 'Naidagdag at naibahagi na sa buong team ✅');

  const tabs: { id: Tab; label: string; n: number }[] = [
    { id: 'learned', label: 'Natutunan', n: counts.learned }, { id: 'core', label: 'Guardrails', n: counts.core },
    { id: 'review', label: 'Review', n: counts.review }, { id: 'archived', label: 'Archive', n: counts.archived },
  ];

  if (b.error === 'no-supabase' || (!isSupabaseConfigured && !b.loading)) {
    return <Card><EmptyState icon={<Brain className="h-10 w-10" />} title="Kailangan ng Supabase ang Shared Brain" subtitle="Ilagay ang VITE_SUPABASE_URL at VITE_SUPABASE_ANON_KEY, i-deploy ulit, at i-apply ang migration." /></Card>;
  }
  if (b.error === 'no-migration') {
    return <Card><EmptyState icon={<Brain className="h-10 w-10" />} title="Hindi pa naka-apply ang Shared Brain migration" subtitle="Patakbuhin ang `supabase db push` (file: 20261122000000_idea_lab.sql), tapos i-refresh ang page." /></Card>;
  }

  return (
    <div className="space-y-4">
      {/* hero */}
      <div
        className="relative overflow-hidden rounded-2xl border border-violet-400/20 p-4 sm:p-6"
        style={{ background: 'radial-gradient(600px 220px at 85% -10%, rgba(139,92,246,0.28), transparent 70%), radial-gradient(420px 200px at 0% 110%, rgba(52,211,153,0.16), transparent 70%), linear-gradient(180deg,#171c2b,#121620)' }}
      >
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div className="min-w-0">
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-violet-400/30 to-emerald-400/20 text-violet-200 shadow-[0_0_24px_-4px_rgba(167,139,250,0.7)] ring-1 ring-violet-300/30"><Brain className="h-6 w-6" /></span>
              <div className="min-w-0">
                <h2 className="text-lg font-bold tracking-tight text-white sm:text-xl">Shared Brain</h2>
                <p className="text-xs text-slate-400">Dito inilalagay ng bawat bot ang natutunan nila — binabasa ito ng buong team bago magsulat.</p>
              </div>
            </div>
            <span className={`mt-3 inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] font-semibold ${b.live ? 'border-emerald-400/30 bg-emerald-500/10 text-emerald-300' : 'border-white/10 bg-white/[0.04] text-slate-400'}`}>
              <span className={`h-1.5 w-1.5 rounded-full ${b.live ? 'bg-emerald-400 shadow-[0_0_6px_rgba(52,211,153,0.9)]' : 'bg-slate-500'}`} />
              {b.live ? (b.realtime ? 'Live — realtime' : 'Live — auto refresh') : 'Kumokonekta…'}
            </span>
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Button variant="secondary" disabled={busy} onClick={() => setAdding((v) => !v)}><Plus className="h-4 w-4" />Add rule</Button>
            <Button disabled={busy} onClick={reflect}><RefreshCw className={`h-4 w-4 ${busy ? 'animate-spin' : ''}`} />Reflect now</Button>
          </div>
        </div>
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-white/[0.06] pt-3">
          <Toggle checked={b.autoApprove} onChange={(v) => void run(() => b.setAutoApprove(v))} label="Auto-share ng bagong natutunan (ang Guardrails ay laging dumadaan sa review)" />
        </div>
        {note && (
          <p className={`mt-3 rounded-lg border px-3 py-2 text-xs ${note.tone === 'ok' ? 'border-emerald-400/25 bg-emerald-500/10 text-emerald-200' : 'border-rose-400/25 bg-rose-500/10 text-rose-200'}`}>{note.text}</p>
        )}
      </div>

      {adding && (
        <Card className="p-4 sm:p-5">
          <h3 className="text-sm font-semibold text-white">Magdagdag ng sariling rule</h3>
          <p className="mt-0.5 text-xs text-slate-400">Agad itong babasahin ng lahat ng bot. Ang “Core guardrail” ay hindi mababago ng AI.</p>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <Select label="Category" value={form.category} onChange={(v) => setForm({ ...form, category: v })} options={Object.entries(CATS).map(([value, c]) => ({ value, label: c.label }))} />
            <Select label="Platform" value={form.platform} onChange={(v) => setForm({ ...form, platform: v })} options={[{ value: 'all', label: 'All platforms' }, ...PLATFORMS.map((p) => ({ value: p, label: p }))]} />
            <Input className="sm:col-span-2" label="Title" value={form.title} onChange={(v) => setForm({ ...form, title: v })} placeholder="hal. Max 1 invite bawat user" />
            <TextArea className="sm:col-span-2" label={`Rule (${form.insight_rule.length}/400)`} rows={3} value={form.insight_rule} onChange={(v) => setForm({ ...form, insight_rule: v })} placeholder="Eksaktong instruction na susundin ng mga bot…" />
          </div>
          <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
            <Toggle checked={form.core} onChange={(v) => setForm({ ...form, core: v })} label="Core guardrail (admin-only, laging sinusunod)" />
            <div className="flex gap-2">
              <Button variant="ghost" onClick={() => setAdding(false)}>Cancel</Button>
              <Button disabled={busy} onClick={save}><Zap className="h-4 w-4" />Ibahagi sa team</Button>
            </div>
          </div>
        </Card>
      )}

      {/* stats */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <Stat icon={Brain} label="Natutunan" value={counts.learned} tone="text-violet-300" />
        <Stat icon={ShieldCheck} label="Guardrails" value={counts.core} tone="text-amber-300" />
        <Stat icon={Sparkles} label="Review" value={counts.review} tone="text-sky-300" />
        <Stat icon={TrendingUp} label="Avg confidence" value={`${counts.avg}%`} tone="text-emerald-300" />
        <Stat icon={Zap} label="Beses nagamit" value={counts.applied} tone="text-pink-300" />
        <Stat icon={Radio} label="Naibahagi (24h)" value={counts.today} tone="text-fuchsia-300" />
      </div>

      {/* map + feed */}
      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="overflow-hidden lg:col-span-2">
          <div className="flex items-start justify-between gap-3 border-b border-white/[0.06] px-5 py-3.5">
            <div className="min-w-0">
              <h3 className="text-sm font-semibold text-white">Brain map</h3>
              <p className="text-xs text-slate-400">Bawat bot ay konektado sa iisang utak. Kapag may bagong natutunan, kumakalat ito sa lahat.</p>
            </div>
            <div className="bm-switch shrink-0" role="tablist" aria-label="Brain map view">
              {(['3d', '2d'] as const).map((v) => (
                <button key={v} type="button" role="tab" aria-selected={mapView === v} disabled={v === '3d' && map3dFailed} onClick={() => pickView(v)} className={mapView === v ? 'bm-switch-on' : ''}>
                  {v.toUpperCase()}
                </button>
              ))}
            </div>
          </div>
          <div className="px-2 pt-2 sm:px-4">
            {mapView === '3d' ? (
              <Suspense fallback={<div className="bm3-loading"><span className="bm3-loading-orb" />Ginigising ang utak…</div>}>
                <BrainMap3D bots={b.bots} rules={b.rules} events={b.events} onFail={on3dFail} />
              </Suspense>
            ) : (
              <BrainMap bots={b.bots} rules={b.rules} events={b.events} />
            )}
            {map3dFailed && <p className="mt-1 text-center text-[11px] text-slate-500">Hindi kaya ng device na ito ang 3D (WebGL), kaya 2D ang ipinapakita.</p>}
          </div>
          <div className="grid grid-cols-2 gap-2 p-3 sm:grid-cols-3 sm:p-4 xl:grid-cols-5">
            {b.bots.map((bot) => {
              const st = BOT_STYLE[bot.name] ?? { color: '#94a3b8', emoji: '🤖' }, s = botStats[bot.id];
              return (
                <div key={bot.id} className="rounded-xl border border-white/[0.06] bg-white/[0.03] p-3">
                  <div className="flex items-center gap-2">
                    <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-sm" style={{ background: `${st.color}26` }}>{st.emoji}</span>
                    <div className="min-w-0"><p className="truncate text-xs font-bold" style={{ color: st.color }}>{bot.name}</p><p className="truncate text-[10px] text-slate-500">{bot.role}</p></div>
                  </div>
                  <div className="mt-2 grid grid-cols-3 gap-1 text-center text-[10px] text-slate-500">
                    <span><b className="block text-sm text-white">{s?.rules ?? 0}</b>rules</span>
                    <span><b className="block text-sm text-white">{s?.actions ?? 0}</b>actions</span>
                    <span><b className={`block text-sm ${s?.avg == null ? 'text-slate-500' : scoreColor(s.avg)}`}>{s?.avg ?? '–'}</b>score</span>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>

        <Card className="flex flex-col">
          <div className="flex items-center justify-between border-b border-white/[0.06] px-5 py-3.5">
            <div><h3 className="text-sm font-semibold text-white">Live broadcast</h3><p className="text-xs text-slate-400">Real-time na ipinapasa sa buong office</p></div>
            <Radio className="h-4 w-4 text-violet-300" />
          </div>
          <ul className="max-h-[26rem] flex-1 divide-y divide-white/[0.05] overflow-y-auto">
            {b.events.length === 0 && <li><EmptyState icon={<Radio className="h-8 w-8" />} title="Wala pang naibabahagi" subtitle="Lalabas dito ang bawat bagong natutunan, pinalakas, o inalis na rule." /></li>}
            {b.events.slice(0, 20).map((e) => {
              const rule = e.brain_item_id ? ruleById[e.brain_item_id] : undefined;
              const bot = e.learned_by_bot_id ? botById[e.learned_by_bot_id] : undefined;
              const meta = e.event_type === 'rule_reinforced' ? { icon: TrendingUp, color: 'text-emerald-300', text: 'Pinalakas ang rule' }
                : e.event_type === 'rule_deprecated' ? { icon: Archive, color: 'text-rose-300', text: 'Inalis sa rotation' }
                : { icon: Sparkles, color: 'text-violet-300', text: 'Bagong natutunan' };
              const Icon = meta.icon, fresh = Date.now() - new Date(e.created_at).getTime() < 15_000;
              return (
                <li key={e.id} className={`flex gap-3 px-4 py-3 transition-colors ${fresh ? 'bg-violet-500/10' : ''}`}>
                  <span className={`mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-white/[0.05] ${meta.color}`}><Icon className="h-3.5 w-3.5" /></span>
                  <div className="min-w-0">
                    <p className="text-xs text-slate-300"><b className={meta.color}>{meta.text}</b>{bot ? <> · <span style={{ color: BOT_STYLE[bot.name]?.color }}>{bot.name}</span></> : <> · Admin</>}</p>
                    <p className="mt-0.5 line-clamp-2 text-[13px] font-medium text-white">{rule?.title ?? '(naburang rule)'}</p>
                    <p className="mt-0.5 text-[10px] text-slate-500">{timeAgo(e.created_at)}</p>
                  </div>
                </li>
              );
            })}
          </ul>
        </Card>
      </div>

      {/* knowledge board */}
      <Card>
        <div className="space-y-3 border-b border-white/[0.06] px-4 py-4 sm:px-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div><h3 className="text-sm font-semibold text-white">Knowledge board</h3><p className="text-xs text-slate-400">Lahat ng natutunan ng team — {b.rules.length} kabuuan</p></div>
            <div className="no-scrollbar flex max-w-full gap-1 overflow-x-auto rounded-xl bg-white/[0.04] p-1">
              {tabs.map((t) => (
                <button key={t.id} type="button" onClick={() => setTab(t.id)} className={`flex shrink-0 items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${tab === t.id ? 'bg-violet-500/20 text-violet-200' : 'text-slate-400 hover:text-white'}`}>
                  {t.label}<span className={`rounded-full px-1.5 text-[10px] ${t.id === 'review' && t.n > 0 ? 'bg-sky-500/25 text-sky-200' : 'bg-white/[0.07] text-slate-400'}`}>{t.n}</span>
                </button>
              ))}
            </div>
          </div>
          <div className="grid gap-2 sm:grid-cols-[1fr_9rem_9rem]">
            <label className="relative block">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-500" />
              <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Maghanap sa natutunan…" className="w-full rounded-lg border border-white/[0.08] bg-white/[0.03] py-2 pl-9 pr-3 text-sm text-white placeholder-slate-500 outline-none focus:border-violet-400/50" />
            </label>
            <Select value={platform} onChange={setPlatform} options={[{ value: 'all', label: 'Lahat ng platform' }, ...PLATFORMS.map((p) => ({ value: p, label: p }))]} />
            <Select value={sort} onChange={setSort} options={[{ value: 'confidence', label: 'Pinakamataas na confidence' }, { value: 'newest', label: 'Pinakabago' }, { value: 'used', label: 'Pinakamadalas gamitin' }]} />
          </div>
          <div className="no-scrollbar -mx-1 flex gap-1.5 overflow-x-auto px-1">
            {['all', ...Object.keys(CATS)].map((c) => {
              const m = c === 'all' ? null : catOf(c), Icon = m?.icon ?? Brain, on = cat === c;
              return (
                <button key={c} type="button" onClick={() => setCat(c)} className={`flex shrink-0 items-center gap-1.5 rounded-full border px-3 py-1 text-[11px] font-medium transition-colors ${on ? (m?.chip ?? 'border-violet-400/30 bg-violet-500/15 text-violet-200') : 'border-white/[0.08] text-slate-400 hover:text-white'}`}>
                  <Icon className="h-3 w-3" />{m?.label ?? 'Lahat'}
                </button>
              );
            })}
          </div>
        </div>
        <div className="p-3 sm:p-4">
          {b.loading ? (
            <div className="flex justify-center py-12"><span className="office-spinner" /></div>
          ) : shown.length === 0 ? (
            <EmptyState icon={<Brain className="h-10 w-10" />}
              title={tab === 'review' ? 'Walang naghihintay ng review' : tab === 'learned' ? 'Wala pang natutunan ang team' : 'Walang laman dito'}
              subtitle={tab === 'learned' ? 'Habang nagpo-post at sumasagot ang mga bot, susukatin ni Cipher ang resulta at ilalagay dito ang mga aral. Pindutin ang “Reflect now” para pabilisin.' : undefined} />
          ) : (
            <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
              {shown.map((r) => (
                <RuleCard key={r.id} rule={r} busy={busy} flashing={b.flash.has(r.id)} bot={r.source_bot_id ? botById[r.source_bot_id] : undefined}
                  onApprove={() => void run(() => b.setStatus(r, 'approved'), 'Naaprubahan at naibahagi na sa team ✅')}
                  onReject={() => void run(() => b.setStatus(r, 'deprecated'))}
                  onRestore={() => void run(() => b.setStatus(r, 'approved'))}
                  onArchive={() => void run(() => b.setStatus(r, 'deprecated'))}
                  onDelete={() => { if (window.confirm(r.is_core_guardrail ? 'Burahin ang admin guardrail na ito?' : 'Burahin nang tuluyan ang rule na ito?')) void run(() => b.remove(r)); }} />
              ))}
            </div>
          )}
        </div>
      </Card>

      {/* learning curve */}
      <Card className="p-4 sm:p-5">
        <div className="mb-3 flex flex-wrap items-end justify-between gap-2">
          <div><h3 className="text-sm font-semibold text-white">Learning curve</h3><p className="text-xs text-slate-400">Average score ng posts at replies, huling 7 araw — tumataas ba ang resulta habang natututo ang team?</p></div>
          <span className="text-[11px] text-slate-500">{b.logs.filter((l) => l.action_type !== 'invite').length} na-score na action</span>
        </div>
        <LearningCurve logs={b.logs} />
      </Card>
    </div>
  );
}
