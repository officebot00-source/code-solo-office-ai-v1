import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { AlertTriangle, CalendarClock, CheckCircle2, Clock, Plus, Repeat, Send, Trash2 } from 'lucide-react';
import { DAILY_TIMEZONES, DEFAULT_DAILY_SETTINGS, EMPTY_DAILY_STATUS, MAX_SLOTS, isValidTime, nextRuns, type DailySettings, type DailySlot, type DailyStatus } from '@/lib/app/daily';
import { dailyApi } from '@/lib/app/dailyApi';
import { db } from '@/lib/app/db';
import { isSupabaseConfigured } from '@/lib/app/supabase';
import { PLATFORMS, TONES, type Game, type Platform, type Tone } from '@/lib/app/types';
import { Badge, Button, Card, Select, Toggle } from './ui-kit';

const QUICK_TIMES = ['09:00', '12:00', '18:00', '20:00', '21:00'];
const chip = (on: boolean) =>
  `inline-flex min-h-10 items-center rounded-full border px-3.5 text-xs font-medium transition-colors active:scale-[0.97] ${
    on ? 'border-emerald-400/40 bg-emerald-500/15 text-emerald-300' : 'border-white/[0.1] bg-white/[0.03] text-slate-400'
  }`;

const sameSettings = (a: DailySettings, b: DailySettings) => JSON.stringify(a) === JSON.stringify(b);

function fmtRun(d: Date, tz: string): string {
  try {
    return d.toLocaleString([], { weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', timeZone: tz });
  } catch {
    return d.toLocaleString();
  }
}

export default function DailyAutoPost() {
  const [saved, setSaved] = useState<DailySettings>(DEFAULT_DAILY_SETTINGS);
  const [draft, setDraft] = useState<DailySettings>(DEFAULT_DAILY_SETTINGS);
  const [status, setStatus] = useState<DailyStatus>(EMPTY_DAILY_STATUS);
  const [connected, setConnected] = useState<string[]>([]);
  const [games, setGames] = useState<Game[]>([]);
  const [loading, setLoading] = useState(isSupabaseConfigured);
  const [busy, setBusy] = useState<'save' | 'toggle' | 'test' | null>(null);
  const [error, setError] = useState('');
  const [note, setNote] = useState('');

  const savedRef = useRef<DailySettings>(DEFAULT_DAILY_SETTINGS);
  const applySaved = useCallback((s: DailySettings) => { savedRef.current = s; setSaved(s); }, []);

  const load = useCallback(async () => {
    if (!isSupabaseConfigured) return;
    try {
      const o = await dailyApi.overview();
      // keep what the user is editing: only follow the server when there are no unsaved changes
      setDraft((cur) => (sameSettings(cur, savedRef.current) ? o.settings : cur));
      applySaved(o.settings);
      setStatus(o.status);
      setConnected(o.connected);
      setError('');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load the daily schedule');
    } finally {
      setLoading(false);
    }
  }, [applySaved]);

  useEffect(() => {
    void load();
    db.listGames().then(setGames).catch(() => undefined);
    const t = window.setInterval(() => { if (!document.hidden) void load(); }, 30000);
    return () => window.clearInterval(t);
  }, [load]);

  const dirty = !sameSettings(draft, saved);
  const patch = (p: Partial<DailySettings>) => { setDraft((d) => ({ ...d, ...p })); setNote(''); };
  const setSlot = (id: string, p: Partial<DailySlot>) => patch({ slots: draft.slots.map((s) => (s.id === id ? { ...s, ...p } : s)) });

  const addSlot = (time: string) => {
    if (!isValidTime(time) || draft.slots.length >= MAX_SLOTS || draft.slots.some((s) => s.time === time)) return;
    let n = 1;
    while (draft.slots.some((s) => s.id === `s${n}`)) n++;
    patch({ slots: [...draft.slots, { id: `s${n}`, time, platforms: [] }].sort((a, b) => a.time.localeCompare(b.time)) });
  };
  const togglePlatform = (slot: DailySlot, p: Platform) =>
    setSlot(slot.id, { platforms: slot.platforms.includes(p) ? slot.platforms.filter((x) => x !== p) : [...slot.platforms, p] });
  const toggleGame = (id: string) =>
    patch({ game_ids: draft.game_ids.includes(id) ? draft.game_ids.filter((g) => g !== id) : [...draft.game_ids, id] });

  const persist = async (next: DailySettings, kind: 'save' | 'toggle') => {
    setBusy(kind);
    setError('');
    try {
      const s = await dailyApi.save(next);
      applySaved(s);
      setDraft(s);
      setNote(s.enabled ? 'Naka-save na. Awtomatiko nang magpo-post araw-araw.' : 'Naka-save. Naka-off ang daily auto-post.');
      void db.log('info', 'scheduler', s.enabled ? 'Daily auto-post turned ON' : 'Daily auto-post turned OFF');
      void load();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Hindi na-save');
    } finally {
      setBusy(null);
    }
  };

  const onToggle = (enabled: boolean) => {
    if (enabled && !draft.slots.length) { setError('Magdagdag muna ng kahit isang oras ng pag-post.'); return; }
    void persist({ ...draft, enabled }, 'toggle');
  };

  const testNow = async () => {
    if (!window.confirm('Magpo-post ito nang TOTOO sa mga connected na social account (sa loob ng ~1 minuto). Ituloy?')) return;
    setBusy('test');
    setError('');
    setNote('');
    try {
      const r = await dailyApi.runNow(draft.slots[0]?.id);
      if (r.queued) setNote(`Naka-queue: ${r.items[0]?.game ?? 'post'} → ${(r.items[0]?.platforms ?? []).join(', ')}. Lalabas ito sa Post Queue.`);
      else setError(r.items[0]?.note ?? r.error ?? 'Walang na-queue.');
      void load();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Hindi na-queue ang test post');
    } finally {
      setBusy(null);
    }
  };

  const upcoming = useMemo(() => nextRuns(saved, new Date(), 3), [saved]);
  const noPlatforms = isSupabaseConfigured && !loading && connected.length === 0;

  return (
    <Card className="overflow-hidden">
      <div className="flex items-start justify-between gap-3 p-4 sm:p-5">
        <div className="flex min-w-0 items-start gap-3">
          <span className={`mt-0.5 shrink-0 rounded-lg p-2.5 ${saved.enabled ? 'bg-sky-500/10 text-sky-300' : 'bg-white/[0.06] text-slate-500'}`}>
            <Repeat className="h-5 w-5" />
          </span>
          <div className="min-w-0">
            <h3 className="text-sm font-semibold text-white">Daily Auto-Post</h3>
            <p className="mt-0.5 text-xs leading-relaxed text-slate-400">
              {saved.enabled
                ? 'Awtomatikong nagpo-post araw-araw sa mga oras na pinili mo. Hindi mo na kailangang mag-schedule.'
                : 'I-on para may bagong post araw-araw sa piniling oras — hindi na manual na schedule.'}
            </p>
          </div>
        </div>
        <div className="shrink-0 pt-1">
          <Toggle checked={draft.enabled} onChange={onToggle} label={busy === 'toggle' ? '…' : draft.enabled ? 'On' : 'Off'} />
        </div>
      </div>

      {!isSupabaseConfigured ? (
        <p className="border-t border-white/[0.06] px-4 py-4 text-xs text-amber-300 sm:px-5">
          Kailangan ang server connection (Supabase) para sa awtomatikong daily posting — ang Local mode ay hindi makakapag-post kapag sarado ang browser.
        </p>
      ) : (
        <div className="space-y-5 border-t border-white/[0.06] p-4 sm:p-5">
          {noPlatforms && (
            <div className="flex items-start gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 px-3 py-2.5 text-xs text-amber-200">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              Wala pang naka-connect na social account. I-save ang Facebook / X / Discord / Telegram credentials sa API Settings para may mapag-postan.
            </div>
          )}

          {/* times */}
          <section>
            <h4 className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wide text-slate-400"><Clock className="h-3.5 w-3.5" /> Oras ng pag-post</h4>
            {draft.slots.length === 0 && <p className="mt-2 text-xs text-slate-500">Wala pang oras. Pumili sa ibaba o magdagdag.</p>}
            <ul className="mt-3 space-y-3">
              {draft.slots.map((s) => (
                <li key={s.id} className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-3">
                  <div className="flex items-center gap-2">
                    <input
                      type="time"
                      value={s.time}
                      aria-label="Oras ng pag-post"
                      onChange={(e) => {
                        const v = e.target.value;
                        if (isValidTime(v) && !draft.slots.some((x) => x.id !== s.id && x.time === v)) setSlot(s.id, { time: v });
                      }}
                      className="min-h-11 w-36 rounded-lg border border-white/[0.08] bg-white/[0.04] px-3 text-base text-white outline-none focus:border-emerald-500/50"
                    />
                    <span className="min-w-0 flex-1 truncate text-xs text-slate-500">
                      {s.platforms.length ? s.platforms.map((p) => PLATFORMS.find((x) => x.id === p)?.label ?? p).join(' · ') : 'Lahat ng connected'}
                    </span>
                    <Button variant="ghost" className="!p-2" onClick={() => patch({ slots: draft.slots.filter((x) => x.id !== s.id) })} aria-label="Alisin ang oras">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="no-scrollbar -mx-1 mt-2.5 flex gap-2 overflow-x-auto px-1 pb-0.5">
                    <button type="button" className={chip(s.platforms.length === 0)} onClick={() => setSlot(s.id, { platforms: [] })}>Lahat</button>
                    {PLATFORMS.map((p) => (
                      <button key={p.id} type="button" className={`${chip(s.platforms.includes(p.id))} shrink-0 ${connected.length && !connected.includes(p.id) ? 'opacity-50' : ''}`} onClick={() => togglePlatform(s, p.id)}>
                        {p.label}
                      </button>
                    ))}
                  </div>
                </li>
              ))}
            </ul>
            {draft.slots.length < MAX_SLOTS && (
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <span className="text-xs text-slate-500">Dagdag:</span>
                {QUICK_TIMES.filter((t) => !draft.slots.some((s) => s.time === t)).map((t) => (
                  <button key={t} type="button" className={chip(false)} onClick={() => addSlot(t)}><Plus className="mr-1 h-3 w-3" />{t}</button>
                ))}
              </div>
            )}
          </section>

          {/* options */}
          <section className="grid gap-4 sm:grid-cols-2">
            <Select label="Time zone" value={draft.timezone} onChange={(v) => patch({ timezone: v })} options={DAILY_TIMEZONES} />
            <Select label="Tono ng post" value={draft.tone} onChange={(v) => patch({ tone: v as Tone })} options={TONES.map((t) => ({ value: t.id, label: t.label }))} />
          </section>

          <section>
            <h4 className="text-xs font-semibold uppercase tracking-wide text-slate-400">Anong game ang ipo-post</h4>
            <p className="mt-1 text-xs text-slate-500">
              {draft.game_ids.length ? `Papalit-palit sa ${draft.game_ids.length} piniling game.` : 'Papalit-palit sa lahat ng active game (iba bawat araw).'}
            </p>
            <div className="no-scrollbar -mx-1 mt-2.5 flex flex-wrap gap-2 px-1">
              <button type="button" className={chip(draft.game_ids.length === 0)} onClick={() => patch({ game_ids: [] })}>Lahat ng active</button>
              {games.filter((g) => g.active).map((g) => (
                <button key={g.id} type="button" className={chip(draft.game_ids.includes(g.id))} onClick={() => toggleGame(g.id)}>{g.title}</button>
              ))}
            </div>
            {games.length === 0 && <p className="mt-2 text-xs text-amber-300/80">Magdagdag ng game sa Game Profiles para may maipo-post.</p>}
          </section>

          <Toggle checked={draft.use_ai} onChange={(v) => patch({ use_ai: v })} label={draft.use_ai ? 'AI ang magsusulat ng post (may template kapag walang AI)' : 'Template lang (walang AI)'} />

          {/* preview + status */}
          <section className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-3 text-xs">
            <h4 className="flex items-center gap-2 font-semibold text-slate-300"><CalendarClock className="h-3.5 w-3.5 text-sky-400" /> Susunod na post</h4>
            {saved.enabled && upcoming.length ? (
              <ul className="mt-2 space-y-1 text-slate-400">
                {upcoming.map((u, i) => (
                  <li key={i} className="flex items-center justify-between gap-2">
                    <span>{fmtRun(u.runAt, saved.timezone)}</span>
                    <span className="truncate text-slate-500">{u.slot.platforms.length ? u.slot.platforms.join(', ') : 'lahat'}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="mt-2 text-slate-500">{saved.enabled ? 'Magdagdag ng oras para magsimula.' : 'Naka-off ang daily auto-post.'}</p>
            )}
            {status.last_queued && (
              <p className="mt-3 flex items-start gap-1.5 text-slate-400">
                <CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-400" />
                Huling na-queue: {status.last_queued.game_title} → {status.last_queued.platforms.join(', ')}
              </p>
            )}
            {status.last_error && (
              <p className="mt-2 flex items-start gap-1.5 break-words text-red-300"><AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />{status.last_error}</p>
            )}
            <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
              Kung bumagsak ang server, magpo-post pa rin hanggang 30 minuto pagkalampas ng oras. Kapag mas late pa, laktawan ito at tuloy sa susunod.
            </p>
          </section>

          {error && <div role="alert" className="rounded-lg border border-red-500/30 bg-red-500/10 px-3 py-2 text-sm text-red-300">{error}</div>}
          {note && <div role="status" className="rounded-lg border border-emerald-500/30 bg-emerald-500/10 px-3 py-2 text-sm text-emerald-300">{note}</div>}

          <div className="flex flex-col gap-2 sm:flex-row sm:justify-end">
            <Button variant="secondary" disabled={busy !== null || !draft.slots.length || noPlatforms} onClick={() => void testNow()} className="w-full sm:w-auto">
              <Send className="h-4 w-4" /> {busy === 'test' ? 'Nagku-queue…' : 'Mag-post ng test ngayon'}
            </Button>
            <Button disabled={busy !== null || !dirty} onClick={() => void persist(draft, 'save')} className="w-full sm:w-auto">
              {busy === 'save' ? 'Sine-save…' : dirty ? 'I-save ang pagbabago' : 'Naka-save'}
            </Button>
          </div>
          {saved.enabled && <div className="flex justify-center"><Badge tone="green">Aktibo · {saved.slots.length} post bawat araw</Badge></div>}
        </div>
      )}
    </Card>
  );
}
