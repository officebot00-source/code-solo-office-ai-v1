import { memo, useEffect, useMemo, useRef, useState } from 'react';
import { Activity, Radio, Timer } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import type { BotLog, LogLevel } from '@/lib/app/types';

/* ------------------------------------------------------------------ */
/* helpers                                                             */
/* ------------------------------------------------------------------ */

const prefersReducedMotion = () =>
  typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

/** Smoothly counts from the previous value to the new one (ease-out). Falls back to the plain number if motion is reduced. */
export function useCountUp(target: number, duration = 900) {
  const [value, setValue] = useState(0);
  const from = useRef(0);
  useEffect(() => {
    if (prefersReducedMotion()) {
      setValue(target);
      from.current = target;
      return;
    }
    const start = performance.now();
    const origin = from.current;
    let raf = 0;
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      const next = origin + (target - origin) * eased;
      setValue(next);
      from.current = next;
      if (t < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return value;
}

/** Re-render once per `ms` (used by the clock and countdowns, never faster than 1s). */
function useNow(ms = 1000) {
  const [now, setNow] = useState(() => Date.now());
  useEffect(() => {
    const t = window.setInterval(() => setNow(Date.now()), ms);
    return () => window.clearInterval(t);
  }, [ms]);
  return now;
}

/* ------------------------------------------------------------------ */
/* Live hero banner: greeting + clock + autopilot state               */
/* ------------------------------------------------------------------ */

function greeting(h: number) {
  if (h < 5) return 'Gising ka pa, Boss';
  if (h < 12) return 'Magandang umaga, Boss';
  if (h < 18) return 'Magandang hapon, Boss';
  return 'Magandang gabi, Boss';
}

export function LiveHero({ autoPilot, eventsPerMin, activeGames }: { autoPilot: boolean; eventsPerMin: number; activeGames: number }) {
  const now = useNow(1000);
  const d = new Date(now);
  const time = d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  const date = d.toLocaleDateString([], { weekday: 'long', month: 'long', day: 'numeric' });

  return (
    <div className="dash-hero fade-up relative overflow-hidden rounded-2xl border border-emerald-400/20 p-4 sm:p-6">
      <div className="dash-orb dash-orb-a" aria-hidden="true" />
      <div className="dash-orb dash-orb-b" aria-hidden="true" />
      <div className="dash-grid-bg" aria-hidden="true" />
      <div className="relative flex flex-wrap items-center justify-between gap-4">
        <div className="min-w-0">
          <p className="text-[11px] font-semibold uppercase tracking-[0.18em] text-emerald-300/80">Command Center</p>
          <h2 className="dash-shimmer-text mt-1 text-xl font-extrabold tracking-tight sm:text-2xl">{greeting(d.getHours())}</h2>
          <p className="mt-1 text-xs text-slate-400 sm:text-sm">{date}</p>
          <div className="mt-3 flex flex-wrap items-center gap-2">
            <span
              className={`inline-flex items-center gap-2 rounded-full border px-3 py-1 text-[11px] font-semibold ${
                autoPilot ? 'border-emerald-400/30 bg-emerald-500/10 text-emerald-300' : 'border-white/10 bg-white/[0.04] text-slate-400'
              }`}
            >
              <span className="relative flex h-2 w-2">
                {autoPilot && <span className="dash-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400" />}
                <span className={`relative inline-flex h-2 w-2 rounded-full ${autoPilot ? 'bg-emerald-400' : 'bg-slate-500'}`} />
              </span>
              {autoPilot ? 'Auto-Pilot RUNNING 24/7' : 'Auto-Pilot OFF'}
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-sky-400/25 bg-sky-500/10 px-3 py-1 text-[11px] font-semibold text-sky-300">
              <Radio className="h-3 w-3" /> {eventsPerMin.toFixed(1)} events/min
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-fuchsia-400/25 bg-fuchsia-500/10 px-3 py-1 text-[11px] font-semibold text-fuchsia-300">
              {activeGames} active game{activeGames === 1 ? '' : 's'}
            </span>
          </div>
        </div>
        <div className="text-right">
          <p className="font-mono text-3xl font-bold tabular-nums tracking-tight text-white sm:text-4xl" aria-label="Current time">
            {time}
          </p>
          <p className="mt-1 text-[11px] text-slate-500">local time</p>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Animated stat card: count-up number + sparkline + glowing icon    */
/* ------------------------------------------------------------------ */

function Sparkline({ data, stroke, fillId }: { data: number[]; stroke: string; fillId: string }) {
  const pts = data.length > 1 ? data : [0, 0];
  const max = Math.max(1, ...pts);
  const w = 100;
  const h = 28;
  const x = (i: number) => (i / (pts.length - 1)) * w;
  const y = (v: number) => h - 3 - (v / max) * (h - 8);
  const line = pts.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(v).toFixed(1)}`).join(' ');
  const area = `${line} L${w},${h} L0,${h} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} preserveAspectRatio="none" className="h-7 w-full" aria-hidden="true">
      <defs>
        <linearGradient id={fillId} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor={stroke} stopOpacity="0.35" />
          <stop offset="100%" stopColor={stroke} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#${fillId})`} />
      <path d={line} fill="none" stroke={stroke} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" vectorEffect="non-scaling-stroke" className="dash-draw" pathLength={1} />
    </svg>
  );
}

export interface LiveStatProps {
  label: string;
  value: number;
  suffix?: string;
  decimals?: number;
  sub: string;
  icon: LucideIcon;
  /** tailwind classes for the icon bubble */
  accent: string;
  /** hex colour for the sparkline + glow */
  color: string;
  spark: number[];
  delay?: number;
}

export const LiveStatCard = memo(function LiveStatCard({ label, value, suffix = '', decimals = 0, sub, icon: Icon, accent, color, spark, delay = 0 }: LiveStatProps) {
  const shown = useCountUp(value);
  const id = useMemo(() => `spark-${label.replace(/[^a-z0-9]/gi, '').toLowerCase()}`, [label]);
  return (
    <div
      className="dash-stat surface fade-up group relative overflow-hidden rounded-2xl p-4 sm:rounded-xl sm:p-5"
      style={{ animationDelay: `${delay}ms`, ['--stat-color' as string]: color }}
    >
      <span className="dash-stat-glow" aria-hidden="true" />
      <div className="relative flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="text-[11px] font-medium leading-tight text-slate-400 sm:text-xs">{label}</p>
          <p className="mt-1.5 text-2xl font-bold tabular-nums tracking-tight text-white sm:mt-2 sm:text-3xl">
            {shown.toFixed(decimals)}
            {suffix}
          </p>
          <p className="mt-1 text-xs text-slate-500">{sub}</p>
        </div>
        <span className={`dash-icon-pulse shrink-0 rounded-lg p-2 sm:p-2.5 ${accent}`}>
          <Icon className="h-4 w-4 sm:h-5 sm:w-5" />
        </span>
      </div>
      <div className="relative mt-3">
        <Sparkline data={spark} stroke={color} fillId={id} />
      </div>
    </div>
  );
});

/* ------------------------------------------------------------------ */
/* Live activity chart: events per minute for the last 30 minutes     */
/* ------------------------------------------------------------------ */

const BUCKETS = 30;

function bucketLogs(logs: BotLog[], now: number) {
  const buckets = Array.from({ length: BUCKETS }, () => ({ total: 0, bad: 0 }));
  for (const l of logs) {
    const age = Math.floor((now - new Date(l.created_at).getTime()) / 60000);
    if (age < 0 || age >= BUCKETS) continue;
    const slot = buckets[BUCKETS - 1 - age];
    if (!slot) continue;
    slot.total += 1;
    if (l.level === 'error' || l.level === 'warning') slot.bad += 1;
  }
  return buckets;
}

export function LiveActivityChart({ logs }: { logs: BotLog[] }) {
  const now = useNow(15000);
  const buckets = useMemo(() => bucketLogs(logs, now), [logs, now]);
  const max = Math.max(3, ...buckets.map((b) => b.total));
  const total = buckets.reduce((s, b) => s + b.total, 0);

  return (
    <div className="surface fade-up rounded-2xl p-4 sm:rounded-xl sm:p-5">
      <div className="flex items-center justify-between gap-2">
        <h3 className="flex items-center gap-2 text-sm font-semibold text-white">
          <Activity className="h-4 w-4 text-emerald-400" /> Live Bot Activity
        </h3>
        <span className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-400">
          <span className="relative flex h-2 w-2">
            <span className="dash-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400" />
            <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
          </span>
          LIVE
        </span>
      </div>
      <p className="mt-0.5 text-xs text-slate-500">Events kada minuto · huling {BUCKETS} min · {total} total</p>

      <div className="relative mt-4 flex h-28 items-end gap-[3px] sm:h-32" role="img" aria-label="Bot events per minute">
        <div className="dash-scan" aria-hidden="true" />
        {buckets.map((b, i) => {
          const pct = b.total === 0 ? 3 : Math.max(8, (b.total / max) * 100);
          const hasBad = b.bad > 0;
          const isNow = i === BUCKETS - 1;
          return (
            <div key={i} className="relative flex h-full flex-1 items-end">
              <div
                className={`dash-bar w-full rounded-t-[3px] ${
                  b.total === 0
                    ? 'bg-white/[0.06]'
                    : hasBad
                      ? 'bg-gradient-to-t from-amber-500/60 to-amber-300'
                      : 'bg-gradient-to-t from-emerald-500/50 to-emerald-300'
                } ${isNow ? 'dash-bar-now' : ''}`}
                style={{ height: `${pct}%`, animationDelay: `${i * 18}ms` }}
                title={`${b.total} event${b.total === 1 ? '' : 's'}`}
              />
            </div>
          );
        })}
      </div>
      <div className="mt-2 flex justify-between text-[10px] text-slate-600">
        <span>-{BUCKETS}m</span>
        <span>-{Math.round(BUCKETS / 2)}m</span>
        <span>now</span>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Heartbeat / EKG line (CSS-only; nothing re-renders)               */
/* ------------------------------------------------------------------ */

export function Heartbeat({ active }: { active: boolean }) {
  return (
    <div className="relative h-12 overflow-hidden rounded-lg bg-white/[0.03]" aria-hidden="true">
      <svg viewBox="0 0 200 40" preserveAspectRatio="none" className="absolute inset-0 h-full w-full">
        <path
          d="M0,20 L40,20 L48,20 L54,6 L60,34 L66,12 L72,20 L110,20 L118,20 L124,6 L130,34 L136,12 L142,20 L200,20"
          fill="none"
          stroke={active ? '#34d399' : '#64748b'}
          strokeWidth="1.6"
          strokeLinecap="round"
          strokeLinejoin="round"
          vectorEffect="non-scaling-stroke"
          className={active ? 'dash-ekg' : ''}
          pathLength={1}
          opacity={active ? 1 : 0.5}
        />
      </svg>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Live ticker: newest log lines slide in                             */
/* ------------------------------------------------------------------ */

const LEVEL_DOT: Record<LogLevel, string> = {
  info: 'bg-sky-400',
  success: 'bg-emerald-400',
  warning: 'bg-amber-400',
  error: 'bg-red-400',
};

export function LiveTicker({ logs }: { logs: BotLog[] }) {
  const latest = logs.slice(0, 4);
  return (
    <div className="space-y-1.5">
      {latest.length === 0 ? (
        <p className="rounded-lg bg-white/[0.03] px-3 py-2.5 text-xs text-slate-500">Naghihintay ng bot activity…</p>
      ) : (
        latest.map((l, i) => (
          <div
            key={l.id}
            className="dash-slide-in flex items-start gap-2 rounded-lg bg-white/[0.03] px-3 py-2 text-xs"
            style={{ opacity: 1 - i * 0.14 }}
          >
            <span className={`mt-1 h-1.5 w-1.5 shrink-0 rounded-full ${LEVEL_DOT[l.level]}`} />
            <span className="min-w-0 flex-1 truncate text-slate-300">{l.message}</span>
            <span className="shrink-0 font-mono text-[10px] text-slate-600">
              {new Date(l.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        ))
      )}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Countdown to the next scheduled post                               */
/* ------------------------------------------------------------------ */

function fmtCountdown(ms: number) {
  if (ms <= 0) return 'Ngayon na!';
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (d > 0) return `${d}d ${h}h ${m}m`;
  if (h > 0) return `${h}h ${m}m ${String(sec).padStart(2, '0')}s`;
  return `${m}m ${String(sec).padStart(2, '0')}s`;
}

export function NextPostCountdown({ scheduledAt, title }: { scheduledAt: string | null; title?: string }) {
  const now = useNow(1000);
  if (!scheduledAt) {
    return (
      <div className="rounded-xl border border-white/[0.06] bg-white/[0.03] px-3 py-3 text-xs text-slate-500">
        Walang naka-schedule na post.
      </div>
    );
  }
  const diff = new Date(scheduledAt).getTime() - now;
  return (
    <div className="dash-countdown relative overflow-hidden rounded-xl border border-sky-400/20 px-3 py-3">
      <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-wide text-sky-300">
        <Timer className="h-3.5 w-3.5" /> Next post in
      </div>
      <p className="mt-1 font-mono text-xl font-bold tabular-nums text-white sm:text-2xl">{fmtCountdown(diff)}</p>
      {title && <p className="mt-0.5 truncate text-xs text-slate-400">{title}</p>}
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* data helpers used by Dashboard                                     */
/* ------------------------------------------------------------------ */

/** Count of log events per minute for the last `n` minutes (oldest -> newest), for sparklines. */
export function logSeries(logs: BotLog[], now: number, n = 12, filter?: (l: BotLog) => boolean) {
  const out = new Array<number>(n).fill(0);
  for (const l of logs) {
    if (filter && !filter(l)) continue;
    const age = Math.floor((now - new Date(l.created_at).getTime()) / 60000);
    if (age < 0 || age >= n) continue;
    out[n - 1 - age] = (out[n - 1 - age] ?? 0) + 1;
  }
  return out;
}
