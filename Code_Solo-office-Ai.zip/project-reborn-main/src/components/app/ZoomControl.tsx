import { useState } from 'react';
import { Minus, Plus, RotateCcw, ScanSearch, X } from 'lucide-react';
import { ZOOM_MAX, ZOOM_MIN, ZOOM_STEP } from '@/lib/app/zoom';

const PRESETS = [0.75, 1, 1.25, 1.5, 2];

interface Props {
  zoom: number;
  onChange: (v: number) => void;
}

/**
 * Floating zoom control, rendered OUTSIDE the zoomed wrapper so it stays the same size.
 * Collapsed by default into one small button so it never covers any detail.
 */
export default function ZoomControl({ zoom, onChange }: Props) {
  const [open, setOpen] = useState(false);
  const pct = Math.round(zoom * 100);

  return (
    <div
      className="fixed z-50 flex flex-col items-end gap-2"
      style={{
        right: 'max(0.75rem, env(safe-area-inset-right))',
        bottom: 'calc(max(0.75rem, env(safe-area-inset-bottom)) + var(--nav-h, 0px))',
      }}
    >
      {open && (
        <div
          role="dialog"
          aria-label="Zoom interface"
          className="w-[min(18rem,calc(100vw-1.5rem))] rounded-2xl border border-white/[0.1] bg-[#141821] p-3 text-slate-200 shadow-2xl shadow-black/50"
        >
          <div className="mb-2 flex items-center justify-between">
            <p className="text-xs font-semibold text-white">Zoom ng Interface · {pct}%</p>
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Isara ang zoom panel"
              className="flex h-10 w-10 items-center justify-center rounded-lg text-slate-400 hover:bg-white/[0.08] hover:text-white"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onChange(zoom - ZOOM_STEP)}
              disabled={zoom <= ZOOM_MIN}
              aria-label="Zoom out"
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-white/[0.1] bg-white/[0.06] text-white active:bg-white/[0.14] disabled:opacity-40"
            >
              <Minus className="h-5 w-5" />
            </button>
            <input
              type="range"
              min={ZOOM_MIN}
              max={ZOOM_MAX}
              step={0.05}
              value={zoom}
              onChange={(e) => onChange(parseFloat(e.target.value))}
              aria-label="Zoom level"
              className="h-11 min-w-0 flex-1 accent-emerald-500"
            />
            <button
              type="button"
              onClick={() => onChange(zoom + ZOOM_STEP)}
              disabled={zoom >= ZOOM_MAX}
              aria-label="Zoom in"
              className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-white/[0.1] bg-white/[0.06] text-white active:bg-white/[0.14] disabled:opacity-40"
            >
              <Plus className="h-5 w-5" />
            </button>
          </div>

          <div className="mt-3 flex flex-wrap gap-1.5">
            {PRESETS.map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => onChange(p)}
                className={`h-9 flex-1 rounded-lg border px-2 text-xs font-semibold ${
                  Math.abs(zoom - p) < 0.01
                    ? 'border-emerald-400/50 bg-emerald-500/20 text-emerald-300'
                    : 'border-white/[0.08] bg-white/[0.04] text-slate-300'
                }`}
              >
                {Math.round(p * 100)}%
              </button>
            ))}
          </div>

          <button
            type="button"
            onClick={() => onChange(1)}
            className="mt-2 flex h-9 w-full items-center justify-center gap-2 rounded-lg border border-white/[0.08] bg-white/[0.04] text-xs font-medium text-slate-300 active:bg-white/[0.1]"
          >
            <RotateCcw className="h-3.5 w-3.5" /> I-reset sa 100%
          </button>
          <p className="mt-2 text-[11px] leading-snug text-slate-500">
            Tip: pwede ka ring mag-pinch sa mismong screen. Sa 3D office, 2 daliri = zoom / ikot.
          </p>
        </div>
      )}

      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label="Buksan ang zoom controls"
        aria-expanded={open}
        className="flex h-12 items-center gap-1.5 rounded-full border border-emerald-400/30 bg-[#141821] px-3.5 text-xs font-semibold text-emerald-300 shadow-xl shadow-black/40 active:bg-[#1b2130]"
      >
        <ScanSearch className="h-5 w-5" />
        {pct !== 100 && <span>{pct}%</span>}
      </button>
    </div>
  );
}
