import { memo, useEffect, useRef, useState } from 'react';
import { Activity, Send, Sparkles, UserPlus, Zap, AlertTriangle, Info, CheckCircle, XCircle, Terminal, Eye, MessageCircle } from 'lucide-react';
import type { BotLog, LogLevel } from '@/lib/app/types';
import { db, subscribeLogs } from '@/lib/app/db';
import { Badge } from './ui-kit';

const LEVEL_META: Record<LogLevel, { icon: typeof Info; color: string; label: string }> = {
  info: { icon: Info, color: 'text-sky-400', label: 'bg-sky-500/10 text-sky-300 border-sky-500/20' },
  success: { icon: CheckCircle, color: 'text-emerald-400', label: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20' },
  warning: { icon: AlertTriangle, color: 'text-amber-400', label: 'bg-amber-500/10 text-amber-300 border-amber-500/20' },
  error: { icon: XCircle, color: 'text-red-400', label: 'bg-red-500/10 text-red-300 border-red-500/20' },
};

function sourceMeta(source: string) {
  if (source === 'auto-poster') return { icon: Send, label: 'AUTO-POSTER' };
  if (source === 'auto-inviter') return { icon: UserPlus, label: 'AUTO-INVITER' };
  if (source === 'auto-pilot') return { icon: Sparkles, label: 'AUTO-PILOT' };
  if (source === 'watchdog') return { icon: Eye, label: 'ARGUS' };
  if (source === 'x-bot') return { icon: MessageCircle, label: 'X-REPLY' };
  if (source === 'comment-bot') return { icon: MessageCircle, label: 'FB-REPLY' };
  if (source === 'system') return { icon: Zap, label: 'SYSTEM' };
  if (source === 'boss') return { icon: Sparkles, label: 'BOSS' };
  if (source === 'team') return { icon: Sparkles, label: 'TEAM' };
  return { icon: Activity, label: source.toUpperCase() };
}

const time = (iso: string) =>
  new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

const LogRow = memo(function LogRow({ log }: { log: BotLog }) {
  const meta = LEVEL_META[log.level];
  const Icon = meta.icon;
  const badge = sourceMeta(log.source);
  const BadgeIcon = badge.icon;
  return (
    <div className="flex flex-wrap items-start gap-x-2 gap-y-1 px-3 py-2 sm:flex-nowrap sm:gap-3 sm:px-5">
      <span className="shrink-0 pt-0.5 text-[11px] text-slate-500 sm:text-xs">[{time(log.created_at)}]</span>
      <span className={`shrink-0 rounded border px-1.5 py-0.5 text-[10px] font-semibold tracking-wide ${meta.label}`}>
        <BadgeIcon className="mr-1 inline h-3 w-3" />
        {badge.label}
      </span>
      <Icon className={`mt-0.5 h-3.5 w-3.5 shrink-0 ${meta.color}`} />
      <span className="min-w-0 basis-full break-words text-slate-300 sm:basis-auto">{log.message}</span>
    </div>
  );
});

export default function ActivityConsole() {
  const [logs, setLogs] = useState<BotLog[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let mounted = true;

    const load = async () => {
      try {
        const data = await db.listLogs(60);
        if (mounted) setLogs(data);
      } catch (err) {
        console.error('Failed to load logs', err);
      }
    };
    void load();

    const unsubscribe = subscribeLogs((row) =>
      setLogs((prev) => (prev.some((l) => l.id === row.id) ? prev : [row, ...prev].slice(0, 60))),
    );

    return () => {
      mounted = false;
      unsubscribe();
    };
  }, []);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = 0;
  }, [logs]);

  return (
    <div className="overflow-hidden rounded-xl border border-white/[0.06] bg-[#0d1117]">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/[0.06] bg-[#141821] px-4 py-3 sm:px-5">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1">
          <Terminal className="h-4 w-4 text-emerald-400" />
          <h3 className="text-sm font-semibold text-white">Activity &amp; Bot Logs</h3>
          <span className="flex items-center gap-1.5 text-[11px] font-semibold text-emerald-400">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-pulse rounded-full bg-emerald-400 opacity-60" />
              <span className="relative inline-flex h-2 w-2 rounded-full bg-emerald-400" />
            </span>
            LIVE
          </span>
        </div>
        <Badge tone="slate">{logs.length} events</Badge>
      </div>
      <div ref={scrollRef} className="max-h-72 overflow-y-auto font-mono text-xs">
        {logs.length === 0 ? (
          <p className="px-5 py-8 text-center text-slate-500">Waiting for bot activity…</p>
        ) : (
          <div className="divide-y divide-white/[0.04]">
            {logs.map((log) => (
              <LogRow key={log.id} log={log} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
