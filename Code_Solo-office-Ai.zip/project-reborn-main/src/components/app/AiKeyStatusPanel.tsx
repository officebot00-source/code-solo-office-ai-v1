import { useCallback, useEffect, useState } from 'react';
import { AlertTriangle, CheckCircle2, CircleHelp, Coins, KeyRound, RefreshCw, XCircle } from 'lucide-react';
import { aiKeyStatus, integrationsAdmin, type AiKeyStatus } from '@/lib/app/publish';
import { Button, Card, Input } from './ui-kit';

type Tone = 'good' | 'bad' | 'unknown';

const toneClass: Record<Tone, string> = {
  good: 'border-emerald-500/30 bg-emerald-500/10 text-emerald-300',
  bad: 'border-red-500/30 bg-red-500/10 text-red-300',
  unknown: 'border-amber-500/30 bg-amber-500/10 text-amber-200',
};

function Tile({ label, value, tone }: { label: string; value: string; tone: Tone }) {
  const Icon = tone === 'good' ? CheckCircle2 : tone === 'bad' ? XCircle : CircleHelp;
  return (
    <div className={`flex items-center gap-2.5 rounded-lg border px-3 py-2.5 ${toneClass[tone]}`}>
      <Icon className="h-5 w-5 shrink-0" />
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-wider opacity-70">{label}</p>
        <p className="truncate text-sm font-semibold">{value}</p>
      </div>
    </div>
  );
}

/** API Settings → live status of the AI key (accepted? credits left?) with a quick way to swap in another key. */
export default function AiKeyStatusPanel({ onChanged }: { onChanged?: () => void }) {
  const [status, setStatus] = useState<AiKeyStatus | null>(null);
  const [checking, setChecking] = useState(false);
  const [saving, setSaving] = useState(false);
  const [newKey, setNewKey] = useState('');
  const [error, setError] = useState('');

  const check = useCallback(async () => {
    setChecking(true);
    setError('');
    try {
      setStatus(await aiKeyStatus());
      onChanged?.();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Check failed');
    } finally {
      setChecking(false);
    }
  }, [onChanged]);

  useEffect(() => { void check(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const replace = async () => {
    if (!newKey.trim()) return;
    setSaving(true);
    setError('');
    try {
      await integrationsAdmin('save', 'openai', { api_key: newKey.trim() });
      setNewKey('');
      await check();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Saving the key failed');
    } finally {
      setSaving(false);
    }
  };

  const s = status;
  const keyTone: Tone = !s || !s.configured || s.keyValid === null ? 'unknown' : s.keyValid ? 'good' : 'bad';
  const keyText = !s ? 'Checking…' : !s.configured ? 'No key saved' : s.keyValid === null ? "Can't tell" : s.keyValid ? 'Valid' : 'Not accepted';
  const creditTone: Tone = !s || s.credits === 'unknown' ? 'unknown' : s.credits === 'ok' ? 'good' : 'bad';
  const creditText = !s
    ? 'Checking…'
    : s.credits === 'ok'
      ? typeof s.creditLeft === 'number' ? `Available ($${s.creditLeft.toFixed(2)} left)` : 'Available'
      : s.credits === 'empty' ? 'Used up' : "Can't tell";
  const needsNewKey = !!s && (!s.configured || s.keyValid === false || s.credits === 'empty');

  return (
    <Card className="p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2.5">
          <span className="rounded-lg bg-white/[0.06] p-2 text-slate-300">
            <Coins className="h-4 w-4" />
          </span>
          <div>
            <h3 className="text-sm font-semibold text-white">AI key status</h3>
            <p className="text-[11px] text-slate-500">
              {s?.configured
                ? <>{s.provider} · key <span className="font-mono">{s.keyHint}</span> · model <span className="font-mono">{s.model}</span></>
                : 'The key every bot uses to think and write.'}
            </p>
          </div>
        </div>
        <Button variant="secondary" onClick={() => void check()} disabled={checking || saving}>
          <RefreshCw className={`h-4 w-4 ${checking ? 'animate-spin' : ''}`} />
          {checking ? 'Checking…' : 'Check now'}
        </Button>
      </div>

      <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
        <Tile label="API key" value={keyText} tone={keyTone} />
        <Tile label="Credits" value={creditText} tone={creditTone} />
      </div>

      {s && (
        <p className="mt-3 break-words text-xs text-slate-400">
          {s.message}
          <span className="ml-1 text-slate-600">· checked {new Date(s.checkedAt).toLocaleTimeString()}</span>
        </p>
      )}
      {error && <p className="mt-3 break-words rounded-lg bg-red-500/10 px-3 py-2 text-xs text-red-300">{error}</p>}

      <div className={`mt-4 rounded-lg border p-3 ${needsNewKey ? 'border-amber-500/30 bg-amber-500/[0.06]' : 'border-white/[0.06]'}`}>
        {needsNewKey && (
          <p className="mb-2 flex items-center gap-1.5 text-xs text-amber-200">
            <AlertTriangle className="h-3.5 w-3.5" /> Palitan ang key ng may credits para gumana ulit ang mga bots.
          </p>
        )}
        <div className="flex flex-col gap-2 sm:flex-row sm:items-end">
          <Input
            className="flex-1"
            label="Replace with another key (OpenRouter sk-or-…, OpenAI sk-…, Gemini AIza…)"
            type="password"
            value={newKey}
            onChange={setNewKey}
            placeholder="paste the new key"
          />
          <Button onClick={() => void replace()} disabled={!newKey.trim() || saving || checking}>
            <KeyRound className="h-4 w-4" />
            {saving ? 'Saving…' : 'Save & check'}
          </Button>
        </div>
        <p className="mt-2 text-[11px] text-slate-500">
          The old key is replaced right away. If the saved model belongs to another provider, the matching default model is used.
        </p>
      </div>
    </Card>
  );
}
