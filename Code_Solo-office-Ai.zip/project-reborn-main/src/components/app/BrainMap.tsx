import { useMemo } from 'react';
import { BOT_STYLE, type BrainBot, type BrainEvent, type BrainRule } from '@/lib/app/brain';
import { useCountUp } from './DashboardLive';

/* "Neural Orb" brain map.
   Core: layered rotating rings + breathing glow + count-up rule counter.
   Wires: curved, gradient, flowing dashes with data packets (and a glowing comet trail when a bot just learned something).
   Bots: breathing halo, orbiting satellite, a progress arc showing their share of the lessons, ripples when "hot".
   Everything is SMIL/CSS on leaf SVG elements (no filters, no blur) so it stays smooth on phones. */

const C = { x: 360, y: 172 };
const POS: Record<string, { x: number; y: number }> = {
  Cipher: { x: 360, y: 50 }, Aria: { x: 100, y: 112 }, Blaze: { x: 620, y: 112 }, Nova: { x: 160, y: 264 }, Echo: { x: 560, y: 264 },
};
const reduced = typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

/** unknown bot names still get a seat on an ellipse around the core */
function seat(name: string, i: number, total: number) {
  const known = POS[name];
  if (known) return known;
  const a = (-Math.PI / 2) + (i / Math.max(1, total)) * Math.PI * 2;
  return { x: C.x + Math.cos(a) * 250, y: C.y + Math.sin(a) * 120 };
}

/** gentle quadratic curve between two points; `bend` alternates so the wires fan out instead of looking like spokes */
function curve(ax: number, ay: number, bx: number, by: number, bend: number) {
  const mx = (ax + bx) / 2, my = (ay + by) / 2;
  const dx = bx - ax, dy = by - ay, len = Math.hypot(dx, dy) || 1;
  return `M${ax.toFixed(1)},${ay.toFixed(1)} Q${(mx + (-dy / len) * bend).toFixed(1)},${(my + (dx / len) * bend).toFixed(1)} ${bx.toFixed(1)},${by.toFixed(1)}`;
}

// deterministic "synapse" specks drifting in the background
const SPECKS = Array.from({ length: 18 }, (_, i) => ({
  x: 30 + ((i * 197) % 660), y: 18 + ((i * 89) % 310), r: 1 + (i % 3) * 0.6, d: (i * 0.7) % 6, t: 5 + (i % 5),
}));

export default function BrainMap({ bots, rules, events }: { bots: BrainBot[]; rules: BrainRule[]; events: BrainEvent[] }) {
  const active = rules.filter((r) => r.status === 'approved').length;
  const shown = Math.round(useCountUp(active, 1100));
  const byBot = useMemo(() => {
    const m: Record<string, number> = {};
    for (const r of rules) if (r.source_bot_id && r.status === 'approved') m[r.source_bot_id] = (m[r.source_bot_id] ?? 0) + 1;
    return m;
  }, [rules]);
  const hot = useMemo(() => {
    const cutoff = Date.now() - 120_000;
    return new Set(events.filter((e) => new Date(e.created_at).getTime() > cutoff && e.learned_by_bot_id).map((e) => e.learned_by_bot_id as string));
  }, [events]);

  const nodes = useMemo(() => bots.map((b, i) => ({ bot: b, ...seat(b.name, i, bots.length) })), [bots]);
  const anyHot = nodes.some((n) => hot.has(n.bot.id));
  const hotCount = nodes.filter((n) => hot.has(n.bot.id)).length;
  const maxN = Math.max(1, ...nodes.map((n) => byBot[n.bot.id] ?? 0));

  // faint team mesh: each bot to the next one around the circle
  const ring = useMemo(() => [...nodes].sort((p, q) => Math.atan2(p.y - C.y, p.x - C.x) - Math.atan2(q.y - C.y, q.x - C.x)), [nodes]);

  return (
    <div className="bm-wrap">
      <svg viewBox="0 0 720 350" className="h-auto w-full" role="img" aria-label="Shared Brain map">
        <defs>
          <radialGradient id="bm-core" cx="38%" cy="32%" r="75%">
            <stop offset="0%" stopColor="#f5f3ff" stopOpacity="0.98" />
            <stop offset="35%" stopColor="#a78bfa" stopOpacity="0.9" />
            <stop offset="100%" stopColor="#4c1d95" stopOpacity="0.85" />
          </radialGradient>
          <radialGradient id="bm-glow" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#a78bfa" stopOpacity="0.45" />
            <stop offset="60%" stopColor="#6366f1" stopOpacity="0.12" />
            <stop offset="100%" stopColor="#6366f1" stopOpacity="0" />
          </radialGradient>
          <pattern id="bm-dots" width="22" height="22" patternUnits="userSpaceOnUse">
            <circle cx="1.5" cy="1.5" r="1" fill="#fff" fillOpacity="0.09" />
          </pattern>
          <radialGradient id="bm-fade" cx="50%" cy="50%" r="60%">
            <stop offset="30%" stopColor="#fff" />
            <stop offset="100%" stopColor="#000" />
          </radialGradient>
          <mask id="bm-mask"><rect width="720" height="350" fill="url(#bm-fade)" /></mask>
          {nodes.map((n, i) => {
            const col = BOT_STYLE[n.bot.name]?.color ?? '#94a3b8';
            return (
              <linearGradient key={n.bot.id} id={`bm-w${i}`} gradientUnits="userSpaceOnUse" x1={n.x} y1={n.y} x2={C.x} y2={C.y}>
                <stop offset="0%" stopColor={col} stopOpacity="0.9" />
                <stop offset="100%" stopColor="#a78bfa" stopOpacity="0.9" />
              </linearGradient>
            );
          })}
        </defs>

        {/* backdrop: dotted grid that fades to the edges + drifting synapse specks */}
        <rect width="720" height="350" fill="url(#bm-dots)" mask="url(#bm-mask)" />
        {!reduced && SPECKS.map((s, i) => (
          <circle key={i} className="bm-speck" cx={s.x} cy={s.y} r={s.r} fill="#c4b5fd" style={{ animationDelay: `-${s.d}s`, animationDuration: `${s.t}s` }} />
        ))}

        <circle cx={C.x} cy={C.y} r="150" fill="url(#bm-glow)" className="bm-breathe" />

        {/* team mesh */}
        {ring.map((n, i) => {
          const m = ring[(i + 1) % ring.length]!;
          if (m === n) return null;
          const d = curve(n.x, n.y, m.x, m.y, 0);
          return (
            <g key={`mesh-${n.bot.id}`}>
              <path d={d} stroke="#94a3b8" strokeOpacity="0.1" strokeWidth="1" fill="none" strokeDasharray="1 7" strokeLinecap="round" />
              {!reduced && anyHot && (
                <circle r="2.4" fill="#e9d5ff" opacity="0.8">
                  <animateMotion dur={`${3.4 + i * 0.4}s`} repeatCount="indefinite" path={d} begin={`${i * 0.5}s`} />
                </circle>
              )}
            </g>
          );
        })}

        {/* wires bot <-> brain */}
        {nodes.map((n, i) => {
          const col = BOT_STYLE[n.bot.name]?.color ?? '#94a3b8', on = hot.has(n.bot.id);
          const bend = (i % 2 ? 1 : -1) * 26;
          const into = curve(n.x, n.y, C.x, C.y, bend);
          const out = curve(C.x, C.y, n.x, n.y, -bend);
          return (
            <g key={n.bot.id}>
              <path d={into} stroke={`url(#bm-w${i})`} strokeOpacity={on ? 0.35 : 0.14} strokeWidth={on ? 5 : 3} fill="none" strokeLinecap="round" />
              <path d={into} stroke={`url(#bm-w${i})`} strokeOpacity={on ? 0.95 : 0.5} strokeWidth={on ? 2.2 : 1.4} fill="none" strokeLinecap="round" strokeDasharray="3 9" className={on ? 'bm-flow bm-flow-fast' : 'bm-flow'} />
              {!reduced && (
                <circle r="3" fill={col} opacity="0.65">
                  <animateMotion dur={`${5 + i * 0.7}s`} repeatCount="indefinite" path={into} begin={`${i * 0.6}s`} />
                </circle>
              )}
              {/* a bot just learned something: a comet rushes into the brain */}
              {!reduced && on && [0, 1, 2].map((k) => (
                <circle key={k} r={6 - k * 1.6} fill={col} opacity={1 - k * 0.3}>
                  <animateMotion dur="1.5s" repeatCount="indefinite" path={into} begin={`${k * 0.09}s`} />
                </circle>
              ))}
              {/* ...then the lesson is broadcast from the centre to everyone else */}
              {!reduced && anyHot && !on && [0, 1].map((k) => (
                <circle key={k} r={4.6 - k * 1.5} fill="#ddd6fe" opacity={0.95 - k * 0.35}>
                  <animateMotion dur="1.8s" repeatCount="indefinite" path={out} begin={`${1.2 + k * 0.1}s`} />
                </circle>
              ))}
            </g>
          );
        })}

        {/* core */}
        <g>
          {!reduced && [0, 1.6].map((b) => (
            <circle key={b} cx={C.x} cy={C.y} r="50" fill="none" stroke="#a78bfa" strokeWidth="1.6">
              <animate attributeName="r" values="50;96" dur="3.2s" begin={`${b}s`} repeatCount="indefinite" />
              <animate attributeName="opacity" values="0.55;0" dur="3.2s" begin={`${b}s`} repeatCount="indefinite" />
            </circle>
          ))}
          <g className="bm-spin-slow" style={{ transformOrigin: `${C.x}px ${C.y}px` }}>
            <circle cx={C.x} cy={C.y} r="66" fill="none" stroke="#c4b5fd" strokeOpacity="0.55" strokeWidth="1.5" strokeDasharray="4 10" strokeLinecap="round" />
            <circle cx={C.x} cy={C.y - 66} r="3.4" fill="#f0abfc" />
          </g>
          <g className="bm-spin-rev" style={{ transformOrigin: `${C.x}px ${C.y}px` }}>
            <circle cx={C.x} cy={C.y} r="78" fill="none" stroke="#818cf8" strokeOpacity="0.7" strokeWidth="2" strokeDasharray="60 120 22 90" strokeLinecap="round" />
            <circle cx={C.x + 78} cy={C.y} r="2.6" fill="#a5b4fc" />
          </g>
          <g className="bm-spin-fast" style={{ transformOrigin: `${C.x}px ${C.y}px` }}>
            <circle cx={C.x} cy={C.y} r="57" fill="none" stroke="#e9d5ff" strokeOpacity="0.8" strokeWidth="2.2" strokeDasharray="34 330" strokeLinecap="round" />
          </g>
          <circle cx={C.x} cy={C.y} r="48" fill="url(#bm-core)" stroke="#ddd6fe" strokeOpacity="0.7" strokeWidth="1.5" className="bm-core-pulse" style={{ transformOrigin: `${C.x}px ${C.y}px` }} />
          <ellipse cx={C.x - 14} cy={C.y - 20} rx="20" ry="9" fill="#fff" fillOpacity="0.16" transform={`rotate(-28 ${C.x - 14} ${C.y - 20})`} />
          <text x={C.x} y={C.y + 6} textAnchor="middle" fontSize="34" fontWeight="800" fill="#fff" style={{ fontVariantNumeric: 'tabular-nums' }}>{shown}</text>
          <text x={C.x} y={C.y + 25} textAnchor="middle" fontSize="11" fontWeight="700" fill="#ede9fe" letterSpacing="2.5">RULES</text>
        </g>

        {/* bots */}
        {nodes.map((n, i) => {
          const st = BOT_STYLE[n.bot.name] ?? { color: '#94a3b8', emoji: '🤖' };
          const count = byBot[n.bot.id] ?? 0, r = 24 + Math.min(10, Math.sqrt(count) * 3), on = hot.has(n.bot.id);
          const arcR = r + 6, circ = 2 * Math.PI * arcR, share = count / maxN;
          return (
            <g key={n.bot.id}>
              {/* halo */}
              <circle className="bm-halo" cx={n.x} cy={n.y} r={r + 14} fill={st.color} fillOpacity="0.1" style={{ transformOrigin: `${n.x}px ${n.y}px`, animationDelay: `-${i * 0.9}s` }} />
              {/* ripples when it just learned something */}
              {!reduced && on && [0, 0.7].map((b) => (
                <circle key={b} cx={n.x} cy={n.y} r={r + 4} fill="none" stroke={st.color} strokeWidth="2">
                  <animate attributeName="r" values={`${r + 4};${r + 32}`} dur="1.4s" begin={`${b}s`} repeatCount="indefinite" />
                  <animate attributeName="opacity" values="0.75;0" dur="1.4s" begin={`${b}s`} repeatCount="indefinite" />
                </circle>
              ))}
              {/* share-of-lessons arc */}
              <circle cx={n.x} cy={n.y} r={arcR} fill="none" stroke={st.color} strokeOpacity="0.16" strokeWidth="3" />
              <circle
                cx={n.x} cy={n.y} r={arcR} fill="none" stroke={st.color} strokeWidth="3" strokeLinecap="round"
                strokeDasharray={`${Math.max(0.02, share) * circ} ${circ}`} transform={`rotate(-90 ${n.x} ${n.y})`} className="bm-arc"
              />
              {/* orbiting satellite */}
              {!reduced && (
                <g className="bm-orbit" style={{ transformOrigin: `${n.x}px ${n.y}px`, animationDuration: `${5 + i * 1.3}s` }}>
                  <circle cx={n.x} cy={n.y - arcR - 7} r="2.6" fill={st.color} />
                </g>
              )}
              {/* body */}
              <circle cx={n.x} cy={n.y} r={r} fill="#0f1320" stroke={st.color} strokeWidth="2" />
              <circle cx={n.x} cy={n.y} r={r} fill={st.color} fillOpacity={on ? 0.32 : 0.16} />
              <text x={n.x} y={n.y + 8} textAnchor="middle" fontSize="22">{st.emoji}</text>
              <text x={n.x} y={n.y + r + 24} textAnchor="middle" fontSize="18" fontWeight="700" fill={on ? st.color : '#e2e8f0'}>{n.bot.name}</text>
              <text x={n.x} y={n.y + r + 41} textAnchor="middle" fontSize="13" fill="#94a3b8">{count} {count === 1 ? 'lesson' : 'lessons'}</text>
            </g>
          );
        })}
      </svg>

      <div className="bm-legend">
        <span className="bm-pill"><i className="bm-dot" style={{ background: '#a78bfa' }} />{active} active rules</span>
        <span className="bm-pill"><i className="bm-dot" style={{ background: '#38bdf8' }} />{nodes.length} bots connected</span>
        <span className={`bm-pill ${hotCount ? 'bm-pill-hot' : ''}`}>
          <i className={`bm-dot ${hotCount ? 'bm-dot-live' : ''}`} style={{ background: hotCount ? '#34d399' : '#64748b' }} />
          {hotCount ? `${hotCount} bot${hotCount === 1 ? '' : 's'} learning now` : 'Tahimik ang utak ngayon'}
        </span>
      </div>
    </div>
  );
}
