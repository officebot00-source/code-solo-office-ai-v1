import { useEffect, useState } from 'react';
import { FlaskConical, Trophy } from 'lucide-react';
import { db } from '@/lib/app/db';
import {
  MIN_CLICKS, ctr, getAutoPromote, loadExperiments, saveExperiments, setAutoPromote, simulateTraffic, winnerOf,
  type Experiment, type Variant, type VariantKey,
} from '@/lib/app/ab';
import { Card, Toggle } from './ui-kit';

function Chart({ exp }: { exp: Experiment }) {
  const pts = exp.series.slice(-24);
  const max = Math.max(1, ...pts.map((p) => Math.max(p.a, p.b)));
  const x = (i: number) => (pts.length < 2 ? 0 : (i / (pts.length - 1)) * 300);
  const y = (v: number) => 70 - (v / max) * 62;
  const line = (k: VariantKey) => pts.map((p, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)},${y(p[k]).toFixed(1)}`).join(' ');
  return (
    <svg viewBox="0 0 300 76" className="h-20 w-full" preserveAspectRatio="none" role="img" aria-label="Clicks over time">
      {[0, 1, 2].map((i) => <line key={i} x1="0" x2="300" y1={8 + i * 31} y2={8 + i * 31} stroke="rgba(255,255,255,0.06)" />)}
      <path d={line('a')} fill="none" stroke="#38bdf8" strokeWidth="2" vectorEffect="non-scaling-stroke" />
      <path d={line('b')} fill="none" stroke="#f472b6" strokeWidth="2" vectorEffect="non-scaling-stroke" />
    </svg>
  );
}

function Row({ v, color, max, winner }: { v: Variant; color: string; max: number; winner: boolean }) {
  return (
    <div className={`rounded-lg p-3 ${winner ? 'bg-amber-400/10 ring-1 ring-amber-400/50 shadow-[0_0_18px_rgba(251,191,36,0.25)]' : 'bg-white/[0.03]'}`}>
      <div className="flex items-center justify-between text-xs">
        <span className="font-semibold text-white">
          Variant {v.key.toUpperCase()} <span className="font-normal text-slate-500">· {v.angle}</span>
          {v.paused && <span className="ml-2 rounded bg-slate-500/20 px-1.5 text-[10px] text-slate-400">paused</span>}
        </span>
        {winner && <span className="flex items-center gap-1 font-bold text-amber-300"><Trophy className="h-3.5 w-3.5" />🏆 WINNER</span>}
      </div>
      <div className="mt-2 h-2 overflow-hidden rounded-full bg-white/[0.06]">
        <div className="h-full rounded-full transition-all duration-700" style={{ width: `${(ctr(v) / max) * 100}%`, backgroundColor: color }} />
      </div>
      <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4 text-[11px] text-slate-400">
        <span>Sent <b className="block text-sm text-white">{v.impressions}</b></span>
        <span>Clicks <b className="block text-sm text-white">{v.clicks}</b></span>
        <span>CTR <b className="block text-sm text-white">{ctr(v).toFixed(1)}%</b></span>
        <span>Joins ~<b className="block text-sm text-white">{v.conversions}</b></span>
      </div>
    </div>
  );
}

export default function AbExperiments() {
  const [exps, setExps] = useState<Experiment[]>(() => loadExperiments());
  const [auto, setAuto] = useState(getAutoPromote);

  useEffect(() => {
    const t = window.setInterval(() => {
      const next = simulateTraffic();
      if (getAutoPromote()) {
        next.forEach((e) => {
          const w = winnerOf(e);
          if (e.status !== 'active' || !w || e.promoted) return;
          const loser: VariantKey = w === 'a' ? 'b' : 'a';
          e.promoted = w;
          e.variants[loser].paused = true;
          const rate = ctr(e.variants[w]).toFixed(1);
          void db.log('info', 'system', `Variant ${w.toUpperCase()} winning at ${rate}% CTR! Switching future posts to Variant ${w.toUpperCase()}...`);
          void db.log('success', 'scheduler', `Pausing Variant ${loser.toUpperCase()}, queueing Variant ${w.toUpperCase()} for next slots...`);
          void db.log('info', 'system', 'Rate limit safe: 14/20 per hour.');
        });
        saveExperiments(next);
      }
      setExps([...next]);
    }, 5000);
    return () => window.clearInterval(t);
  }, []);

  const toggleAuto = (v: boolean) => { setAuto(v); setAutoPromote(v); };

  return (
    <Card className="p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <FlaskConical className="h-4 w-4 text-fuchsia-400" />
          <h3 className="text-sm font-semibold text-white">A/B Test Experiments</h3>
        </div>
        <Toggle checked={auto} onChange={toggleAuto} label="Auto-Promote Winner" />
      </div>
      <p className="mt-1 text-xs text-slate-500">Winner is awarded at {MIN_CLICKS}+ clicks or after 24 hours. Cipher tells Blaze to pause the loser.</p>
      <div className="mt-4 grid grid-cols-1 gap-4 xl:grid-cols-2">
        {exps.map((e) => {
          const w = winnerOf(e);
          const max = Math.max(0.1, ctr(e.variants.a), ctr(e.variants.b));
          return (
            <div key={e.id} className="space-y-3 rounded-xl border border-white/[0.06] p-4">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-white">{e.game_title} <span className="font-mono text-slate-500">#{e.id}</span></span>
                <span className={e.status === 'active' ? 'text-emerald-400' : 'text-slate-500'}>{e.status === 'active' ? '● Active' : 'Completed'}</span>
              </div>
              <Row v={e.variants.a} color="#38bdf8" max={max} winner={w === 'a'} />
              <Row v={e.variants.b} color="#f472b6" max={max} winner={w === 'b'} />
              <Chart exp={e} />
              <div className="flex gap-4 text-[10px] text-slate-500">
                <span><span className="text-sky-400">━</span> Variant A clicks</span>
                <span><span className="text-pink-400">━</span> Variant B clicks</span>
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
}
