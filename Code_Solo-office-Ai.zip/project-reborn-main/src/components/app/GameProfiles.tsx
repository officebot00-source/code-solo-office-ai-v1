import { useEffect, useState } from 'react';
import { Gamepad2, Pencil, Plus, Trash2, Upload } from 'lucide-react';
import type { Game } from '@/lib/app/types';
import { db } from '@/lib/app/db';
import { Badge, Button, Card, EmptyState, Input, Notice, PageHero, TextArea, Toggle } from './ui-kit';

const EMPTY = {
  title: '',
  genre: '',
  description: '',
  promo_link: '',
  banner_image: '',
  active: true,
};

export default function GameProfiles() {
  const [games, setGames] = useState<Game[]>([]);
  const [editing, setEditing] = useState<typeof EMPTY & { id?: string }>(EMPTY);
  const [open, setOpen] = useState(false);
  const [error, setError] = useState('');

  const load = async () => {
    try {
      setGames(await db.listGames());
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load games');
    }
  };

  useEffect(() => {
    void load();
  }, []);

  const save = async () => {
    if (!editing.title.trim()) {
      setError('Game title is required.');
      return;
    }
    try {
      await db.saveGame({ ...editing, id: editing.id, title: editing.title.trim() });
      setOpen(false);
      setEditing(EMPTY);
      setError('');
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save game');
    }
  };

  const remove = async (id: string) => {
    try {
      await db.deleteGame(id);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete game');
    }
  };

  const toggleActive = async (game: Game) => {
    try {
      await db.saveGame({ ...game, active: !game.active });
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update game');
    }
  };

  const onBanner = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setEditing((prev) => ({ ...prev, banner_image: String(reader.result) }));
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-5">
      <PageHero
        icon={Gamepad2} accent="sky" title="Game Profiles"
        subtitle="Dito mo inaayos ang mga laro na pino-promote ng bot. Ang mga Active lang ang ginagamit ng Aria at ng Studio."
        chip={games.some((g) => g.active !== false) ? { label: `${games.filter((g) => g.active !== false).length} laro ang active`, tone: 'live' } : { label: 'Wala pang active na laro', tone: 'warn' }}
        stats={[
          { label: 'Lahat ng laro', value: games.length },
          { label: 'Active', value: games.filter((g) => g.active !== false).length },
          { label: 'Naka-pause', value: games.filter((g) => g.active === false).length },
        ]}
        actions={
          <Button
            onClick={() => {
              setEditing(EMPTY);
              setOpen(true);
            }}
          >
            <Plus className="h-4 w-4" /> Add Game
          </Button>
        }
      />

      {error && <Notice tone="error">{error}</Notice>}

      {open && (
        <Card className="p-5">
          <h3 className="mb-4 text-sm font-semibold text-white">
            {editing.id ? 'Edit Game' : 'New Game'}
          </h3>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
            <Input label="Game Title" value={editing.title} onChange={(v) => setEditing({ ...editing, title: v })} placeholder="Nova Raid Arena" />
            <Input label="Genre" value={editing.genre} onChange={(v) => setEditing({ ...editing, genre: v })} placeholder="PvP Battle Arena" />
            <TextArea
              label="Short Description"
              value={editing.description}
              onChange={(v) => setEditing({ ...editing, description: v })}
              placeholder="What makes this game exciting?"
              className="md:col-span-2"
            />
            <Input label="Promo / Referral Link" value={editing.promo_link} onChange={(v) => setEditing({ ...editing, promo_link: v })} placeholder="https://play.example.com/your-game" />
            <label className="block">
              <span className="mb-1.5 block text-xs font-medium text-slate-400">Banner / Screenshot</span>
              <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-dashed border-white/[0.15] bg-white/[0.03] px-3 py-2 text-sm text-slate-400 transition-colors hover:border-emerald-500/40 hover:text-slate-300">
                <Upload className="h-4 w-4" />
                {editing.banner_image ? 'Image attached — click to replace' : 'Upload image'}
                <input type="file" accept="image/*" className="hidden" onChange={onBanner} />
              </label>
            </label>
          </div>
          <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
            <Toggle
              checked={editing.active ?? true}
              onChange={(v) => setEditing({ ...editing, active: v })}
              label="Active (used by Auto-Pilot)"
            />
            <div className="flex gap-2">
              <Button variant="secondary" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={save}>Save Game</Button>
            </div>
          </div>
        </Card>
      )}

      {games.length === 0 && !open ? (
        <Card>
          <EmptyState icon={<Gamepad2 className="h-10 w-10" />} title="No games yet" subtitle="Add your first game profile so the bot knows what to promote." />
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
          {games.map((g) => (
            <Card key={g.id} className="overflow-hidden transition-transform duration-200 hover:-translate-y-0.5">
              {g.banner_image ? (
                <img src={g.banner_image} alt={g.title} className="h-32 w-full object-cover" />
              ) : (
                <div className="flex h-32 items-center justify-center bg-gradient-to-br from-slate-800 to-slate-900">
                  <Gamepad2 className="h-8 w-8 text-slate-600" />
                </div>
              )}
              <div className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <h4 className="truncate font-semibold text-white">{g.title}</h4>
                    {g.genre && <p className="text-xs text-slate-500">{g.genre}</p>}
                  </div>
                  <Badge tone={g.active ? 'green' : 'slate'}>{g.active ? 'Active' : 'Paused'}</Badge>
                </div>
                {g.description && <p className="mt-2 line-clamp-2 text-xs leading-relaxed text-slate-400">{g.description}</p>}
                {g.promo_link && (
                  <p className="mt-2 truncate text-xs text-emerald-400/80">{g.promo_link}</p>
                )}
                <div className="mt-4 flex items-center gap-2">
                  <Button variant="secondary" className="flex-1 !py-1.5 !text-xs" onClick={() => { setEditing({ ...g }); setOpen(true); }}>
                    <Pencil className="h-3.5 w-3.5" /> Edit
                  </Button>
                  <Button variant="secondary" className="!py-1.5 !text-xs" onClick={() => toggleActive(g)}>
                    {g.active ? 'Pause' : 'Activate'}
                  </Button>
                  <Button variant="danger" className="!py-1.5 !text-xs" onClick={() => remove(g.id)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
