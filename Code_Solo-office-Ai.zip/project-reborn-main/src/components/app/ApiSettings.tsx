import { useEffect, useState } from 'react';
import { CheckCircle2, KeyRound, Lock, Plug, Send, XCircle } from 'lucide-react';
import type { Integration } from '@/lib/app/types';
import { db } from '@/lib/app/db';
import { canPublishLive, getPasscode, integrationsAdmin, setPasscode } from '@/lib/app/publish';
import { Badge, Button, Card, Input, Notice, PageHero } from './ui-kit';
import AiKeyStatusPanel from './AiKeyStatusPanel';

const FIELD_LABELS: Record<string, Record<string, string>> = {
  openai: { model: 'Model (optional, e.g. openai/gpt-4o-mini)', api_key: 'OpenRouter / OpenAI / Gemini API Key' },
  facebook: { page_id: 'Page ID', access_token: 'Page Access Token' },
  discord: { webhook_url: 'Webhook URL' },
  telegram: { bot_token: 'Bot Token', chat_id: 'Chat / Channel ID' },
  twitter: { api_key: 'API Key (Consumer Key)', api_secret: 'API Key Secret', access_token: 'Access Token', access_secret: 'Access Token Secret' },
};

const HELP: Record<string, string> = {
  facebook: 'Posts to your Page feed. Kailangan ng long-lived PAGE Access Token (hindi User token) na may pages_manage_posts, pages_read_engagement at pages_show_list, galing sa admin ng Page. Page ID ng Page mismo, hindi ng profile o group. Pindutin ang "Test connection" para ma-check.',
  discord: 'Channel settings → Integrations → Webhooks → Copy Webhook URL.',
  telegram: 'Create a bot with @BotFather, add it as admin of your channel/group, then use the chat id (e.g. -100123… or @channelname).',
  twitter: 'From developer.x.com: app with "Read and write" permission; use the OAuth 1.0a keys and access token of your account. Auto-post gumagana agad; para sa auto-reply sa mentions kailangan ng X API plan na may read access (tingnan ang SETUP-X-WATCHDOG.md).',
  openai: 'Pang-AI ng lahat ng bots. Gumagana ang OpenRouter key (sk-or-…), OpenAI o Gemini. Pagkatapos i-save, pindutin ang "Test connection".',
};

type Msg = { ok: boolean; text: string };

export default function ApiSettings() {
  const [integrations, setIntegrations] = useState<Integration[]>([]);
  const [drafts, setDrafts] = useState<Record<string, Record<string, string>>>({});
  const [busy, setBusy] = useState<string | null>(null);
  const [notes, setNotes] = useState<Record<string, Msg>>({});
  const [passcode, setPass] = useState(getPasscode());
  const [error, setError] = useState('');

  const load = () =>
    db.listIntegrations()
      .then(setIntegrations)
      .catch((err) => setError(err instanceof Error ? err.message : 'Failed to load integrations'));

  useEffect(() => {
    void load();
  }, []);

  const note = (provider: string, ok: boolean, text: string) => setNotes((n) => ({ ...n, [provider]: { ok, text } }));
  const setField = (provider: string, key: string, value: string) =>
    setDrafts((d) => ({ ...d, [provider]: { ...d[provider], [key]: value } }));

  const run = async (intg: Integration, action: 'save' | 'test' | 'send_test') => {
    setBusy(`${intg.provider}:${action}`);
    setError('');
    try {
      if (!canPublishLive) {
        // Local simulation mode (no Supabase): nothing real can be sent from a browser-only build.
        if (action === 'save') {
          await db.saveIntegration({ ...intg, config: { ...intg.config, ...drafts[intg.provider] } });
          note(intg.provider, true, 'Saved in this browser only (simulation mode — connect Supabase for real posting).');
        } else {
          note(intg.provider, false, 'Real posting needs Supabase. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY, then deploy the functions.');
        }
      } else if (action === 'save') {
        await integrationsAdmin('save', intg.provider, drafts[intg.provider] ?? {});
        setDrafts((d) => ({ ...d, [intg.provider]: {} }));
        note(intg.provider, true, 'Saved securely on the server. Now press "Test connection".');
      } else {
        const r = await integrationsAdmin(action, intg.provider);
        note(intg.provider, r.ok, r.ok ? (r.detail ?? 'OK') : (r.error ?? 'Failed'));
      }
      await load();
    } catch (err) {
      note(intg.provider, false, err instanceof Error ? err.message : 'Failed');
    } finally {
      setBusy(null);
    }
  };

  if (integrations.length === 0) {
    return <p className="text-sm text-slate-400">{error || 'Loading integrations…'}</p>;
  }

  return (
    <div className="space-y-5">
      <PageHero
        icon={Plug} accent="sky" title="API & Webhook Settings"
        subtitle="Ilagay ang totoong account details mo. Pagkatapos mag-save, live na magpo-post ang mga utos sa accounts mo. Sa server lang nakatago ang mga key at hindi na mababasa ulit sa page na ito."
        chip={canPublishLive ? { label: 'Live — nagpo-post sa totoong accounts', tone: 'live' } : { label: 'Simulation mode', tone: 'warn' }}
        stats={[
          { label: 'Connected', value: integrations.filter((i) => i.status === 'connected').length, hint: `sa ${integrations.length} integrations` },
          { label: 'May error', value: integrations.filter((i) => i.status === 'error').length },
        ]}
      />

      {!canPublishLive && (
        <Notice tone="warn">
          Simulation mode: walang Supabase connection ang build na ito kaya walang totoong napo-post. Itakda ang
          VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY at i-deploy ang Edge Functions para mag-live.
        </Notice>
      )}

      {canPublishLive && (
        <Card className="flex flex-col gap-3 p-4 sm:flex-row sm:items-end">
          <Input
            className="flex-1"
            label="App password (saved on this device)"
            type="password"
            value={passcode}
            onChange={(v) => { setPass(v); setPasscode(v); }}
            placeholder="same as the lock-screen password"
          />
          <p className="flex items-center gap-1.5 text-[11px] text-slate-500 sm:pb-2.5">
            <Lock className="h-3.5 w-3.5" /> Protects posting and key changes.
          </p>
        </Card>
      )}

      {canPublishLive && <AiKeyStatusPanel onChanged={() => void load()} />}

      {error && (
        <div className="rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-2 text-sm text-red-300">{error}</div>
      )}

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        {integrations.map((intg) => {
          const fields = FIELD_LABELS[intg.provider] ?? {};
          const statusTone = intg.status === 'connected' ? 'green' : intg.status === 'error' ? 'red' : 'slate';
          const n = notes[intg.provider];
          const isBusy = (a: string) => busy === `${intg.provider}:${a}`;
          return (
            <Card key={intg.id} className="p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-2.5">
                  <span className="rounded-lg bg-white/[0.06] p-2 text-slate-300">
                    <KeyRound className="h-4 w-4" />
                  </span>
                  <div>
                    <h4 className="text-sm font-semibold text-white">{intg.provider === 'openai' ? 'AI Engine (OpenRouter / OpenAI / Gemini)' : intg.label || intg.provider}</h4>
                    <p className="text-[11px] capitalize text-slate-500">{intg.provider}</p>
                  </div>
                </div>
                <Badge tone={statusTone}>
                  {intg.status === 'connected' ? <CheckCircle2 className="mr-1 h-3 w-3" /> : intg.status === 'error' ? <XCircle className="mr-1 h-3 w-3" /> : null}
                  {intg.status}
                </Badge>
              </div>
              {HELP[intg.provider] && <p className="mt-2 text-[11px] leading-snug text-slate-500">{HELP[intg.provider]}</p>}

              <div className="mt-4 space-y-3">
                {Object.entries(fields).map(([key, label]) => {
                  const saved = intg.config[key] === 'set';
                  return (
                    <Input
                      key={key}
                      label={`${label}${saved ? '  ✓ saved' : ''}`}
                      type={key === 'model' || key === 'page_id' || key === 'chat_id' ? 'text' : 'password'}
                      value={drafts[intg.provider]?.[key] ?? ''}
                      onChange={(v) => setField(intg.provider, key, v)}
                      placeholder={saved ? '•••••• saved — type only to replace' : ''}
                    />
                  );
                })}
              </div>

              {n && (
                <p className={`mt-3 break-words rounded-lg px-3 py-2 text-xs ${n.ok ? 'bg-emerald-500/10 text-emerald-300' : 'bg-red-500/10 text-red-300'}`}>
                  {n.text}
                </p>
              )}

              <div className="mt-4 flex flex-wrap gap-2">
                <Button className="flex-1" onClick={() => run(intg, 'save')} disabled={busy !== null}>
                  {isBusy('save') ? 'Saving…' : 'Save'}
                </Button>
                <Button variant="secondary" onClick={() => run(intg, 'test')} disabled={busy !== null}>
                  <Plug className={`h-4 w-4 ${isBusy('test') ? 'animate-pulse' : ''}`} />
                  {isBusy('test') ? 'Testing…' : 'Test connection'}
                </Button>
                {intg.provider !== 'openai' && (
                  <Button variant="secondary" onClick={() => run(intg, 'send_test')} disabled={busy !== null || !canPublishLive}>
                    <Send className={`h-4 w-4 ${isBusy('send_test') ? 'animate-pulse' : ''}`} />
                    {isBusy('send_test') ? 'Sending…' : 'Send test post'}
                  </Button>
                )}
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
