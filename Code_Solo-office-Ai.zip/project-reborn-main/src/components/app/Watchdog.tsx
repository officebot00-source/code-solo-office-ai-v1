import { useCallback, useEffect, useState } from 'react';
import { BellRing, CheckCircle2, ExternalLink, Eye, EyeOff, Moon, RefreshCw, Send } from 'lucide-react';
import {
  adminRead, adminWrite, canPublishLive, watchdogList, watchdogResolve, watchdogRunNow, watchdogSnooze, watchdogTest, type WatchdogIssue,
} from '@/lib/app/publish';
import { Badge, Button, Card, CardHeader, EmptyState, Input, Notice, PageHero, TextArea, Toggle } from './ui-kit';

const TAG: Record<string, string> = { facebook: 'FB', twitter: 'X', discord: 'Discord', telegram: 'Telegram', all: 'All' };
const KIND: Record<string, string> = {
  needs_human: 'Kailangan ng tao', missed_comment: 'Walang sumagot (FB)', missed_mention: 'Walang sumagot (X)', reply_failed: 'Pumalya ang reply',
  reply_stuck: 'Di natapos ang reply', reply_skipped: 'Hourly limit', post_failed: 'Pumalya ang post', post_partial: 'Half-published',
  post_overdue: 'Overdue na post', no_post_24h: 'Walang post 24h',
};

function age(iso: string) {
  const m = Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / 60000));
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  return h < 24 ? `${h}h ${m % 60}m` : `${Math.floor(h / 24)}d ${h % 24}h`;
}

interface Settings {
  watchdog_enabled: boolean; x_auto_reply_enabled: boolean; fb_auto_reply_enabled: boolean; fb_reply_instructions: string; watchdog_grace_minutes: number; watchdog_nag_minutes: number;
  watchdog_mention: string; watchdog_quiet_start: number; watchdog_quiet_end: number;
}
const DEFAULTS: Settings = { watchdog_enabled: true, x_auto_reply_enabled: true, fb_auto_reply_enabled: true, fb_reply_instructions: '', watchdog_grace_minutes: 15, watchdog_nag_minutes: 30, watchdog_mention: '', watchdog_quiet_start: 0, watchdog_quiet_end: 0 };

export default function Watchdog() {
  const [open, setOpen] = useState<WatchdogIssue[]>([]);
  const [closed, setClosed] = useState<WatchdogIssue[]>([]);
  const [settings, setSettings] = useState<Settings>(DEFAULTS);
  const [busy, setBusy] = useState('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    if (!canPublishLive) return;
    try {
      const r = await watchdogList();
      setOpen(r.open); setClosed(r.closed); setError('');
    } catch (e) { setError(e instanceof Error ? e.message : 'Failed to load'); }
    try {
      const data = await adminRead<Record<string, unknown> | null>('bot_settings');
      if (data) {
        const picked: Partial<Settings> = {};
        for (const k of Object.keys(DEFAULTS) as (keyof Settings)[]) if (k in data) (picked as Record<string, unknown>)[k] = data[k];
        setSettings({ ...DEFAULTS, ...picked });
      }
    } catch { /* settings stay on the last known values */ }
  }, []);

  useEffect(() => {
    void load();
    const t = window.setInterval(() => { if (!document.hidden) void load(); }, 30000);
    return () => window.clearInterval(t);
  }, [load]);

  const act = async (key: string, fn: () => Promise<void>) => {
    setBusy(key); setMsg(null);
    try { await fn(); await load(); } catch (e) { setMsg({ ok: false, text: e instanceof Error ? e.message : 'Failed' }); } finally { setBusy(''); }
  };

  const save = (patch: Partial<Settings>) => {
    const next = { ...settings, ...patch };
    setSettings(next);
    void act('save', () => adminWrite('bot_settings', 'update', { id: 1, row: patch }).then(() => undefined));
  };

  const num = (v: string, min: number, max: number, fallback: number) => { const n = parseInt(v, 10); return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback; };

  if (!canPublishLive) {
    return <p className="text-sm text-slate-400">Kailangan ng Supabase connection ang Watchdog (VITE_SUPABASE_URL / VITE_SUPABASE_ANON_KEY).</p>;
  }

  const live = open.filter((i) => i.status === 'open');
  const snoozed = open.filter((i) => i.status === 'snoozed');

  return (
    <div className="space-y-5">
      <PageHero
        icon={Eye} accent="amber" title="Argus — ang Watchdog"
        subtitle="Sinusuri niya kada 5 minuto ang lahat ng post at comment (Facebook at X). Kapag may na-miss na hindi nasagot o hindi na-post, kinukulit niya ang team sa Telegram / Discord hanggang maayos. Kapag naayos na, kusa siyang titigil."
        chip={live.length ? { label: `${live.length} ang hindi pa naasikaso`, tone: 'warn' } : { label: 'Walang na-miss — bantay pa rin', tone: 'live' }}
        stats={[
          { label: 'Hindi pa naasikaso', value: live.length },
          { label: 'Naka-snooze', value: snoozed.length },
          { label: 'Naayos na', value: closed.length },
        ]}
      />

      {error && <Notice tone="error">{error}</Notice>}
      {msg && <Notice tone={msg.ok ? 'ok' : 'error'}>{msg.text}</Notice>}

      <Card>
        <CardHeader
          title={`Hindi pa naasikaso (${live.length})`}
          subtitle="Pinakamatagal na naghihintay ang nasa itaas."
          action={
            <div className="flex flex-wrap gap-2">
              <Button variant="secondary" disabled={busy !== ''} onClick={() => act('run', async () => {
                const r = await watchdogRunNow();
                setMsg({ ok: r.ok, text: r.ok ? (r.skipped ?? `Tapos ang check: ${r.open ?? 0} open, ${r.new ?? 0} bago, ${r.fixed ?? 0} naayos${r.reminded ? `, nagpaalala sa ${(r.channels ?? []).join(' + ')}` : ''}${r.quiet ? ' (quiet hours — hindi muna nagpaalala)' : ''}.`) : (r.error ?? 'Failed') });
              })}>
                <RefreshCw className={`h-4 w-4 ${busy === 'run' ? 'animate-spin' : ''}`} /> Check now
              </Button>
              <Button variant="secondary" disabled={busy !== ''} onClick={() => act('test', async () => {
                const r = await watchdogTest();
                setMsg({ ok: r.ok, text: r.ok ? (r.detail ?? 'Naipadala') : (r.error ?? 'Failed') });
              })}>
                <Send className="h-4 w-4" /> Test reminder
              </Button>
            </div>
          }
        />
        {live.length === 0 ? (
          <EmptyState icon={<CheckCircle2 className="h-8 w-8" />} title="Wala kang na-miss 🎉" subtitle="Lahat ng comment at post ay naasikaso." />
        ) : (
          <ul className="divide-y divide-white/[0.06]">
            {live.map((i) => (
              <li key={i.id} className="flex flex-col gap-2 px-5 py-3 sm:flex-row sm:items-center">
                <div className="min-w-0 flex-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <Badge tone={i.nag_count >= 6 ? 'red' : i.nag_count >= 3 ? 'amber' : 'blue'}>{TAG[i.platform] ?? i.platform}</Badge>
                    <span className="text-[11px] text-slate-500">{KIND[i.kind] ?? i.kind} · {age(i.item_at)} na · {i.nag_count}× pinaalalahanan</span>
                  </div>
                  <p className="mt-1 break-words text-sm text-slate-200">{i.title}</p>
                  {i.url && <a href={i.url} target="_blank" rel="noreferrer" className="mt-0.5 inline-flex items-center gap-1 text-xs text-sky-400 hover:underline"><ExternalLink className="h-3 w-3" /> Buksan</a>}
                </div>
                <div className="flex shrink-0 flex-wrap gap-2">
                  <Button variant="primary" disabled={busy !== ''} onClick={() => act(i.id, () => watchdogResolve(i.id, 'handled').then(() => undefined))}><CheckCircle2 className="h-4 w-4" /> Tapos na</Button>
                  <Button variant="secondary" disabled={busy !== ''} onClick={() => act(i.id, () => watchdogSnooze(i.id, 4).then(() => undefined))}><Moon className="h-4 w-4" /> 4h</Button>
                  <Button variant="ghost" disabled={busy !== ''} onClick={() => act(i.id, () => watchdogResolve(i.id, 'dismissed').then(() => undefined))}><EyeOff className="h-4 w-4" /> Ignore</Button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </Card>

      {snoozed.length > 0 && (
        <Card>
          <CardHeader title={`Naka-snooze (${snoozed.length})`} subtitle="Babalik ang paalala kapag tapos na ang snooze." />
          <ul className="divide-y divide-white/[0.06]">
            {snoozed.map((i) => (
              <li key={i.id} className="flex items-center gap-3 px-5 py-2.5 text-sm text-slate-300">
                <Badge tone="slate">{TAG[i.platform] ?? i.platform}</Badge>
                <span className="min-w-0 flex-1 truncate">{i.title}</span>
                <Button variant="ghost" disabled={busy !== ''} onClick={() => act(i.id, () => watchdogResolve(i.id, 'open').then(() => undefined))}>Ibalik</Button>
              </li>
            ))}
          </ul>
        </Card>
      )}

      <Card>
        <CardHeader title="Settings ng Watchdog" subtitle="Saan magpapaalala: Telegram (bot token + chat id) at/o Discord webhook sa API Settings." />
        <div className="grid gap-4 p-5 sm:grid-cols-2">
          <div className="flex items-center justify-between rounded-lg border border-white/[0.06] px-3 py-2.5"><span className="text-sm text-slate-300">Watchdog ON</span><Toggle checked={settings.watchdog_enabled} onChange={(v) => save({ watchdog_enabled: v })} /></div>
          <div className="flex items-center justify-between rounded-lg border border-white/[0.06] px-3 py-2.5"><span className="text-sm text-slate-300">X auto-reply ON</span><Toggle checked={settings.x_auto_reply_enabled} onChange={(v) => save({ x_auto_reply_enabled: v })} /></div>
          <div className="flex items-center justify-between rounded-lg border border-white/[0.06] px-3 py-2.5"><span className="text-sm text-slate-300">Facebook auto-reply ON</span><Toggle checked={settings.fb_auto_reply_enabled} onChange={(v) => save({ fb_auto_reply_enabled: v })} /></div>
          <div className="sm:col-span-2">
            <TextArea label="Extra na bilin sa Facebook auto-reply (optional) — hal. 'Laging i-invite sa Messenger kapag presyo ang tanong'" value={settings.fb_reply_instructions} rows={2}
              onChange={(v) => setSettings((s) => ({ ...s, fb_reply_instructions: v.slice(0, 600) }))} />
            <p className="mt-1 text-[11px] text-slate-500">Real-time ang reply sa comment sa Page. Kapag hindi sigurado ang AI (presyo, order, reklamo), magpapadala ito ng hand-off reply at kukulitin ni Argus ang team. Kailangan ng Facebook webhook (FB_APP_SECRET + FB_VERIFY_TOKEN) at token na may pages_manage_engagement.</p>
          </div>
          <Input label="Ilang minuto bago ituring na na-miss" type="number" value={String(settings.watchdog_grace_minutes)} onChange={(v) => setSettings((s) => ({ ...s, watchdog_grace_minutes: num(v, 1, 1440, 15) }))} />
          <Input label="Paalala kada ilang minuto (min 10)" type="number" value={String(settings.watchdog_nag_minutes)} onChange={(v) => setSettings((s) => ({ ...s, watchdog_nag_minutes: num(v, 10, 1440, 30) }))} />
          <Input label="Sino ang ita-tag (hal. @everyone sa Discord, o @juan @maria sa Telegram)" value={settings.watchdog_mention} onChange={(v) => setSettings((s) => ({ ...s, watchdog_mention: v.slice(0, 200) }))} />
          <div className="grid grid-cols-2 gap-3">
            <Input label="Quiet hours simula (oras sa PH, 0-23)" type="number" value={String(settings.watchdog_quiet_start)} onChange={(v) => setSettings((s) => ({ ...s, watchdog_quiet_start: num(v, 0, 23, 0) }))} />
            <Input label="Quiet hours hanggang" type="number" value={String(settings.watchdog_quiet_end)} onChange={(v) => setSettings((s) => ({ ...s, watchdog_quiet_end: num(v, 0, 23, 0) }))} />
          </div>
          <p className="text-[11px] text-slate-500 sm:col-span-2">Quiet hours: pareho ang simula at hanggang = walang quiet hours. Halimbawa 22 → 7 = walang paalala mula 10PM hanggang 7AM.</p>
          <div className="sm:col-span-2">
            <Button disabled={busy !== ''} onClick={() => act('save', () => adminWrite('bot_settings', 'update', { id: 1, row: {
              watchdog_grace_minutes: settings.watchdog_grace_minutes, watchdog_nag_minutes: settings.watchdog_nag_minutes, watchdog_mention: settings.watchdog_mention,
              watchdog_quiet_start: settings.watchdog_quiet_start, watchdog_quiet_end: settings.watchdog_quiet_end,
              fb_reply_instructions: settings.fb_reply_instructions,
            } }).then(() => setMsg({ ok: true, text: 'Na-save ang settings.' })))}><BellRing className="h-4 w-4" /> I-save ang settings</Button>
          </div>
        </div>
      </Card>

      {closed.length > 0 && (
        <Card>
          <CardHeader title="Kamakailang naayos" />
          <ul className="divide-y divide-white/[0.06]">
            {closed.slice(0, 12).map((i) => (
              <li key={i.id} className="flex items-center gap-3 px-5 py-2.5 text-xs text-slate-400">
                <Badge tone={i.status === 'dismissed' ? 'slate' : 'green'}>{i.status === 'fixed' ? 'naayos' : i.status === 'handled' ? 'tapos' : 'ignored'}</Badge>
                <span className="min-w-0 flex-1 truncate">{i.title}</span>
              </li>
            ))}
          </ul>
        </Card>
      )}
    </div>
  );
}
