import { createFileRoute } from '@tanstack/react-router';

// The app's server functions (same names as the original backend functions).
// Public path on purpose: Facebook and click links call it from outside. Every handler verifies its caller itself.
const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey, X-App-Passcode',
};

async function dispatch(name: string, request: Request) {
  // The Facebook webhook is background work triggered from outside: only the ACTIVE deployment may answer it,
  // otherwise two deployments registered at Meta would both reply to the same comment.
  if (name === 'fb-webhook') {
    const { checkActiveDeployment } = await import('@/server/deployment-guard');
    const guard = checkActiveDeployment(request);
    if (!guard.allowed) {
      console.warn(`[fb-webhook] ignored on ${guard.host}: ${guard.reason}`);
      // GET = Meta's verification handshake -> refuse; POST = comment events -> 200 so Meta doesn't retry here.
      return request.method === 'GET'
        ? new Response('Inactive deployment', { status: 403 })
        : Response.json({ ok: true, skipped: true, reason: guard.reason });
    }
  }
  const { runBotFunction } = await import('@/server/bot/registry');
  return runBotFunction(name, request);
}

export const Route = createFileRoute('/api/public/bot/$fn')({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204, headers: CORS }),
      GET: async ({ request, params }) => {
        // only the Facebook webhook check and click redirects use GET
        if (params.fn !== 'fb-webhook' && params.fn !== 'track-click') return new Response('Method not allowed', { status: 405 });
        return dispatch(params.fn, request);
      },
      POST: async ({ request, params }) => dispatch(params.fn, request),
    },
  },
});
