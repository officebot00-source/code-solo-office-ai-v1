import { createFileRoute } from '@tanstack/react-router';
import { authenticateCronRequest } from '@/integrations/supabase/cron-auth';

// One scheduled call every minute runs the 24/7 bots on their original cadence:
// worker every minute, X replies every 2, Watchdog every 5, Shared Brain reflector every 30.
export const Route = createFileRoute('/api/public/cron/tick')({
  server: {
    handlers: {
      POST: async ({ request }) => {
        // 1) who is calling: CRON_SECRET (Netlify) or LOVABLE_CRON_SECRET (Lovable schedule)
        const { authenticateTick, checkActiveDeployment, claimTick } = await import('@/server/deployment-guard');
        const authFailure = await authenticateTick(request, authenticateCronRequest);
        if (authFailure) return authFailure;

        // 2) is THIS deployment the active one? If not, answer 200 + skipped so schedulers don't retry or alarm.
        const guard = checkActiveDeployment(request);
        if (!guard.allowed) {
          console.warn(`[cron.tick] skipped on ${guard.host}: ${guard.reason}`);
          return Response.json({ ok: true, skipped: true, reason: guard.reason });
        }

        const { runBotFunction, CRON_JOBS, REALTIME_JOBS } = await import('@/server/bot/registry');
        const serviceKey = process.env['SUPABASE_SERVICE_ROLE_KEY'] ?? '';
        const minute = Math.floor(Date.now() / 60_000);

        // 3) one tick per minute across every deployment running this code (retries, overlaps, double schedules)
        const { supabaseAdmin } = await import('@/integrations/supabase/client.server');
        if (!(await claimTick(supabaseAdmin as never, minute, guard.host))) {
          return Response.json({ ok: true, skipped: true, reason: 'this minute was already handled by another run' });
        }
        const due = [...CRON_JOBS.filter((j) => minute % j.everyMinutes === 0), ...REALTIME_JOBS];

        // The bots recognise a trusted scheduled call by the service bearer (same as the original pg_cron call).
        const results = await Promise.allSettled(
          due.map(async (j) => {
            const res = await runBotFunction(
              j.name,
              new Request(request.url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${serviceKey}` },
                body: '{}',
              }),
            );
            return { job: j.name, status: res.status };
          }),
        );
        return Response.json({
          ok: true,
          ran: results.map((r, i) => (r.status === 'fulfilled' ? r.value : { job: due[i]?.name, error: String(r.reason) })),
        });
      },
    },
  },
});
