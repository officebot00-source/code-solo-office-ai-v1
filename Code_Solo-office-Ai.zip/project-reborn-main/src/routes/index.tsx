import { createFileRoute } from '@tanstack/react-router';
import App from '@/components/app/App';

// The office runs in the browser only (3D scene, voice, saved password), so this page is not server-rendered.
export const Route = createFileRoute('/')({
  ssr: false,
  head: () => ({
    meta: [
      { title: 'Code Ai Office — AI Social Auto-Post & Invite Bot' },
      { name: 'description', content: 'A 3D office of AI bots that write, schedule and publish game promos, reply to comments and invite players 24/7.' },
      { property: 'og:title', content: 'Code Ai Office — AI Social Auto-Post & Invite Bot' },
      { property: 'og:description', content: 'A 3D office of AI bots that write, schedule and publish game promos, reply to comments and invite players 24/7.' },
      { property: 'og:type', content: 'website' },
      { name: 'twitter:card', content: 'summary_large_image' },
    ],
  }),
  component: App,
  pendingComponent: () => (
    <div className="flex min-h-screen items-center justify-center">
      <div className="office-spinner" />
    </div>
  ),
});
