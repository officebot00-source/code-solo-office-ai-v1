export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      ab_results: {
        Row: {
          ctr_a: number
          ctr_b: number
          decided_at: string
          game_id: string | null
          variant_group: string
          winner: string
        }
        Insert: {
          ctr_a?: number
          ctr_b?: number
          decided_at?: string
          game_id?: string | null
          variant_group: string
          winner: string
        }
        Update: {
          ctr_a?: number
          ctr_b?: number
          decided_at?: string
          game_id?: string | null
          variant_group?: string
          winner?: string
        }
        Relationships: [
          {
            foreignKeyName: "ab_results_game_id_fkey"
            columns: ["game_id"]
            isOneToOne: false
            referencedRelation: "games"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_action_logs: {
        Row: {
          action_type: string
          applied_rule_ids: string[]
          bot_id: string | null
          content_sent: string
          created_at: string | null
          id: string
          is_processed: boolean | null
          metrics: Json | null
          performance_score: number | null
          platform: string
          source_ref: string | null
        }
        Insert: {
          action_type: string
          applied_rule_ids?: string[]
          bot_id?: string | null
          content_sent: string
          created_at?: string | null
          id?: string
          is_processed?: boolean | null
          metrics?: Json | null
          performance_score?: number | null
          platform: string
          source_ref?: string | null
        }
        Update: {
          action_type?: string
          applied_rule_ids?: string[]
          bot_id?: string | null
          content_sent?: string
          created_at?: string | null
          id?: string
          is_processed?: boolean | null
          metrics?: Json | null
          performance_score?: number | null
          platform?: string
          source_ref?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "bot_action_logs_bot_id_fkey"
            columns: ["bot_id"]
            isOneToOne: false
            referencedRelation: "employee_bots"
            referencedColumns: ["id"]
          },
        ]
      }
      bot_logs: {
        Row: {
          created_at: string
          id: string
          level: string
          message: string
          source: string
        }
        Insert: {
          created_at?: string
          id?: string
          level?: string
          message: string
          source?: string
        }
        Update: {
          created_at?: string
          id?: string
          level?: string
          message?: string
          source?: string
        }
        Relationships: []
      }
      bot_settings: {
        Row: {
          auto_pilot_enabled: boolean
          est_audience: number
          fb_auto_reply_enabled: boolean
          fb_reply_instructions: string
          id: number
          idea_lab_auto_approve: boolean
          idea_lab_min_logs: number
          max_invites_per_hour: number
          max_posts_per_hour: number
          min_queue_size: number
          platform_discord: boolean
          platform_facebook: boolean
          platform_telegram: boolean
          platform_twitter: boolean
          updated_at: string
          watchdog_enabled: boolean
          watchdog_grace_minutes: number
          watchdog_mention: string
          watchdog_nag_minutes: number
          watchdog_quiet_end: number
          watchdog_quiet_start: number
          winner_min_clicks: number
          x_auto_reply_enabled: boolean
        }
        Insert: {
          auto_pilot_enabled?: boolean
          est_audience?: number
          fb_auto_reply_enabled?: boolean
          fb_reply_instructions?: string
          id?: number
          idea_lab_auto_approve?: boolean
          idea_lab_min_logs?: number
          max_invites_per_hour?: number
          max_posts_per_hour?: number
          min_queue_size?: number
          platform_discord?: boolean
          platform_facebook?: boolean
          platform_telegram?: boolean
          platform_twitter?: boolean
          updated_at?: string
          watchdog_enabled?: boolean
          watchdog_grace_minutes?: number
          watchdog_mention?: string
          watchdog_nag_minutes?: number
          watchdog_quiet_end?: number
          watchdog_quiet_start?: number
          winner_min_clicks?: number
          x_auto_reply_enabled?: boolean
        }
        Update: {
          auto_pilot_enabled?: boolean
          est_audience?: number
          fb_auto_reply_enabled?: boolean
          fb_reply_instructions?: string
          id?: number
          idea_lab_auto_approve?: boolean
          idea_lab_min_logs?: number
          max_invites_per_hour?: number
          max_posts_per_hour?: number
          min_queue_size?: number
          platform_discord?: boolean
          platform_facebook?: boolean
          platform_telegram?: boolean
          platform_twitter?: boolean
          updated_at?: string
          watchdog_enabled?: boolean
          watchdog_grace_minutes?: number
          watchdog_mention?: string
          watchdog_nag_minutes?: number
          watchdog_quiet_end?: number
          watchdog_quiet_start?: number
          winner_min_clicks?: number
          x_auto_reply_enabled?: boolean
        }
        Relationships: []
      }
      bot_state: {
        Row: {
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          key: string
          updated_at?: string
          value?: Json
        }
        Update: {
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: []
      }
      brain_sync_events: {
        Row: {
          brain_item_id: string | null
          created_at: string | null
          event_type: string
          id: string
          learned_by_bot_id: string | null
        }
        Insert: {
          brain_item_id?: string | null
          created_at?: string | null
          event_type: string
          id?: string
          learned_by_bot_id?: string | null
        }
        Update: {
          brain_item_id?: string | null
          created_at?: string | null
          event_type?: string
          id?: string
          learned_by_bot_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "brain_sync_events_brain_item_id_fkey"
            columns: ["brain_item_id"]
            isOneToOne: false
            referencedRelation: "idea_lab_brain"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "brain_sync_events_learned_by_bot_id_fkey"
            columns: ["learned_by_bot_id"]
            isOneToOne: false
            referencedRelation: "employee_bots"
            referencedColumns: ["id"]
          },
        ]
      }
      comment_replies: {
        Row: {
          brain_rule_ids: string[]
          comment_id: string
          comment_text: string
          created_at: string
          error: string | null
          platform: string
          post_id: string
          reply_id: string | null
          reply_text: string | null
          status: string
          user_name: string
        }
        Insert: {
          brain_rule_ids?: string[]
          comment_id: string
          comment_text?: string
          created_at?: string
          error?: string | null
          platform?: string
          post_id?: string
          reply_id?: string | null
          reply_text?: string | null
          status?: string
          user_name?: string
        }
        Update: {
          brain_rule_ids?: string[]
          comment_id?: string
          comment_text?: string
          created_at?: string
          error?: string | null
          platform?: string
          post_id?: string
          reply_id?: string | null
          reply_text?: string | null
          status?: string
          user_name?: string
        }
        Relationships: []
      }
      employee_bots: {
        Row: {
          created_at: string | null
          id: string
          name: string
          platform: string
          role: string
          status: string | null
        }
        Insert: {
          created_at?: string | null
          id?: string
          name: string
          platform: string
          role: string
          status?: string | null
        }
        Update: {
          created_at?: string | null
          id?: string
          name?: string
          platform?: string
          role?: string
          status?: string | null
        }
        Relationships: []
      }
      games: {
        Row: {
          active: boolean
          banner_image: string
          created_at: string
          description: string
          genre: string
          id: string
          promo_link: string
          title: string
        }
        Insert: {
          active?: boolean
          banner_image?: string
          created_at?: string
          description?: string
          genre?: string
          id?: string
          promo_link?: string
          title: string
        }
        Update: {
          active?: boolean
          banner_image?: string
          created_at?: string
          description?: string
          genre?: string
          id?: string
          promo_link?: string
          title?: string
        }
        Relationships: []
      }
      idea_lab_brain: {
        Row: {
          category: string
          confidence_score: number | null
          created_at: string | null
          embedding: string | null
          id: string
          insight_rule: string
          is_core_guardrail: boolean | null
          platform: string | null
          source_bot_id: string | null
          status: string | null
          title: string
          updated_at: string | null
          usage_count: number | null
        }
        Insert: {
          category: string
          confidence_score?: number | null
          created_at?: string | null
          embedding?: string | null
          id?: string
          insight_rule: string
          is_core_guardrail?: boolean | null
          platform?: string | null
          source_bot_id?: string | null
          status?: string | null
          title: string
          updated_at?: string | null
          usage_count?: number | null
        }
        Update: {
          category?: string
          confidence_score?: number | null
          created_at?: string | null
          embedding?: string | null
          id?: string
          insight_rule?: string
          is_core_guardrail?: boolean | null
          platform?: string | null
          source_bot_id?: string | null
          status?: string | null
          title?: string
          updated_at?: string | null
          usage_count?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "idea_lab_brain_source_bot_id_fkey"
            columns: ["source_bot_id"]
            isOneToOne: false
            referencedRelation: "employee_bots"
            referencedColumns: ["id"]
          },
        ]
      }
      integration_secrets: {
        Row: {
          provider: string
          secrets: Json
          updated_at: string
        }
        Insert: {
          provider: string
          secrets?: Json
          updated_at?: string
        }
        Update: {
          provider?: string
          secrets?: Json
          updated_at?: string
        }
        Relationships: []
      }
      integrations: {
        Row: {
          config: Json
          created_at: string
          id: string
          label: string
          provider: string
          status: string
        }
        Insert: {
          config?: Json
          created_at?: string
          id?: string
          label?: string
          provider: string
          status?: string
        }
        Update: {
          config?: Json
          created_at?: string
          id?: string
          label?: string
          provider?: string
          status?: string
        }
        Relationships: []
      }
      invite_queue: {
        Row: {
          created_at: string
          error: string | null
          game_id: string | null
          id: string
          message: string
          platform: string
          sent_at: string | null
          status: string
          target_user: string
        }
        Insert: {
          created_at?: string
          error?: string | null
          game_id?: string | null
          id?: string
          message?: string
          platform?: string
          sent_at?: string | null
          status?: string
          target_user: string
        }
        Update: {
          created_at?: string
          error?: string | null
          game_id?: string | null
          id?: string
          message?: string
          platform?: string
          sent_at?: string | null
          status?: string
          target_user?: string
        }
        Relationships: [
          {
            foreignKeyName: "invite_queue_game_id_fkey"
            columns: ["game_id"]
            isOneToOne: false
            referencedRelation: "games"
            referencedColumns: ["id"]
          },
        ]
      }
      invite_rules: {
        Row: {
          created_at: string
          delay_max_seconds: number
          delay_min_seconds: number
          enabled: boolean
          id: string
          max_per_hour: number
          message_template: string
          name: string
          platform: string
          target_webhook: string
          trigger_keywords: string[]
          trigger_type: string
        }
        Insert: {
          created_at?: string
          delay_max_seconds?: number
          delay_min_seconds?: number
          enabled?: boolean
          id?: string
          max_per_hour?: number
          message_template?: string
          name: string
          platform?: string
          target_webhook?: string
          trigger_keywords?: string[]
          trigger_type?: string
        }
        Update: {
          created_at?: string
          delay_max_seconds?: number
          delay_min_seconds?: number
          enabled?: boolean
          id?: string
          max_per_hour?: number
          message_template?: string
          name?: string
          platform?: string
          target_webhook?: string
          trigger_keywords?: string[]
          trigger_type?: string
        }
        Relationships: []
      }
      posts: {
        Row: {
          content: string
          created_at: string
          game_id: string | null
          game_title: string
          hashtags: string
          id: string
          platforms: string[]
          published_at: string | null
          scheduled_at: string
          status: string
          tone: string
        }
        Insert: {
          content?: string
          created_at?: string
          game_id?: string | null
          game_title?: string
          hashtags?: string
          id?: string
          platforms?: string[]
          published_at?: string | null
          scheduled_at?: string
          status?: string
          tone?: string
        }
        Update: {
          content?: string
          created_at?: string
          game_id?: string | null
          game_title?: string
          hashtags?: string
          id?: string
          platforms?: string[]
          published_at?: string | null
          scheduled_at?: string
          status?: string
          tone?: string
        }
        Relationships: [
          {
            foreignKeyName: "posts_game_id_fkey"
            columns: ["game_id"]
            isOneToOne: false
            referencedRelation: "games"
            referencedColumns: ["id"]
          },
        ]
      }
      scheduled_posts: {
        Row: {
          brain_rule_ids: string[]
          claimed_at: string | null
          clicks: number
          content: string
          created_at: string
          error: string | null
          game_id: string | null
          game_title: string
          hashtags: string
          id: string
          impressions: number
          platforms: string[]
          published_at: string | null
          results: Json | null
          scheduled_at: string
          status: string
          tone: string
          variant: string | null
          variant_group: string | null
        }
        Insert: {
          brain_rule_ids?: string[]
          claimed_at?: string | null
          clicks?: number
          content?: string
          created_at?: string
          error?: string | null
          game_id?: string | null
          game_title?: string
          hashtags?: string
          id?: string
          impressions?: number
          platforms?: string[]
          published_at?: string | null
          results?: Json | null
          scheduled_at?: string
          status?: string
          tone?: string
          variant?: string | null
          variant_group?: string | null
        }
        Update: {
          brain_rule_ids?: string[]
          claimed_at?: string | null
          clicks?: number
          content?: string
          created_at?: string
          error?: string | null
          game_id?: string | null
          game_title?: string
          hashtags?: string
          id?: string
          impressions?: number
          platforms?: string[]
          published_at?: string | null
          results?: Json | null
          scheduled_at?: string
          status?: string
          tone?: string
          variant?: string | null
          variant_group?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "scheduled_posts_game_id_fkey"
            columns: ["game_id"]
            isOneToOne: false
            referencedRelation: "games"
            referencedColumns: ["id"]
          },
        ]
      }
      watchdog_issues: {
        Row: {
          detail: string
          first_seen_at: string
          id: string
          issue_key: string
          item_at: string
          kind: string
          last_nagged_at: string | null
          nag_count: number
          platform: string
          ref_id: string
          resolved_at: string | null
          resolved_reason: string | null
          snoozed_until: string | null
          status: string
          title: string
          url: string
        }
        Insert: {
          detail?: string
          first_seen_at?: string
          id?: string
          issue_key: string
          item_at?: string
          kind: string
          last_nagged_at?: string | null
          nag_count?: number
          platform?: string
          ref_id?: string
          resolved_at?: string | null
          resolved_reason?: string | null
          snoozed_until?: string | null
          status?: string
          title?: string
          url?: string
        }
        Update: {
          detail?: string
          first_seen_at?: string
          id?: string
          issue_key?: string
          item_at?: string
          kind?: string
          last_nagged_at?: string | null
          nag_count?: number
          platform?: string
          ref_id?: string
          resolved_at?: string | null
          resolved_reason?: string | null
          snoozed_until?: string | null
          status?: string
          title?: string
          url?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      adjust_rule: {
        Args: { p_bot?: string; p_delta: number; p_id: string }
        Returns: string
      }
      bump_rule_usage: { Args: { p_ids: string[] }; Returns: undefined }
      increment_click: {
        Args: { p_group: string; p_variant: string }
        Returns: string
      }
      match_brain_rules: {
        Args: { p_limit?: number; p_platforms: string[]; q: string }
        Returns: {
          category: string
          confidence_score: number
          id: string
          insight_rule: string
          is_core_guardrail: boolean
          platform: string
          similarity: number
          title: string
        }[]
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
