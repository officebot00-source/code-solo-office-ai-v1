import { botFnUrl } from './supabase';
import { getPasscode, LOCK_EVENT, setPasscode } from './publish';
import type { EnhancePreset, VideoJob, VideoSettings } from './video';

export type PublicVideoJob = Omit<VideoJob, 'output_path'> & { has_output: boolean };
export interface EditorStatus { settings: VideoSettings; editors: Record<'ffmpeg' | 'cloud' | 'mock', { ok: boolean; reason?: string }>; media_folder_enabled: boolean; connected_platforms?: string[] }

async function call<T>(body: Record<string, unknown>): Promise<T> {
  let res: Response;
  try {
    res = await fetch(botFnUrl('video-editor-bot'), {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'x-app-passcode': getPasscode() }, body: JSON.stringify(body),
    });
  } catch {
    throw new Error(navigator.onLine === false ? 'Walang internet connection.' : 'Hindi maabot ang video bot. Subukan ulit mamaya.');
  }
  let data: unknown = null;
  try { data = await res.json(); } catch { /* not json */ }
  if (res.status === 401) { setPasscode(''); window.dispatchEvent(new Event(LOCK_EVENT)); throw new Error('Wrong or missing password.'); }
  if (!res.ok) throw new Error((data as { error?: string })?.error ?? `Request failed (${res.status})`);
  return data as T;
}

export interface EnqueueInput {
  input: string;
  edit: { aspect: string; start_sec?: number; end_sec?: number; overlay_text?: string; normalize_audio: boolean };
  post: { title: string; caption: string; tags: string[]; platforms: string[] };
  realtime: boolean;
  dry_run: boolean;
  /** true = the bot waits for the boss to approve before posting. */
  needs_approval?: boolean;
}

export interface EnhanceInput {
  /** Link to the boss's own finished video (public https). */
  input: string;
  preset: EnhancePreset;
  aspect?: string;
  title?: string;
  /** Empty = download only, nothing is posted. */
  platforms: string[];
  dry_run?: boolean;
}

export const videoApi = {
  /** Assigns the boss's own video link to Reel to enhance. He watches it first; with no platform it is download-only. */
  enhance: (b: EnhanceInput) => call<{ job: PublicVideoJob }>({
    action: 'enqueue', source: 'ui', task: 'enhance', input: b.input,
    edit: { aspect: b.aspect ?? 'original', normalize_audio: true, enhance: b.preset },
    post: { title: b.title ?? '', caption: '', tags: [], platforms: b.platforms },
    realtime: false, ...(b.dry_run !== undefined ? { dry_run: b.dry_run } : {}),
  }).then((r) => r.job),
  list: () => call<{ jobs: PublicVideoJob[] }>({ action: 'list' }).then((r) => r.jobs),
  status: () => call<EditorStatus>({ action: 'status' }),
  enqueue: (b: EnqueueInput) => call<{ job: PublicVideoJob }>({ action: 'enqueue', source: 'ui', ...b }).then((r) => r.job),
  setSettings: (settings: Partial<VideoSettings>) => call<{ settings: VideoSettings }>({ action: 'settings_set', settings }).then((r) => r.settings),
  act: (action: 'retry' | 'pause' | 'resume' | 'post_now', id: string) => call<{ ok: boolean }>({ action, id }),
  tick: () => call<{ ok: boolean }>({ action: 'tick' }),
  /** The bot makes a video from a saved game (a given one, or it picks). It waits for approval. */
  generateGame: (o: { game_id?: string; variant?: number; platforms?: string[] } = {}) => call<{ job: PublicVideoJob }>({ action: 'generate_game', source: 'ui', ...o }).then((r) => r.job),
  approve: (id: string) => call<{ ok: boolean }>({ action: 'approve', id }),
  reject: (id: string, reason = '') => call<{ ok: boolean }>({ action: 'reject', id, reason }),
  /** Downloads the video (needs the password header) and returns a playable object URL — call URL.revokeObjectURL when done. */
  async preview(id: string): Promise<string> {
    let res: Response;
    try {
      res = await fetch(botFnUrl('video-editor-bot'), { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-app-passcode': getPasscode() }, body: JSON.stringify({ action: 'preview', id }) });
    } catch { throw new Error('Hindi maabot ang video bot. Subukan ulit mamaya.'); }
    if (res.status === 401) { setPasscode(''); window.dispatchEvent(new Event(LOCK_EVENT)); throw new Error('Wrong or missing password.'); }
    const type = res.headers.get('content-type') ?? '';
    if (!res.ok) { const j = (await res.json().catch(() => null)) as { error?: string } | null; throw new Error(j?.error ?? `Request failed (${res.status})`); }
    if (type.includes('application/json')) { const j = (await res.json()) as { url?: string }; if (j.url) return j.url; throw new Error('Walang video na mapapanood.'); }
    return URL.createObjectURL(await res.blob());
  },
};
