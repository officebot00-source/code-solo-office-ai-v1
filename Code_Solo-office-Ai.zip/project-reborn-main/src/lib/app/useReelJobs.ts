import { useEffect, useMemo, useState } from 'react';
import { videoApi } from './videoApi';
import { reelStatus, type ReelStatus } from './videoStaff';
import type { VideoJob } from './video';

export type ReelJob = Pick<VideoJob, 'status' | 'task' | 'updated_at' | 'post'>;

/**
 * One shared poller for Reel's video jobs: the 3D office and the status bar both read it,
 * so the video bot is asked once (every 8s, only while the tab is visible), never twice.
 * `null` = not loaded yet. Nothing here is invented: it is only what the video bot returns.
 */
let jobs: ReelJob[] | null = null;
const listeners = new Set<(j: ReelJob[] | null) => void>();
let timer: number | null = null;
let alive = false;

const publish = (j: ReelJob[] | null) => {
  jobs = j;
  listeners.forEach((l) => l(j));
};

const load = () => {
  if (typeof document !== 'undefined' && document.hidden) return;
  videoApi
    .list()
    .then((j) => { if (alive) publish(j); })
    .catch(() => { if (alive && jobs === null) publish([]); });
};

function start() {
  if (timer !== null) return;
  alive = true;
  load();
  timer = window.setInterval(load, 8000);
}

function stop() {
  if (listeners.size > 0) return;
  alive = false;
  if (timer !== null) window.clearInterval(timer);
  timer = null;
}

export function useReelJobs(): ReelJob[] | null {
  const [value, setValue] = useState<ReelJob[] | null>(jobs);
  useEffect(() => {
    listeners.add(setValue);
    setValue(jobs);
    start();
    return () => {
      listeners.delete(setValue);
      stop();
    };
  }, []);
  return value;
}

/** Reel's status worked out from the real jobs (no made-up activity). */
export function useReelStatus(): ReelStatus {
  const j = useReelJobs();
  return useMemo(() => reelStatus(j ?? []), [j]);
}
