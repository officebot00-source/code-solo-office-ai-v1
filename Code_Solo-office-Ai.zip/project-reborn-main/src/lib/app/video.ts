// Video Editor Bot + Real-Time Auto-Poster — shared contracts and PURE helpers.
// No network, no database, no Node APIs here, so the browser, the server bot and the tests can all import it.

export type VideoJobStatus = 'queued' | 'editing' | 'edited' | 'awaiting_approval' | 'posting' | 'posted' | 'failed' | 'paused' | 'rejected' | 'done';
/** What the job is for: a plain edit, a game clip, or "enhance my own video" (Reel). */
export type VideoTask = 'edit' | 'enhance' | 'game';
/** The employee bot that does the video work. Blaze only posts; Reel makes / edits / enhances. */
export const VIDEO_EDITOR_ASSIGNEE = 'reel';
export type VideoAspect = 'original' | '9:16' | '16:9' | '1:1';
export type VideoJobSource = 'ui' | 'webhook' | 'boss' | 'worker';
export type VideoEditorChoice = 'auto' | 'ffmpeg' | 'cloud' | 'mock';

export const VIDEO_STATUSES: VideoJobStatus[] = ['queued', 'editing', 'edited', 'awaiting_approval', 'posting', 'posted', 'failed', 'paused', 'rejected', 'done'];
export const VIDEO_ASPECTS: { value: VideoAspect; label: string }[] = [
  { value: 'original', label: 'Original' },
  { value: '9:16', label: '9:16 Vertical (Reels / Shorts / TikTok)' },
  { value: '16:9', label: '16:9 Horizontal' },
  { value: '1:1', label: '1:1 Square' },
];

/* ---------- enhance presets (Reel improves a video the boss already made) ---------- */
export type EnhancePreset = 'auto' | 'sharper' | 'vivid' | 'low_light' | 'clean_audio';
export const ENHANCE_PRESETS: { value: EnhancePreset; label: string; hint: string }[] = [
  { value: 'auto', label: 'Auto Enhance (inirerekomenda)', hint: 'Linis ng ingay, mas buhay na kulay, mas malinaw, at pantay na lakas ng boses.' },
  { value: 'sharper', label: 'Mas Malinaw (Sharpen)', hint: 'Dagdag linaw sa malabong video.' },
  { value: 'vivid', label: 'Makulay (Vivid)', hint: 'Mas matingkad ang kulay at contrast.' },
  { value: 'low_light', label: 'Madilim na video (Low light)', hint: 'Pinaliliwanag at nililinis ang ingay sa dilim.' },
  { value: 'clean_audio', label: 'Linisin ang audio lang', hint: 'Tanggal ang ugong at pantay ang lakas ng boses; hindi gagalawin ang larawan.' },
];
export const isEnhancePreset = (v: unknown): v is EnhancePreset => ENHANCE_PRESETS.some((p) => p.value === v);

/** ffmpeg filters for a preset. Only long-standing, always-built-in filters (hqdn3d, eq, unsharp, highpass, lowpass). */
export function enhanceFilters(preset: EnhancePreset): { vf: string[]; af: string[]; normalize: boolean } {
  switch (preset) {
    case 'auto': return { vf: ['hqdn3d=1.5:1.5:6:6', 'eq=contrast=1.06:saturation=1.12', 'unsharp=5:5:0.6:5:5:0.0'], af: ['highpass=f=80'], normalize: true };
    case 'sharper': return { vf: ['unsharp=7:7:1.0:7:7:0.0'], af: [], normalize: false };
    case 'vivid': return { vf: ['eq=contrast=1.1:saturation=1.35:gamma=1.02'], af: [], normalize: false };
    case 'low_light': return { vf: ['hqdn3d=2:2:6:6', 'eq=brightness=0.06:contrast=1.12:gamma=1.15'], af: [], normalize: false };
    case 'clean_audio': return { vf: [], af: ['highpass=f=80', 'lowpass=f=14000'], normalize: true };
  }
}

export const MAX_CLIP_SECONDS = 600;
export const MAX_OVERLAY_CHARS = 140;
export const VIDEO_PLATFORMS = ['facebook', 'twitter', 'discord', 'telegram'] as const;

export interface VideoEditSpec {
  start_sec?: number;
  end_sec?: number;
  aspect: VideoAspect;
  /** Text burned into the video (lower third). Optional. */
  overlay_text?: string;
  normalize_audio: boolean;
  /** 0.1 – 4 multiplier. Optional. */
  volume?: number;
  /** 'image' = build a short clip from a still (a game banner) instead of trimming a video. Default 'video'. */
  kind?: 'video' | 'image';
  /** Length of an image clip, 3–60 seconds. */
  duration_sec?: number;
  /** Big headline burned into an image clip. */
  title_text?: string;
  /** Enhance preset (Reel). Applied after resizing and before any text overlay. */
  enhance?: EnhancePreset;
}

export interface VideoPostSpec {
  title: string;
  caption: string;
  tags: string[];
  platforms: string[];
  game_title?: string;
  /** Link to the game; always kept at the end of the caption. */
  link?: string;
}

export interface VideoStageEntry { at: string; status: VideoJobStatus; note: string }
export interface VideoPostResult { platform: string; id?: string; url?: string; note?: string }

export interface VideoJob {
  id: string;
  status: VideoJobStatus;
  source: VideoJobSource;
  input: string;
  spec: VideoEditSpec;
  post: VideoPostSpec;
  /** true = go straight from edit to post without waiting (when the real-time switch is on). */
  realtime: boolean;
  dry_run: boolean;
  attempts: number;
  max_attempts: number;
  created_at: string;
  updated_at: string;
  stages: VideoStageEntry[];
  editor?: 'ffmpeg' | 'cloud' | 'mock';
  /** Server-side temp path of the edited file (never sent to the browser). */
  output_path?: string;
  output_url?: string;
  warnings: string[];
  error?: string | null;
  /** Set when the failure looks temporary (timeout, network, 5xx): the worker retries it by itself. */
  auto_retry?: boolean;
  retry_after?: string;
  results?: VideoPostResult[];
  /** Status to go back to when a paused job is resumed. */
  paused_from?: VideoJobStatus;
  /** true = the bot may NOT post this video until the boss approves it. */
  needs_approval?: boolean;
  approved?: boolean;
  approved_at?: string;
  rejected_reason?: string;
  /** Set when the video was made from a saved game (input is then `game:<id>`). */
  game_id?: string;
  /** Which hook/wording variant of the game video this is (a redo uses the next one). */
  variant?: number;
  /** What the job is for. Missing = a plain edit (older jobs). */
  task?: VideoTask;
  /** The employee bot doing the work ('reel'). */
  assignee?: string;
}

export interface VideoSettings {
  /** Master real-time switch: edited videos are posted immediately. Off = they wait at "edited" for a manual post. */
  realtime_enabled: boolean;
  /** Safe mode: edit with the mock adapter and never call a social API. */
  dry_run: boolean;
  editor: VideoEditorChoice;
  default_platforms: string[];
  /** The bot makes game videos by itself (they always wait for the boss's approval). */
  auto_generate?: boolean;
  /** How many game videos the bot makes per day (Philippine time). */
  auto_per_day?: number;
}

export const DEFAULT_VIDEO_SETTINGS: VideoSettings = {
  realtime_enabled: true,
  dry_run: false,
  editor: 'auto',
  default_platforms: [],
  auto_generate: false,
  auto_per_day: 1,
};

/** The bot never keeps more than this many finished videos waiting for the boss. */
export const MAX_PENDING_REVIEW = 3;
export const MAX_AUTO_PER_DAY = 5;

export const VIDEO_JOB_PREFIX = 'video_job:';
export const VIDEO_SETTINGS_KEY = 'video_settings';

/* ---------- state machine ---------- */
const NEXT: Record<VideoJobStatus, VideoJobStatus[]> = {
  queued: ['editing', 'paused', 'failed'],
  editing: ['edited', 'awaiting_approval', 'failed', 'queued', 'paused'],
  edited: ['posting', 'paused', 'failed'],
  // The boss's decision point: approve → edited (then posts) or queued (file expired, edit again), or reject.
  // 'done' = the boss accepted an enhanced video that is NOT meant to be posted (download only). Never leads to posting.
  awaiting_approval: ['edited', 'queued', 'rejected', 'failed', 'done'],
  posting: ['posted', 'failed'],
  posted: [],
  failed: ['queued', 'edited'],
  paused: ['queued', 'edited'],
  rejected: [],
  done: [],
};

export const canTransition = (from: VideoJobStatus, to: VideoJobStatus): boolean => NEXT[from]?.includes(to) ?? false;
export const isTerminal = (s: VideoJobStatus): boolean => s === 'posted' || s === 'done';
export const isActive = (s: VideoJobStatus): boolean => s === 'queued' || s === 'editing' || s === 'edited' || s === 'awaiting_approval' || s === 'posting';
/** True while a job may not be posted yet because the boss has not said yes. */
export const isGated = (j: Pick<VideoJob, 'needs_approval' | 'approved'>): boolean => j.needs_approval === true && j.approved !== true;

/** Returns the job moved to `to` (with history), or throws when the move is not allowed. Never mutates the input. */
export function transition(job: VideoJob, to: VideoJobStatus, note: string, now = new Date(), patch: Partial<VideoJob> = {}): VideoJob {
  if (!canTransition(job.status, to)) throw new Error(`Job ${job.id}: cannot go from "${job.status}" to "${to}"`);
  const at = now.toISOString();
  return {
    ...job, ...patch, status: to, updated_at: at,
    stages: [...job.stages, { at, status: to, note: note.slice(0, 300) }].slice(-30),
  };
}

/** Decides whether a failure is worth an automatic retry (temporary problem) or needs a human (bad input / missing setup). */
export function classifyError(message: string): { transient: boolean } {
  const m = message.toLowerCase();
  const permanent = /not found|invalid|unsupported|missing|not allowed|blocked|no such|unknown platform|wrong or missing|ffmpeg is not installed|dry-run|403|401|400/.test(m);
  if (permanent) return { transient: false };
  return { transient: /timed out|timeout|econn|enotfound|network|fetch failed|socket|temporar|rate limit|429|5\d\d|unavailable/.test(m) };
}

/** 2, 4, 8 … minutes, capped at 15. */
export const backoffMs = (attempts: number): number => Math.min(15, 2 ** Math.max(1, attempts)) * 60_000;

/* ---------- input checks ---------- */
const PRIVATE_HOST = /^(localhost|.*\.local|.*\.internal|0\.0\.0\.0|127\.\d+\.\d+\.\d+|10\.\d+\.\d+\.\d+|192\.168\.\d+\.\d+|169\.254\.\d+\.\d+|172\.(1[6-9]|2\d|3[01])\.\d+\.\d+|\[?::1\]?|\[?f[cd][0-9a-f]{2}:.*)$/i;

export type MediaInput = { kind: 'url'; value: string } | { kind: 'path'; value: string };

/** Accepts public http(s) URLs, or a file path that sits inside the allowed media folder. Anything else is refused (no SSRF, no path tricks). */
export function classifyMediaInput(raw: unknown, allowedDir = ''): { ok: true; input: MediaInput } | { ok: false; error: string } {
  if (typeof raw !== 'string' || !raw.trim()) return { ok: false, error: 'Video input is required (a public http(s) URL).' };
  const v = raw.trim();
  if (v.length > 2000) return { ok: false, error: 'Video input is too long.' };
  if (/^https?:\/\//i.test(v)) {
    let u: URL;
    try { u = new URL(v); } catch { return { ok: false, error: 'Video URL is not a valid URL.' }; }
    if (u.username || u.password) return { ok: false, error: 'Video URL must not contain a username or password.' };
    if (PRIVATE_HOST.test(u.hostname)) return { ok: false, error: 'Video URL points to a private or local address, which is not allowed.' };
    return { ok: true, input: { kind: 'url', value: u.toString() } };
  }
  if (/^[a-z][a-z0-9+.-]*:/i.test(v) && !/^[a-z]:[\\/]/i.test(v)) return { ok: false, error: 'Only http(s) URLs or files inside the media folder are allowed.' };
  const dir = allowedDir.replace(/\/+$/, '');
  if (!dir) return { ok: false, error: 'Local file paths are disabled (set VIDEO_MEDIA_DIR on the server to allow a folder). Use a public URL.' };
  const norm = v.replace(/\\/g, '/');
  if (norm.split('/').includes('..') || !norm.startsWith(`${dir}/`)) return { ok: false, error: 'Local file must be inside the media folder.' };
  return { ok: true, input: { kind: 'path', value: norm } };
}

const num = (v: unknown): number | undefined => {
  if (v === undefined || v === null || v === '') return undefined;
  const n = Number(v);
  return Number.isFinite(n) ? n : NaN;
};

export function validateEditSpec(raw: unknown): { ok: true; spec: VideoEditSpec } | { ok: false; error: string } {
  const r = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const start = num(r['start_sec']), end = num(r['end_sec']), volume = num(r['volume']);
  if (Number.isNaN(start) || Number.isNaN(end) || Number.isNaN(volume)) return { ok: false, error: 'start_sec, end_sec and volume must be numbers.' };
  if (start !== undefined && start < 0) return { ok: false, error: 'start_sec cannot be negative.' };
  if (end !== undefined && end <= (start ?? 0)) return { ok: false, error: 'end_sec must be greater than start_sec.' };
  if (end !== undefined && end - (start ?? 0) > MAX_CLIP_SECONDS) return { ok: false, error: `Clip length is limited to ${MAX_CLIP_SECONDS} seconds.` };
  if (volume !== undefined && (volume < 0.1 || volume > 4)) return { ok: false, error: 'volume must be between 0.1 and 4.' };
  const aspect = (r['aspect'] ?? 'original') as VideoAspect;
  if (!VIDEO_ASPECTS.some((a) => a.value === aspect)) return { ok: false, error: 'aspect must be original, 9:16, 16:9 or 1:1.' };
  const duration = num(r['duration_sec']);
  if (Number.isNaN(duration) || (duration !== undefined && (duration < 3 || duration > 60))) return { ok: false, error: 'duration_sec must be between 3 and 60.' };
  const overlay = typeof r['overlay_text'] === 'string' ? r['overlay_text'].trim().slice(0, MAX_OVERLAY_CHARS) : '';
  const titleText = typeof r['title_text'] === 'string' ? r['title_text'].trim().slice(0, 80) : '';
  const spec: VideoEditSpec = { aspect, normalize_audio: r['normalize_audio'] !== false };
  if (r['enhance'] !== undefined && r['enhance'] !== null && r['enhance'] !== '') {
    if (!isEnhancePreset(r['enhance'])) return { ok: false, error: `enhance must be one of: ${ENHANCE_PRESETS.map((p) => p.value).join(', ')}.` };
    spec.enhance = r['enhance'];
  }
  if (r['kind'] === 'image') spec.kind = 'image';
  if (duration !== undefined) spec.duration_sec = duration;
  if (titleText) spec.title_text = titleText;
  if (start !== undefined) spec.start_sec = start;
  if (end !== undefined) spec.end_sec = end;
  if (volume !== undefined) spec.volume = volume;
  if (overlay) spec.overlay_text = overlay;
  return { ok: true, spec };
}

/** `allowNoPlatforms`: an enhanced video the boss only wants to download (nothing is ever posted). */
export function validatePostSpec(raw: unknown, defaults: string[] = [], opts: { allowNoPlatforms?: boolean } = {}): { ok: true; post: VideoPostSpec } | { ok: false; error: string } {
  const r = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  const str = (k: string, max: number) => (typeof r[k] === 'string' ? (r[k] as string).trim().slice(0, max) : '');
  const platformsIn = Array.isArray(r['platforms']) ? (r['platforms'] as unknown[]) : defaults;
  const platforms = [...new Set(platformsIn.filter((p): p is string => typeof p === 'string' && (VIDEO_PLATFORMS as readonly string[]).includes(p)))];
  if (!platforms.length && !opts.allowNoPlatforms) return { ok: false, error: 'Pick at least one platform (facebook, twitter, discord or telegram).' };
  const tagsIn = Array.isArray(r['tags']) ? (r['tags'] as unknown[]) : typeof r['tags'] === 'string' ? (r['tags'] as string).split(/[\s,]+/) : [];
  const tags = tagsIn.filter((t): t is string => typeof t === 'string').map((t) => t.trim().replace(/^#*/, '#')).filter((t) => t.length > 1 && t.length <= 40).slice(0, 10);
  const post: VideoPostSpec = { title: str('title', 120), caption: str('caption', 1500), tags, platforms };
  const game = str('game_title', 120);
  if (game) post.game_title = game;
  const link = str('link', 500);
  if (/^https?:\/\/[^\s]+$/i.test(link)) post.link = link;
  if (!post.title && !post.caption && !opts.allowNoPlatforms) return { ok: false, error: 'Give the post a title or a caption.' };
  return { ok: true, post };
}

/** Final text sent with the video. Keeps every platform inside its own length limit. */
export function buildCaption(post: VideoPostSpec, platform: string, link?: string): string {
  const parts = [post.title, post.caption].filter(Boolean).join('\n\n');
  const tags = post.tags.join(' ');
  const limits: Record<string, number> = { twitter: 270, discord: 1900, telegram: 1000, facebook: 3000 };
  const max = limits[platform] ?? 1000;
  const tail = [post.link, link, tags].filter(Boolean).join('\n');
  const room = Math.max(0, max - (tail ? tail.length + 2 : 0));
  const body = parts.length > room ? `${parts.slice(0, Math.max(0, room - 1)).trimEnd()}…` : parts;
  return [body, tail].filter(Boolean).join('\n\n').slice(0, max);
}

/* ---------- ffmpeg command builder (pure) ---------- */
const SIZE: Record<Exclude<VideoAspect, 'original'>, [number, number]> = { '9:16': [1080, 1920], '16:9': [1920, 1080], '1:1': [1080, 1080] };

/** drawtext needs these characters escaped (the text is also written to a file-less filter string). */
export function escapeDrawtext(t: string): string {
  return t.replace(/\\/g, '\\\\').replace(/'/g, '\u2019').replace(/:/g, '\\:').replace(/[\r\n]+/g, ' ');
}

export interface FfmpegPlan { args: string[]; usesText: boolean }

export function buildFfmpegArgs(o: { input: string; output: string; spec: VideoEditSpec; withText?: boolean; fontFile?: string; isUrl?: boolean }): FfmpegPlan {
  const { spec } = o;
  const args: string[] = ['-hide_banner', '-nostdin', '-loglevel', 'error', '-y'];
  if (o.isUrl) args.push('-protocol_whitelist', 'https,http,tcp,tls,crypto');
  if (spec.start_sec !== undefined && spec.start_sec > 0) args.push('-ss', String(spec.start_sec));
  args.push('-i', o.input);
  const length = spec.end_sec !== undefined ? spec.end_sec - (spec.start_sec ?? 0) : undefined;
  args.push('-t', String(Math.min(length ?? MAX_CLIP_SECONDS, MAX_CLIP_SECONDS)));
  const vf: string[] = [];
  if (spec.aspect !== 'original') {
    const [w, h] = SIZE[spec.aspect];
    vf.push(`scale=${w}:${h}:force_original_aspect_ratio=increase`, `crop=${w}:${h}`);
  }
  const enh = spec.enhance ? enhanceFilters(spec.enhance) : null;
  if (enh) vf.push(...enh.vf);
  const usesText = Boolean(spec.overlay_text) && o.withText !== false;
  if (usesText) {
    const font = o.fontFile ? `fontfile='${o.fontFile.replace(/:/g, '\\:')}':` : '';
    vf.push(`drawtext=${font}expansion=none:text='${escapeDrawtext(spec.overlay_text ?? '')}':fontcolor=white:fontsize=h/22:box=1:boxcolor=black@0.55:boxborderw=14:x=(w-text_w)/2:y=h-text_h-h/12`);
  }
  if (vf.length) args.push('-vf', vf.join(','));
  const af: string[] = [];
  if (spec.volume !== undefined && spec.volume !== 1) af.push(`volume=${spec.volume}`);
  if (enh) af.push(...enh.af);
  if (spec.normalize_audio || enh?.normalize) af.push('loudnorm=I=-16:TP=-1.5:LRA=11');
  if (af.length) args.push('-af', af.join(','));
  // an enhanced video keeps more detail (lower CRF) than a plain edit
  args.push('-c:v', 'libx264', '-preset', 'veryfast', '-crf', enh ? '20' : '23', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '128k', '-movflags', '+faststart', o.output);
  return { args, usesText };
}

export const STATUS_LABEL: Record<VideoJobStatus, string> = {
  queued: 'Nakapila', editing: 'Ine-edit', edited: 'Tapos i-edit', awaiting_approval: 'Hinihintay ang approval mo', posting: 'Pini-post', posted: 'Na-post', failed: 'Pumalya', paused: 'Naka-pause', rejected: 'Na-reject mo', done: 'Tapos na (hindi ipo-post)',
};

/* ---------- game clip (a short vertical video made from a saved game's banner) ---------- */
export const GAME_CLIP_SIZE: [number, number] = [1080, 1920];

/** Splits a headline into at most `maxLines` lines of about `maxChars` characters, never breaking inside a word. */
export function wrapLines(text: string, maxChars: number, maxLines: number): string[] {
  const words = text.replace(/\s+/g, ' ').trim().split(' ').filter(Boolean);
  const lines: string[] = [];
  let cur = '';
  for (const w of words) {
    if (cur && (cur + ' ' + w).length > maxChars) { lines.push(cur); cur = w; } else cur = cur ? `${cur} ${w}` : w;
  }
  if (cur) lines.push(cur);
  if (lines.length > maxLines) {
    const kept = lines.slice(0, maxLines);
    kept[maxLines - 1] = `${kept[maxLines - 1]!.slice(0, Math.max(0, maxChars - 1)).trimEnd()}…`;
    return kept;
  }
  return lines;
}

export interface GameClipArgs { imagePath?: string; output: string; durationSec: number; title: string; tagline?: string; cta?: string; fontFile?: string; withText?: boolean }

/** ffmpeg arguments for the game clip: slow zoom on the banner (or a dark background when there is none), headline, tagline, call-to-action, silent audio track. No shell involved. */
export function buildGameClipArgs(o: GameClipArgs): FfmpegPlan {
  const [w, h] = GAME_CLIP_SIZE;
  const fps = 30;
  const dur = Math.min(60, Math.max(3, Math.round(o.durationSec)));
  const frames = dur * fps;
  const args: string[] = ['-hide_banner', '-nostdin', '-loglevel', 'error', '-y'];
  if (o.imagePath) args.push('-i', o.imagePath);
  else args.push('-f', 'lavfi', '-i', `color=c=0x0b1020:s=${w}x${h}:r=${fps}`);
  args.push('-f', 'lavfi', '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100', '-t', String(dur));

  const vf: string[] = [];
  if (o.imagePath) {
    // Work on a 1.5x canvas so the zoom stays smooth, then let zoompan output the final 1080x1920 frames.
    vf.push(`scale=${Math.round(w * 1.5)}:${Math.round(h * 1.5)}:force_original_aspect_ratio=increase`, `crop=${Math.round(w * 1.5)}:${Math.round(h * 1.5)}`,
      `zoompan=z='min(1+0.0009*on,1.35)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=${frames}:s=${w}x${h}:fps=${fps}`);
    vf.push('drawbox=x=0:y=0:w=iw:h=ih:color=black@0.40:t=fill');
  }
  vf.push('format=yuv420p');

  const usesText = o.withText !== false && Boolean(o.title || o.tagline || o.cta);
  if (usesText) {
    const font = o.fontFile ? `fontfile='${o.fontFile.replace(/:/g, '\\:')}':` : '';
    const fade = "alpha='if(lt(t,0.4),0,min(1,(t-0.4)/0.5))'";
    const titleLines = wrapLines(o.title, 15, 3);
    titleLines.forEach((line, i) => {
      vf.push(`drawtext=${font}expansion=none:text='${escapeDrawtext(line)}':fontcolor=white:fontsize=h/19:borderw=5:bordercolor=black@0.85:x=(w-text_w)/2:y=h*0.27+${i}*h/13:${fade}`);
    });
    if (o.tagline) {
      vf.push(`drawtext=${font}expansion=none:text='${escapeDrawtext(wrapLines(o.tagline, 34, 1)[0] ?? '')}':fontcolor=0xfde68a:fontsize=h/34:borderw=3:bordercolor=black@0.85:x=(w-text_w)/2:y=h*0.27+${titleLines.length}*h/13+h/40:alpha='if(lt(t,1.2),0,min(1,(t-1.2)/0.5))'`);
    }
    if (o.cta) {
      vf.push(`drawtext=${font}expansion=none:text='${escapeDrawtext(wrapLines(o.cta, 30, 1)[0] ?? '')}':fontcolor=white:fontsize=h/30:box=1:boxcolor=0x16a34a@0.92:boxborderw=26:x=(w-text_w)/2:y=h*0.80:alpha='if(lt(t,2),0,min(1,(t-2)/0.5))'`);
    }
  }
  args.push('-vf', vf.join(','), '-map', '0:v', '-map', '1:a', '-r', String(fps), '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '23', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '96k', '-shortest', '-movflags', '+faststart', o.output);
  return { args, usesText };
}
