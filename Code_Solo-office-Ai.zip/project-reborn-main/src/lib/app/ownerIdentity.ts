// "Sino ako?": ang sagot ni Code Solo kapag tinanong siya ng owner kung sino ang kausap niya.
// Pure module (walang browser/server import) kaya pareho ang gamit ng screen (bossChat.ts) at ng server (boss-chat.ts).
import type { VoiceLang } from './voice';

// Tinatanggap ang iba't ibang bigkas/typo: "sino ako", "sino po ako", "who am I", "who im i", "who i am", "do you know who I am"…
export const ABOUT_OWNER = new RegExp(
  [
    String.raw`sino\s+(po\s+|ba\s+|na\s+)?ako`,
    String.raw`sino\s+(ba\s+)?(po\s+)?ako\s+(sa|para)`,
    String.raw`ako\s+ba\s+(si\s+)?sino`,
    String.raw`kilala\s+mo\s+(ba\s+)?(po\s+)?(ako|kung\s+sino\s+ako)`,
    String.raw`sino\s+(ang\s+|yung\s+|iyong\s+|'?yung\s+)?(kausap|kinakausap)(\s+mo|\s+ko)?`,
    String.raw`who\s*(am|m|'m|’m|im|i'm|i’m)\s*i\b`,
    String.raw`who\s+i\s+am\b`,
    String.raw`who\s+am\b`,
    String.raw`who\s*('s|’s|\s+is)\s+(this|talking\s+to\s+you|your\s+boss)`,
    String.raw`who\s+are\s+you\s+(talking|speaking)\s+(to|with)`,
    String.raw`do\s+you\s+know\s+(me|who\s+i\s+am|who\s+im)`,
    String.raw`sino\s+(ang\s+)?boss\s+mo`,
  ].join('|'),
  'i',
);

export const OWNER_ANSWER: Record<VoiceLang, string> = {
  'fil-PH': 'Ikaw ang totoong Code Solo, ang Boss ko, boss. Ikaw ang nag-program at developer ng office AI system na ito, kaya kami nandito: ikaw ang utak ng lahat ng ito.',
  'en-US': 'You are the real Code Solo, my Boss, boss. You are the one who programmed and developed this office AI system, which is why we are here: you are the brains behind all of this.',
};
