// Mga utos ni Boss na gagawin sa office (meeting, kausapin ang mga tao). Nakatago sa localStorage (at sa memory kung bawal ito),
// kaya hindi nawawala kung lumipat ka ng tab, isinara ang panel, o na-reload ang page bago pa nagsimula ang office simulation.
// Nawawalan ng bisa pagkalipas ng 10 minuto, para hindi biglang magmeeting ang team kinabukasan.
import type { AfterCallPlan } from './callActions';

const KEY = 'botoffice_pending_plans';
export const PLAN_TTL_MS = 10 * 60_000;
interface Item { plan: AfterCallPlan; at: number }
let mem: Item[] = [];

const load = (now: number): Item[] => {
  let list = mem;
  try { const v = JSON.parse(window.localStorage.getItem(KEY) ?? 'null'); if (Array.isArray(v)) list = v as Item[]; } catch { /* gamitin ang memory */ }
  return list.filter((i) => i && i.plan && now - i.at < PLAN_TTL_MS);
};
const save = (list: Item[]) => {
  mem = list;
  try { window.localStorage.setItem(KEY, JSON.stringify(list.slice(-10))); } catch { /* private mode: memory lang */ }
};

export const queuePlan = (plan: AfterCallPlan, now = Date.now()): void => save([...load(now), { plan, at: now }]);
export const hasPlan = (now = Date.now()): boolean => load(now).length > 0;
export function takePlan(now = Date.now()): AfterCallPlan | null {
  const list = load(now);
  const first = list.shift();
  save(list);
  return first?.plan ?? null;
}
