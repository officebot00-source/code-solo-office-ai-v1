import { useCallback, useEffect, useState } from 'react';

export const ZOOM_MIN = 0.6;
export const ZOOM_MAX = 2;
export const ZOOM_STEP = 0.1;
const KEY = 'gg-ui-zoom';

const clamp = (v: number) => Math.min(ZOOM_MAX, Math.max(ZOOM_MIN, Math.round(v * 100) / 100));

/** true when the browser supports the CSS `zoom` property (Chrome / Samsung Internet / Edge / Firefox 126+ on Android) */
export const supportsCssZoom = typeof CSS !== 'undefined' && typeof CSS.supports === 'function' && CSS.supports('zoom', '1');

function load(): number {
  try {
    const raw = window.localStorage.getItem(KEY);
    const n = raw ? parseFloat(raw) : 1;
    return Number.isFinite(n) ? clamp(n) : 1;
  } catch {
    return 1;
  }
}

/**
 * Whole-interface zoom. Layout re-flows at the zoomed size (like a real browser zoom),
 * so nothing is cut off or pushed outside the screen when zooming in.
 */
export function useUiZoom() {
  const [zoom, setZoomState] = useState<number>(load);

  const setZoom = useCallback((v: number) => {
    const next = clamp(v);
    setZoomState(next);
    try {
      window.localStorage.setItem(KEY, String(next));
    } catch {
      /* storage can be blocked — zoom still works for this session */
    }
  }, []);

  // Fallback for browsers without CSS zoom: scale everything that uses rem.
  useEffect(() => {
    if (supportsCssZoom) return;
    document.documentElement.style.fontSize = `${zoom * 100}%`;
    return () => {
      document.documentElement.style.fontSize = '';
    };
  }, [zoom]);

  // Keyboard: Ctrl/Cmd + (+ / - / 0) for tablets with keyboards & desktop testing.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!(e.ctrlKey || e.metaKey) || !e.shiftKey) return;
      if (e.key === '+' || e.key === '=') { e.preventDefault(); setZoom(zoom + ZOOM_STEP); }
      else if (e.key === '-' || e.key === '_') { e.preventDefault(); setZoom(zoom - ZOOM_STEP); }
      else if (e.key === '0') { e.preventDefault(); setZoom(1); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [zoom, setZoom]);

  return { zoom, setZoom, zoomIn: () => setZoom(zoom + ZOOM_STEP), zoomOut: () => setZoom(zoom - ZOOM_STEP), reset: () => setZoom(1) };
}
