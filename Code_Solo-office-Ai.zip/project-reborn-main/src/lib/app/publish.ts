import { botApiHost, botFnUrl, isSupabaseConfigured } from './supabase';

const PASS_KEY = 'botoffice_passcode';
export const LOCK_EVENT = 'botoffice:locked';
export const getPasscode = () => {
  try { return sessionStorage.getItem(PASS_KEY) ?? localStorage.getItem(PASS_KEY) ?? ''; } catch { return ''; }
};
/** remember=true keeps it on this device; false keeps it only until the tab/app is closed. Empty string clears it. */
export const setPasscode = (v: string, remember = true) => {
  try {
    sessionStorage.removeItem(PASS_KEY);
    localStorage.removeItem(PASS_KEY);
    if (!v) return;
    (remember ? localStorage : sessionStorage).setItem(PASS_KEY, v);
  } catch { /* ignore */ }
};

/** Real publishing needs the server (secrets + CORS), so it only exists when Supabase is configured. */
export const canPublishLive = isSupabaseConfigured;

async function call<T>(fn: string, body: unknown): Promise<T> {
  if (!isSupabaseConfigured) throw new Error('Real posting needs the server. This build runs in local simulation mode.');
  let res: Response;
  try {
    res = await fetch(botFnUrl(fn), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-app-passcode': getPasscode() },
      body: JSON.stringify(body),
    });
  } catch {
    // The browser could not reach the function at all (no response, usually no CORS headers).
    throw new Error(
      navigator.onLine === false
        ? 'Walang internet connection.'
        : `Hindi maabot ang server function "${fn}". Subukan ulit mamaya.`
    );
  }
  let data: unknown = null;
  const raw = await res.clone().text().catch(() => '');
  try { data = await res.json(); } catch { /* not json */ }
  // Cloudflare / hosting error pages (e.g. "error code: 1016" = the host's DNS does not resolve) are not JSON.
  if (!res.ok && data === null && /error code: \d{4}/i.test(raw)) {
    throw new Error(`Hindi maabot ang server sa ${botApiHost} (${raw.trim().slice(0, 40)}). Tingnan ang VITE_BOT_API_BASE / kung naka-publish pa ang site.`);
  }
  if (res.status === 401) {
    setPasscode('');
    window.dispatchEvent(new Event(LOCK_EVENT)); // wrong / changed password -> back to the lock screen
    throw new Error('Wrong or missing password.');
  }
  if (res.status === 404) throw new Error(`The "${fn}" server function was not found.`);
  if (!res.ok) throw new Error((data as { error?: string })?.error ?? `Request failed (${res.status})`);
  return data as T;
}

export interface PublishResult {
  id: string;
  status: 'published' | 'failed' | 'skipped';
  sent?: { platform: string; id?: string; url?: string }[];
  errors?: string[];
}

/** Publishes already-saved posts right now to the real platforms. */
export const publishNow = (postIds: string[], retry = false) =>
  call<{ ok: boolean; results: PublishResult[] }>('publish-now', { post_ids: postIds, retry });

export type IntegrationAction = 'save' | 'test' | 'send_test';

export interface AiKeyStatus {
  configured: boolean;
  provider?: 'OpenAI' | 'OpenRouter' | 'Gemini';
  model?: string;
  keyHint?: string;
  keyValid: boolean | null;
  credits: 'ok' | 'empty' | 'unknown';
  creditLeft?: number | null;
  message: string;
  checkedAt: string;
}
/** Checks the saved AI key on the server: accepted? credits left? (sends one tiny AI request) */
export const aiKeyStatus = () =>
  call<{ ok: boolean; status: AiKeyStatus }>('integrations-admin', { action: 'ai_status', provider: 'openai' }).then((r) => r.status);
export const integrationsAdmin = (action: IntegrationAction, provider: string, fields?: Record<string, string>) =>
  call<{ ok: boolean; detail?: string; error?: string; config?: Record<string, string> }>('integrations-admin', { action, provider, fields });

/** Checks a password against the server. Returns 'ok' | 'wrong' | 'locked-out' | 'not-set' | 'offline'. */
export async function verifyPasscode(code: string): Promise<'ok' | 'wrong' | 'locked-out' | 'not-set' | 'offline'> {
  try {
    const res = await fetch(botFnUrl('admin-db'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-app-passcode': code },
      body: JSON.stringify({ op: 'verify' }),
    });
    if (res.ok) return 'ok';
    if (res.status === 429) return 'locked-out';
    if (res.status === 503) return 'not-set';
    if (res.status === 401) return 'wrong';
    return 'offline';
  } catch {
    return 'offline';
  }
}

export interface WatchdogIssue {
  id: string; kind: string; platform: string; title: string; url: string; item_at: string; first_seen_at: string;
  last_nagged_at: string | null; nag_count: number; status: 'open' | 'snoozed' | 'handled' | 'dismissed' | 'fixed';
  snoozed_until: string | null; resolved_at: string | null; resolved_reason: string | null;
}
/** Argus the Watchdog: the list of everything the team missed. */
export const watchdogList = () =>
  call<{ ok: boolean; open: WatchdogIssue[]; closed: WatchdogIssue[]; state: { last_digest_at?: number; last_scan_at?: number } }>('watchdog-admin', { action: 'list' });
export const watchdogResolve = (id: string, status: 'handled' | 'dismissed' | 'open') => call<{ ok: boolean }>('watchdog-admin', { action: 'resolve', id, status });
export const watchdogSnooze = (id: string, hours: number) => call<{ ok: boolean }>('watchdog-admin', { action: 'snooze', id, hours });
export const watchdogTest = () => call<{ ok: boolean; detail?: string; error?: string }>('watchdog-admin', { action: 'test' });
/** Runs the Watchdog right now (full scan of Facebook / X, and reminds the team if something is missed). */
export const watchdogRunNow = () => call<{ ok: boolean; open?: number; new?: number; fixed?: number; reminded?: number; channels?: string[]; quiet?: boolean; error?: string; skipped?: string }>('watchdog-bot', { force: true });

export type AdminTable = 'games' | 'studio_saved_copy' | 'scheduled_posts' | 'invite_rules' | 'bot_logs' | 'bot_settings' | 'integrations' | 'idea_lab_brain' | 'brain_sync_events' | 'employee_bots';

/** Which tables the server is willing to write. Rejects with "Not allowed" when the server still runs an OLD version of admin-db. */
export const serverCapabilities = () => call<{ ok: boolean; tables: string[]; reads: string[] }>('admin-db', { op: 'version' });

/** Every database WRITE goes through the server (which checks the password). The browser itself can only read. */
export const adminWrite = (table: AdminTable, action: 'insert' | 'update' | 'delete', args: { id?: string | number; row?: Record<string, unknown> } = {}) =>
  call<{ ok: boolean; id?: string }>('admin-db', { table, action, ...args });

export type AdminQuery = 'games' | 'studio_saved_copy' | 'scheduled_posts' | 'invite_rules' | 'integrations' | 'bot_settings' | 'bot_logs' | 'brain' | 'boss_commands' | 'lessons';
/** Reads the office's private records through the server (password checked there); the public key cannot read them. */
export const adminRead = <T,>(query: AdminQuery, params: Record<string, unknown> = {}) =>
  call<{ ok: boolean; data: T }>('admin-db', { op: 'read', query, params }).then((r) => r.data);

/** Runs the Shared Brain reflector right now (harvest results → reinforce / weaken rules → learn new ones). */
export const reflectNow = () =>
  call<{ ok: boolean; harvested?: number; pending?: number; new_rules?: number; reinforced?: number; weakened?: number; error?: string }>('idea-lab-reflector', {});

/** Live chat kay Boss (AI sa server, gamit ang key sa API Settings). */
export const bossChatServer = (messages: { role: 'user' | 'boss'; text: string }[], status = '', lang: 'fil-PH' | 'en-US' = 'fil-PH', strict = false) =>
  call<{ reply: string; command: { text: string; platform: string } | null; action?: unknown; learned?: string | null }>('boss-chat', { messages, status, lang, strict });

/** AI Caption & Hashtag writer (Lovable AI on the server): topic + target platform → caption and hashtags. */
export const writeCaption = (topic: string, platform: import('./caption').CaptionPlatform, tone: string) =>
  call<{ ok: boolean; platform: import('./caption').CaptionPlatform; caption: string; hashtags: string[] }>('caption-writer', { topic, platform, tone });
