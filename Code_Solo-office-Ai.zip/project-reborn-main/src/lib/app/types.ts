export type Platform = 'facebook' | 'twitter' | 'discord' | 'telegram';
export type Tone = 'hype' | 'competitive' | 'casual' | 'fomo';
export type PostStatus = 'scheduled' | 'publishing' | 'published' | 'failed' | 'draft';

export interface Game {
  id: string;
  title: string;
  genre: string;
  description: string;
  promo_link: string;
  banner_image: string;
  active: boolean;
  created_at: string;
}

export interface Post {
  id: string;
  game_id: string | null;
  game_title: string;
  platforms: Platform[];
  content: string;
  hashtags: string;
  tone: Tone;
  status: PostStatus;
  scheduled_at: string;
  published_at: string | null;
  created_at: string;
  error?: string | null;
  results?: { platform: string; id?: string; url?: string }[] | null;
}

export interface InviteRule {
  id: string;
  name: string;
  platform: Platform;
  trigger_type: 'keyword' | 'webhook';
  trigger_keywords: string[];
  message_template: string;
  target_webhook: string;
  max_per_hour: number;
  delay_min_seconds: number;
  delay_max_seconds: number;
  enabled: boolean;
  created_at: string;
}

export type LogLevel = 'info' | 'success' | 'warning' | 'error';

export interface BotLog {
  id: string;
  level: LogLevel;
  source: string;
  message: string;
  created_at: string;
}

export interface Integration {
  id: string;
  provider: string;
  label: string;
  config: Record<string, string>;
  status: 'untested' | 'connected' | 'error';
  created_at: string;
}

export const PLATFORMS: { id: Platform; label: string }[] = [
  { id: 'facebook', label: 'Facebook' },
  { id: 'twitter', label: 'X (Twitter)' },
  { id: 'discord', label: 'Discord' },
  { id: 'telegram', label: 'Telegram' },
];

export const TONES: { id: Tone; label: string; hint: string }[] = [
  { id: 'hype', label: 'Hype', hint: 'Exciting, high-energy launch announcements' },
  { id: 'competitive', label: 'Competitive', hint: 'Ranked grind, leaderboard, skill-based angle' },
  { id: 'casual', label: 'Casual', hint: 'Friendly, relaxed, community-driven voice' },
  { id: 'fomo', label: 'FOMO / Urgent', hint: 'Limited-time events, urgency, scarcity' },
];
