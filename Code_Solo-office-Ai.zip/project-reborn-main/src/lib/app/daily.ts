// Daily Auto-Post — shared contracts + pure logic (no server / browser APIs, so it is trivial to test).
// The user picks one or more times of day; the server queues a fresh post for each of them EVERY day, so nobody has to
// schedule posts by hand. Posts are written to the normal `scheduled_posts` queue and sent by the existing worker.
import { PLATFORMS, TONES, type Platform, type Tone } from './types';

export const DAILY_SETTINGS_KEY = 'daily_poster_settings';
export const DAILY_STATUS_KEY = 'daily_poster_status';
/** One `bot_state` row per (date, slot): inserting it is the lock that stops two runs queuing the same daily post. */
export const DAILY_CLAIM_PREFIX = 'daily_poster_run:';

export const MAX_SLOTS = 6;
/** The server queues a slot's post this long before its time (the worker then publishes it exactly on time). */
export const DEFAULT_LOOKAHEAD_MIN = 15;
/** If the server was down, a slot is still posted when it is at most this many minutes late; later than that it is skipped. */
export const DEFAULT_GRACE_MIN = 30;

export const DAILY_TIMEZONES: { value: string; label: string }[] = [
  { value: 'Asia/Manila', label: 'Pilipinas (UTC+8)' },
  { value: 'Asia/Singapore', label: 'Singapore (UTC+8)' },
  { value: 'Asia/Tokyo', label: 'Japan (UTC+9)' },
  { value: 'Asia/Dubai', label: 'Dubai (UTC+4)' },
  { value: 'Europe/London', label: 'London' },
  { value: 'America/New_York', label: 'New York' },
  { value: 'America/Los_Angeles', label: 'Los Angeles' },
  { value: 'Australia/Sydney', label: 'Sydney' },
  { value: 'UTC', label: 'UTC' },
];

export interface DailySlot {
  id: string;
  /** 24h local time in the settings' timezone, "HH:MM". */
  time: string;
  /** Empty = every connected platform. */
  platforms: Platform[];
}

export interface DailySettings {
  enabled: boolean;
  timezone: string;
  slots: DailySlot[];
  /** Empty = rotate through every active game. */
  game_ids: string[];
  /** false = skip the AI and use the built-in template (still posts every day). */
  use_ai: boolean;
  tone: Tone;
}

export interface DailyStatus {
  last_run_at: string | null;
  last_queued: { game_title: string; platforms: string[]; scheduled_at: string } | null;
  last_error: string | null;
}

export const DEFAULT_DAILY_SETTINGS: DailySettings = {
  enabled: false,
  timezone: 'Asia/Manila',
  slots: [{ id: 's1', time: '19:00', platforms: [] }],
  game_ids: [],
  use_ai: true,
  tone: 'hype',
};
export const EMPTY_DAILY_STATUS: DailyStatus = { last_run_at: null, last_queued: null, last_error: null };

/* ------------------------------ validation ------------------------------ */

const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;
const ID_RE = /^[a-z0-9_-]{1,24}$/i;
const UUID_RE = /^[0-9a-f-]{36}$/i;
const PLATFORM_IDS = PLATFORMS.map((p) => p.id);
const TONE_IDS = TONES.map((t) => t.id);

export const isValidTime = (t: unknown): t is string => typeof t === 'string' && TIME_RE.test(t);

export function isValidTimezone(tz: unknown): tz is string {
  if (typeof tz !== 'string' || !tz || tz.length > 64) return false;
  try { new Intl.DateTimeFormat('en-US', { timeZone: tz }); return true; } catch { return false; }
}

/** Never throws. Anything missing or invalid falls back to `base`, so a half-filled request can never corrupt the settings. */
export function sanitizeDailySettings(raw: unknown, base: DailySettings = DEFAULT_DAILY_SETTINGS): DailySettings {
  const r = (raw && typeof raw === 'object' ? raw : {}) as Record<string, unknown>;
  let slots = base.slots;
  if (Array.isArray(r['slots'])) {
    const seenTime = new Set<string>();
    const seenId = new Set<string>();
    const out: DailySlot[] = [];
    for (const s of r['slots'] as unknown[]) {
      if (!s || typeof s !== 'object') continue;
      const o = s as Record<string, unknown>;
      if (!isValidTime(o['time']) || seenTime.has(o['time'])) continue;
      let id = typeof o['id'] === 'string' && ID_RE.test(o['id']) ? o['id'] : '';
      for (let n = 1; !id || seenId.has(id); n++) id = `s${n}`;
      seenTime.add(o['time']); seenId.add(id);
      const platforms = Array.isArray(o['platforms'])
        ? [...new Set((o['platforms'] as unknown[]).filter((p): p is Platform => typeof p === 'string' && (PLATFORM_IDS as string[]).includes(p)))]
        : [];
      out.push({ id, time: o['time'], platforms });
      if (out.length >= MAX_SLOTS) break;
    }
    slots = out.sort((a, b) => a.time.localeCompare(b.time));
  }
  return {
    enabled: typeof r['enabled'] === 'boolean' ? r['enabled'] : base.enabled,
    timezone: isValidTimezone(r['timezone']) ? r['timezone'] : base.timezone,
    slots,
    game_ids: Array.isArray(r['game_ids'])
      ? [...new Set((r['game_ids'] as unknown[]).filter((g): g is string => typeof g === 'string' && UUID_RE.test(g)))].slice(0, 50)
      : base.game_ids,
    use_ai: typeof r['use_ai'] === 'boolean' ? r['use_ai'] : base.use_ai,
    tone: typeof r['tone'] === 'string' && (TONE_IDS as string[]).includes(r['tone']) ? (r['tone'] as Tone) : base.tone,
  };
}

/* ------------------------------ time zones ------------------------------ */

const pad = (n: number) => String(n).padStart(2, '0');

function zonedParts(ms: number, tz: string): Record<string, number> {
  const f = new Intl.DateTimeFormat('en-US', {
    timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit',
  });
  const out: Record<string, number> = {};
  for (const p of f.formatToParts(new Date(ms))) if (p.type !== 'literal') out[p.type] = Number(p.value);
  return out;
}

/** How far `tz` is ahead of UTC at that instant, in ms (Manila = +8h). */
export function tzOffsetMs(ms: number, tz: string): number {
  const o = zonedParts(ms, tz);
  return Date.UTC(o['year'], o['month'] - 1, o['day'], (o['hour'] ?? 0) % 24, o['minute'], o['second']) - Math.floor(ms / 1000) * 1000;
}

/** "YYYY-MM-DD" of `d` as seen on the wall clock of `tz`. */
export function localDateKey(d: Date, tz: string): string {
  const o = zonedParts(d.getTime(), tz);
  return `${o['year']}-${pad(o['month'])}-${pad(o['day'])}`;
}

export function addDays(dateKey: string, n: number): string {
  const [y, m, d] = dateKey.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10);
}

/** The exact instant when the wall clock of `tz` shows `time` on `dateKey` (handles daylight-saving zones). */
export function zonedTimeToUtc(dateKey: string, time: string, tz: string): Date {
  const [y, m, d] = dateKey.split('-').map(Number);
  const [hh, mm] = time.split(':').map(Number);
  const guess = Date.UTC(y, m - 1, d, hh, mm);
  let t = guess - tzOffsetMs(guess, tz);
  t = guess - tzOffsetMs(t, tz);
  return new Date(t);
}

/* ------------------------------ what is due ------------------------------ */

export interface DueSlot { slot: DailySlot; slotIndex: number; dateKey: string; runAt: Date; claimKey: string }

/** Slots whose post should be queued right now: starts within the look-ahead, or is at most `graceMin` late. */
export function dueSlots(s: DailySettings, now: Date, o: { lookaheadMin?: number; graceMin?: number } = {}): DueSlot[] {
  if (!s.enabled) return [];
  const look = (o.lookaheadMin ?? DEFAULT_LOOKAHEAD_MIN) * 60_000;
  const grace = (o.graceMin ?? DEFAULT_GRACE_MIN) * 60_000;
  const today = localDateKey(now, s.timezone);
  const out: DueSlot[] = [];
  // yesterday / tomorrow too: a slot just after midnight is "tomorrow" for a run just before it (and the reverse for grace).
  for (const dateKey of [addDays(today, -1), today, addDays(today, 1)]) {
    s.slots.forEach((slot, slotIndex) => {
      const runAt = zonedTimeToUtc(dateKey, slot.time, s.timezone);
      const diff = runAt.getTime() - now.getTime();
      if (diff <= look && -diff <= grace) out.push({ slot, slotIndex, dateKey, runAt, claimKey: `${DAILY_CLAIM_PREFIX}${dateKey}:${slot.id}` });
    });
  }
  return out.sort((a, b) => a.runAt.getTime() - b.runAt.getTime());
}

/** The next `count` times a post will go out (for the preview in the app). */
export function nextRuns(s: DailySettings, now: Date, count = 4): { runAt: Date; slot: DailySlot }[] {
  if (!s.enabled || !s.slots.length) return [];
  const today = localDateKey(now, s.timezone);
  const all: { runAt: Date; slot: DailySlot }[] = [];
  for (let i = 0; i <= 8; i++) {
    for (const slot of s.slots) {
      const runAt = zonedTimeToUtc(addDays(today, i), slot.time, s.timezone);
      if (runAt.getTime() > now.getTime()) all.push({ runAt, slot });
    }
  }
  return all.sort((a, b) => a.runAt.getTime() - b.runAt.getTime()).slice(0, count);
}

/* ------------------------------ choosing a game + a template post ------------------------------ */

/** Deterministic rotation: a different game each slot and each day (no random repeats), only among the chosen / active games. */
export function pickGame<T extends { id: string; active?: boolean | null }>(games: T[], s: DailySettings, dateKey: string, slotIndex: number): T | null {
  let pool = games.filter((g) => g.active !== false);
  if (s.game_ids.length) pool = pool.filter((g) => s.game_ids.includes(g.id));
  if (!pool.length) return null;
  pool = [...pool].sort((a, b) => a.id.localeCompare(b.id));
  const [y, m, d] = dateKey.split('-').map(Number);
  const day = Math.floor(Date.UTC(y, m - 1, d) / 86_400_000);
  return pool[(day * Math.max(1, s.slots.length) + slotIndex) % pool.length];
}

export interface TemplateGame { title: string; genre?: string | null; description?: string | null; promo_link?: string | null }

const OPENERS: Record<Tone, (t: string) => string> = {
  hype: (t) => `🎮 ${t} is LIVE! Jump in today and show what you've got.`,
  competitive: (t) => `🏆 Think you're the best at ${t}? Climb the ranks today and prove it.`,
  casual: (t) => `Hey gamers! 👋 Looking for something fun? Come hang out in ${t} today.`,
  fomo: (t) => `⏳ Don't miss out — ${t} is waiting for you right now!`,
};

/** Used when no AI key is saved (or the AI fails), so the daily post still goes out. */
export function buildFallbackPost(game: TemplateGame, tone: Tone): { content: string; hashtags: string } {
  const lines = [OPENERS[tone](game.title)];
  const desc = (game.description ?? '').trim().replace(/\s+/g, ' ');
  if (desc) lines.push(desc.length > 140 ? `${desc.slice(0, 137).trimEnd()}…` : desc);
  if (game.promo_link) lines.push(game.promo_link);
  const slug = game.title.replace(/[^\p{L}\p{N}]+/gu, '');
  const tags = [slug ? `#${slug}` : '', '#gaming', '#indiegame'].filter(Boolean);
  return { content: lines.join('\n'), hashtags: tags.join(' ') };
}
