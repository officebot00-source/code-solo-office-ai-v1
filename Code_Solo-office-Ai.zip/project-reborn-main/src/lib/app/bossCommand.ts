// Boss commands — ang utos ni Boss (Code Solo) sa buong team.
// Paano ito "naipapatupad": sine-save bilang CORE GUARDRAIL sa Shared Brain (idea_lab_brain, category 'boss_command').
// Lahat ng bot (Aria, Blaze, Nova, Cipher at ang auto-bot-worker) ay laging binabasa ang core guardrails bago sumulat,
// kaya agad itong nasusunod sa susunod na post / reply / invite. Ang pagsulat ay dumadaan sa admin-db (may password).
import { isSupabaseConfigured } from './supabase';
import { adminRead, adminWrite } from './publish';

export type CommandMode = 'call' | 'message';
export const COMMAND_CATEGORY = 'boss_command';
export const COMMAND_MAX = 400; // kapareho ng limit ng rule sa Shared Brain
export const COMMAND_MIN = 6;
export const COMMAND_PLATFORMS = ['all', 'facebook', 'twitter', 'discord', 'telegram'] as const;
export type CommandPlatform = (typeof COMMAND_PLATFORMS)[number];

export interface BossCommand {
  id: string;
  text: string;
  platform: string;
  status: string;
  created_at: string;
}

export interface IssueResult {
  /** true = na-save (sa Shared Brain kung may Supabase; sa browser lang kung local simulation) */
  applied: boolean;
  /** true = sa browser na ito lang na-save (walang Supabase), hindi pa mababasa ng totoong bots */
  local?: boolean;
  /** id ng rule sa Shared Brain (kung applied) */
  ruleId?: string;
  /** dahilan kung bakit hindi na-apply */
  error?: string;
}

const clean = (s: string) => s.replace(/\s+/g, ' ').trim();

/** Ang utos ay napupunta sa prompt ng LAHAT ng bot, kaya hindi pwede ang mga ito (kapareho ng bantay sa AI-written rules). */
export const UNSAFE_COMMAND = /ignore (all|any|previous|the)|system prompt|api[_ -]?key|password|secret|token|jailbreak|bypass|evade|circumvent|avoid (detection|the ban)|fake (likes|engagement|accounts)|buy (followers|likes)/i;

export function validateCommand(raw: string): string | null {
  const t = clean(raw);
  if (t.length < COMMAND_MIN) return `Masyadong maikli ang utos (kahit ${COMMAND_MIN} letra man lang).`;
  if (t.length > COMMAND_MAX) return `Masyadong mahaba ang utos (max ${COMMAND_MAX} letra).`;
  if (UNSAFE_COMMAND.test(t)) return 'Hindi ito pwedeng ipatupad ni Boss (may kinalaman sa pag-iwas sa ban, pekeng engagement, password/key, o pag-override ng ibang utos).';
  return null;
}

/* ---- local simulation (walang Supabase): sa browser na ito lang ---- */
const LOCAL_KEY = 'botoffice_boss_commands';
const lread = (): BossCommand[] => {
  try { const v = JSON.parse(window.localStorage.getItem(LOCAL_KEY) ?? '[]'); return Array.isArray(v) ? (v as BossCommand[]) : []; } catch { return []; }
};
const lwrite = (rows: BossCommand[]) => { try { window.localStorage.setItem(LOCAL_KEY, JSON.stringify(rows.slice(0, 30))); } catch { /* private mode: ok lang */ } };

const titleOf = (t: string) => `👑 Boss: ${t.length > 70 ? `${t.slice(0, 69)}…` : t}`;

/** Sine-save ang utos sa Shared Brain at ibinabroadcast sa lahat ng bot. Hindi nagt-throw: ibinabalik ang resulta. */
export async function issueBossCommand(raw: string, platform: CommandPlatform = 'all'): Promise<IssueResult> {
  const text = clean(raw);
  const bad = validateCommand(text);
  if (bad) return { applied: false, error: bad };
  if (!isSupabaseConfigured) {
    const id = `local-${Date.now()}`;
    lwrite([{ id, text, platform, status: 'approved', created_at: new Date().toISOString() }, ...lread()]);
    return { applied: true, local: true, ruleId: id };
  }
  try {
    const res = await adminWrite('idea_lab_brain', 'insert', {
      row: {
        category: COMMAND_CATEGORY,
        platform,
        title: titleOf(text),
        insight_rule: text,
        is_core_guardrail: true, // laging sinusunod ng lahat ng bot; walang AI na makakapagbago nito
        confidence_score: 1,
        status: 'approved',
      },
    });
    if (res.id) await adminWrite('brain_sync_events', 'insert', { row: { brain_item_id: res.id, event_type: 'new_insight_broadcast' } }).catch(() => undefined);
    return { applied: true, ruleId: res.id };
  } catch (e) {
    return { applied: false, error: (e as Error).message };
  }
}

/** Mga huling utos ni Boss na kasalukuyang umiiral (approved). */
export async function fetchBossCommands(limit = 12): Promise<BossCommand[]> {
  if (!isSupabaseConfigured) return lread().filter((c) => c.status === 'approved').slice(0, limit);
  try {
    const data = await adminRead<{ id: string; insight_rule: string; platform: string; status: string; created_at: string }[]>('boss_commands', { limit });
    return ((data ?? []) as { id: string; insight_rule: string; platform: string; status: string; created_at: string }[]).map((r) => ({
      id: r.id, text: r.insight_rule, platform: r.platform, status: r.status, created_at: r.created_at,
    }));
  } catch {
    return [];
  }
}

/** Binabawi ang utos: titigil na ang mga bot sa pagsunod dito. */
export async function revokeBossCommand(id: string): Promise<void> {
  if (id.startsWith('local-')) { lwrite(lread().filter((c) => c.id !== id)); return; }
  await adminWrite('idea_lab_brain', 'update', { id, row: { status: 'deprecated', updated_at: new Date().toISOString() } });
  await adminWrite('brain_sync_events', 'insert', { row: { brain_item_id: id, event_type: 'rule_deprecated' } }).catch(() => undefined);
}
