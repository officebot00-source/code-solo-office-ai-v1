import type { Game, Platform, Tone } from './types';

/**
 * Local template-based post generator. Simulates AI caption generation so the
 * app works fully before real API keys are connected.
 */

const tonePhrases: Record<Tone, string[]> = {
  hype: [
    "This is NOT a drill. {title} is calling all players right now.",
    "The servers are LIT. {title} just changed the game — literally.",
    "Stop scrolling. {title} is the most exciting thing you'll play this year.",
  ],
  competitive: [
    "Think you can climb the ranks in {title}? Prove it.",
    "Ranked season is live in {title}. Only the sharpest survive.",
    "Your leaderboard spot is waiting. {title} won't hold it for long.",
  ],
  casual: [
    "Looking for something chill to play tonight? {title} has you covered.",
    "No pressure, just good vibes and great matches in {title}.",
    "Jump into {title} whenever — the community is super welcoming.",
  ],
  fomo: [
    "You have 48 hours. After that, this {title} event is GONE forever.",
    "Everyone's already inside {title}. Don't be the last to find out.",
    "This {title} drop ends soon — once it's over, it never comes back.",
  ],
};

const platformBody: Record<Platform, string> = {
  facebook:
    'Full story and details inside — bring your squad, the more the merrier. Drop a comment and we will send you an invite link.',
  twitter:
    'Reply "JOIN" below and we will DM you the invite. Threads are open, come make some noise.',
  discord:
    'Our Discord community is where the action happens: tournaments, squads, and early access. Say "JOIN" in #lobby to get your role.',
  telegram:
    'Tap the channel, say "JOIN", and our bot sends your personal invite instantly. No spam, just game news and links.',
};

const hashtagPool: Record<Platform, string[]> = {
  facebook: ['#gamingcommunity', '#newgame', '#gamersunite', '#multiplayer'],
  twitter: ['#gaming', '#indiegames', '#playnow', '#esports'],
  discord: ['#discordgames', '#lfg', '#squadup'],
  telegram: ['#gamenews', '#playfree', '#joinus'],
};

export interface GeneratedPost {
  content: string;
  hashtags: string;
}

export function generatePost(
  game: Pick<Game, 'title' | 'genre' | 'description' | 'promo_link'>,
  platform: Platform,
  tone: Tone
): GeneratedPost {
  const phrase = tonePhrases[tone][Math.floor(Math.random() * tonePhrases[tone].length)];
  const hook = phrase.replace('{title}', game.title);
  const body = platformBody[platform];
  const genreLine = game.genre ? `${game.genre} — ` : '';
  const desc = game.description ? `${game.description} ` : '';
  const link = game.promo_link ? `\n${game.promo_link}` : '';

  const content = `${hook}\n\n${genreLine}${desc}${body}${link}`;

  const pool = [...hashtagPool[platform]];
  const genreTag = game.genre
    ? `#${game.genre.toLowerCase().replace(/[^a-z0-9]/g, '')}`
    : null;
  if (genreTag && genreTag.length > 3) pool.push(genreTag);
  const picked = pool.slice(0, 4).join(' ');

  return { content, hashtags: picked };
}
