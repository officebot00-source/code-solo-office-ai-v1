// Shared Brain — data layer. Reads and changes both go through admin-db (password checked on the server); the screen
// refreshes itself every few seconds while it is open.
import { useCallback, useEffect, useRef, useState } from 'react';
import type { RealtimeChannel } from '@supabase/supabase-js';
import { isSupabaseConfigured, supabase } from './supabase';
import { BRAIN_CHANNEL, BRAIN_EVENT, isDeletePing, parseBrainPing } from './brainChannel';
import { adminRead, adminWrite, reflectNow } from './publish';

export type BrainStatus = 'approved' | 'pending_review' | 'deprecated';
export type BrainCategory = 'winning_hook' | 'best_timing' | 'invite_script' | 'ban_guardrail' | 'audience_insight';

export interface BrainRule {
  id: string;
  source_bot_id: string | null;
  category: BrainCategory | string;
  platform: string;
  title: string;
  insight_rule: string;
  confidence_score: number;
  usage_count: number;
  is_core_guardrail: boolean;
  status: BrainStatus | string;
  created_at: string;
  updated_at: string;
}
export interface BrainBot { id: string; name: string; role: string; platform: string; status: string }
export interface BrainEvent { id: string; brain_item_id: string | null; learned_by_bot_id: string | null; event_type: string; created_at: string }
export interface ActionLog {
  id: string; bot_id: string | null; action_type: string; platform: string; content_sent: string;
  metrics: Record<string, unknown>; performance_score: number; created_at: string;
}

const RULE_COLS = 'id, source_bot_id, category, platform, title, insight_rule, confidence_score, usage_count, is_core_guardrail, status, created_at, updated_at';

export const BOT_STYLE: Record<string, { color: string; emoji: string }> = {
  Aria: { color: '#34d399', emoji: '✍️' },
  Blaze: { color: '#38bdf8', emoji: '🚀' },
  Nova: { color: '#f472b6', emoji: '📡' },
  Echo: { color: '#fbbf24', emoji: '💬' },
  Cipher: { color: '#a78bfa', emoji: '🔬' },
};

export const num = (v: unknown) => (typeof v === 'number' ? v : Number(v) || 0);

export function timeAgo(iso: string): string {
  const s = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  if (s < 45) return 'ngayon lang';
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${Math.round(s / 3600)}h ago`;
  return `${Math.round(s / 86400)}d ago`;
}

export interface BrainState {
  rules: BrainRule[]; bots: BrainBot[]; events: BrainEvent[]; logs: ActionLog[];
  autoApprove: boolean; loading: boolean; live: boolean; error: string | null;
}

// Pings in a row (update + sync event, bot bursts, or someone spamming the public channel) never reload more often than this.
const MIN_RELOAD_GAP_MS = 700;

const EMPTY: BrainState = { rules: [], bots: [], events: [], logs: [], autoApprove: true, loading: true, live: false, error: null };

export function useBrain() {
  const [state, setState] = useState<BrainState>(EMPTY);
  const [flash, setFlash] = useState<Set<string>>(new Set());
  const timer = useRef<number | undefined>(undefined);
  const seen = useRef<Map<string, string> | null>(null);
  const [realtime, setRealtime] = useState(false);
  const rt = useRef(false);
  const seq = useRef(0); // only the newest reload may write the screen: a slow older answer must not undo a newer one
  const mark = useCallback((id?: string | null) => {
    if (!id) return;
    setFlash((f) => new Set(f).add(id));
    window.setTimeout(() => setFlash((f) => { const n = new Set(f); n.delete(id); return n; }), 6000);
  }, []);

  const load = useCallback(async () => {
    if (!isSupabaseConfigured) { setState({ ...EMPTY, loading: false, error: 'no-supabase' }); return; }
    const mine = ++seq.current;
    try {
      const d = await adminRead<{ rules: BrainRule[]; bots: BrainBot[]; events: BrainEvent[]; logs: ActionLog[]; autoApprove: boolean }>('brain');
      if (mine !== seq.current) return;
      // highlight rules that changed since the last refresh (what the old live feed used to do)
      const before = seen.current;
      const next = new Map(d.rules.map((x) => [x.id, x.updated_at]));
      if (before) for (const [id, at] of next) if (before.get(id) !== at) mark(id);
      seen.current = next;
      setState({ rules: d.rules, bots: d.bots, events: d.events, logs: d.logs, autoApprove: d.autoApprove, loading: false, live: true, error: null });
    } catch (err) {
      if (mine !== seq.current) return;
      setState((p) => ({ ...p, loading: false, live: false, error: err instanceof Error ? err.message : 'Failed to load' }));
    }
  }, []);

  // Realtime: the server broadcasts a tiny "brain changed" ping (no rule text; the tables stay private). The first ping reloads
  // through admin-db at once; pings that follow within MIN_RELOAD_GAP_MS collapse into one trailing reload (so the sync event that
  // is written right after a rule still shows up). A deleted rule disappears instantly. The poll stays as a safety net:
  // every 8s while realtime is down, every ~32s while it is up. While the tab is hidden nothing loads; it catches up when shown.
  useEffect(() => {
    void load();
    if (!isSupabaseConfigured) return;
    let channel: RealtimeChannel | null = null;
    let trailing: number | undefined;
    let last = 0;
    let dirty = false;
    let ticks = 0;
    const run = () => { last = Date.now(); void load(); };
    const request = () => {
      if (document.hidden) { dirty = true; return; }
      const wait = last + MIN_RELOAD_GAP_MS - Date.now();
      if (wait <= 0) { window.clearTimeout(trailing); trailing = undefined; run(); }
      else if (trailing === undefined) trailing = window.setTimeout(() => { trailing = undefined; run(); }, wait);
    };
    try {
      channel = supabase.channel(BRAIN_CHANNEL)
        .on('broadcast', { event: BRAIN_EVENT }, (msg: { payload?: unknown }) => {
          const ping = parseBrainPing(msg.payload);
          if (!ping) return;
          if (isDeletePing(ping) && ping.rule_id) {
            const gone = ping.rule_id;
            seen.current?.delete(gone);
            setState((p) => ({ ...p, rules: p.rules.filter((x) => x.id !== gone) }));
          } else mark(ping.rule_id);
          request();
        })
        .subscribe((status: string) => {
          const up = status === 'SUBSCRIBED';
          rt.current = up; setRealtime(up);
          if (up) void load(); // catch up on anything missed while disconnected
        });
    } catch { rt.current = false; setRealtime(false); }
    timer.current = window.setInterval(() => {
      if (document.hidden) return;
      if (rt.current && ++ticks % 4 !== 0) return;
      dirty = false; void load();
    }, 8000);
    const onVisible = () => { if (!document.hidden) { dirty = false; void load(); } };
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      window.clearInterval(timer.current); window.clearTimeout(trailing);
      document.removeEventListener('visibilitychange', onVisible);
      if (channel) void supabase.removeChannel(channel);
      rt.current = false; void dirty;
    };
  }, [load, mark]);

  /* ---- admin actions (server checks the password) ---- */
  const broadcast = (id: string, type: string) =>
    adminWrite('brain_sync_events', 'insert', { row: { brain_item_id: id, event_type: type } }).catch(() => undefined);

  const setStatus = async (rule: BrainRule, status: BrainStatus) => {
    setState((p) => ({ ...p, rules: p.rules.map((x) => (x.id === rule.id ? { ...x, status } : x)) })); // optimistic
    try {
      await adminWrite('idea_lab_brain', 'update', { id: rule.id, row: { status, updated_at: new Date().toISOString() } });
      if (status === 'approved') void broadcast(rule.id, 'new_insight_broadcast');
      if (status === 'deprecated') void broadcast(rule.id, 'rule_deprecated');
    } catch (e) { void load(); throw e; }
  };
  const remove = async (rule: BrainRule) => {
    setState((p) => ({ ...p, rules: p.rules.filter((x) => x.id !== rule.id) }));
    try { await adminWrite('idea_lab_brain', 'delete', { id: rule.id }); } catch (e) { void load(); throw e; }
  };
  const addRule = async (r: { category: string; platform: string; title: string; insight_rule: string; core: boolean }) => {
    const res = await adminWrite('idea_lab_brain', 'insert', {
      row: { category: r.category, platform: r.platform, title: r.title.trim(), insight_rule: r.insight_rule.trim(), is_core_guardrail: r.core, confidence_score: r.core ? 1 : 0.8, status: 'approved' },
    });
    if (res.id) await broadcast(res.id, 'new_insight_broadcast');
    void load();
  };
  const setAutoApprove = async (v: boolean) => {
    setState((p) => ({ ...p, autoApprove: v }));
    try { await adminWrite('bot_settings', 'update', { id: 1, row: { idea_lab_auto_approve: v, updated_at: new Date().toISOString() } }); }
    catch (e) { setState((p) => ({ ...p, autoApprove: !v })); throw e; }
  };
  const reflect = async () => { const r = await reflectNow(); void load(); return r; };

  return { ...state, realtime, flash, reload: load, setStatus, remove, addRule, setAutoApprove, reflect };
}
