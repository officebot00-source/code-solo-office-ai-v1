// Energy at breaks nina Reel at Argus (parang ibang AI employee: kape, laro, idlip o kain kapag pagod na).
// Pure logic, walang 3D at walang network, kaya madaling i-test. Ang energy ay hindi pumapalit sa
// totoong trabaho: ang break ay sa itsura lang nila sa office; tuloy pa rin ang video job / pagbabantay sa server.
import type { ReelState } from './videoStaff';

export type ReelDoing = 'work' | 'coffee' | 'game' | 'rest' | 'eat';
export type ReelBreak = Exclude<ReelDoing, 'work'>;
export interface ReelRoutine {
  energy: number;
  doing: ReelDoing;
  /** huling break na ginawa (hindi uulitin agad) */
  last: ReelBreak | null;
  /** energy na nawawala kada segundo habang nag-e-edit */
  drain: number;
  /** sa anong energy siya hihinto at magbe-break */
  floor: number;
  /** ilang millisecond na siyang nasa break */
  breakMs: number;
}

export const REEL_FULL = 92;
export const REEL_BREAK_ICON: Record<ReelBreak, string> = { coffee: '☕', game: '🎮', rest: '😴', eat: '🍱' };
const RECOVER: Record<ReelBreak, number> = { coffee: 1.9, game: 1.4, rest: 2.3, eat: 1.7 };
const MIN_BREAK_MS: Record<ReelBreak, number> = { coffee: 22000, game: 28000, rest: 32000, eat: 26000 };
export const REEL_BREAK_GO: Record<ReelBreak, string[]> = {
  coffee: ['Pagod na ang mata ko sa timeline… kape muna! ☕', 'Kailangan ko ng caffeine bago mag-cut ☕'],
  game: ['Break muna, maglalaro lang ako sandali 🎮', 'Ayusin ko muna ang utak ko sa game 🕹️'],
  rest: ['Antok na ako… idlip muna saglit 😴', 'Pahinga muna, konting tulog lang 💤'],
  eat: ['Gutom na ako… kain muna bago mag-edit 🍱', 'Lunch break muna, boss! 🍙'],
};
export const REEL_BREAK_BACK = ['Balik sa timeline, boss! 🎞️', 'Ayos na, ituloy natin ang edit ✂️', 'Fresh na ako, tara! 🎬'];

/** Mga linya ni Argus (Watchdog): nagbabantay pa rin siya kahit nagpapahinga. */
export const ARGUS_BREAK_GO: Record<ReelBreak, string[]> = {
  coffee: ['Kape muna habang nakatutok sa CCTV ☕', 'Isang tasa lang, nakabantay pa rin ako 👁️'],
  game: ['Saglit lang, laro muna habang tahimik ang feed 🎮', 'Break ng bantay: isang round lang 🕹️'],
  rest: ['Idlip muna ako sa sofa, gisingin n’yo ako kapag may na-miss 😴', 'Pipikit lang ako sandali… hindi ako tulog, nagre-recharge 💤'],
  eat: ['Kain muna ako, nasa desk ko lang ang CCTV 🍱', 'Tanghalian ng watchdog 🍙 may bantay pa rin ang mata ko'],
};
export const ARGUS_BREAK_BACK = ['Balik bantay na ako! 👁️', 'Recharged, tuloy ang pag-scan 🔎', 'Handa na ulit ang mga mata ko 👀', 'Walang nakalusot habang wala ako? Check ko na 😤'];

const rand = (min: number, max: number, r: () => number) => min + r() * (max - min);
const rollDrain = (r: () => number) => rand(0.45, 0.9, r);
const rollFloor = (r: () => number) => rand(20, 36, r);

export function initReelRoutine(r: () => number = Math.random): ReelRoutine {
  return { energy: rand(55, 100, r), doing: 'work', last: null, drain: rollDrain(r), floor: rollFloor(r), breakMs: 0 };
}

/** Random na break, may bigat; hindi pareho sa huli; kapag sobrang baba ng energy, mas malamang na idlip. */
export function pickReelBreak(last: ReelBreak | null, energy: number, r: () => number = Math.random): ReelBreak {
  const w: Record<ReelBreak, number> = { coffee: 3, game: 2, rest: energy < 14 ? 6 : 2.5, eat: 2.5 };
  const kinds = (Object.keys(w) as ReelBreak[]).filter((k) => k !== last);
  let x = r() * kinds.reduce((n, k) => n + w[k], 0);
  for (const k of kinds) { x -= w[k]; if (x <= 0) return k; }
  return kinds[0];
}

/**
 * Isang hakbang ng routine (dt sa segundo). Ibinabalik ang bagong state; hindi ginagalaw ang luma.
 * - Nag-e-edit (working): nauubos ang energy. Naghihintay ng approval (waiting): mabagal lang.
 * - Walang trabaho (idle): kaunting bawi ng energy sa desk, at paminsan-minsang maikling break.
 * - Pumalya (problem): hindi nagpapahinga; kapag may break at pumalya, agad siyang babalik para ayusin.
 */
export function stepReel(s: ReelRoutine, dt: number, state: ReelState, r: () => number = Math.random): ReelRoutine {
  if (!(dt > 0)) return s;
  const n: ReelRoutine = { ...s };

  if (state === 'problem' && n.doing !== 'work') {
    n.doing = 'work';
    n.breakMs = 0;
    n.drain = rollDrain(r);
    n.floor = rollFloor(r);
  }

  if (n.doing === 'work') {
    if (state === 'working') n.energy = Math.max(0, n.energy - n.drain * dt);
    else if (state === 'waiting') n.energy = Math.max(0, n.energy - n.drain * 0.3 * dt);
    else if (state === 'idle') n.energy = Math.min(100, n.energy + 0.6 * dt);
    // pagod na, o paminsan-minsan kapag walang trabaho (mga isang beses kada 2 minuto) para hindi siyang nakatayo lang
    const idleBreak = state === 'idle' && r() < dt / 120;
    if (state !== 'problem' && (n.energy <= n.floor || idleBreak)) {
      const kind = pickReelBreak(n.last, n.energy, r);
      n.doing = kind;
      n.last = kind;
      n.breakMs = 0;
    }
  } else {
    const kind = n.doing;
    n.breakMs += dt * 1000;
    n.energy = Math.min(100, n.energy + RECOVER[kind] * dt);
    if (n.energy >= REEL_FULL && n.breakMs >= MIN_BREAK_MS[kind]) {
      n.doing = 'work';
      n.breakMs = 0;
      n.drain = rollDrain(r);
      n.floor = rollFloor(r);
    }
  }
  return n;
}
