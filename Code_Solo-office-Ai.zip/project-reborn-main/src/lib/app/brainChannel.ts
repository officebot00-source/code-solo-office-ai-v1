// Shared by the server (broadcast) and the browser (subscribe) so the two can never drift apart.
// The channel only carries a tiny "something changed" ping (kind + rule id). Rule text is NEVER sent over it:
// the screen still reloads through admin-db (password checked), so the office tables stay private.
export const BRAIN_CHANNEL = 'brain-sync';
export const BRAIN_EVENT = 'brain_changed';

export interface BrainPing { kind: string; rule_id: string | null; at: string | null }

/**
 * The channel is public (anyone with the publishable key can send on it), so a ping is only a hint and is validated like
 * untrusted input: strings only, short, and it can do nothing but make the screen reload through the password-checked admin-db.
 */
export function parseBrainPing(raw: unknown): BrainPing | null {
  if (!raw || typeof raw !== 'object') return null;
  const p = raw as Record<string, unknown>;
  if (typeof p['kind'] !== 'string' || !p['kind'] || p['kind'].length > 60) return null;
  const id = typeof p['rule_id'] === 'string' && p['rule_id'].length <= 64 ? p['rule_id'] : null;
  const at = typeof p['at'] === 'string' && p['at'].length <= 40 ? p['at'] : null;
  return { kind: p['kind'], rule_id: id, at };
}

/** A ping that says a rule is gone: the screen can drop it at once, before the reload confirms it. */
export const isDeletePing = (p: BrainPing) => p.kind.endsWith(':delete') && !!p.rule_id;
