import { describe, expect, it } from 'vitest';
import { initReelRoutine, pickReelBreak, REEL_FULL, stepReel, type ReelRoutine } from '@/lib/app/reelRoutine';

const mid = () => 0.5;
const base = (over: Partial<ReelRoutine> = {}): ReelRoutine => ({ energy: 80, doing: 'work', last: null, drain: 0.6, floor: 25, breakMs: 0, ...over });

describe('reel routine', () => {
  it('starts with sane values', () => {
    const s = initReelRoutine(mid);
    expect(s.doing).toBe('work');
    expect(s.energy).toBeGreaterThanOrEqual(55);
    expect(s.energy).toBeLessThanOrEqual(100);
    expect(s.floor).toBeGreaterThanOrEqual(20);
    expect(s.floor).toBeLessThanOrEqual(36);
  });

  it('drains while editing and stays bounded at 0', () => {
    const s = stepReel(base({ energy: 50 }), 10, 'working', mid);
    expect(s.energy).toBeCloseTo(50 - 0.6 * 10, 5);
    expect(stepReel(base({ energy: 1 }), 100, 'working', mid).energy).toBe(0);
  });

  it('drains slowly while waiting for approval and recovers a bit when idle', () => {
    expect(stepReel(base({ energy: 50 }), 10, 'waiting', mid).energy).toBeCloseTo(50 - 0.6 * 0.3 * 10, 5);
    expect(stepReel(base({ energy: 50 }), 10, 'idle', mid).energy).toBeCloseTo(56, 5);
  });

  it('does not change energy while there is a problem (it is not a break)', () => {
    expect(stepReel(base({ energy: 50 }), 5, 'problem', mid).energy).toBe(50);
  });

  it('starts a break once energy reaches the floor', () => {
    const s = stepReel(base({ energy: 25.1, floor: 25 }), 1, 'working', mid);
    expect(s.doing).not.toBe('work');
    expect(s.last).toBe(s.doing);
    expect(s.breakMs).toBe(0);
  });

  it('when idle and not tired, he sometimes takes a short break', () => {
    const s = stepReel(base({ energy: 95, floor: 25 }), 1, 'idle', () => 0);
    expect(s.doing).not.toBe('work');
    expect(stepReel(base({ energy: 95, floor: 25 }), 1, 'idle', mid).doing).toBe('work');
  });

  it('never starts a break while a problem is open', () => {
    expect(stepReel(base({ energy: 10, floor: 25 }), 1, 'problem', mid).doing).toBe('work');
  });

  it('a break ends only after min time AND energy is full again', () => {
    const onBreak = base({ energy: 40, doing: 'coffee', breakMs: 1000 });
    const early = stepReel(onBreak, 1, 'working', mid);
    expect(early.doing).toBe('coffee');
    const full = stepReel({ ...onBreak, energy: REEL_FULL - 0.1, breakMs: 30000 }, 1, 'working', mid);
    expect(full.doing).toBe('work');
    expect(full.breakMs).toBe(0);
  });

  it('a problem interrupts a break so he goes back to fix it', () => {
    const s = stepReel(base({ energy: 20, doing: 'rest', breakMs: 5000 }), 1, 'problem', mid);
    expect(s.doing).toBe('work');
    expect(s.breakMs).toBe(0);
  });

  it('pickReelBreak never repeats the last break', () => {
    for (let i = 0; i < 50; i++) {
      const r = Math.random;
      expect(pickReelBreak('coffee', 50, r)).not.toBe('coffee');
    }
  });

  it('ignores zero or negative time steps', () => {
    const s = base();
    expect(stepReel(s, 0, 'working', mid)).toBe(s);
    expect(stepReel(s, -1, 'working', mid)).toBe(s);
  });

  it('can pick eat as a break, and never the same one twice in a row', () => {
    const seen = new Set<string>();
    for (let i = 0; i < 200; i++) seen.add(pickReelBreak('coffee', 50, Math.random));
    expect(seen.has('eat')).toBe(true);
    expect(seen.has('coffee')).toBe(false);
    expect(pickReelBreak('eat', 50, () => 0.99)).not.toBe('eat');
  });

  it('an eating break recovers energy and ends after min time', () => {
    const eating = base({ energy: 40, doing: 'eat', breakMs: 1000 });
    expect(stepReel(eating, 1, 'working', mid).energy).toBeGreaterThan(40);
    expect(stepReel({ ...eating, energy: 99, breakMs: 30000 }, 1, 'working', mid).doing).toBe('work');
  });
});
