import { describe, expect, it } from 'vitest';
import { isReportRequest } from '@/lib/app/bossChat';

describe('Boss: kailan magre-report', () => {
  it.each([
    'ano na natapos mo', 'Ano na ang natapos ng team?', 'ano na ang ginawa mo', 'tapos mo na ba', 'kumusta na ang trabaho ninyo',
    'anong update', 'ano nang balita', 'ano na nangyari sa pinapagawa ko', 'magreport ka', 'status',
    'what have you finished', 'how is the team doing', 'any update',
  ])('"%s" ay hiling ng ulat', (t) => expect(isReportRequest(t)).toBe(true));

  it.each([
    'i-update mo ang caption', 'magreport ka tuwing umaga', 'gawin mong mas maikli ang caption', 'sino ka', 'ano ang ginagawa mo',
    'hello', 'ok', 'ano ang paborito mong kulay', 'huwag kang mag-post ng spam',
  ])('"%s" ay hindi hiling ng ulat', (t) => expect(isReportRequest(t)).toBe(false));
});
