import { describe, expect, it } from 'vitest';
import { aiErrorStatus } from '@/server/bot/_shared/ai.ts';

describe('AI key problems are reported as key issues, not server crashes', () => {
  it('no credits left on the OpenAI key → 402', () => {
    expect(aiErrorStatus('OpenAI 429: You have no credits remaining.')).toBe(402);
  });
  it('invalid key → 402', () => {
    expect(aiErrorStatus('Gemini 403: API key not valid')).toBe(402);
  });
  it('other failures stay 500', () => {
    expect(aiErrorStatus('AI response missing reply')).toBe(500);
  });
});

import { classifyAiError, pickModel } from '@/server/bot/_shared/ai.ts';

describe('AI key status panel verdicts', () => {
  it('OpenAI key with no credits → key valid, credits used up', () => {
    const r = classifyAiError('OpenAI 429: You have no credits remaining. Add credits to continue using the API.');
    expect(r.keyValid).toBe(true);
    expect(r.credits).toBe('empty');
  });
  it('OpenRouter 402 → credits used up', () => {
    expect(classifyAiError('OpenRouter 402: Insufficient credits').credits).toBe('empty');
  });
  it('rejected key → key not valid', () => {
    expect(classifyAiError('OpenAI 401: Incorrect API key provided').keyValid).toBe(false);
    expect(classifyAiError('Gemini 400: API key not valid. Please pass a valid API key.').keyValid).toBe(false);
  });
  it('plain rate limit → credits unknown, key still valid', () => {
    const r = classifyAiError('OpenAI 429: Rate limit reached for requests');
    expect(r.keyValid).toBe(true);
    expect(r.credits).toBe('unknown');
  });
});

describe('swapping keys keeps a model the new provider understands', () => {
  it('OpenAI model saved, Gemini key → Gemini default', () => {
    expect(pickModel('gemini', 'gpt-4o-mini')).toBe('gemini-2.0-flash');
  });
  it('OpenRouter model saved, OpenAI key → prefix dropped', () => {
    expect(pickModel('openai', 'openai/gpt-4o')).toBe('gpt-4o');
  });
  it('plain model, OpenRouter key → vendor prefix added', () => {
    expect(pickModel('openrouter', 'gpt-4o-mini')).toBe('openai/gpt-4o-mini');
    expect(pickModel('openrouter', 'gemini-2.0-flash')).toBe('google/gemini-2.0-flash');
  });
  it('nothing saved → provider default', () => {
    expect(pickModel('openai', '')).toBe('gpt-4o-mini');
  });
});
