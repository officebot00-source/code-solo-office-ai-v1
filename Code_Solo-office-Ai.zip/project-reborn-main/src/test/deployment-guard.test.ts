import { describe, expect, it } from "vitest";
import { authenticateTick, checkActiveDeployment, claimTick, parseHosts } from "@/server/deployment-guard";

const ACTIVE = "https://site.netlify.app";
const req = (url: string, headers: Record<string, string> = {}) => new Request(url, { headers });

describe("deployment guard", () => {
  it("parses hosts from urls and bare hosts", () => {
    expect(parseHosts("https://Site.netlify.app/x, custom.com")).toEqual(["site.netlify.app", "custom.com"]);
  });
  it("fails closed when ACTIVE_DEPLOYMENT_URL is missing", () => {
    expect(checkActiveDeployment(req(`${ACTIVE}/t`), {}).allowed).toBe(false);
  });
  it("allows only the active host", () => {
    const env = { ACTIVE_DEPLOYMENT_URL: ACTIVE };
    expect(checkActiveDeployment(req(`${ACTIVE}/t`), env).allowed).toBe(true);
    expect(checkActiveDeployment(req("https://officejerome.lovable.app/t"), env).allowed).toBe(false);
  });
  it("never runs on Netlify previews / branch deploys, and honours the kill switch", () => {
    expect(checkActiveDeployment(req(`${ACTIVE}/t`), { ACTIVE_DEPLOYMENT_URL: ACTIVE, CONTEXT: "deploy-preview" }).allowed).toBe(false);
    expect(checkActiveDeployment(req(`${ACTIVE}/t`), { ACTIVE_DEPLOYMENT_URL: ACTIVE, BOT_JOBS_ENABLED: "false" }).allowed).toBe(false);
  });
  it("authenticates CRON_SECRET and leaves the Lovable secret path unchanged", async () => {
    const lovable = async () => new Response("lovable", { status: 418 });
    const bearer = (t: string) => req(ACTIVE, { authorization: `Bearer ${t}` });
    expect(await authenticateTick(bearer("s3"), lovable, { CRON_SECRET: "s3" })).toBeNull();
    expect((await authenticateTick(bearer("bad"), lovable, { CRON_SECRET: "s3" }))?.status).toBe(401);
    expect((await authenticateTick(bearer("x"), lovable, { LOVABLE_CRON_SECRET: "L" }))?.status).toBe(418);
  });
  it("lets only one runner take a given minute", async () => {
    const seen = new Set<string>();
    const client = {
      from: () => ({
        insert: async (row: { key: string }) => {
          if (seen.has(row.key)) return { error: { code: "23505", message: "dup" } };
          seen.add(row.key);
          return { error: null };
        },
        delete: () => ({ like: () => ({ lt: async () => ({}) }) }),
      }),
    };
    expect(await claimTick(client, 100, "a")).toBe(true);
    expect(await claimTick(client, 100, "b")).toBe(false);
  });
});
