import { describe, expect, it } from 'vitest';
import { spawnSync } from 'node:child_process';
import { existsSync, mkdtempSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { buildCaption, buildGameClipArgs, canTransition, validatePostSpec, wrapLines, type VideoJob, type VideoSettings } from '@/lib/app/video';
import { pickGame, planGameVideo, shouldAutoGenerate, type GameLite } from '@/lib/app/gameVideo';
import { approveJob, enqueueGameJob, enqueueJob, memoryStore, rejectJob, runJob, tick, type PipelineDeps, type PostOutcome } from '@/server/bot/_shared/video-pipeline';

const GAME: GameLite = { id: 'g1', title: 'Gallop Racer', genre: 'Racing', description: 'Karera ng mga kabayo. Mag-bet at manalo!', promo_link: 'https://play.example.com/gallop', active: true };
const SETTINGS: VideoSettings = { realtime_enabled: true, dry_run: false, editor: 'auto', default_platforms: ['telegram'], auto_generate: false, auto_per_day: 1 };

function makeDeps(opts: { settings?: Partial<VideoSettings>; fileExists?: boolean } = {}) {
  const store = memoryStore();
  const logs: string[] = [];
  const settings: VideoSettings = { ...SETTINGS, ...opts.settings };
  let clock = Date.parse('2026-11-19T01:00:00Z');
  let n = 0;
  const calls = { edit: 0, post: 0, posted: [] as string[][], cleaned: [] as (string | undefined)[], review: 0, auto: 0 };
  const deps: PipelineDeps = {
    store,
    settings: async () => settings,
    edit: async () => { calls.edit++; return { adapter: 'ffmpeg', outputPath: '/tmp/clip.mp4', warnings: [], edited: true }; },
    post: async (_j, platforms): Promise<PostOutcome> => { calls.post++; calls.posted.push(platforms); return { results: platforms.map((platform) => ({ platform, id: '1' })), errors: [] }; },
    fileExists: async () => opts.fileExists ?? true,
    cleanup: async (p) => { calls.cleaned.push(p); },
    onReadyForReview: async () => { calls.review++; },
    log: async (_l, _s, m) => { logs.push(m); },
    mediaDir: '', editTimeoutMs: 1000, postTimeoutMs: 1000,
    now: () => new Date(clock), newId: () => `00000000-0000-4000-8000-${String(++n).padStart(12, '0')}`,
  };
  return { deps, store, logs, calls, settings, advance: (ms: number) => { clock += ms; } };
}
const jobOf = async (t: ReturnType<typeof makeDeps>, id: string): Promise<VideoJob> => (await t.store.get(id))!.job;

describe('game video waits for the boss', () => {
  it('stops at "awaiting_approval" and never posts on its own — not by runJob, not by the tick', async () => {
    const t = makeDeps();
    const made = await enqueueGameJob(t.deps, GAME);
    expect(made.ok).toBe(true);
    if (!made.ok) return;
    expect(made.job.needs_approval).toBe(true);
    expect(made.job.input).toBe('game:g1');
    expect((await runJob(t.deps, made.job.id))?.status).toBe('awaiting_approval');
    expect(t.calls.review).toBe(1); // the boss gets one ping
    for (let i = 0; i < 3; i++) await tick(t.deps);
    expect((await runJob(t.deps, made.job.id, { forcePost: true }))?.status).toBe('awaiting_approval');
    expect(t.calls.post).toBe(0);
    expect((await jobOf(t, made.job.id)).status).toBe('awaiting_approval');
  });

  it('posts only after approval, to the chosen platforms', async () => {
    const t = makeDeps();
    const made = await enqueueGameJob(t.deps, GAME, { platforms: ['telegram', 'discord'] });
    if (!made.ok) throw new Error(made.error);
    await runJob(t.deps, made.job.id);
    expect((await approveJob(t.deps, made.job.id)).ok).toBe(true);
    expect((await runJob(t.deps, made.job.id, { forcePost: true }))?.status).toBe('posted');
    expect(t.calls.post).toBe(1);
    expect(t.calls.posted[0]).toEqual(['telegram', 'discord']);
    const done = await jobOf(t, made.job.id);
    expect(done.approved).toBe(true);
    expect(done.approved_at).toBeTruthy();
  });

  it('if the video file expired before approval, it is made again and then posted', async () => {
    const t = makeDeps({ fileExists: false });
    const made = await enqueueGameJob(t.deps, GAME);
    if (!made.ok) throw new Error(made.error);
    await runJob(t.deps, made.job.id);
    expect(t.calls.edit).toBe(1);
    await approveJob(t.deps, made.job.id);
    expect((await jobOf(t, made.job.id)).status).toBe('queued');
    expect((await runJob(t.deps, made.job.id, { forcePost: true }))?.status).toBe('posted');
    expect(t.calls.edit).toBe(2);
    expect(t.calls.post).toBe(1);
  });

  it('a rejected video is never posted and its file is deleted', async () => {
    const t = makeDeps();
    const made = await enqueueGameJob(t.deps, GAME);
    if (!made.ok) throw new Error(made.error);
    await runJob(t.deps, made.job.id);
    expect((await rejectJob(t.deps, made.job.id, 'panget ang text')).ok).toBe(true);
    const j = await jobOf(t, made.job.id);
    expect(j.status).toBe('rejected');
    expect(j.rejected_reason).toBe('panget ang text');
    expect(t.calls.cleaned).toContain('/tmp/clip.mp4');
    expect((await approveJob(t.deps, made.job.id)).ok).toBe(false); // too late: it was rejected
    await tick(t.deps);
    expect(t.calls.post).toBe(0);
  });

  it('refuses to post an unapproved job even if something forces it (last line of defence)', async () => {
    const t = makeDeps();
    const made = await enqueueGameJob(t.deps, GAME);
    if (!made.ok) throw new Error(made.error);
    // Simulate a bug / manual tampering: the job is "edited" but the boss never approved.
    const cur = (await t.store.get(made.job.id))!;
    await t.store.cas(made.job.id, cur.rev, { ...cur.job, status: 'edited', output_path: '/tmp/clip.mp4' });
    expect((await runJob(t.deps, made.job.id, { forcePost: true }))?.status).toBe('edited');
    await tick(t.deps);
    expect(t.calls.post).toBe(0);
    expect(t.logs.some((m) => m.includes('has not been approved'))).toBe(true);
  });

  it('only a video that is waiting can be approved or rejected', async () => {
    const t = makeDeps();
    const made = await enqueueGameJob(t.deps, GAME);
    if (!made.ok) throw new Error(made.error);
    expect((await approveJob(t.deps, made.job.id)).ok).toBe(false); // still queued
    expect((await rejectJob(t.deps, made.job.id)).ok).toBe(false);
    expect((await approveJob(t.deps, 'nope')).ok).toBe(false);
  });

  it('a manual video can ask for approval too, and the old behaviour (post at once) is unchanged without it', async () => {
    const t = makeDeps();
    const body = { input: 'https://cdn.example.com/clip.mp4', edit: { aspect: '9:16' }, post: { title: 'X', caption: 'y', platforms: ['telegram'] } };
    const gated = await enqueueJob(t.deps, { ...body, needs_approval: true }, 'ui');
    const plain = await enqueueJob(t.deps, body, 'ui');
    if (!gated.ok || !plain.ok) throw new Error('enqueue failed');
    expect((await runJob(t.deps, gated.job.id))?.status).toBe('awaiting_approval');
    expect((await runJob(t.deps, plain.job.id))?.status).toBe('posted');
    expect(t.calls.post).toBe(1);
  });

  it('needs somewhere to post, and says so', async () => {
    const t = makeDeps({ settings: { default_platforms: [] } });
    const made = await enqueueGameJob(t.deps, GAME);
    expect(made.ok).toBe(false);
    if (!made.ok) expect(made.error).toMatch(/platform/i);
  });

  it('state machine: nothing jumps from "awaiting_approval" straight to posting', () => {
    expect(canTransition('awaiting_approval', 'posting')).toBe(false);
    expect(canTransition('awaiting_approval', 'posted')).toBe(false);
    expect(canTransition('awaiting_approval', 'rejected')).toBe(true);
    expect(canTransition('awaiting_approval', 'edited')).toBe(true);
    expect(canTransition('rejected', 'posting')).toBe(false);
  });
});

describe('the bot works on its own (but within limits)', () => {
  it('makes one game video per tick when allowed, and respects the daily quota and the review pile', async () => {
    const t = makeDeps({ settings: { auto_generate: true, auto_per_day: 1 } });
    t.deps.autoGenerate = async () => { t.calls.auto++; const m = await enqueueGameJob(t.deps, GAME, { source: 'worker' }); if (m.ok) await runJob(t.deps, m.job.id); };
    expect((await tick(t.deps)).generated).toBe(1);
    expect((await tick(t.deps)).generated).toBe(0); // quota of 1 per day reached
    expect(t.calls.auto).toBe(1);
    expect(t.calls.post).toBe(0);
  });

  it('does nothing when auto-generate is off', async () => {
    const t = makeDeps();
    t.deps.autoGenerate = async () => { t.calls.auto++; };
    expect((await tick(t.deps)).generated).toBe(0);
    expect(t.calls.auto).toBe(0);
  });

  it('shouldAutoGenerate: daily quota (Philippine day), max 3 waiting, nothing already in progress', () => {
    const now = new Date('2026-11-19T01:00:00Z'); // 09:00 in Manila, 19 Nov
    const job = (status: VideoJob['status'], at: string, source: VideoJob['source'] = 'worker') => ({ game_id: 'g1', status, created_at: at, source });
    const s = { auto_generate: true, auto_per_day: 2 };
    expect(shouldAutoGenerate({ ...s, auto_generate: false }, [], now)).toBe(false);
    expect(shouldAutoGenerate(s, [], now)).toBe(true);
    expect(shouldAutoGenerate(s, [job('posted', '2026-11-19T00:00:00Z')], now)).toBe(true);
    expect(shouldAutoGenerate(s, [job('posted', '2026-11-19T00:00:00Z'), job('rejected', '2026-11-19T00:30:00Z')], now)).toBe(false);
    // 23:30 UTC on the 18th is already the 19th in Manila → counts for today
    expect(shouldAutoGenerate({ ...s, auto_per_day: 1 }, [job('posted', '2026-11-18T23:30:00Z')], now)).toBe(false);
    expect(shouldAutoGenerate({ ...s, auto_per_day: 1 }, [job('posted', '2026-11-18T10:00:00Z')], now)).toBe(true);
    const pile = [1, 2, 3].map((i) => job('awaiting_approval', `2026-11-1${i}T00:00:00Z`));
    expect(shouldAutoGenerate({ ...s, auto_per_day: 5 }, pile, now)).toBe(false);
    expect(shouldAutoGenerate(s, [job('editing', '2026-11-17T00:00:00Z')], now)).toBe(false);
    expect(shouldAutoGenerate({ ...s, auto_per_day: 1 }, [job('posted', '2026-11-19T00:00:00Z', 'ui')], now)).toBe(true); // manual videos do not use the bot's quota
  });
});

describe('game video planning', () => {
  it('writes the headline, caption, tags and keeps the promo link at the end', () => {
    const plan = planGameVideo(GAME, 0);
    expect(plan.title_text).toBe('Gallop Racer');
    expect(plan.caption).toContain('Karera ng mga kabayo.');
    expect(plan.tags).toContain('#racing');
    expect(plan.tags).toContain('#gallopracer');
    const v = validatePostSpec({ title: plan.post_title, caption: plan.caption, tags: plan.tags, platforms: ['twitter'], link: GAME.promo_link });
    expect(v.ok).toBe(true);
    if (!v.ok) return;
    const tweet = buildCaption(v.post, 'twitter');
    expect(tweet.length).toBeLessThanOrEqual(270);
    expect(tweet).toContain('https://play.example.com/gallop');
    expect(buildCaption({ ...v.post, caption: 'x'.repeat(2000) }, 'twitter')).toContain('https://play.example.com/gallop'); // never cut off
  });
  it('"gawa ulit" gives different wording', () => {
    expect(planGameVideo(GAME, 1).caption).not.toBe(planGameVideo(GAME, 0).caption);
    expect(planGameVideo(GAME, 1).overlay_text).not.toBe(planGameVideo(GAME, 0).overlay_text);
  });
  it('picks the game used longest ago, skips inactive ones, and says which wording to use next', () => {
    const games: GameLite[] = [GAME, { id: 'g2', title: 'Beta', active: true }, { id: 'g3', title: 'Off', active: false }];
    expect(pickGame(games, [])?.game.id).toBe('g2'); // never used first (alphabetical)
    const used = [{ game_id: 'g2', created_at: '2026-11-18T00:00:00Z' }, { game_id: 'g1', created_at: '2026-11-10T00:00:00Z' }];
    const next = pickGame(games, used);
    expect(next?.game.id).toBe('g1');
    expect(next?.variant).toBe(1);
    expect(pickGame([{ id: 'x', title: 'Off', active: false }], [])).toBeNull();
  });
});

describe('game clip (ffmpeg)', () => {
  it('wraps long titles by words and never exceeds the line limit', () => {
    expect(wrapLines('Gallop Racer: Karera ng Bayan', 15, 3)).toEqual(['Gallop Racer:', 'Karera ng Bayan']);
    const many = wrapLines('one two three four five six seven eight nine ten eleven twelve', 8, 2);
    expect(many.length).toBe(2);
    expect(many[1]!.endsWith('…')).toBe(true);
  });

  it('builds arguments (no shell) for a banner clip and for a plain-background clip', () => {
    const img = buildGameClipArgs({ imagePath: '/tmp/b.jpg', output: '/tmp/o.mp4', durationSec: 12, title: "Rock'n Roll: 50% Off", tagline: 'Racing • go', cta: 'Play', fontFile: '/f.ttf' }).args;
    expect(img).toContain('/tmp/b.jpg');
    expect(img.join(' ')).toContain('zoompan');
    expect(img.join(' ')).toContain('-t 12');
    expect(img.join(' ')).not.toContain("Rock'n"); // the apostrophe is replaced, so it cannot break the filter
    const plain = buildGameClipArgs({ output: '/tmp/o.mp4', durationSec: 3, title: 'T' }).args.join(' ');
    expect(plain).toContain('color=c=');
    expect(plain).not.toContain('zoompan');
    expect(buildGameClipArgs({ output: '/tmp/o.mp4', durationSec: 3, title: 'T', withText: false }).usesText).toBe(false);
    expect(buildGameClipArgs({ output: '/tmp/o.mp4', durationSec: 999, title: 'T' }).args.join(' ')).toContain('-t 60');
  });

  const hasFfmpeg = spawnSync('ffmpeg', ['-version']).status === 0;
  it.skipIf(!hasFfmpeg)('really renders a 1080x1920 mp4 with ffmpeg', () => {
    const out = join(mkdtempSync(join(tmpdir(), 'clip-')), 'o.mp4');
    const plan = buildGameClipArgs({ output: out, durationSec: 3, title: 'Gallop Racer', tagline: 'Laruin na ngayon!', cta: 'Play now' });
    let r = spawnSync('ffmpeg', plan.args, { encoding: 'utf8' });
    if (r.status !== 0 && plan.usesText) r = spawnSync('ffmpeg', buildGameClipArgs({ output: out, durationSec: 3, title: 'x', withText: false }).args, { encoding: 'utf8' }); // no drawtext in this build
    expect(r.status).toBe(0);
    expect(existsSync(out)).toBe(true);
    expect(statSync(out).size).toBeGreaterThan(1024);
    const probe = spawnSync('ffprobe', ['-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height', '-of', 'csv=p=0', out], { encoding: 'utf8' });
    if (probe.status === 0) expect(probe.stdout.trim()).toBe('1080,1920');
  });
});
