import { describe, expect, it } from 'vitest';
import { isGoodbye, nowConfirm, parseAfterCall, parseNowCall, sanitizeAction } from '@/lib/app/callActions';
import { ABOUT_OWNER, OWNER_ANSWER } from '@/lib/app/ownerIdentity';

describe('after-call plan', () => {
  it('finds meeting + everyone named', () => {
    const p = parseAfterCall('after natin mag usap mag set ka ng meeting or kausapin mo si reel si cipher, argus, nova aria at blaze');
    expect(p?.meeting).toBe(true);
    expect(p?.people.sort()).toEqual(['argus', 'aria', 'blaze', 'cipher', 'nova', 'reel']);
  });
  it('finds a meeting for the whole team', () => {
    expect(parseAfterCall('after natin mag usap magpatawag ka ng meeting sa buong team')?.meeting).toBe(true);
    expect(parseAfterCall('pagkatapos ng tawag, ipatawag mo ang lahat sa meeting')?.meeting).toBe(true);
  });
  it('understands "pag binaba ko ang tawag" and English', () => {
    expect(parseAfterCall('pag binaba ko ang tawag kausapin mo si Reel at Nova')?.people.sort()).toEqual(['nova', 'reel']);
    expect(parseAfterCall('after this call set a meeting and talk to Aria')).toEqual({ meeting: true, people: ['aria'] });
  });
  it('understands bare "tapos" (the owner\'s own words)', () => {
    expect(parseAfterCall('tapos natin mag usap magpatawag ka ng meeting sa buong team')?.meeting).toBe(true);
    expect(parseAfterCall('after namin mag chat at mag usap magpatawag ka ng meeting sa buong team')?.meeting).toBe(true);
  });
  it('runs a bare request right now instead of leaving it to the AI', () => {
    expect(parseNowCall('magpatawag ka ng meeting sa buong team')).toEqual({ meeting: true, people: [] });
    expect(parseNowCall('kausapin mo si Reel at Nova')?.people.sort()).toEqual(['nova', 'reel']);
    expect(nowConfirm({ meeting: true, people: [] }, 'fil-PH')).toContain('ngayon din');
  });
  it('does not fire on questions, small talk or after-phrases', () => {
    expect(parseNowCall('ano ang napag-usapan sa meeting kahapon?')).toBeNull();
    expect(parseNowCall('maganda ang meeting natin')).toBeNull();
    expect(parseNowCall('tapos natin mag usap magpatawag ka ng meeting')).toBeNull(); // hawak ito ng parseAfterCall
  });
  it('ignores plain requests with no "after"', () => {
    expect(parseAfterCall('mag set ka ng meeting ngayon')).toBeNull();
  });
});

describe('speech-to-text and typing variants', () => {
  it('understands "miting", "mag patawag" and "mag set"', () => {
    expect(parseNowCall('mag patawag ka ng miting sa buong team')?.meeting).toBe(true);
    expect(parseNowCall('mag set ka ng meeting')?.meeting).toBe(true);
    expect(parseAfterCall('tapos natin mag usap ipa tawag mo ang lahat sa miting')?.meeting).toBe(true);
  });
});

describe('AI-detected actions are cleaned before use', () => {
  it('keeps only known people and a valid time', () => {
    expect(sanitizeAction({ meeting: true, people: ['Aria', 'hacker', 'reel'], when: 'later' })).toEqual({ meeting: true, people: ['aria', 'reel'], when: 'now' });
    expect(sanitizeAction({ meeting: false, people: ['x'], when: 'now' })).toBeNull();
    expect(sanitizeAction('meeting')).toBeNull();
    expect(sanitizeAction({ meeting: true, people: [], when: 'after_call' })?.when).toBe('after_call');
  });
});

describe('who am I', () => {
  it('matches Tagalog and English', () => {
    expect(ABOUT_OWNER.test('Sino ako na kausap mo')).toBe(true);
    expect(ABOUT_OWNER.test('who am I?')).toBe(true);
    expect(ABOUT_OWNER.test('sino ka')).toBe(false);
  });
  it('matches typos and the exact answers', () => {
    for (const t of ['who im i', 'who i am', 'sino po ako', 'do you know who I am']) expect(ABOUT_OWNER.test(t)).toBe(true);
    expect(OWNER_ANSWER['fil-PH']).toContain('Ikaw ang totoong Code Solo, ang Boss ko, boss.');
    expect(OWNER_ANSWER['en-US']).toContain('You are the real Code Solo, my Boss, boss.');
  });
});

describe('goodbye ends the talk', () => {
  it('detects short goodbyes only', () => {
    for (const t of ['sige bye boss', 'yun lang boss', 'tapos na tayo', 'thank you boss', 'that is all']) expect(isGoodbye(t)).toBe(true);
    for (const t of ['yun lang ba ang gagawin ng team', 'mag set ka ng meeting', 'salamat']) expect(isGoodbye(t)).toBe(false);
  });
});
