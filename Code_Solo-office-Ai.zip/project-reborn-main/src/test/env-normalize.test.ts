import { describe, expect, it } from "vitest";
import { cleanSupabaseUrl, normalizeEnv } from "@/lib/env-normalize";

describe("env normalize", () => {
  it("reduces a supabase url to its origin", () => {
    expect(cleanSupabaseUrl("https://abc.supabase.co/rest/v1/")).toBe("https://abc.supabase.co");
    expect(cleanSupabaseUrl('  "https://abc.supabase.co/"\n')).toBe("https://abc.supabase.co");
    expect(cleanSupabaseUrl("abc.supabase.co")).toBe("https://abc.supabase.co");
  });
  it("trims keys", () => {
    const env: Record<string, string> = { SUPABASE_SERVICE_ROLE_KEY: ' "sb_secret_x"\n', SUPABASE_URL: "https://a.supabase.co/x" };
    normalizeEnv(env);
    expect(env["SUPABASE_SERVICE_ROLE_KEY"]).toBe("sb_secret_x");
    expect(env["SUPABASE_URL"]).toBe("https://a.supabase.co");
  });
});
