import { afterEach, describe, expect, it, vi } from 'vitest';
import { checkConnection, explainFacebookError, sendFacebook } from '../server/bot/_shared/publish';

const M200 = '(#200) If posting to a page, requires both pages_read_engagement and pages_manage_posts as an admin with sufficient administrative permission';
const jsonRes = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status });
const creds = { facebook: { page_id: '111', access_token: 'tok' } };

afterEach(() => vi.unstubAllGlobals());

describe('Facebook #200', () => {
  it('explains how to fix it and keeps Meta\'s own message', () => {
    const t = explainFacebookError(403, M200);
    expect(t).toContain(M200);
    expect(t).toMatch(/PAGE access token/);
    expect(t).toContain('pages_manage_posts');
  });

  it('sendFacebook throws the explained message', async () => {
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue(jsonRes({ error: { message: M200, code: 200 } }, 403)));
    await expect(sendFacebook(creds.facebook, 'hi')).rejects.toThrow(/Page access token|PAGE access token/);
  });

  it('Test connection catches a User token (it used to say OK, then posting failed)', async () => {
    vi.stubGlobal('fetch', vi.fn()
      .mockResolvedValueOnce(jsonRes({ id: '111', name: 'My Page' }))
      .mockResolvedValueOnce(jsonRes({ id: '999', name: 'Juan' })));
    await expect(checkConnection('facebook', creds)).rejects.toThrow(/User token/);
  });

  it('Test connection catches a Page token missing pages_read_engagement', async () => {
    vi.stubGlobal('fetch', vi.fn()
      .mockResolvedValueOnce(jsonRes({ id: '111', name: 'My Page' }))
      .mockResolvedValueOnce(jsonRes({ id: '111', name: 'My Page' }))
      .mockResolvedValueOnce(jsonRes({ error: { message: M200, code: 200 } }, 403)));
    await expect(checkConnection('facebook', creds)).rejects.toThrow(/kulang ang permissions/);
  });

  it('passes with a proper Page token', async () => {
    vi.stubGlobal('fetch', vi.fn()
      .mockResolvedValueOnce(jsonRes({ id: '111', name: 'My Page' }))
      .mockResolvedValueOnce(jsonRes({ id: '111', name: 'My Page' }))
      .mockResolvedValueOnce(jsonRes({ data: [] })));
    await expect(checkConnection('facebook', creds)).resolves.toBe('Page "My Page" OK');
  });
});
