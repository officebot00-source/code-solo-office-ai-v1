// Server-only. Decides whether THIS deployment (Netlify, Lovable, a preview, ...) is the one allowed to run
// background work: the 1-minute bot tick and the Facebook webhook.
//
// Why: the same code can be live in several places at once (Netlify production, Netlify deploy previews,
// the Lovable-published site). Each one would run the bots against the same database -> duplicate posts/replies.
//
// Rule (fail CLOSED): background work runs only when the host that received the request is listed in
// ACTIVE_DEPLOYMENT_URL. If the variable is missing, nothing runs. User-driven routes (admin-db, publish-now,
// generate-post, ...) are NOT affected by this guard.
//
// No Node-only imports at the top level, so it is safe to load from route files; it is loaded on demand anyway.

export type GuardResult =
  | { allowed: true; host: string }
  | { allowed: false; host: string; reason: string };

type Env = Record<string, string | undefined>;

/** "https://App.Netlify.app/path, other.example.com" -> ["app.netlify.app", "other.example.com"] */
export function parseHosts(value: string | undefined): string[] {
  return String(value ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
    .map((s) => {
      try {
        return new URL(/^[a-z][a-z0-9+.-]*:\/\//i.test(s) ? s : `https://${s}`).host.toLowerCase();
      } catch {
        return s.toLowerCase();
      }
    });
}

/** Hosts this request claims to be for: the URL host, plus x-forwarded-host when a proxy sets it. */
export function requestHosts(request: Request): string[] {
  const hosts = new Set<string>();
  try { hosts.add(new URL(request.url).host.toLowerCase()); } catch { /* ignore */ }
  const fwd = request.headers.get('x-forwarded-host')?.split(',')[0]?.trim().toLowerCase();
  if (fwd) hosts.add(fwd);
  return [...hosts];
}

export function checkActiveDeployment(request: Request, env: Env = process.env): GuardResult {
  const hosts = requestHosts(request);
  const host = hosts[0] ?? 'unknown';

  if (String(env['BOT_JOBS_ENABLED'] ?? '').trim().toLowerCase() === 'false') {
    return { allowed: false, host, reason: 'BOT_JOBS_ENABLED=false (jobs switched off on this deployment)' };
  }

  const active = parseHosts(env['ACTIVE_DEPLOYMENT_URL']);
  if (active.length === 0) {
    return { allowed: false, host, reason: 'ACTIVE_DEPLOYMENT_URL is not set on this deployment, so it runs no background jobs' };
  }

  // Netlify deploy previews / branch deploys must never run jobs (CONTEXT is only set on Netlify).
  const context = String(env['CONTEXT'] ?? '').trim();
  if (context && context !== 'production') {
    return { allowed: false, host, reason: `Netlify context "${context}" is not production` };
  }

  if (!hosts.some((h) => active.includes(h))) {
    return { allowed: false, host, reason: `this host is not the active deployment (active: ${active.join(', ')})` };
  }
  return { allowed: true, host };
}

async function sha256(value: string): Promise<Uint8Array> {
  const { createHash } = await import('node:crypto');
  return createHash('sha256').update(value, 'utf8').digest();
}

/**
 * Auth for /api/public/cron/tick. Accepts CRON_SECRET (Netlify / any scheduler you run yourself).
 * Falls back to Lovable's own check (LOVABLE_CRON_SECRET) so the Lovable schedule keeps working unchanged.
 * `lovableAuth` is the generated authenticateCronRequest; it is passed in so that file stays untouched.
 */
export async function authenticateTick(
  request: Request,
  lovableAuth: (r: Request) => Promise<Response | null>,
  env: Env = process.env,
): Promise<Response | null> {
  const ours = env['CRON_SECRET'];
  const theirs = env['LOVABLE_CRON_SECRET'];

  if (ours) {
    const token = /^Bearer ([^\s,]+)$/.exec(request.headers.get('authorization') ?? '')?.[1];
    if (token) {
      const { timingSafeEqual } = await import('node:crypto');
      if (timingSafeEqual(await sha256(token), await sha256(ours))) return null;
    }
    if (!theirs) return new Response('Unauthorized', { status: 401 });
  }
  return lovableAuth(request);
}

interface LockClient {
  from: (table: string) => any; // supabase-js query builder (typed loosely on purpose)
}

/**
 * One tick per minute, across ALL deployments that run this code. The first caller inserts
 * bot_state(key = "cron_tick:<minute>") and wins; everybody else gets the unique-key error and skips.
 * Uses the existing bot_state table (same trick daily-poster uses): no migration needed.
 * If the database call fails for any other reason we RUN the tick (a missed minute is worse than a retry of idempotent jobs).
 */
export async function claimTick(client: LockClient, minute: number, host: string): Promise<boolean> {
  const key = `cron_tick:${minute}`;
  try {
    const { error } = await client.from('bot_state').insert({ key, value: { host }, updated_at: new Date().toISOString() });
    if (error) {
      if (error.code === '23505') return false;
      console.warn(`[tick-lock] could not take lock (${error.message}); running anyway`);
      return true;
    }
    // best-effort cleanup of old locks (older than 1 hour)
    const cutoff = new Date(Date.now() - 60 * 60_000).toISOString();
    await client.from('bot_state').delete().like('key', 'cron_tick:%').lt('updated_at', cutoff);
    return true;
  } catch (e) {
    console.warn(`[tick-lock] lock check failed (${String(e)}); running anyway`);
    return true;
  }
}
