// "Post now": publishes the given queued posts to the real platforms immediately (no waiting for the 1-minute worker).
// Body: { post_ids: string[], retry?: boolean }
import type { SupabaseClient } from '@supabase/supabase-js';
import { supabaseAdmin } from '@/integrations/supabase/client.server';
import { authorized, claimPost, corsHeaders, json, loadCreds, makeLogger, publishClaimed } from './_shared/publish.ts';

const sb = supabaseAdmin as unknown as SupabaseClient;

export default async function handler(req: Request): Promise<Response> {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'POST only' }, 405);
  if (!authorized(req)) return json({ error: 'Wrong or missing passcode' }, 401);

  let body: { post_ids?: unknown; retry?: unknown };
  try { body = await req.json(); } catch { return json({ error: 'Invalid JSON' }, 400); }
  const ids = Array.isArray(body.post_ids) ? body.post_ids.filter((x): x is string => typeof x === 'string' && /^[0-9a-f-]{36}$/i.test(x)).slice(0, 10) : [];
  if (!ids.length) return json({ error: 'post_ids required' }, 400);

  const log = makeLogger(sb);
  const creds = await loadCreds(sb);
  const { data: cfg } = await sb.from('bot_settings').select('est_audience').eq('id', 1).maybeSingle();
  const results = [];
  for (const id of ids) {
    const post = await claimPost(sb, id, body.retry === true);
    if (!post) { results.push({ id, status: 'skipped', errors: ['Already published, in progress, or not found'] }); continue; }
    await log('info', 'auto-poster', `Blaze is publishing "${post.game_title}" now to ${post.platforms.join(', ')}…`);
    try {
      results.push(await publishClaimed(sb, post, creds, cfg?.est_audience ?? 0, log));
    } catch (e) {
      await sb.from('scheduled_posts').update({ status: 'failed', error: (e as Error).message }).eq('id', id);
      results.push({ id, status: 'failed', errors: [(e as Error).message] });
    }
  }
  return json({ ok: true, results });
}
