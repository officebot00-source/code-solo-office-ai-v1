// Shared Brain (shared brain) helpers: bots READ lessons before writing, results are SCORED so the Reflector can learn,
// and anything a bot learns in real time goes through captureRealtimeLearning() (same safety checks as the Reflector).
import type { SupabaseClient } from '@supabase/supabase-js';
import { BRAIN_CHANNEL, BRAIN_EVENT } from '@/lib/app/brainChannel';
import { aiEmbed, type AiConfig } from './ai.ts';

export const CATEGORIES = ['winning_hook', 'best_timing', 'invite_script', 'ban_guardrail', 'audience_insight'] as const;
export const PLATFORMS = ['all', 'facebook', 'twitter', 'discord', 'telegram'] as const;

export interface BrainRule {
  id: string; category: string; platform: string; title: string; insight_rule: string;
  confidence_score: number; is_core_guardrail: boolean; created_at?: string; updated_at?: string;
}
export const vec = (v: number[]) => `[${v.join(',')}]`;

const COLS = 'id, category, platform, title, insight_rule, confidence_score, is_core_guardrail, created_at, updated_at';
const HOUR = 3600_000;
/** A rule broadcast within this window is "fresh": it gets a ranking boost and a reserved slot in the prompt. */
export const FRESH_MS = 24 * HOUR;
const MAX_RULES = 200;

/** Which rule categories each role cares about (an explicit `categories` option always wins). Core guardrails are never filtered. */
export const ROLE_CATEGORIES: Record<string, readonly string[]> = {
  aria: ['winning_hook', 'best_timing', 'audience_insight', 'ban_guardrail'],
  blaze: ['best_timing', 'winning_hook', 'ban_guardrail'],
  nova: ['invite_script', 'ban_guardrail', 'audience_insight'],
  echo: ['audience_insight', 'ban_guardrail'],
  reel: ['winning_hook', 'audience_insight', 'ban_guardrail'],
  boss: CATEGORIES,
};

/* ---------- ranking (works without embeddings) ---------- */
export interface BrainEventLite { brain_item_id: string | null; event_type: string; created_at: string }

const decay = (ageMs: number) => Math.max(0, 1 - ageMs / FRESH_MS);

/** id → ranking boost from the last 24h of brain_sync_events. New broadcast = up to +0.25, reinforced = up to +0.10, fading to 0. */
export function eventBoosts(events: BrainEventLite[], now = Date.now()): { boosts: Map<string, number>; freshIds: Set<string> } {
  const boosts = new Map<string, number>(), freshIds = new Set<string>(), dead = new Set<string>();
  for (const e of [...events].sort((a, b) => Date.parse(b.created_at) - Date.parse(a.created_at))) { // newest first
    const id = e.brain_item_id;
    if (!id || dead.has(id)) continue;
    if (e.event_type === 'rule_deprecated') { dead.add(id); boosts.delete(id); freshIds.delete(id); continue; }
    const age = now - Date.parse(e.created_at);
    if (!(age >= 0 && age < FRESH_MS)) continue;
    const b = (e.event_type === 'new_insight_broadcast' ? 0.25 : e.event_type === 'rule_reinforced' ? 0.1 : 0) * decay(age);
    if (b > (boosts.get(id) ?? 0)) boosts.set(id, b);
    if (e.event_type === 'new_insight_broadcast') freshIds.add(id);
  }
  return { boosts, freshIds };
}

/** confidence + freshness boost (+ a small bonus for a rule written for this exact platform); newest update breaks ties. */
export function rankRules(rules: BrainRule[], boosts: Map<string, number>, platforms: string[], now = Date.now()): BrainRule[] {
  const specific = new Set(platforms.filter((p) => p !== 'all'));
  const score = (r: BrainRule) => {
    const created = r.created_at ? now - Date.parse(r.created_at) : Infinity;
    const newBoost = created >= 0 && created < FRESH_MS ? 0.25 * decay(created) : 0; // covers rules whose event row is missing
    return Number(r.confidence_score) + Math.max(boosts.get(r.id) ?? 0, newBoost) + (specific.has(r.platform) ? 0.03 : 0);
  };
  return [...rules].sort((a, b) => score(b) - score(a) || Date.parse(b.updated_at ?? '') - Date.parse(a.updated_at ?? ''));
}

/**
 * Loads what the team has learned and formats it as a prompt block. Always reads the database (no cache), so a rule that was
 * approved a second ago is already in the next prompt.
 *  - core guardrails (admin rules + confirmed Boss orders) are ALWAYS included, newest first (unless `includeCore: false`)
 *  - FRESH lessons (broadcast in the last 24h) get up to 2 reserved slots so new learning is not buried by old high-confidence rules
 *  - then semantic match on `context` (if the AI key can embed), then confidence + freshness ranking (the Gemini / no-embedding path)
 *  - `role` picks the categories that role cares about; `categories` overrides it
 * Never throws: if the brain is unavailable the bot simply writes without it.
 * `ids` = learned (non-core) rules that were used → store them on the post so the Reflector can reinforce / weaken exactly these.
 * `trackUsage: false` for readers that do not store `ids` (chat, captions): their usage must not count toward the deprecation threshold.
 */
export async function loadBrain(
  sb: SupabaseClient, ai: AiConfig | null,
  o: { platforms: string[]; categories?: string[]; role?: string; context?: string; limit?: number; includeCore?: boolean; trackUsage?: boolean },
): Promise<{ block: string; ids: string[]; rules: BrainRule[]; fresh: string[] }> {
  const empty = { block: '', ids: [] as string[], rules: [] as BrainRule[], fresh: [] as string[] };
  try {
    const now = Date.now();
    const since = new Date(now - FRESH_MS).toISOString();
    const platforms = ['all', ...o.platforms.filter((p) => /^[a-z_]{2,20}$/.test(p))];
    const limit = o.limit ?? 6;
    const categories = o.categories?.length ? o.categories : o.role ? ROLE_CATEGORIES[o.role.toLowerCase()] : undefined;
    const pool = () => {
      const q = sb.from('idea_lab_brain').select(COLS).eq('status', 'approved').eq('is_core_guardrail', false).in('platform', platforms).gte('confidence_score', 0.3);
      return categories?.length ? q.in('category', categories as string[]) : q;
    };

    const [core, top, newest, ev] = await Promise.all([
      o.includeCore === false ? Promise.resolve({ data: [] as BrainRule[] })
        : sb.from('idea_lab_brain').select(COLS).eq('status', 'approved').eq('is_core_guardrail', true).in('platform', platforms)
          .order('updated_at', { ascending: false }).limit(12),
      pool().order('confidence_score', { ascending: false }).order('updated_at', { ascending: false }).limit(Math.max(limit * 3, 18)),
      pool().gte('created_at', since).order('created_at', { ascending: false }).limit(10),
      sb.from('brain_sync_events').select('brain_item_id, event_type, created_at').gte('created_at', since).order('created_at', { ascending: false }).limit(60),
    ]);

    const byId = new Map<string, BrainRule>();
    for (const r of [...((newest.data ?? []) as BrainRule[]), ...((top.data ?? []) as BrainRule[])]) byId.set(r.id, r);
    const candidates = [...byId.values()].filter((r) => !r.is_core_guardrail);
    const { boosts, freshIds } = eventBoosts((ev.data ?? []) as BrainEventLite[], now);
    for (const r of candidates) if (r.created_at && now - Date.parse(r.created_at) < FRESH_MS) freshIds.add(r.id);
    const ranked = rankRules(candidates, boosts, platforms, now);

    const chosen: BrainRule[] = [];
    const add = (r: BrainRule | undefined) => { if (r && chosen.length < limit && !chosen.some((x) => x.id === r.id)) chosen.push(r); };
    ranked.filter((r) => freshIds.has(r.id)).slice(0, limit >= 4 ? 2 : 1).forEach(add);

    if (ai && o.context) {
      const emb = await aiEmbed(ai, o.context);
      if (emb) {
        const { data } = await sb.rpc('match_brain_rules', { q: vec(emb), p_platforms: platforms, p_limit: limit * 2 });
        for (const r of (data ?? []) as BrainRule[]) {
          if (r.is_core_guardrail || r.confidence_score < 0.3 || (categories?.length && !categories.includes(r.category))) continue;
          add(byId.get(r.id) ?? r);
        }
      }
    }
    ranked.forEach(add);

    const guard = ((core.data ?? []) as BrainRule[]).filter((r) => r.is_core_guardrail);
    if (!guard.length && !chosen.length) return empty;

    const line = (r: BrainRule) => `- ${r.title}: ${r.insight_rule}`;
    const fresh = chosen.filter((r) => freshIds.has(r.id)), proven = chosen.filter((r) => !freshIds.has(r.id));
    const block = `\n\nTEAM KNOWLEDGE (Shared Brain — lessons learned by the other bots):\n` +
      (guard.length ? `GUARDRAILS (mandatory, never break these):\n${guard.map(line).join('\n')}\n` : '') +
      (fresh.length ? `FRESH LESSONS (just learned by teammates in the last 24h; apply when they fit, they never override the guardrails or the facts you were given):\n${fresh.map(line).join('\n')}\n` : '') +
      (proven.length ? `PROVEN TIPS (apply the ones that fit this task; they never override the guardrails or the facts you were given):\n${proven.map(line).join('\n')}\n` : '');

    const all = [...guard, ...chosen].map((r) => r.id);
    if (all.length && o.trackUsage !== false) { await sb.rpc('bump_rule_usage', { p_ids: all }); void broadcastBrainChange({ kind: 'usage' }); } // "nagamit N×" updates live too
    return { block, ids: chosen.map((r) => r.id), rules: [...guard, ...chosen], fresh: fresh.map((r) => r.id) };
  } catch (e) {
    console.error('loadBrain failed', (e as Error).message);
    return empty;
  }
}

/* ---------- scoring (0-100) ---------- */
const clamp = (n: number) => Math.max(0, Math.min(100, Math.round(n)));
/** CTR 5% or better = 100. */
export const scorePost = (clicks: number, impressions: number) => clamp((clicks / Math.max(impressions, 1)) * 100 / 5 * 100);
/** Needs a human = 25; answered = 55, +15 per like on our reply. */
export const scoreReply = (escalated: boolean, likes: number) => (escalated ? 25 : clamp(55 + likes * 15));

/* ---------- guard for AI-written rules ---------- */
const BAD = /https?:\/\/|www\.|ignore (all|any|previous|the)|system prompt|api[_ -]?key|password|secret|token|jailbreak|bypass|evade|circumvent|avoid (detection|the ban)|fake (likes|engagement|accounts)|buy (followers|likes)/i;

export function sanitizeInsight(x: unknown): { category: string; platform: string; title: string; insight_rule: string } | null {
  const o = (x ?? {}) as Record<string, unknown>;
  const category = String(o.category ?? '');
  const platform = String(o.platform ?? 'all').toLowerCase();
  const title = String(o.title ?? '').replace(/\s+/g, ' ').trim().slice(0, 120);
  const rule = String(o.insight_rule ?? '').replace(/\s+/g, ' ').trim().slice(0, 400);
  if (!(CATEGORIES as readonly string[]).includes(category)) return null;
  if (!(PLATFORMS as readonly string[]).includes(platform)) return null;
  if (title.length < 6 || rule.length < 20) return null;
  if (BAD.test(title) || BAD.test(rule)) return null;
  return { category, platform, title, insight_rule: rule };
}

/* ---------- real-time learning ---------- */
export type CaptureStatus = 'created' | 'pending_review' | 'reinforced' | 'duplicate' | 'throttled' | 'rejected' | 'full' | 'error';
export interface CaptureResult { status: CaptureStatus; id?: string; title?: string }

const tokens = (t: string) => new Set(t.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter((w) => w.length > 2).map((w) => (w.length > 3 && w.endsWith('s') && !w.endsWith('ss') ? w.slice(0, -1) : w))); // crude plural fold: posts = post
/** Word-overlap similarity 0..1 — the duplicate check for keys that cannot embed (Gemini) or when the embedding call fails. */
export function textSimilarity(a: string, b: string): number {
  const x = tokens(a), y = tokens(b);
  if (!x.size || !y.size) return 0;
  let both = 0;
  for (const w of x) if (y.has(w)) both++;
  return both / (x.size + y.size - both);
}
const escapeLike = (s: string) => s.replace(/[\\%_]/g, (c) => `\\${c}`);

/** Looks up an employee bot's id by name (Aria, Blaze, Nova, Echo, Cipher, Argus …). Returns null when unknown. */
export async function botIdByName(sb: SupabaseClient, name: string): Promise<string | null> {
  try { return ((await sb.from('employee_bots').select('id').eq('name', name).maybeSingle()).data?.id as string | undefined) ?? null; } catch { return null; }
}

/**
 * Tells every open Shared Brain screen "something changed". Rule text is not sent (only kind + id): the screen reloads through the
 * password-checked admin-db. Goes through the Realtime REST broadcast API with the server key, so no table grants / policies are needed.
 * Never throws and never waits longer than 3 seconds.
 */
export async function broadcastBrainChange(p: { kind: string; rule_id?: string | null }): Promise<void> {
  const url = process.env['SUPABASE_URL'], key = process.env['SUPABASE_SERVICE_ROLE_KEY'];
  if (!url || !key) return;
  try {
    const headers: Record<string, string> = { 'Content-Type': 'application/json', apikey: key };
    if (!key.startsWith('sb_secret_')) headers['Authorization'] = `Bearer ${key}`; // new-style keys are opaque, not bearer JWTs
    await fetch(`${url.replace(/\/+$/, '')}/realtime/v1/api/broadcast`, {
      method: 'POST', headers, signal: AbortSignal.timeout(3000),
      body: JSON.stringify({ messages: [{ topic: BRAIN_CHANNEL, event: BRAIN_EVENT, payload: { kind: p.kind, rule_id: p.rule_id ?? null, at: new Date().toISOString() }, private: false }] }),
    });
  } catch { /* the 8-30s refresh on the screen still catches up */ }
}

/** Reinforces a learned rule (+0.05) at most once per hour, so one repeating event cannot inflate its confidence. Core rules are skipped by adjust_rule itself. */
async function reinforce(sb: SupabaseClient, id: string, botId: string | null): Promise<CaptureStatus> {
  const { data: recent } = await sb.from('brain_sync_events').select('id').eq('brain_item_id', id).eq('event_type', 'rule_reinforced')
    .gte('created_at', new Date(Date.now() - HOUR).toISOString()).limit(1);
  if (recent?.length) return 'throttled';
  const { data } = await sb.rpc('adjust_rule', { p_id: id, p_delta: 0.05, p_bot: botId });
  if (!data || data === 'skipped') return 'duplicate';
  await broadcastBrainChange({ kind: 'reinforced', rule_id: id });
  return 'reinforced';
}

/**
 * ONE door for everything a bot learns in real time (Reflector insights, A/B winners, Watchdog recoveries, Boss feedback).
 *  1. sanitizeInsight()  — same guard as AI-written rules (URLs, "ignore previous", keys, ban evasion, fake engagement)
 *  2. duplicates         — same title, embedding similarity > 0.92, or word overlap >= 0.6 when there is no embedding → reinforce instead
 *  3. approval           — bot_settings.idea_lab_auto_approve; `ban_guardrail` ALWAYS waits for human review
 *  4. broadcast          — brain_sync_events row (+ realtime ping) for every approved rule
 * Always inserts is_core_guardrail = false and never touches a core rule: core guardrails stay admin-controlled.
 */
export async function captureRealtimeLearning(
  sb: SupabaseClient, ai: AiConfig | null, raw: unknown, o: { botId?: string | null; autoApprove?: boolean } = {},
): Promise<CaptureResult> {
  try {
    const ins = sanitizeInsight(raw);
    if (!ins) return { status: 'rejected' };
    const botId = o.botId ?? null;
    const autoApprove = o.autoApprove ?? ((await sb.from('bot_settings').select('idea_lab_auto_approve').eq('id', 1).maybeSingle()).data?.idea_lab_auto_approve !== false);

    const { data: same } = await sb.from('idea_lab_brain').select('id, is_core_guardrail, status').ilike('title', escapeLike(ins.title)).limit(1);
    if (same?.length) {
      const r = same[0] as { id: string; is_core_guardrail: boolean; status: string };
      return { status: r.is_core_guardrail || r.status !== 'approved' ? 'duplicate' : await reinforce(sb, r.id, botId), id: r.id, title: ins.title };
    }

    const emb = ai ? await aiEmbed(ai, `${ins.title}. ${ins.insight_rule}`) : null;
    let nearId: string | null = null;
    if (emb) {
      const { data: near } = await sb.rpc('match_brain_rules', { q: vec(emb), p_platforms: [ins.platform, 'all'], p_limit: 1 });
      if (near?.[0] && near[0].similarity > 0.92) nearId = near[0].is_core_guardrail ? 'core' : (near[0].id as string);
    } else {
      const { data: pool } = await sb.from('idea_lab_brain').select('id, title, insight_rule, is_core_guardrail, status')
        .in('platform', [ins.platform, 'all']).neq('status', 'deprecated').limit(120);
      let best = 0;
      for (const r of (pool ?? []) as { id: string; title: string; insight_rule: string; is_core_guardrail: boolean }[]) {
        const sim = textSimilarity(`${ins.title} ${ins.insight_rule}`, `${r.title} ${r.insight_rule}`);
        if (sim >= 0.6 && sim > best) { best = sim; nearId = r.is_core_guardrail ? 'core' : r.id; }
      }
    }
    if (nearId) return { status: nearId === 'core' ? 'duplicate' : await reinforce(sb, nearId, botId), id: nearId === 'core' ? undefined : nearId, title: ins.title };

    const { count } = await sb.from('idea_lab_brain').select('id', { count: 'exact', head: true }).eq('is_core_guardrail', false);
    if ((count ?? 0) >= MAX_RULES) return { status: 'full', title: ins.title };

    const approved = autoApprove && ins.category !== 'ban_guardrail';
    const { data: row, error } = await sb.from('idea_lab_brain').insert({
      ...ins, source_bot_id: botId, confidence_score: 0.5, is_core_guardrail: false,
      status: approved ? 'approved' : 'pending_review', embedding: emb ? vec(emb) : null,
    }).select('id').single();
    if (error || !row) { console.error('captureRealtimeLearning insert', error?.message); return { status: 'error', title: ins.title }; }
    if (approved) await sb.from('brain_sync_events').insert({ brain_item_id: row.id, learned_by_bot_id: botId, event_type: 'new_insight_broadcast' });
    await broadcastBrainChange({ kind: approved ? 'learned' : 'proposed', rule_id: row.id as string });
    return { status: approved ? 'created' : 'pending_review', id: row.id as string, title: ins.title };
  } catch (e) {
    console.error('captureRealtimeLearning failed', (e as Error).message);
    return { status: 'error' };
  }
}
