// Argus the Watchdog — pure helpers (no network, no database) so the nagging rules can be tested on their own.

export type IssueKind =
  | 'reply_failed' | 'reply_stuck' | 'reply_skipped' | 'needs_human'
  | 'missed_comment' | 'missed_mention'
  | 'post_failed' | 'post_partial' | 'post_overdue' | 'no_post_24h';

/** Kinds that need a call to Facebook / X to evaluate. They are only auto-resolved on runs that actually did that scan. */
export const SCAN_KINDS: IssueKind[] = ['missed_comment', 'missed_mention', 'needs_human'];

export interface Detected {
  key: string;            // unique per problem, e.g. "needs_human:123_456"
  kind: IssueKind;
  platform: string;       // facebook | twitter | discord | telegram | all
  ref_id: string;
  title: string;          // one line the team can act on
  detail: string;
  url: string;
  item_at: string;        // when the comment / post / failure happened (age is counted from here)
}

export interface NagItem { id: string; kind: string; platform: string; title: string; url: string; item_at: string; nag_count: number }

export const PLATFORM_TAG: Record<string, string> = { facebook: 'FB', twitter: 'X', discord: 'Discord', telegram: 'Telegram', all: 'All' };

/** "5m", "2h 10m", "3d 4h" */
export function fmtAge(ms: number): string {
  const m = Math.max(0, Math.floor(ms / 60_000));
  if (m < 60) return `${m}m`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ${m % 60}m`;
  return `${Math.floor(h / 24)}d ${h % 24}h`;
}

/** Quiet hours are in Philippine time. start === end means "never quiet". The window may wrap midnight (e.g. 22 → 7). */
export function inQuietHours(now: Date, start: number, end: number): boolean {
  if (!Number.isInteger(start) || !Number.isInteger(end) || start === end) return false;
  const h = (now.getUTCHours() + 8) % 24;
  return start < end ? h >= start && h < end : h >= start || h < end;
}

/** 0 = first reminder … 3 = very urgent. Driven by how many times the most-nagged item was already reminded. */
export const nagLevel = (maxNagCount: number): 0 | 1 | 2 | 3 => (maxNagCount >= 6 ? 3 : maxNagCount >= 3 ? 2 : maxNagCount >= 1 ? 1 : 0);

/** Builds ONE reminder message. `shownIds` = the issues that really fit in it (only those get their reminder counter raised). */
export function buildDigest(o: { items: NagItem[]; mention?: string; now: Date; maxItems?: number; maxChars?: number }): { text: string; shownIds: string[] } {
  const { items, now } = o;
  const maxItems = o.maxItems ?? 12;
  const maxChars = o.maxChars ?? 1800; // Discord allows 2000, Telegram 4000
  const sorted = [...items].sort((a, b) => new Date(a.item_at).getTime() - new Date(b.item_at).getTime());
  const n = sorted.length;
  const oldest = fmtAge(now.getTime() - new Date(sorted[0]?.item_at ?? now).getTime());
  const level = nagLevel(Math.max(0, ...sorted.map((i) => i.nag_count)));
  const head = [
    `👀 Argus (Watchdog): may ${n} na hindi pa naasikaso ng team.`,
    `⚠️ Paalala ulit! ${n} pa rin ang naka-pending — ang pinakamatagal ay ${oldest} na.`,
    `🚨 Hoy team! ${n} items pa rin ang hindi nagagawa. ${oldest} nang naghihintay ang pinakamatagal!`,
    `🔥 URGENT! Ilang beses na akong nagpaalala — ${n} pa rin ang naka-pending at ${oldest} na ang pinakamatagal. Pakiasikaso na po NGAYON DIN, may customer na naghihintay.`,
  ][level];
  const lines: string[] = [];
  const shownIds: string[] = [];
  let used = head.length + 120;
  let shown = 0;
  for (const it of sorted) {
    const age = fmtAge(now.getTime() - new Date(it.item_at).getTime());
    const line = `• [${PLATFORM_TAG[it.platform] ?? it.platform}] ${it.title} — ${age} na${it.url ? `\n  ${it.url}` : ''}`;
    if (shown >= maxItems || used + line.length > maxChars) break;
    lines.push(line); shownIds.push(it.id); used += line.length + 1; shown++;
  }
  if (shown < n) lines.push(`…at ${n - shown} pa.`);
  const foot = 'Kapag naasikaso na, kusa itong mawawala sa listahan. Puwede ring i-mark na tapos / i-snooze sa Code Ai Office → Watchdog.';
  const text = [o.mention?.trim() || '', head, '', ...lines, '', foot].filter((x, i) => x !== '' || i > 0).join('\n').trim();
  return { text, shownIds };
}

/** A platform counts as connected when its credentials are saved in API Settings (same rule as the posting worker). */
export function connectedPlatforms(c: Record<string, Record<string, string> | undefined>): string[] {
  const has = (p: string, fields: string[]) => fields.every((f) => (c[p]?.[f] ?? '').trim() !== '');
  return ['facebook', 'twitter', 'discord', 'telegram'].filter((p) =>
    p === 'facebook' ? has(p, ['page_id', 'access_token'])
    : p === 'twitter' ? has(p, ['api_key', 'api_secret', 'access_token', 'access_secret'])
    : p === 'discord' ? has(p, ['webhook_url'])
    : has(p, ['bot_token', 'chat_id']));
}
