// Daily Auto-Post pipeline. Each tick it looks at the saved daily schedule and, for every slot that is due,
// queues ONE fresh post in `scheduled_posts` (the existing worker then publishes it on time).
// All I/O goes through `DailyDeps`, so the logic is tested without Supabase. It never throws: a failure is logged and
// retried on the next tick (the per-slot claim is released), so one bad run can never stop tomorrow's posts.
import {
  buildFallbackPost, dueSlots, pickGame,
  type DailySettings, type DailyStatus,
} from '@/lib/app/daily';
import type { Tone } from '@/lib/app/types';

type Level = 'info' | 'success' | 'warning' | 'error';

export interface DailyGame { id: string; title: string; genre?: string | null; description?: string | null; promo_link?: string | null; active?: boolean | null }

export interface DailyPostRow {
  game_id: string; game_title: string; platforms: string[]; tone: string; content: string; hashtags: string;
  status: 'queued'; scheduled_at: string; brain_rule_ids: string[];
}

export interface GeneratedCopy { content: string; hashtags: string; brain_rule_ids?: string[] }

export interface DailyDeps {
  settings(): Promise<DailySettings>;
  games(): Promise<DailyGame[]>;
  /** Platforms that have real credentials saved in API Settings. */
  connected(): Promise<string[]>;
  /** Locks one (date, slot). false = another run already took it. */
  claim(key: string, info: Record<string, unknown>): Promise<boolean>;
  release(key: string): Promise<void>;
  insertPost(row: DailyPostRow): Promise<void>;
  /** null = no AI available (the template is used instead). */
  generate(game: DailyGame, platforms: string[], tone: Tone): Promise<GeneratedCopy | null>;
  /** Merges into the saved status (fields not given are kept). */
  saveStatus(patch: Partial<DailyStatus>): Promise<void>;
  log(level: Level, source: string, message: string): Promise<void>;
  now(): Date;
  generateTimeoutMs: number;
}

export interface DailyTickSummary {
  ok: boolean;
  skipped?: string;
  queued: number;
  failed: number;
  items: { slot: string; date: string; game?: string; platforms?: string[]; scheduled_at?: string; note?: string }[];
  error?: string;
}

function withTimeout<T>(p: Promise<T>, ms: number, what: string): Promise<T> {
  let t: ReturnType<typeof setTimeout> | undefined;
  const timer = new Promise<never>((_, rej) => { t = setTimeout(() => rej(new Error(`${what} timed out after ${Math.round(ms / 1000)}s`)), ms); });
  return Promise.race([p, timer]).finally(() => clearTimeout(t));
}

const clean = (s: unknown, max: number) => (typeof s === 'string' ? s.trim().slice(0, max) : '');

export async function dailyTick(deps: DailyDeps, opts: { force?: { slotId?: string } } = {}): Promise<DailyTickSummary> {
  const summary: DailyTickSummary = { ok: true, queued: 0, failed: 0, items: [] };
  try {
    const settings = await deps.settings();
    const now = deps.now();
    // "Post a test now" (UI): behaves like a due slot that is due this very second, without any lock (it never blocks the real schedule).
    const due = opts.force
      ? (() => {
          const slot = settings.slots.find((s) => s.id === opts.force?.slotId) ?? settings.slots[0] ?? { id: 'test', time: '00:00', platforms: [] };
          return [{ slot, slotIndex: Math.max(0, settings.slots.indexOf(slot)), dateKey: now.toISOString().slice(0, 10), runAt: now, claimKey: '' }];
        })()
      : dueSlots(settings, now);
    if (!opts.force && !settings.enabled) return { ...summary, skipped: 'off' };
    if (!due.length) return { ...summary, skipped: 'nothing due' };

    const quietLog = now.getMinutes() % 10 === 0; // the warnings below repeat every tick; show them every 10 minutes only
    const [games, connected] = await Promise.all([deps.games(), deps.connected()]);
    let lastError: string | null = null;
    let lastQueued: DailyStatus['last_queued'] = null;

    for (const d of due) {
      const label = `${d.slot.time}`;
      const claimed = d.claimKey ? await deps.claim(d.claimKey, { slot: d.slot.id, date: d.dateKey, at: now.toISOString() }) : true;
      if (!claimed) continue; // already queued by an earlier tick

      const platforms = d.slot.platforms.length ? d.slot.platforms.filter((p) => connected.includes(p)) : connected;
      if (!platforms.length) {
        lastError = 'Walang naka-connect na social account — i-save ang credentials sa API Settings.';
        if (d.claimKey) await deps.release(d.claimKey);
        if (quietLog || opts.force) await deps.log('warning', 'auto-poster', `Daily ${label}: ${lastError}`);
        summary.failed++; summary.items.push({ slot: label, date: d.dateKey, note: lastError });
        continue;
      }
      const game = pickGame(games, settings, d.dateKey, d.slotIndex);
      if (!game) {
        lastError = 'Walang active game para sa daily post — magdagdag o i-activate sa Game Profiles.';
        if (d.claimKey) await deps.release(d.claimKey);
        if (quietLog || opts.force) await deps.log('warning', 'auto-poster', `Daily ${label}: ${lastError}`);
        summary.failed++; summary.items.push({ slot: label, date: d.dateKey, note: lastError });
        continue;
      }

      try {
        let copy: GeneratedCopy | null = null;
        if (settings.use_ai) {
          try { copy = await withTimeout(deps.generate(game, platforms, settings.tone), deps.generateTimeoutMs, 'AI'); }
          catch (e) { await deps.log('warning', 'ai-studio', `Daily ${label}: AI failed (${(e as Error).message}) — template ang gagamitin.`); }
          if (copy && !clean(copy.content, 1)) copy = null;
        }
        const base = copy ?? { ...buildFallbackPost(game, settings.tone), brain_rule_ids: [] as string[] };
        const content = clean(base.content, 1800);
        const link = game.promo_link?.trim();
        // The promo link is always part of the post, even when the AI forgot it.
        const finalContent = link && !content.includes(link) ? `${content}\n${link}` : content;
        const scheduledAt = new Date(Math.max(d.runAt.getTime(), now.getTime() + 30_000));
        await deps.insertPost({
          game_id: game.id, game_title: game.title, platforms, tone: settings.tone,
          content: finalContent, hashtags: clean(base.hashtags, 300), status: 'queued',
          scheduled_at: scheduledAt.toISOString(), brain_rule_ids: base.brain_rule_ids ?? [],
        });
        summary.queued++;
        lastQueued = { game_title: game.title, platforms, scheduled_at: scheduledAt.toISOString() };
        summary.items.push({ slot: label, date: d.dateKey, game: game.title, platforms, scheduled_at: scheduledAt.toISOString(), note: copy ? 'ai' : 'template' });
        await deps.log('success', 'auto-poster', `Daily ${label}: naka-queue ang post para sa "${game.title}" → ${platforms.join(', ')} (${copy ? 'AI' : 'template'}).`);
      } catch (e) {
        lastError = (e as Error).message;
        if (d.claimKey) await deps.release(d.claimKey).catch(() => undefined); // retry on the next tick
        summary.failed++; summary.items.push({ slot: label, date: d.dateKey, note: lastError });
        await deps.log('error', 'auto-poster', `Daily ${label}: hindi na-queue ang post — ${lastError}`);
      }
    }

    if (summary.queued || summary.failed) {
      await deps.saveStatus({ last_run_at: now.toISOString(), ...(lastQueued ? { last_queued: lastQueued } : {}), last_error: summary.queued ? null : lastError }).catch(() => undefined);
    }
    summary.ok = summary.failed === 0;
    return summary;
  } catch (e) {
    await deps.log('error', 'system', `Daily poster failed: ${(e as Error).message}`).catch(() => undefined);
    return { ...summary, ok: false, error: (e as Error).message };
  }
}
