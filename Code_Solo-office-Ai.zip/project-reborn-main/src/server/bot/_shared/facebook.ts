// Facebook Page helpers for REAL-TIME comment handling (Graph API).
// Needs a Page access token with: pages_manage_engagement, pages_read_engagement, pages_manage_posts.
import { safeEqual } from './publish.ts';

export const GRAPH = 'https://graph.facebook.com/v21.0';

async function fbError(res: Response): Promise<string> {
  const t = await res.text().catch(() => '');
  try { return JSON.parse(t)?.error?.message ?? t.slice(0, 200); } catch { return t.slice(0, 200); }
}

/** Posts a public reply under a comment. Returns the new comment's id. */
export async function replyToFacebookComment(
  cfg: Record<string, string> | undefined, commentId: string, message: string,
): Promise<{ id?: string }> {
  const token = cfg?.access_token?.trim();
  if (!token) throw new Error('Facebook: missing access_token — add it in API Settings');
  if (!/^[0-9_]+$/.test(commentId)) throw new Error('Facebook: invalid comment id');
  const body = new URLSearchParams({ message: message.slice(0, 1000), access_token: token });
  const res = await fetch(`${GRAPH}/${commentId}/comments`, { method: 'POST', body, signal: AbortSignal.timeout(20_000) });
  if (!res.ok) throw new Error(`Facebook ${res.status}: ${await fbError(res)}`);
  const j = await res.json().catch(() => ({}));
  return { id: j?.id };
}

/** The text of the post that was commented on (gives the AI context). Never throws. */
export async function getPostText(cfg: Record<string, string> | undefined, postId: string): Promise<string> {
  try {
    const token = cfg?.access_token?.trim();
    if (!token || !/^[0-9_]+$/.test(postId)) return '';
    const res = await fetch(`${GRAPH}/${postId}?fields=message&access_token=${encodeURIComponent(token)}`, { signal: AbortSignal.timeout(10_000) });
    if (!res.ok) return '';
    return String((await res.json())?.message ?? '');
  } catch { return ''; }
}

/** Verifies Facebook's X-Hub-Signature-256 header (HMAC-SHA256 of the RAW body with your App Secret). */
export async function verifySignature(rawBody: string, header: string | null, appSecret: string): Promise<boolean> {
  if (!appSecret || !header?.startsWith('sha256=')) return false;
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(appSecret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = new Uint8Array(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(rawBody)));
  const hex = Array.from(sig).map((b) => b.toString(16).padStart(2, '0')).join('');
  return safeEqual(hex, header.slice('sha256='.length));
}

/** Likes on one of our own replies (used to score the reply). Returns null if unavailable. */
export async function getCommentLikes(cfg: Record<string, string> | undefined, commentId: string): Promise<number | null> {
  try {
    const token = cfg?.access_token?.trim();
    if (!token || !/^[0-9_]+$/.test(commentId)) return null;
    const res = await fetch(`${GRAPH}/${commentId}?fields=like_count&access_token=${encodeURIComponent(token)}`, { signal: AbortSignal.timeout(10_000) });
    if (!res.ok) return null;
    const n = (await res.json())?.like_count;
    return typeof n === 'number' ? n : null;
  } catch { return null; }
}

/* ---------- used by the Watchdog (Argus): look for comments nobody has answered ---------- */
export interface FbComment { id: string; postId: string; postUrl: string; text: string; userId: string; userName: string; createdAt: string; pageReplies: number }

/** Recent top-level comments (newest first) on the Page's latest posts, with how many replies the Page itself already wrote. Throws on API errors. */
export async function getRecentPageComments(cfg: Record<string, string> | undefined, maxPosts = 10, perPost = 50): Promise<FbComment[]> {
  const token = cfg?.access_token?.trim();
  const pageId = cfg?.page_id?.trim();
  if (!token || !pageId) throw new Error('Facebook: missing page_id / access_token');
  const fields = `id,permalink_url,comments.filter(toplevel).order(reverse_chronological).limit(${perPost}){id,message,from,created_time,comments.limit(10){id,from}}`;
  const url = `${GRAPH}/${encodeURIComponent(pageId)}/posts?fields=${encodeURIComponent(fields)}&limit=${maxPosts}&access_token=${encodeURIComponent(token)}`;
  const res = await fetch(url, { signal: AbortSignal.timeout(25_000) });
  if (!res.ok) throw new Error(`Facebook ${res.status}: ${await fbError(res)}`);
  const j = await res.json();
  const out: FbComment[] = [];
  for (const p of j?.data ?? []) {
    for (const c of p?.comments?.data ?? []) {
      out.push({
        id: String(c.id), postId: String(p.id), postUrl: String(p.permalink_url ?? ''), text: String(c.message ?? ''),
        userId: String(c.from?.id ?? ''), userName: String(c.from?.name ?? ''), createdAt: String(c.created_time ?? ''),
        pageReplies: ((c.comments?.data ?? []) as { from?: { id?: string } }[]).filter((r) => r.from?.id === pageId).length,
      });
    }
  }
  return out;
}

/** Ids of the replies the Page itself wrote under one comment. Returns null if it could not be read. */
export async function getPageRepliesUnder(cfg: Record<string, string> | undefined, commentId: string): Promise<string[] | null> {
  try {
    const token = cfg?.access_token?.trim();
    const pageId = cfg?.page_id?.trim();
    if (!token || !pageId || !/^[0-9_]+$/.test(commentId)) return null;
    const res = await fetch(`${GRAPH}/${commentId}?fields=${encodeURIComponent('comments.limit(25){id,from}')}&access_token=${encodeURIComponent(token)}`, { signal: AbortSignal.timeout(10_000) });
    if (!res.ok) return null;
    const j = await res.json();
    return ((j?.comments?.data ?? []) as { id: string; from?: { id?: string } }[]).filter((r) => r.from?.id === pageId).map((r) => String(r.id));
  } catch { return null; }
}
