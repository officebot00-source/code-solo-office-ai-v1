// Pure helpers (no network, no database): turn a real event into a structured lesson for captureRealtimeLearning().
// Lessons are built from STRUCTURED facts only (issue kind, platform, tone, CTR) — never from customer text — and every one
// still passes sanitizeInsight() before it can reach the Shared Brain.
export interface Lesson { category: string; platform: string; title: string; insight_rule: string }

const PLATFORM_LABEL: Record<string, string> = { facebook: 'Facebook', twitter: 'X/Twitter', discord: 'Discord', telegram: 'Telegram', all: 'all platforms' };
const ANGLE: Record<string, string> = { fomo: 'limited-time urgency (FOMO)', competitive: 'competitive challenge and gameplay curiosity' };
const known = (p: string) => (p in PLATFORM_LABEL ? p : 'all');

/** An A/B test just got a winner → a lesson the other bots can use immediately (no waiting for the 30-minute reflector). */
export function lessonFromAbWinner(o: { winnerTone: string; ctrWin: number; ctrLose: number; platforms: string[] }): Lesson | null {
  const angle = ANGLE[o.winnerTone];
  if (!angle || !(o.ctrWin > o.ctrLose)) return null;
  const platform = o.platforms.length === 1 ? known(o.platforms[0]!) : 'all';
  const label = PLATFORM_LABEL[platform];
  return {
    category: 'winning_hook', platform,
    title: `${angle.split(' (')[0]} angle wins A/B on ${label}`.slice(0, 120),
    insight_rule: `On ${label} promo posts, lean on the ${angle} angle: it won an A/B test with ${o.ctrWin.toFixed(1)}% CTR against ${o.ctrLose.toFixed(1)}% for the other angle.`,
  };
}

/** The Watchdog saw a problem get fixed → what should the writers / repliers do differently next time? Returns null when nothing general can be said. */
export function lessonFromFixedIssue(kind: string, platform: string, detail: string): Lesson | null {
  const p = known(platform);
  if (kind === 'post_failed' && p === 'twitter' && /too long|280|character|length/i.test(detail)) {
    return { category: 'winning_hook', platform: 'twitter', title: 'Keep X posts under 260 characters',
      insight_rule: 'Keep every X/Twitter post under 260 characters including hashtags; longer posts were rejected and had to be fixed by hand.' };
  }
  if (kind === 'post_failed' && /duplicate|already (posted|said)/i.test(detail)) {
    return { category: 'winning_hook', platform: p, title: `Never repeat identical post text on ${PLATFORM_LABEL[p]}`,
      insight_rule: `Vary the wording of every post on ${PLATFORM_LABEL[p]}; a repeated identical text was rejected as a duplicate and had to be rewritten.` };
  }
  if (kind === 'needs_human' && (p === 'facebook' || p === 'twitter')) {
    return { category: 'audience_insight', platform: p, title: 'Hand off price, shipping and order questions to a human',
      insight_rule: 'When a comment asks about price, shipping, order status, refunds or a complaint and no fact is given, hand it off to the team right away instead of guessing; the team had to answer these by hand.' };
  }
  return null;
}
