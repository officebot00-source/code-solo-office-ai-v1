// Daily Auto-Post bot (office bot: Blaze). Queues a fresh post for every daily time slot the user saved, EVERY day,
// so nobody has to schedule posts by hand. The posts go into the normal `scheduled_posts` queue and the existing
// auto-bot-worker publishes them on time (same rate limits, same retry + logging).
// Callers: the scheduler (service bearer, every tick) or the app (APP_PASSCODE).
// Body: { action: 'tick' | 'status' | 'settings_get' | 'settings_set' | 'run_now', settings?, slot_id? }  (scheduled call with an empty body = 'tick')
import type { SupabaseClient } from '@supabase/supabase-js';
import { supabaseAdmin } from '@/integrations/supabase/client.server';
import {
  DAILY_SETTINGS_KEY, DAILY_STATUS_KEY, EMPTY_DAILY_STATUS, sanitizeDailySettings,
  type DailySettings, type DailyStatus,
} from '@/lib/app/daily';
import { TONES } from '@/lib/app/types';
import { aiJson, loadAiConfig } from './_shared/ai.ts';
import { loadBrain } from './_shared/brain.ts';
import { dailyTick, type DailyDeps, type DailyGame } from './_shared/daily-pipeline.ts';
import { authorized, corsHeaders, isServiceCall, json, loadCreds, makeLogger, type Creds } from './_shared/publish.ts';

const sb = supabaseAdmin as unknown as SupabaseClient;

const PLATFORM_ORDER = ['facebook', 'twitter', 'discord', 'telegram'];
/** A platform counts as connected when its credentials are saved in API Settings (same rule as the main worker). */
export function connectedPlatforms(c: Creds): string[] {
  const has = (p: string, fields: string[]) => fields.every((f) => (c[p]?.[f] ?? '').trim() !== '');
  return PLATFORM_ORDER.filter((p) =>
    p === 'facebook' ? has(p, ['page_id', 'access_token'])
    : p === 'twitter' ? has(p, ['api_key', 'api_secret', 'access_token', 'access_secret'])
    : p === 'discord' ? has(p, ['webhook_url'])
    : has(p, ['bot_token', 'chat_id']));
}

export async function loadDailySettings(client: SupabaseClient): Promise<DailySettings> {
  const { data } = await client.from('bot_state').select('value').eq('key', DAILY_SETTINGS_KEY).maybeSingle();
  return sanitizeDailySettings(data?.value);
}
export async function loadDailyStatus(client: SupabaseClient): Promise<DailyStatus> {
  const { data } = await client.from('bot_state').select('value').eq('key', DAILY_STATUS_KEY).maybeSingle();
  const v = (data?.value && typeof data.value === 'object' ? data.value : {}) as Partial<DailyStatus>;
  return { ...EMPTY_DAILY_STATUS, ...v };
}
async function saveDailySettings(client: SupabaseClient, patch: unknown): Promise<DailySettings> {
  const next = sanitizeDailySettings(patch, await loadDailySettings(client));
  const { error } = await client.from('bot_state').upsert({ key: DAILY_SETTINGS_KEY, value: next as never, updated_at: new Date().toISOString() });
  if (error) throw new Error(error.message);
  return next;
}

export function makeDailyDeps(client: SupabaseClient = sb): DailyDeps {
  const log = makeLogger(client);
  return {
    settings: () => loadDailySettings(client),
    async games() {
      const { data, error } = await client.from('games').select('id, title, genre, description, promo_link, active').eq('active', true).limit(50);
      if (error) throw new Error(`games: ${error.message}`);
      return (data ?? []) as DailyGame[];
    },
    async connected() { return connectedPlatforms(await loadCreds(client)); },
    async claim(key, info) {
      const { error } = await client.from('bot_state').insert({ key, value: info as never, updated_at: new Date().toISOString() });
      if (!error) return true;
      if (error.code === '23505') return false; // already claimed
      throw new Error(`claim: ${error.message}`);
    },
    async release(key) { await client.from('bot_state').delete().eq('key', key); },
    async insertPost(row) {
      const { error } = await client.from('scheduled_posts').insert(row);
      if (error) throw new Error(error.message);
    },
    async generate(game, platforms, tone) {
      const ai = await loadAiConfig(client);
      if (!ai) return null;
      const brain = await loadBrain(client, ai, { platforms, role: 'aria', context: `${game.title} ${game.genre ?? ''} ${game.description ?? ''}` });
      const hint = TONES.find((t) => t.id === tone)?.hint ?? '';
      const short = platforms.includes('twitter');
      const out = await aiJson<{ content?: unknown; hashtags?: unknown }>(ai,
        `You are a social media copywriter for an indie game studio. Write ONE fresh daily promo post.\nGame: ${game.title}\nGenre: ${game.genre || 'n/a'}\nDescription: ${game.description || 'n/a'}\nTone: ${tone} — ${hint}\nPlatforms: ${platforms.join(', ')}\nKeep it under ${short ? 240 : 500} characters. Do NOT include any URL (it is added automatically). Make it different from a generic ad: one concrete hook.${brain.block}\nReturn ONLY JSON: {"content":"...","hashtags":"#a #b #c"}`, 500);
      if (typeof out.content !== 'string' || !out.content.trim()) return null;
      return { content: out.content, hashtags: typeof out.hashtags === 'string' ? out.hashtags : '', brain_rule_ids: brain.ids };
    },
    async saveStatus(patch) {
      const next = { ...(await loadDailyStatus(client)), ...patch };
      await client.from('bot_state').upsert({ key: DAILY_STATUS_KEY, value: next as never, updated_at: new Date().toISOString() });
    },
    log, now: () => new Date(), generateTimeoutMs: 25_000,
  };
}

export default async function handler(req: Request): Promise<Response> {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'POST only' }, 405);
  const service = isServiceCall(req);
  if (!service && !authorized(req)) return json({ error: 'Wrong or missing passcode' }, 401);

  let body: Record<string, unknown> = {};
  try { const t = await req.text(); body = t.trim() ? (JSON.parse(t) as Record<string, unknown>) : {}; } catch { return json({ error: 'Invalid JSON' }, 400); }
  // The scheduler can only ever tick; everything else needs the app password.
  const action = service ? 'tick' : typeof body['action'] === 'string' ? body['action'] : 'status';
  const deps = makeDailyDeps();

  try {
    switch (action) {
      case 'tick': return json({ ...(await dailyTick(deps)) });
      case 'settings_get': return json({ ok: true, settings: await loadDailySettings(sb) });
      case 'status': {
        const [settings, status, creds] = await Promise.all([loadDailySettings(sb), loadDailyStatus(sb), loadCreds(sb)]);
        return json({ ok: true, settings, status, connected: connectedPlatforms(creds) });
      }
      case 'settings_set': {
        const settings = await saveDailySettings(sb, body['settings']);
        await deps.log('info', 'auto-poster', `Daily auto-post is now ${settings.enabled ? `ON (${settings.slots.map((s) => s.time).join(', ') || 'no times set'} · ${settings.timezone})` : 'OFF'}.`);
        // Turning it on at a time that is due right now queues that post immediately instead of waiting for the next tick.
        if (settings.enabled) await dailyTick(deps);
        return json({ ok: true, settings });
      }
      case 'run_now': {
        const slotId = typeof body['slot_id'] === 'string' ? body['slot_id'] : undefined;
        const r = await dailyTick(deps, { force: { slotId } });
        return json({ ...r }, r.queued ? 202 : 200);
      }
      default: return json({ error: `Unknown action "${action}"` }, 400);
    }
  } catch (e) {
    await deps.log('error', 'auto-poster', `Daily poster error (${action}): ${(e as Error).message}`).catch(() => undefined);
    return json({ ok: false, error: (e as Error).message }, 500);
  }
}
