// What the "Watchdog" screen talks to. Protected by the app password (same as every other admin function).
// Body: { action: 'list' }
//       { action: 'resolve', id, status: 'handled' | 'dismissed' | 'open' }   handled = we answered it · dismissed = ignore it forever (spam, not needed)
//       { action: 'snooze', id, hours }                                          stop reminding for a while
//       { action: 'test' }                                                       sends a sample reminder to Telegram / Discord
import type { SupabaseClient } from '@supabase/supabase-js';
import { supabaseAdmin } from '@/integrations/supabase/client.server';
import { authorized, corsHeaders, json, loadCreds } from './_shared/publish.ts';
import { notifyTeam } from './_shared/notify.ts';
import { buildDigest } from './_shared/watchdog.ts';

const sb = supabaseAdmin as unknown as SupabaseClient;
const COLS = 'id, kind, platform, title, url, item_at, first_seen_at, last_nagged_at, nag_count, status, snoozed_until, resolved_at, resolved_reason';

export default async function handler(req: Request): Promise<Response> {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'POST only' }, 405);
  if (!authorized(req)) return json({ error: 'Wrong or missing passcode' }, 401);

  let body: { action?: string; id?: unknown; status?: string; hours?: unknown };
  try { body = await req.json(); } catch { return json({ error: 'Invalid JSON' }, 400); }
  const id = typeof body.id === 'string' && /^[0-9a-f-]{36}$/i.test(body.id) ? body.id : null;

  try {
    if (body.action === 'list') {
      const [{ data: open }, { data: closed }, { data: st }] = await Promise.all([
        sb.from('watchdog_issues').select(COLS).in('status', ['open', 'snoozed']).order('item_at').limit(200),
        sb.from('watchdog_issues').select(COLS).in('status', ['fixed', 'handled', 'dismissed']).order('resolved_at', { ascending: false, nullsFirst: false }).limit(30),
        sb.from('bot_state').select('value').eq('key', 'watchdog').maybeSingle(),
      ]);
      return json({ ok: true, open: open ?? [], closed: closed ?? [], state: st?.value ?? {} });
    }
    if (body.action === 'resolve') {
      if (!id || !['handled', 'dismissed', 'open'].includes(String(body.status))) return json({ error: 'id and status required' }, 400);
      const reopen = body.status === 'open';
      const { error } = await sb.from('watchdog_issues').update(reopen
        ? { status: 'open', resolved_at: null, resolved_reason: null, snoozed_until: null, nag_count: 0, last_nagged_at: null }
        : { status: body.status, resolved_at: new Date().toISOString(), resolved_reason: body.status === 'handled' ? 'minarkahang tapos ng team' : 'in-ignore ng team' }).eq('id', id);
      if (error) return json({ error: error.message }, 400);
      return json({ ok: true });
    }
    if (body.action === 'snooze') {
      const hours = Number(body.hours);
      if (!id || !(hours > 0 && hours <= 24 * 14)) return json({ error: 'id and hours (1-336) required' }, 400);
      const { error } = await sb.from('watchdog_issues').update({ status: 'snoozed', snoozed_until: new Date(Date.now() + hours * 3600_000).toISOString() }).eq('id', id);
      if (error) return json({ error: error.message }, 400);
      return json({ ok: true });
    }
    if (body.action === 'test') {
      const creds = await loadCreds(sb);
      const { data: s } = await sb.from('bot_settings').select('watchdog_mention').eq('id', 1).maybeSingle();
      const { text } = buildDigest({
        mention: s?.watchdog_mention ?? '', now: new Date(),
        items: [{ id: 't', kind: 'test', platform: 'facebook', title: 'TEST lang ito: halimbawa ng comment na hindi nasagot', url: '', item_at: new Date(Date.now() - 45 * 60_000).toISOString(), nag_count: 0 }],
      });
      const r = await notifyTeam(creds, `${text}\n\n(Ito ay test lang — walang kailangang gawin.)`);
      if (!r.sent.length) return json({ ok: false, error: r.errors[0] ?? 'Walang Telegram (bot token + chat id) o Discord webhook na naka-save sa API Settings.' });
      return json({ ok: true, detail: `Naipadala sa ${r.sent.join(' + ')}` });
    }
    return json({ error: 'Unknown action' }, 400);
  } catch (e) {
    return json({ ok: false, error: (e as Error).message }, 500);
  }
}
