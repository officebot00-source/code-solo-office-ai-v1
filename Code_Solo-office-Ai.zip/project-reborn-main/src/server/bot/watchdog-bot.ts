// ARGUS — the Watchdog bot. Runs every 5 minutes (pg_cron).
// Its only job: find everything the team MISSED and keep reminding them until it is done.
//   • comments / mentions nobody answered (bot failed, bot said "needs a human", or the event never arrived)
//   • posts that failed, only half-published, are overdue, or a platform that got no post in 24 hours
// Every problem becomes a row in `watchdog_issues`. While it is open the team gets ONE combined reminder in Telegram / Discord
// (every `watchdog_nag_minutes`, more and more insistent). When the problem is gone the row closes itself — no manual cleanup.
import type { SupabaseClient } from '@supabase/supabase-js';
import { supabaseAdmin } from '@/integrations/supabase/client.server';
import { authorized, corsHeaders, isServiceCall, json, loadCreds, makeLogger, type Creds } from './_shared/publish.ts';
import { getPageRepliesUnder, getRecentPageComments } from './_shared/facebook.ts';
import { fetchMentions, getMe, hasXCreds, stripHandles } from './_shared/x.ts';
import { notifyTeam } from './_shared/notify.ts';
import { loadAiConfig } from './_shared/ai.ts';
import { botIdByName, captureRealtimeLearning } from './_shared/brain.ts';
import { lessonFromFixedIssue } from './_shared/lessons.ts';
import {
  buildDigest, connectedPlatforms, fmtAge, inQuietHours, PLATFORM_TAG,
  type Detected, type IssueKind, type NagItem,
} from './_shared/watchdog.ts';

const sb = supabaseAdmin as unknown as SupabaseClient;
const log = makeLogger(sb);
const MIN = 60_000;
const DAY = 24 * 3600_000;
const SCAN_EVERY_MIN = 15;   // asking Facebook / X "what comments exist?" is rate-limited, so do it every 15 minutes
const HUMAN_DONE = 'answered by team';
const MIN_GAP_MIN = 4;       // never two reminders closer than this (protects against repeated "Check now")

interface Settings {
  auto_pilot_enabled: boolean; watchdog_enabled: boolean; watchdog_grace_minutes: number; watchdog_nag_minutes: number;
  watchdog_mention: string; watchdog_quiet_start: number; watchdog_quiet_end: number; platform_discord?: boolean; platform_telegram?: boolean;
}
interface WState { last_digest_at?: number; last_scan_at?: number; had_open?: boolean; warn_at?: number }

const iso = (ms: number) => new Date(ms).toISOString();
const snip = (s: string, n = 70) => { const t = String(s ?? '').replace(/\s+/g, ' ').trim(); return t.length > n ? `${t.slice(0, n)}…` : t; };
const fbUrl = (postId: string, commentId: string) => `https://www.facebook.com/${postId}?comment_id=${commentId.split('_').pop()}`;
const xUrl = (id: string) => `https://x.com/i/web/status/${id}`;
const manila = (ms: number) => new Date(ms).toLocaleString('en-PH', { timeZone: 'Asia/Manila', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });

async function getState(): Promise<WState> {
  const { data } = await sb.from('bot_state').select('value').eq('key', 'watchdog').maybeSingle();
  return (data?.value ?? {}) as WState;
}
const saveState = (s: WState) => sb.from('bot_state').upsert({ key: 'watchdog', value: s, updated_at: new Date().toISOString() });

/** At most one warning per hour about a broken check, so a missing API plan does not flood the console. */
async function warnOnce(st: WState, message: string) {
  if (Date.now() - (st.warn_at ?? 0) < 3600_000) return;
  st.warn_at = Date.now();
  await log('warning', 'watchdog', message);
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Row = Record<string, any>;
async function inChunks(ids: string[], fn: (chunk: string[]) => Promise<Row[]>): Promise<Row[]> {
  const out: Row[] = [];
  for (let i = 0; i < ids.length; i += 80) out.push(...(await fn(ids.slice(i, i + 80))));
  return out;
}

/* ------------------------------------------------------------------ detectors ------------------------------------------------------------------ */

/** Rows the reply bots wrote themselves: failed, stuck, skipped by the hourly cap, or "needs a human". */
async function detectReplyProblems(now: number, graceMs: number, fb: Creds[string], scan: boolean): Promise<Detected[]> {
  const { data } = await sb.from('comment_replies')
    .select('comment_id, platform, post_id, user_name, comment_text, reply_id, status, error, created_at')
    .in('status', ['failed', 'processing', 'escalated', 'skipped'])
    .gte('created_at', iso(now - 7 * DAY)).lte('created_at', iso(now - graceMs)).order('created_at').limit(200);
  const out: Detected[] = [];
  let fbChecks = 0;
  for (const r of data ?? []) {
    const tw = r.platform === 'twitter';
    const tag = tw ? 'X' : 'FB';
    const who = r.user_name || 'customer';
    const url = tw ? xUrl(r.comment_id) : fbUrl(r.post_id, r.comment_id);
    let kind: IssueKind;
    let title: string;
    if (r.status === 'failed') { kind = 'reply_failed'; title = `Pumalya ang auto-reply kay ${who} sa ${tag}: "${snip(r.comment_text)}"${r.error ? ` (${snip(r.error, 60)})` : ''}`; }
    else if (r.status === 'processing') { kind = 'reply_stuck'; title = `Hindi natapos ang reply kay ${who} sa ${tag}: "${snip(r.comment_text)}"`; }
    else if (r.status === 'skipped') {
      if (!/hourly/i.test(r.error ?? '')) continue; // "older than 24h" / empty mentions are intentional skips
      kind = 'reply_skipped'; title = `Hindi nasagot si ${who} sa ${tag} (naabot ang hourly limit): "${snip(r.comment_text)}"`;
    } else {
      kind = 'needs_human'; title = `Kailangan ng TAO: si ${who} sa ${tag} nagtanong ng "${snip(r.comment_text)}" (hand-off lang ang naisagot ng bot)`;
      // Facebook: if a person already answered under the comment, it is done
      if (r.error === HUMAN_DONE) continue; // already confirmed on an earlier check
      if (scan && !tw && fbChecks < 10) {
        fbChecks++;
        const replies = await getPageRepliesUnder(fb, r.comment_id);
        if (replies && replies.some((id) => id !== r.reply_id)) {
          await sb.from('comment_replies').update({ error: HUMAN_DONE }).eq('comment_id', r.comment_id); // remember it, so it can never be re-opened
          continue;
        }
      }
    }
    out.push({ key: `${kind}:${r.comment_id}`, kind, platform: tw ? 'twitter' : 'facebook', ref_id: r.comment_id, title, detail: r.error ?? '', url, item_at: r.created_at });
  }
  return out;
}

/** Facebook comments that exist but the bot never saw (webhook missed it) and nobody answered. */
async function detectMissedFacebook(now: number, graceMs: number, fb: Creds[string]): Promise<Detected[]> {
  const pageId = (fb?.page_id ?? '').trim();
  const comments = await getRecentPageComments(fb);
  const cand = comments.filter((c) => c.userId !== pageId && c.text.trim() && c.pageReplies === 0
    && Date.parse(c.createdAt) <= now - graceMs && Date.parse(c.createdAt) >= now - 7 * DAY);
  const known = new Set((await inChunks(cand.map((c) => c.id), async (ids) => (await sb.from('comment_replies').select('comment_id').in('comment_id', ids)).data ?? [])).map((r) => String(r.comment_id)));
  return cand.filter((c) => !known.has(c.id)).map((c) => ({
    key: `missed_comment:${c.id}`, kind: 'missed_comment' as const, platform: 'facebook', ref_id: c.id,
    title: `${c.userName || 'May nag-comment'} sa FB: "${snip(c.text)}" — walang sumagot`, detail: '', url: fbUrl(c.postId, c.id), item_at: c.createdAt,
  }));
}

/** X mentions from the last 24h that the reply bot never recorded. */
async function detectMissedX(now: number, graceMs: number, x: Creds[string], state: { user_id?: string }): Promise<Detected[]> {
  let myId = state.user_id;
  if (!myId) myId = (await getMe(x)).id;
  const mentions = await fetchMentions(x, myId, undefined, 50);
  const cand = mentions.filter((m) => m.author_id !== myId && !m.isRetweet && stripHandles(m.text)
    && Date.parse(m.created_at) <= now - graceMs && Date.parse(m.created_at) >= now - DAY);
  const known = new Set((await inChunks(cand.map((m) => m.id), async (ids) => (await sb.from('comment_replies').select('comment_id').in('comment_id', ids)).data ?? [])).map((r) => String(r.comment_id)));
  return cand.filter((m) => !known.has(m.id)).map((m) => ({
    key: `missed_mention:${m.id}`, kind: 'missed_mention' as const, platform: 'twitter', ref_id: m.id,
    title: `@${m.username || 'someone'} nag-mention sa X: "${snip(stripHandles(m.text))}" — walang sumagot`, detail: '', url: xUrl(m.id), item_at: m.created_at,
  }));
}

/** Posts that failed, half-published, are overdue — and platforms that got nothing in the last 24h. */
async function detectPosts(now: number, graceMs: number, cfg: Settings, platforms: string[]): Promise<Detected[]> {
  const out: Detected[] = [];
  const plat = (p: string[] | null) => (p ?? []).map((x) => PLATFORM_TAG[x] ?? x).join(', ');

  const failed = await sb.from('scheduled_posts').select('id, game_title, platforms, error, scheduled_at')
    .eq('status', 'failed').gte('scheduled_at', iso(now - 7 * DAY)).limit(50);
  for (const p of failed.data ?? []) {
    out.push({ key: `post_failed:${p.id}`, kind: 'post_failed', platform: (p.platforms ?? [])[0] ?? 'all', ref_id: p.id,
      title: `Pumalya ang post na "${snip(p.game_title, 40)}" (${plat(p.platforms)})${p.error ? `: ${snip(p.error, 90)}` : ''}`, detail: p.error ?? '', url: '', item_at: p.scheduled_at });
  }
  const partial = await sb.from('scheduled_posts').select('id, game_title, platforms, error, published_at')
    .eq('status', 'published').not('error', 'is', null).gte('published_at', iso(now - 3 * DAY)).limit(50);
  for (const p of partial.data ?? []) {
    out.push({ key: `post_partial:${p.id}`, kind: 'post_partial', platform: 'all', ref_id: p.id,
      title: `May platform na hindi napag-post ang "${snip(p.game_title, 40)}": ${snip(p.error ?? '', 100)}`, detail: p.error ?? '', url: '', item_at: p.published_at });
  }
  const lateMs = Math.max(graceMs, 10 * MIN);
  const overdue = await sb.from('scheduled_posts').select('id, game_title, platforms, scheduled_at')
    .eq('status', 'queued').lte('scheduled_at', iso(now - lateMs)).gte('scheduled_at', iso(now - 7 * DAY)).limit(50);
  for (const p of overdue.data ?? []) {
    out.push({ key: `post_overdue:${p.id}`, kind: 'post_overdue', platform: (p.platforms ?? [])[0] ?? 'all', ref_id: p.id,
      title: `Hindi pa napo-post ang "${snip(p.game_title, 40)}" (${plat(p.platforms)}) — dapat ${manila(Date.parse(p.scheduled_at))}`, detail: '', url: '', item_at: p.scheduled_at });
  }
  if (cfg.auto_pilot_enabled && platforms.length) {
    const recent = await sb.from('scheduled_posts').select('platforms, results').eq('status', 'published').gte('published_at', iso(now - DAY)).limit(200);
    const covered = new Set<string>();
    for (const r of recent.data ?? []) {
      const sent = Array.isArray(r.results) && r.results.length ? r.results.map((x: { platform: string }) => String(x.platform)) : (r.platforms ?? []);
      for (const p of sent as string[]) covered.add(p);
    }
    for (const p of platforms.filter((x) => !covered.has(x))) {
      out.push({ key: `no_post_24h:${p}`, kind: 'no_post_24h', platform: p, ref_id: p,
        title: `Walang na-post sa ${PLATFORM_TAG[p] ?? p} sa nakalipas na 24 oras (may Auto-Pilot ka pero walang lumalabas)`, detail: '', url: '', item_at: iso(now - DAY) });
    }
  }
  return out;
}

/* ------------------------------------------------------------------ main ------------------------------------------------------------------ */
export default async function handler(req: Request): Promise<Response> {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders }); // the "Check now" button calls this from the browser
  if (!isServiceCall(req) && !authorized(req)) return json({ error: 'Not allowed' }, 401);
  let force = false;
  try { force = Boolean((await req.json())?.force); } catch { /* cron sends {} */ }

  try {
    const now = Date.now();
    const { data: s, error: sErr } = await sb.from('bot_settings').select('*').eq('id', 1).single();
    if (sErr || !s) throw new Error(`bot_settings unavailable: ${sErr?.message}`);
    const cfg = s as Settings;
    if (cfg.watchdog_enabled === false) return json({ ok: true, skipped: 'watchdog is switched off' });
    const graceMs = Math.max(1, cfg.watchdog_grace_minutes ?? 15) * MIN;
    const nagMs = Math.max(10, cfg.watchdog_nag_minutes ?? 30) * MIN;

    const creds = await loadCreds(sb);
    const state = await getState();
    const xState = ((await sb.from('bot_state').select('value').eq('key', 'x_mentions').maybeSingle()).data?.value ?? {}) as { user_id?: string };
    const platforms = connectedPlatforms(creds).filter((p) => !(p === 'discord' && cfg.platform_discord === false) && !(p === 'telegram' && cfg.platform_telegram === false));

    // ---- 1. detect ----
    const scan = force || now - (state.last_scan_at ?? 0) >= SCAN_EVERY_MIN * MIN;
    const detected: Detected[] = [];
    const evaluated = new Set<IssueKind>(['reply_failed', 'reply_stuck', 'reply_skipped', 'post_failed', 'post_partial', 'post_overdue', 'no_post_24h']);
    detected.push(...await detectReplyProblems(now, graceMs, creds.facebook, scan));
    detected.push(...await detectPosts(now, graceMs, cfg, platforms));
    if (scan) {
      evaluated.add('needs_human');
      state.last_scan_at = now;
      if (platforms.includes('facebook')) {
        try { detected.push(...await detectMissedFacebook(now, graceMs, creds.facebook)); evaluated.add('missed_comment'); }
        catch (e) { await warnOnce(state, `Hindi ma-scan ang Facebook comments: ${(e as Error).message}`); }
      }
      if (hasXCreds(creds.twitter)) {
        try { detected.push(...await detectMissedX(now, graceMs, creds.twitter, xState)); evaluated.add('missed_mention'); }
        catch (e) { await warnOnce(state, `Hindi ma-scan ang X mentions: ${(e as Error).message}`); }
      }
    }

    // ---- 2. reconcile with watchdog_issues ----
    const byKey = new Map(detected.map((d) => [d.key, d]));
    const existing = await inChunks([...byKey.keys()], async (keys) => (await sb.from('watchdog_issues').select('*').in('issue_key', keys)).data ?? []);
    const exMap = new Map(existing.map((r) => [r.issue_key as string, r]));
    const fresh: Detected[] = [];
    for (const d of detected) {
      const ex = exMap.get(d.key);
      if (!ex) {
        const { error } = await sb.from('watchdog_issues').insert({
          issue_key: d.key, kind: d.kind, platform: d.platform, ref_id: d.ref_id, title: d.title, detail: d.detail, url: d.url, item_at: d.item_at,
        });
        if (!error) fresh.push(d);
      } else if (ex.status === 'fixed') {
        await sb.from('watchdog_issues').update({ status: 'open', nag_count: 0, last_nagged_at: null, resolved_at: null, resolved_reason: null, first_seen_at: iso(now), title: d.title, url: d.url }).eq('id', ex.id);
        fresh.push(d);
      } else if (ex.status === 'snoozed' && (!ex.snoozed_until || Date.parse(ex.snoozed_until) <= now)) {
        await sb.from('watchdog_issues').update({ status: 'open', snoozed_until: null }).eq('id', ex.id);
      }
      // 'handled' / 'dismissed' stay quiet even though the problem is still visible on the platform
    }
    // anything open that no longer shows up = fixed by the team (only for checks that really ran this time)
    const { data: openAll } = await sb.from('watchdog_issues').select('id, issue_key, kind, title, platform, detail, ref_id').in('status', ['open', 'snoozed']);
    const gone = ((openAll ?? []) as Row[]).filter((r) => !byKey.has(r.issue_key) && evaluated.has(r.kind as IssueKind));
    for (const r of gone) await sb.from('watchdog_issues').update({ status: 'fixed', resolved_at: iso(now), resolved_reason: 'naayos na (wala na sa listahan ng problema)' }).eq('id', r.id);
    // real-time lessons from recoveries (never blocks the watchdog)
    if (gone.length) {
      try {
        const seen = new Set<string>();
        const ai = await loadAiConfig(sb);
        const argus = await botIdByName(sb, 'Argus');
        for (const r of gone) {
          if (seen.size >= 2) break;
          if (r.kind === 'post_failed') { // only a REAL recovery counts, not a deleted post
            const { data: p } = await sb.from('scheduled_posts').select('status').eq('id', r.ref_id).maybeSingle();
            if (!p || p.status === 'failed') continue;
          }
          const lesson = lessonFromFixedIssue(String(r.kind), String(r.platform), String(r.detail ?? ''));
          if (!lesson || seen.has(lesson.title)) continue;
          seen.add(lesson.title);
          const res = await captureRealtimeLearning(sb, ai, lesson, { botId: argus });
          if (res.status === 'created' || res.status === 'pending_review') await log('info', 'watchdog', `Argus: natuto — ${res.title}`);
        }
      } catch (e) { console.error('watchdog lesson failed', (e as Error).message); }
    }
    if (gone.length) await log('success', 'watchdog', `Argus: naayos na ang ${gone.length} dating missed item${gone.length > 1 ? 's' : ''}. Good job, team! 🙌`);
    for (const d of fresh.slice(0, 5)) await log('warning', 'watchdog', `Argus: napansin — ${d.title}`);
    if (fresh.length > 5) await log('warning', 'watchdog', `Argus: at ${fresh.length - 5} pang bagong missed items.`);

    // ---- 3. remind the team ----
    const { data: open } = await sb.from('watchdog_issues').select('id, kind, platform, title, url, item_at, nag_count').eq('status', 'open').order('item_at').limit(200);
    const items = (open ?? []) as NagItem[];
    const quiet = inQuietHours(new Date(now), cfg.watchdog_quiet_start ?? 0, cfg.watchdog_quiet_end ?? 0);
    const sinceLast = now - (state.last_digest_at ?? 0);
    const due = items.length > 0 && sinceLast >= MIN_GAP_MIN * MIN && (items.some((i) => i.nag_count === 0) || sinceLast >= nagMs);
    let reminded = 0;
    let channels: string[] = [];

    if (due && !quiet) {
      const { text, shownIds } = buildDigest({ items, mention: cfg.watchdog_mention, now: new Date(now) });
      const r = await notifyTeam(creds, text);
      channels = r.sent;
      if (r.sent.length) {
        reminded = shownIds.length;
        for (const id of shownIds) {
          const it = items.find((i) => i.id === id)!;
          await sb.from('watchdog_issues').update({ nag_count: it.nag_count + 1, last_nagged_at: iso(now) }).eq('id', id);
        }
        state.last_digest_at = now;
        const oldest = fmtAge(now - Date.parse(items[0].item_at));
        await log('warning', 'watchdog', `Argus nagpaalala sa team (${r.sent.join(' + ')}): ${items.length} na hindi pa naasikaso, ${oldest} na ang pinakamatagal.`);
      } else {
        await warnOnce(state, `Hindi maipadala ang paalala sa team${r.errors.length ? `: ${r.errors[0]}` : ' — walang Telegram o Discord na naka-save sa API Settings'}. ${items.length} item(s) ang naka-pending.`);
      }
    } else if (!items.length && state.had_open && !quiet) {
      const r = await notifyTeam(creds, `✅ Argus: naasikaso na ang lahat ng na-miss. Salamat, team! 🙌`);
      if (r.sent.length) state.had_open = false;
    }
    if (reminded > 0) state.had_open = true; // only celebrate an all-clear for things the team was actually told about
    await saveState(state);

    return json({ ok: true, detected: detected.length, open: items.length, new: fresh.length, fixed: gone.length, reminded, channels, quiet, scanned: scan });
  } catch (e) {
    await log('error', 'watchdog', `Watchdog run failed: ${(e as Error).message}`);
    return json({ ok: false, error: (e as Error).message }, 500);
  }
}
