// The ONLY door to the office's private records. The browser cannot read or change them with the public key;
// every read (op: 'read', a fixed list of named queries below) and every write (games, queued posts,
// invite rules, auto-pilot switch, logs, integration status) must come through here WITH the server password
// (the APP_PASSCODE secret). Without it, nothing can be changed — even by someone who copied the anon key.
// Body: { op: 'verify' }  or  { op: 'read', query, params? }  or  { table, action: 'insert' | 'update' | 'delete', id?, row? }
import type { SupabaseClient } from '@supabase/supabase-js';
import { supabaseAdmin } from '@/integrations/supabase/client.server';
import { broadcastBrainChange } from './_shared/brain.ts';
import { authorized, corsHeaders, json } from './_shared/publish.ts';

const sb = supabaseAdmin as unknown as SupabaseClient;

// what the website is allowed to do, per table (anything else is refused)
const ALLOWED: Record<string, string[]> = {
  games: ['insert', 'update', 'delete'],
  studio_saved_copy: ['insert', 'update', 'delete'], // Save button in AI Content Studio
  scheduled_posts: ['insert', 'update', 'delete'],
  invite_rules: ['insert', 'update', 'delete'],
  bot_logs: ['insert'],
  bot_settings: ['update'],
  integrations: ['update'],
  idea_lab_brain: ['insert', 'update', 'delete'], // admin rules + review of pending AI rules
  employee_bots: ['update'],
  brain_sync_events: ['insert'], // broadcast when the admin adds / approves a rule
};

/* ---- reads: a fixed set of named queries (the browser never sends table names, filters or columns) ---- */
const RULE_COLS = 'id, source_bot_id, category, platform, title, insight_rule, confidence_score, usage_count, is_core_guardrail, status, created_at, updated_at';
const clampInt = (v: unknown, min: number, max: number, dflt: number) => {
  const n = Math.floor(Number(v));
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : dflt;
};
const isoOrNull = (v: unknown) => (typeof v === 'string' && v.length <= 40 && !Number.isNaN(Date.parse(v)) ? new Date(v).toISOString() : null);
const rows = <T,>(r: { data: T[] | null; error: { message: string } | null }) => {
  if (r.error) throw new Error(r.error.message);
  return r.data ?? [];
};

export const READS: Record<string, (p: Record<string, unknown>) => Promise<unknown>> = {
  games: async () => rows(await sb.from('games').select('*').order('created_at', { ascending: false })),
  studio_saved_copy: async () => rows(await sb.from('studio_saved_copy').select('*')),
  scheduled_posts: async () => rows(await sb.from('scheduled_posts').select('*').order('scheduled_at', { ascending: false }).limit(1000)),
  invite_rules: async () => rows(await sb.from('invite_rules').select('*').order('created_at', { ascending: false })),
  integrations: async () => rows(await sb.from('integrations').select('*').order('created_at', { ascending: true })),
  bot_settings: async () => {
    const { data, error } = await sb.from('bot_settings').select('*').eq('id', 1).maybeSingle();
    if (error) throw new Error(error.message);
    return data;
  },
  bot_logs: async (p) => {
    let q = sb.from('bot_logs').select('*').order('created_at', { ascending: false }).limit(clampInt(p.limit, 1, 500, 100));
    const since = isoOrNull(p.since);
    if (since) q = q.gt('created_at', since);
    return rows(await q);
  },
  brain: async () => {
    const [r, b, e, l, s] = await Promise.all([
      sb.from('idea_lab_brain').select(RULE_COLS).order('updated_at', { ascending: false }).limit(500),
      sb.from('employee_bots').select('id, name, role, platform, status').order('created_at'),
      sb.from('brain_sync_events').select('*').order('created_at', { ascending: false }).limit(40),
      sb.from('bot_action_logs').select('id, bot_id, action_type, platform, content_sent, metrics, performance_score, created_at').order('created_at', { ascending: false }).limit(300),
      sb.from('bot_settings').select('idea_lab_auto_approve').eq('id', 1).maybeSingle(),
    ]);
    return {
      rules: rows(r), bots: rows(b), events: rows(e), logs: rows(l),
      autoApprove: (s.data as { idea_lab_auto_approve?: boolean } | null)?.idea_lab_auto_approve !== false,
    };
  },
  boss_commands: async (p) => rows(await sb.from('idea_lab_brain').select('id, insight_rule, platform, status, created_at')
    .eq('category', 'boss_command').eq('status', 'approved').order('created_at', { ascending: false }).limit(clampInt(p.limit, 1, 50, 12))),
  lessons: async () => rows(await sb.from('idea_lab_brain').select('id, title, category')
    .eq('status', 'approved').eq('is_core_guardrail', false).order('updated_at', { ascending: false }).limit(12)),
};

/* ---- brute-force guard: 5 wrong passwords from one address = locked for 10 minutes ---- */
const fails = new Map<string, { n: number; until: number }>();
const MAX_FAILS = 5;
const LOCK_MS = 10 * 60_000;
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const clientIp = (req: Request) =>
  req.headers.get('cf-connecting-ip') ?? req.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ?? 'unknown';

export default async function handler(req: Request): Promise<Response> {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  if (req.method !== 'POST') return json({ error: 'POST only' }, 405);

  if (!process.env['APP_PASSCODE']) {
    return json({ error: 'Server password is not set yet (add the APP_PASSCODE secret)' }, 503);
  }

  const ip = clientIp(req);
  const f = fails.get(ip);
  if (f && f.n >= MAX_FAILS && Date.now() < f.until) return json({ error: 'Too many wrong tries. Try again in a few minutes.' }, 429);

  if (!authorized(req)) {
    const n = (f && Date.now() < f.until ? f.n : 0) + 1;
    fails.set(ip, { n, until: Date.now() + LOCK_MS });
    await sleep(1000); // slows down guessing
    return json({ error: 'Wrong or missing password' }, 401);
  }
  fails.delete(ip);

  if (Number(req.headers.get('content-length') ?? 0) > 200_000) return json({ error: 'Too large' }, 413);
  let body: { op?: string; table?: string; action?: string; id?: unknown; row?: unknown };
  try { body = await req.json(); } catch { return json({ error: 'Invalid JSON' }, 400); }

  if (body.op === 'verify') return json({ ok: true });
  // lets the app tell whether the server it talks to runs this version of the code (an older one answers 'Not allowed' here)
  if (body.op === 'version') return json({ ok: true, tables: Object.keys(ALLOWED), reads: Object.keys(READS) });

  if (body.op === 'read') {
    const b = body as { query?: unknown; params?: unknown };
    const read = typeof b.query === 'string' && Object.hasOwn(READS, b.query) ? READS[b.query] : undefined;
    if (!read) return json({ error: 'Unknown query' }, 400);
    const params = b.params && typeof b.params === 'object' && !Array.isArray(b.params) ? (b.params as Record<string, unknown>) : {};
    try {
      return json({ ok: true, data: await read(params) });
    } catch (e) {
      console.error('admin-db read failed', b.query, e);
      // The caller already passed the password check, so it is safe to say WHY (missing server config is the usual cause on a new deploy).
      const msg = e instanceof Error ? e.message : String((e as { message?: unknown })?.message ?? e);
      const sbHost = (() => { try { return new URL(process.env['SUPABASE_URL'] ?? '').host; } catch { return String(process.env['SUPABASE_URL'] ?? '(empty)'); } })();
      const detail = /error code: 10\d\d|ENOTFOUND|getaddrinfo|fetch failed/i.test(msg)
        ? `Hindi ma-resolve ang Supabase host na "${sbHost}" (${msg.slice(0, 60)}). Mali ang SUPABASE_URL o nabura ang project. Dapat: https://<20-letter-ref>.supabase.co (Supabase > Project Settings > API > Project URL), walang espasyo/dagdag na path.`
        : /Missing Supabase environment/i.test(msg)
        ? `Server config missing on ${new URL(req.url).host}: ${msg.replace(/\. Connect Supabase.*$/i, '')}. Set them in Netlify env vars (Mode B), or set VITE_BOT_API_BASE and redeploy (Mode A).`
        : msg.slice(0, 200);
      return json({ error: `Could not load the data: ${detail}` }, 500);
    }
  }

  const table = String(body.table ?? '');
  const action = String(body.action ?? '');
  if (!ALLOWED[table]?.includes(action)) return json({ error: 'Not allowed' }, 403);

  const row = body.row && typeof body.row === 'object' && !Array.isArray(body.row) ? { ...(body.row as Record<string, unknown>) } : null;
  const id = typeof body.id === 'string' || typeof body.id === 'number' ? body.id : null;

  try {
    if (action === 'insert') {
      if (!row) return json({ error: 'row required' }, 400);
      const { data, error } = await sb.from(table).insert(row).select('id').maybeSingle();
      if (error) return json({ error: error.message }, 400);
      if (table === 'idea_lab_brain' || table === 'brain_sync_events') await broadcastBrainChange({ kind: `${table}:insert`, rule_id: (table === 'idea_lab_brain' ? data?.id : row['brain_item_id']) as string | null });
      return json({ ok: true, id: data?.id });
    }
    if (id === null) return json({ error: 'id required' }, 400);
    if (table === 'bot_settings' && id !== 1) return json({ error: 'Not allowed' }, 403);
    if (action === 'update') {
      if (!row) return json({ error: 'row required' }, 400);
      delete row.id;
      delete row.created_at;
      const { error } = await sb.from(table).update(row).eq('id', id);
      if (error) return json({ error: error.message }, 400);
      if (table === 'idea_lab_brain') await broadcastBrainChange({ kind: 'idea_lab_brain:update', rule_id: String(id) });
      return json({ ok: true });
    }
    const { error } = await sb.from(table).delete().eq('id', id);
    if (error) return json({ error: error.message }, 400);
    if (table === 'idea_lab_brain') await broadcastBrainChange({ kind: 'idea_lab_brain:delete', rule_id: String(id) });
    return json({ ok: true });
  } catch (e) {
    return json({ error: (e as Error).message }, 500);
  }
}
