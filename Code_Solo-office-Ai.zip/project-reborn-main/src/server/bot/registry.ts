// Server-only: maps the original function names to their handlers (loaded on demand).
// Each handler checks its own caller: APP_PASSCODE header, the cron call, or the Facebook signature.
type Handler = (req: Request) => Promise<Response>;

const LOADERS: Record<string, () => Promise<{ default: Handler }>> = {
  'admin-db': () => import('./admin-db'),
  'auto-bot-worker': () => import('./auto-bot-worker'),
  'boss-chat': () => import('./boss-chat'),
  'caption-writer': () => import('./caption-writer'),
  'daily-poster': () => import('./daily-poster'),
  'fb-webhook': () => import('./fb-webhook'),
  'generate-post': () => import('./generate-post'),
  'idea-lab-reflector': () => import('./idea-lab-reflector'),
  'integrations-admin': () => import('./integrations-admin'),
  'publish-now': () => import('./publish-now'),
  'track-click': () => import('./track-click'),
  'video-editor-bot': () => import('./video-editor-bot'),
  'watchdog-admin': () => import('./watchdog-admin'),
  'watchdog-bot': () => import('./watchdog-bot'),
  'x-mentions-bot': () => import('./x-mentions-bot'),
};

export async function runBotFunction(name: string, req: Request): Promise<Response> {
  const load = LOADERS[name];
  if (!load) return new Response(JSON.stringify({ error: 'Unknown function' }), { status: 404, headers: { 'Content-Type': 'application/json' } });
  const mod = await load();
  return mod.default(req);
}

/** Jobs run by the scheduler, and how often (in minutes) each one runs. */
export const CRON_JOBS: { name: string; everyMinutes: number }[] = [
  { name: 'auto-bot-worker', everyMinutes: 1 },
  { name: 'x-mentions-bot', everyMinutes: 2 },
  { name: 'watchdog-bot', everyMinutes: 5 },
  { name: 'idea-lab-reflector', everyMinutes: 30 },
];

/** Extra scheduled jobs that run on EVERY tick (real-time). Kept apart from CRON_JOBS, whose cadence is fixed. */
export const REALTIME_JOBS: { name: string }[] = [{ name: 'video-editor-bot' }, { name: 'daily-poster' }];
