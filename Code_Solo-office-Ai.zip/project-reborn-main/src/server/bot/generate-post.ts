// AI caption generator. Uses the key saved in API Settings (OpenRouter / OpenAI / Gemini), never exposed to the client.
import type { SupabaseClient } from '@supabase/supabase-js';
import { supabaseAdmin } from '@/integrations/supabase/client.server';
import { aiErrorStatus, aiJson, loadAiConfig } from './_shared/ai.ts';
import { loadBrain } from './_shared/brain.ts';
import { authorized } from './_shared/publish.ts';

const sb = supabaseAdmin as unknown as SupabaseClient;

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey, X-App-Passcode',
};

const TONE_HINTS: Record<string, string> = {
  hype: 'high-energy, exclamation-driven launch hype',
  competitive: 'ranked-season, skill-grind, competitive edge',
  casual: 'friendly, relaxed, community-warm',
  fomo: 'limited-time urgency, scarcity, act-now',
};

const PLATFORM_HINTS: Record<string, string> = {
  facebook: 'Facebook: longer, story-driven, invite comments',
  twitter: 'X/Twitter: punchy, under 280 characters',
  discord: 'Discord: community call-out, markdown-friendly',
  telegram: 'Telegram: short broadcast, channel voice',
};

interface GameInfo {
  title: string;
  genre: string;
  description: string;
  promo_link: string;
}

function buildPrompt(game: GameInfo, platform: string, tone: string): string {
  return `You are a social media copywriter for an indie game studio. Write one promotional post.

Game: ${game.title}
Genre: ${game.genre || 'unspecified'}
Description: ${game.description || 'none'}
Promo link: ${game.promo_link || 'none'}
Platform: ${PLATFORM_HINTS[platform] ?? platform}
Tone: ${TONE_HINTS[tone] ?? tone}

Return ONLY valid JSON (no markdown fences) in exactly this shape:
{"content":"the post copy with the promo link included on its own line if present","hashtags":"#tag1 #tag2 #tag3 #tag4"}`;
}

export default async function handler(req: Request): Promise<Response> {
  if (req.method === 'OPTIONS') {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  if (!authorized(req)) {
    return new Response(JSON.stringify({ error: 'Wrong or missing passcode' }), { status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }

  try {
    const { game, platform, tone } = await req.json();
    if (!game || typeof game.title !== 'string') {
      return new Response(JSON.stringify({ error: 'Missing game info' }), {
        status: 400,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const cfg = await loadAiConfig(sb);
    if (!cfg) {
      return new Response(JSON.stringify({ error: 'no_key_configured' }), {
        status: 503,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const brain = await loadBrain(sb, cfg, { platforms: [String(platform)], role: 'aria', context: `${game.title} ${game.genre ?? ''} ${game.description ?? ''}` });
    const prompt = buildPrompt(game, platform, tone).replace('\n\nReturn ONLY valid JSON', `${brain.block}\n\nReturn ONLY valid JSON`);
    const parsed = await aiJson<{ content?: unknown; hashtags?: unknown }>(cfg, prompt, 500);
    if (typeof parsed.content !== 'string') throw new Error('AI response missing content');
    const result = { content: parsed.content, hashtags: typeof parsed.hashtags === 'string' ? parsed.hashtags : '' };

    return new Response(JSON.stringify(result), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Generation failed';
    return new Response(JSON.stringify({ error: message }), {
      status: aiErrorStatus(message),
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
}
