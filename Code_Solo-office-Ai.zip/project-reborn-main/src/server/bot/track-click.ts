// Public redirect: /api/public/bot/track-click?c=<variant_group>&v=a|b
// Counts the click, then sends the player to the game's promo link.
import type { SupabaseClient } from '@supabase/supabase-js';
import { supabaseAdmin } from '@/integrations/supabase/client.server';

export default async function handler(req: Request): Promise<Response> {
  const url = new URL(req.url);
  const group = url.searchParams.get('c') ?? '';
  const variant = url.searchParams.get('v') === 'b' ? 'b' : 'a';
  if (!/^[0-9a-f-]{36}$/i.test(group)) return new Response('Bad link', { status: 400 });

  const sb = supabaseAdmin as unknown as SupabaseClient;
  const { data: gameId } = await sb.rpc('increment_click', { p_group: group, p_variant: variant });
  let dest = '';
  if (gameId) {
    const { data: game } = await sb.from('games').select('promo_link').eq('id', gameId).maybeSingle();
    dest = game?.promo_link ?? '';
  }
  if (!dest) return new Response('Link not found', { status: 404 });
  const target = new URL(dest);
  target.searchParams.set('ref', `bot_var${variant.toUpperCase()}`);
  return Response.redirect(target.toString(), 302);
}
