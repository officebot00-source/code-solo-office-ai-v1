-- ============================================================================
-- Project Reborn — COMPLETE database setup for your OWN Supabase project.
-- Paste this whole file in: Supabase dashboard -> SQL Editor -> New query -> Run.
-- It is the 6 migrations (0000..0005) in order, so you do NOT run them one by one.
--
-- Use an EMPTY project (or one without these tables). The statements use "if not exists",
-- so tables that already exist with an OLD/different layout are left as-is and the app will error.
-- Safe to run twice on the same project.
-- ============================================================================


-- >>>>>>>>>> 0000_migration.sql <<<<<<<<<<
-- GameGrid Bot Office — schema carried over from the original project (final state of its 7 migrations).
-- Single-tenant app: the website READS public tables; every write goes through server routes that check APP_PASSCODE.
create extension if not exists vector with schema extensions;

-- ---------- core ----------
create table if not exists public.games (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  genre text not null default '',
  description text not null default '',
  promo_link text not null default '',
  banner_image text not null default '',
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  game_id uuid references public.games(id) on delete cascade,
  game_title text not null default '',
  platforms text[] not null default '{}',
  content text not null default '',
  hashtags text not null default '',
  tone text not null default 'hype',
  status text not null default 'scheduled',
  scheduled_at timestamptz not null default now(),
  published_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.invite_rules (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  platform text not null default 'discord',
  trigger_type text not null default 'keyword',
  trigger_keywords text[] not null default '{}',
  message_template text not null default 'Hey {username}, join me here: {game_link}',
  target_webhook text not null default '',
  max_per_hour integer not null default 20,
  delay_min_seconds integer not null default 30,
  delay_max_seconds integer not null default 90,
  enabled boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.bot_logs (
  id uuid primary key default gen_random_uuid(),
  level text not null default 'info',
  source text not null default 'system',
  message text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.integrations (
  id uuid primary key default gen_random_uuid(),
  provider text not null unique,
  label text not null default '',
  config jsonb not null default '{}',
  status text not null default 'untested',
  created_at timestamptz not null default now()
);

-- ---------- 24/7 worker ----------
create table if not exists public.bot_settings (
  id integer primary key default 1 check (id = 1),
  auto_pilot_enabled boolean not null default false,
  max_posts_per_hour integer not null default 6,
  max_invites_per_hour integer not null default 20,
  min_queue_size integer not null default 3,
  winner_min_clicks integer not null default 50,
  est_audience integer not null default 500,
  platform_discord boolean not null default true,
  platform_telegram boolean not null default true,
  platform_facebook boolean not null default false,
  platform_twitter boolean not null default false,
  idea_lab_auto_approve boolean not null default true,
  idea_lab_min_logs integer not null default 4,
  x_auto_reply_enabled boolean not null default true,
  watchdog_enabled boolean not null default true,
  watchdog_grace_minutes integer not null default 15,
  watchdog_nag_minutes integer not null default 30,
  watchdog_mention text not null default '',
  watchdog_quiet_start integer not null default 0,
  watchdog_quiet_end integer not null default 0,
  updated_at timestamptz not null default now()
);
insert into public.bot_settings (id) values (1) on conflict (id) do nothing;

create table if not exists public.scheduled_posts (
  id uuid primary key default gen_random_uuid(),
  game_id uuid references public.games(id) on delete cascade,
  game_title text not null default '',
  platforms text[] not null default '{}',
  content text not null default '',
  hashtags text not null default '',
  tone text not null default 'hype',
  status text not null default 'queued' check (status in ('queued','publishing','published','failed')),
  scheduled_at timestamptz not null default now(),
  published_at timestamptz,
  variant_group uuid,
  variant text check (variant in ('a','b')),
  impressions integer not null default 0,
  clicks integer not null default 0,
  error text,
  claimed_at timestamptz,
  results jsonb,
  brain_rule_ids uuid[] not null default '{}',
  created_at timestamptz not null default now()
);
create index if not exists scheduled_posts_due_idx on public.scheduled_posts (status, scheduled_at);
create index if not exists scheduled_posts_group_idx on public.scheduled_posts (variant_group);

create table if not exists public.invite_queue (
  id uuid primary key default gen_random_uuid(),
  game_id uuid references public.games(id) on delete set null,
  platform text not null default 'discord',
  target_user text not null,
  message text not null default '',
  status text not null default 'pending' check (status in ('pending','sent','failed')),
  error text,
  sent_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists invite_queue_status_idx on public.invite_queue (status, created_at);

create table if not exists public.ab_results (
  variant_group uuid primary key,
  game_id uuid references public.games(id) on delete cascade,
  winner text not null check (winner in ('a','b')),
  ctr_a numeric not null default 0,
  ctr_b numeric not null default 0,
  decided_at timestamptz not null default now()
);

-- ---------- server-only tables ----------
create table if not exists public.integration_secrets (
  provider text primary key,
  secrets jsonb not null default '{}',
  updated_at timestamptz not null default now()
);

create table if not exists public.comment_replies (
  comment_id text primary key,
  platform text not null default 'facebook',
  post_id text not null default '',
  user_name text not null default '',
  comment_text text not null default '',
  reply_text text,
  reply_id text,
  status text not null default 'processing' check (status in ('processing','replied','escalated','failed','skipped')),
  error text,
  brain_rule_ids uuid[] not null default '{}',
  created_at timestamptz not null default now()
);
create index if not exists comment_replies_created_idx on public.comment_replies (created_at desc);

create table if not exists public.bot_state (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists public.watchdog_issues (
  id uuid primary key default gen_random_uuid(),
  issue_key text not null unique,
  kind text not null,
  platform text not null default 'all',
  ref_id text not null default '',
  title text not null default '',
  detail text not null default '',
  url text not null default '',
  item_at timestamptz not null default now(),
  first_seen_at timestamptz not null default now(),
  last_nagged_at timestamptz,
  nag_count integer not null default 0,
  status text not null default 'open' check (status in ('open','snoozed','handled','dismissed','fixed')),
  snoozed_until timestamptz,
  resolved_at timestamptz,
  resolved_reason text
);
create index if not exists watchdog_issues_status_idx on public.watchdog_issues (status, item_at);

-- ---------- Shared Brain ----------
create table if not exists public.employee_bots (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  role text not null,
  platform text not null,
  status text default 'active',
  created_at timestamptz default now()
);
create unique index if not exists employee_bots_name_uq on public.employee_bots (name);

create table if not exists public.bot_action_logs (
  id uuid primary key default gen_random_uuid(),
  bot_id uuid references public.employee_bots(id) on delete cascade,
  action_type text not null,
  platform text not null,
  content_sent text not null,
  metrics jsonb default '{}'::jsonb,
  performance_score numeric default 0,
  is_processed boolean default false,
  applied_rule_ids uuid[] not null default '{}',
  source_ref text,
  created_at timestamptz default now()
);
create unique index if not exists bot_action_logs_source_ref_uq on public.bot_action_logs (source_ref);

create table if not exists public.idea_lab_brain (
  id uuid primary key default gen_random_uuid(),
  source_bot_id uuid references public.employee_bots(id) on delete set null,
  category text not null,
  platform text default 'all',
  title text not null,
  insight_rule text not null,
  confidence_score numeric default 0.50,
  usage_count int default 0,
  is_core_guardrail boolean default false,
  status text default 'approved',
  embedding extensions.vector(1536),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table if not exists public.brain_sync_events (
  id uuid primary key default gen_random_uuid(),
  brain_item_id uuid references public.idea_lab_brain(id) on delete cascade,
  learned_by_bot_id uuid references public.employee_bots(id) on delete set null,
  event_type text not null,
  created_at timestamptz default now()
);

create index if not exists idx_brain_active_rules on public.idea_lab_brain (status, platform, confidence_score desc, updated_at desc) where status = 'approved';
create index if not exists idx_unprocessed_logs on public.bot_action_logs (is_processed, created_at) where is_processed = false;
create index if not exists idx_brain_embedding on public.idea_lab_brain using hnsw (embedding extensions.vector_cosine_ops);

-- ---------- grants + RLS: website = read only, writes server-side ----------
grant select on public.games, public.posts, public.invite_rules, public.bot_logs, public.integrations,
  public.bot_settings, public.scheduled_posts, public.invite_queue, public.ab_results,
  public.employee_bots, public.bot_action_logs, public.idea_lab_brain, public.brain_sync_events
  to anon, authenticated;
grant all on public.games, public.posts, public.invite_rules, public.bot_logs, public.integrations,
  public.bot_settings, public.scheduled_posts, public.invite_queue, public.ab_results,
  public.employee_bots, public.bot_action_logs, public.idea_lab_brain, public.brain_sync_events,
  public.integration_secrets, public.comment_replies, public.bot_state, public.watchdog_issues
  to service_role;
revoke all on public.integration_secrets, public.comment_replies, public.bot_state, public.watchdog_issues
  from public, anon, authenticated;

do $$
declare t text;
begin
  foreach t in array array['games','posts','invite_rules','bot_logs','integrations','bot_settings','scheduled_posts','invite_queue','ab_results',
                           'employee_bots','bot_action_logs','idea_lab_brain','brain_sync_events',
                           'integration_secrets','comment_replies','bot_state','watchdog_issues']
  loop
    execute format('alter table public.%I enable row level security', t);
  end loop;
  foreach t in array array['games','posts','invite_rules','bot_logs','integrations','bot_settings','scheduled_posts','invite_queue','ab_results',
                           'employee_bots','bot_action_logs','idea_lab_brain','brain_sync_events']
  loop
    execute format('drop policy if exists %I on public.%I', 'public_read_' || t, t);
    execute format('create policy %I on public.%I for select to anon, authenticated using (true)', 'public_read_' || t, t);
  end loop;
end $$;

-- ---------- server-side helpers (service role only) ----------
create or replace function public.increment_click(p_group uuid, p_variant text) returns text
language sql security definer set search_path = public as $$
  update scheduled_posts set clicks = clicks + 1
  where id = (select id from scheduled_posts where variant_group = p_group and variant = p_variant order by created_at desc limit 1)
  returning game_id::text;
$$;

create or replace function public.bump_rule_usage(p_ids uuid[]) returns void
language sql security definer set search_path = public as $$
  update idea_lab_brain set usage_count = usage_count + 1 where id = any(p_ids);
$$;

create or replace function public.adjust_rule(p_id uuid, p_delta numeric, p_bot uuid default null) returns text
language plpgsql security definer set search_path = public as $$
declare r idea_lab_brain%rowtype; ev text;
begin
  update idea_lab_brain
     set confidence_score = least(0.99, greatest(0.01, confidence_score + p_delta)), updated_at = now()
   where id = p_id and is_core_guardrail = false and status = 'approved'
   returning * into r;
  if not found then return 'skipped'; end if;
  if r.confidence_score < 0.20 and r.usage_count >= 5 then
    update idea_lab_brain set status = 'deprecated', updated_at = now() where id = r.id;
    ev := 'rule_deprecated';
  elsif p_delta > 0 then
    ev := 'rule_reinforced';
  end if;
  if ev is not null then
    insert into brain_sync_events (brain_item_id, learned_by_bot_id, event_type) values (r.id, p_bot, ev);
  end if;
  return coalesce(ev, 'weakened');
end $$;

create or replace function public.match_brain_rules(q extensions.vector(1536), p_platforms text[], p_limit int default 8)
returns table (id uuid, category text, platform text, title text, insight_rule text, confidence_score numeric, is_core_guardrail boolean, similarity float)
language sql stable security definer set search_path = public, extensions as $$
  select b.id, b.category, b.platform, b.title, b.insight_rule, b.confidence_score, b.is_core_guardrail,
         (1 - (b.embedding <=> q))::float
    from idea_lab_brain b
   where b.status = 'approved' and b.embedding is not null and b.platform = any(p_platforms)
   order by b.embedding <=> q
   limit p_limit;
$$;

revoke execute on function public.increment_click(uuid, text), public.bump_rule_usage(uuid[]),
  public.adjust_rule(uuid, numeric, uuid), public.match_brain_rules(extensions.vector, text[], int)
  from public, anon, authenticated;
grant execute on function public.increment_click(uuid, text), public.bump_rule_usage(uuid[]),
  public.adjust_rule(uuid, numeric, uuid), public.match_brain_rules(extensions.vector, text[], int)
  to service_role;

-- ---------- realtime (Virtual Office + Shared Brain) ----------
do $$ begin alter publication supabase_realtime add table public.bot_logs; exception when duplicate_object then null; end $$;
do $$ begin alter publication supabase_realtime add table public.bot_settings; exception when duplicate_object then null; end $$;
do $$ begin alter publication supabase_realtime add table public.idea_lab_brain; exception when duplicate_object then null; end $$;
do $$ begin alter publication supabase_realtime add table public.brain_sync_events; exception when duplicate_object then null; end $$;

-- ---------- starting rows ----------
insert into public.integrations (provider, label, config, status) values
  ('openai',   'AI Engine',     '{}', 'untested'),
  ('facebook', 'Facebook Page', '{}', 'untested'),
  ('discord',  'Discord',       '{}', 'untested'),
  ('telegram', 'Telegram',      '{}', 'untested'),
  ('twitter',  'X (Twitter)',   '{}', 'untested')
on conflict (provider) do nothing;

insert into public.employee_bots (name, role, platform) values
  ('Aria',   'Content Strategist & Copywriter', 'all'),
  ('Blaze',  'Social Media Publisher',          'all'),
  ('Nova',   'Community Outreach & Auto-Invite','discord'),
  ('Echo',   'Engagement Bot (comment replies)','facebook'),
  ('Cipher', 'Reflector / Shared Brain Analyst','all'),
  ('Argus',  'Watchdog — chases the team about missed posts & comments', 'all'),
  ('Echo-X', 'Engagement Bot (X mentions)',     'twitter')
on conflict (name) do nothing;


-- >>>>>>>>>> 0001_migration.sql <<<<<<<<<<
-- Website is read-only: remove any write privileges the public roles may hold (writes go through the password-checked server).
revoke insert, update, delete, truncate on
  public.games, public.posts, public.invite_rules, public.bot_logs, public.integrations, public.bot_settings,
  public.scheduled_posts, public.invite_queue, public.ab_results, public.employee_bots, public.bot_action_logs,
  public.idea_lab_brain, public.brain_sync_events
from anon, authenticated;


-- >>>>>>>>>> 0002_lock_down_office_reads.sql <<<<<<<<<<
-- Office records are private: the browser reads them only through the password-checked server.
DROP POLICY IF EXISTS public_read_bot_settings ON public.bot_settings;
DROP POLICY IF EXISTS public_read_idea_lab_brain ON public.idea_lab_brain;
DROP POLICY IF EXISTS public_read_employee_bots ON public.employee_bots;
DROP POLICY IF EXISTS public_read_posts ON public.posts;
DROP POLICY IF EXISTS public_read_invite_queue ON public.invite_queue;
DROP POLICY IF EXISTS public_read_invite_rules ON public.invite_rules;
DROP POLICY IF EXISTS public_read_ab_results ON public.ab_results;
DROP POLICY IF EXISTS public_read_integrations ON public.integrations;
DROP POLICY IF EXISTS public_read_brain_sync_events ON public.brain_sync_events;
DROP POLICY IF EXISTS public_read_bot_action_logs ON public.bot_action_logs;
DROP POLICY IF EXISTS public_read_bot_logs ON public.bot_logs;
DROP POLICY IF EXISTS public_read_scheduled_posts ON public.scheduled_posts;

REVOKE ALL ON public.bot_settings, public.idea_lab_brain, public.employee_bots, public.posts,
  public.invite_queue, public.invite_rules, public.ab_results, public.integrations,
  public.brain_sync_events, public.bot_action_logs, public.bot_logs, public.scheduled_posts
  FROM anon, authenticated;

GRANT ALL ON public.bot_settings, public.idea_lab_brain, public.employee_bots, public.posts,
  public.invite_queue, public.invite_rules, public.ab_results, public.integrations,
  public.brain_sync_events, public.bot_action_logs, public.bot_logs, public.scheduled_posts
  TO service_role;


-- >>>>>>>>>> 0003_lock_games_reads.sql <<<<<<<<<<
DROP POLICY IF EXISTS public_read_games ON public.games;
REVOKE ALL ON public.games FROM anon, authenticated;
GRANT ALL ON public.games TO service_role;


-- >>>>>>>>>> 0004_studio_saved_copy.sql <<<<<<<<<<
-- Saved post copy for the AI Content Studio (Save button in Preview & Schedule).
-- One row per game (or the "All Games" post). Private: only the server (service_role) can read/write.
create table if not exists public.studio_saved_copy (
  id uuid primary key default gen_random_uuid(),
  copy_key text not null unique,
  content text not null default '',
  hashtags text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.studio_saved_copy enable row level security;
revoke all on public.studio_saved_copy from anon, authenticated;
grant all on public.studio_saved_copy to service_role;



-- >>>>>>>>>> 0005_fb_auto_reply_settings.sql <<<<<<<<<<
-- Facebook auto-reply switch + extra instructions, controlled from the Watchdog settings.
alter table public.bot_settings add column if not exists fb_auto_reply_enabled boolean not null default true;
alter table public.bot_settings add column if not exists fb_reply_instructions text not null default '';



-- >>>>>>>>>> CHECK (should list 18 tables and 4 functions) <<<<<<<<<<
select 'tables' as what, count(*)::int as n from information_schema.tables
 where table_schema = 'public' and table_name in ('ab_results','bot_action_logs','bot_logs','bot_settings','bot_state','brain_sync_events','comment_replies','employee_bots','games','idea_lab_brain','integration_secrets','integrations','invite_queue','invite_rules','posts','scheduled_posts','studio_saved_copy','watchdog_issues')
union all
select 'functions', count(*)::int from pg_proc p join pg_namespace n on n.oid = p.pronamespace
 where n.nspname = 'public' and p.proname in ('adjust_rule','bump_rule_usage','increment_click','match_brain_rules');
