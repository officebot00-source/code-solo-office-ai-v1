# Daily Auto-Post (Scheduler)

Pick the times of day once — the bot queues a fresh post for each of them **every day**. No more scheduling by hand.

**Where:** Scheduler tab → **Daily Auto-Post** card (turn on, add times, save).

**How it works**
1. Settings live in the existing `bot_state` table (`daily_poster_settings`) — **no migration**.
2. `daily-poster` runs on every scheduler tick (`REALTIME_JOBS`; `CRON_JOBS` is untouched).
3. 15 minutes before a slot it writes one post into `scheduled_posts` (status `queued`, `scheduled_at` = the exact slot time).
4. The existing `auto-bot-worker` publishes it on time — same rate limits, retry and activity log.
5. A lock row per (date, slot) (`daily_poster_run:<date>:<slot>`) guarantees a slot is queued only once per day, even with overlapping ticks.

**Rules**
- Time zone is per schedule (default Pilipinas, UTC+8), daylight-saving aware.
- Games rotate by day and slot (all active games, or only the ones you pick).
- AI writes the post (OpenRouter / OpenAI / Gemini key from API Settings). No key or AI error → built-in template, so the post still goes out. The game's promo link is always included.
- Platforms per slot: *All connected* or a chosen subset. Only platforms with saved credentials are used.
- If the server was down, a slot is still posted up to 30 minutes late; later than that it is skipped (no burst of old posts).
- No connected account / no active game → nothing is locked, so it posts as soon as you fix it; a warning appears in the Activity Console.
- "Mag-post ng test ngayon" queues one **real** post within ~1 minute.

**Endpoint** (POST `/api/public/bot/daily-poster`, header `x-app-passcode`): `{ "action": "status" | "settings_get" | "settings_set" | "run_now" | "tick", ... }`. The scheduler can only `tick`.

**Deploy note:** the Netlify build sends every API call to `VITE_BOT_API_BASE` (the Lovable-published site). Publish this version there too, otherwise the card cannot reach `daily-poster`.

Tests: `src/test/daily-poster.test.ts`.

---

# Phone (Android / iOS) notes
- Fields are 16px on touch screens (iOS no longer zooms in on focus); buttons, toggles, inputs and selects are ≥44px tall; selects show a chevron.
- Phone bottom bar: Office · Studio · Queue · Games · **More** (Invites, Brain, Argus, API in a sheet).
- Android keyboard resizes the page (`interactive-widget=resizes-content`); safe-area insets for notch / home bar.
- Installable: `public/manifest.webmanifest`, icons, `apple-touch-icon`, iOS standalone meta (Share → Add to Home Screen; Chrome → Install app).
