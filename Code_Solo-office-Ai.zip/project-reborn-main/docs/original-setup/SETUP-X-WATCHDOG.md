# X (Twitter) auto-reply + Argus the Watchdog

## Ano ang bago
| Feature | Paano gumagana |
|---|---|
| **X auto-post** | Matagal na itong nasa `auto-bot-worker` (Blaze). Ngayon mas matalino na ang pag-ikli ng post: hindi na pinuputol ang tracking link at hashtags kapag lumampas sa 280 (ang teksto lang ang pinaiikli). |
| **X auto-reply** | `x-mentions-bot` — kada 2 minuto binabasa ang bagong @mentions, si AI ang gumagawa ng sagot, at pino-post bilang reply. Kapareho ng Facebook bot: walang double reply, hindi sinasagot ang sarili, 30 sagot/oras max, hindi nag-iimbento ng presyo/policy (kapag walang datos = `ESCALATE` → hand-off reply + paalala sa team). |
| **Argus (Watchdog)** | `watchdog-bot` — kada 5 minuto sinusuri ang LAHAT ng post at comment. Kapag may na-miss, **kinukulit ang team** sa Telegram/Discord hanggang maayos. |

## Ano ang binabantayan ni Argus
- Comment / mention na **hindi nasagot** (pumalya ang bot, na-stuck, naabot ang hourly limit, o **hindi man lang dumating** ang event)
- Comment na sinagot lang ng "ipapa-check namin" — **kailangan pa ng tao** (nawawala kapag may tao nang sumagot sa FB; sa X pindutin ang *Tapos na*)
- Post na **pumalya**, **kalahati lang ang napost** (may platform na pumalya), **overdue** sa queue
- Platform na **walang post sa loob ng 24 oras** (kapag naka-ON ang Auto-Pilot)

Paano ang pangungulit: **isang pinagsamang mensahe** (hindi spam na isa-isa) kada `watchdog_nag_minutes` (default 30). Mas lumalakas ang tono:
`👀 paalala` → `⚠️ paalala ulit` (1-2×) → `🚨 Hoy team!` (3-5×) → `🔥 URGENT` (6×+). Ang bagong na-miss ay agad na ipinapaalam. Kapag naayos na ang lahat, may isang `✅ naasikaso na lahat` na mensahe at titigil siya.

## Setup (isang beses)
1. **Migration**: `supabase db push` (ina-apply ang `20261123000000_x_replies_and_watchdog.sql` — may bagong tables, settings, at cron para sa dalawang bot; gamit ang parehong vault secrets ng worker).
2. **Deploy**:
   ```bash
   supabase functions deploy x-mentions-bot
   supabase functions deploy watchdog-bot
   supabase functions deploy watchdog-admin
   supabase functions deploy idea-lab-reflector   # may maliit na update (nakikilala na ang X replies)
   supabase functions deploy auto-bot-worker      # smart na pag-ikli ng tweet
   supabase functions deploy integrations-admin
   ```
3. **X keys** — API Settings → X (Twitter): API Key, API Secret, Access Token, Access Secret (app na may *Read and write*). Pindutin ang **Test connection**.
   - Ang **pag-post** ay gumagana agad. Ang **pagbasa ng mentions** (para sa auto-reply at para makita ni Argus ang na-miss sa X) ay nangangailangan ng X API plan na may read access — kung wala, lalabas sa Activity Console (`x-bot`) ang babala (isang beses kada oras) at tuloy lang ang lahat ng iba.
   - Awtomatikong hindi sasagutin ang mentions na mahigit 24 oras na.
4. **Saan magpapaalala si Argus** — API Settings → **Telegram** (bot token + chat id ng team group) at/o **Discord** (webhook ng team channel). Kahit isa lang sapat na. Pagkatapos: **Watchdog (Argus) → Test reminder** para makita kung dumarating.
5. **Para ma-detect ni Argus ang comments na hindi dumating ang webhook** — kailangan ang Facebook Page token na may `pages_read_engagement` (kasama na sa nasa SETUP-REALTIME.md).

## Watchdog screen (tab "Argus")
- Listahan ng lahat ng na-miss, pinakamatagal sa itaas, may link para mabuksan agad ang comment/post.
- **Tapos na** (kapag ikaw na ang sumagot / nag-ayos) · **4h** (snooze) · **Ignore** (spam / hindi kailangan — hindi na ito babalik).
- **Check now** = buong scan agad. **Test reminder** = magpapadala ng halimbawang paalala.
- Settings: Watchdog ON/OFF, X auto-reply ON/OFF, gaano katagal bago ituring na "na-miss" (default 15 min), kada ilang minuto ang paalala (min 10), **sino ang ita-tag** (`@everyone`, o `@juan @maria`), at **quiet hours** (oras sa PH; hal. 22 → 7 = walang paalala sa gabi; hihintayin ang umaga bago magpaalala).

## Office ni Argus (3D Office)
- Sa Dashboard (3D office), may sarili nang **👁️ Argus HQ** si Argus sa kanang gilid, sa pagitan ng offices nina Blaze at Cipher (pinalitan nito ang dating print & huddle area). Ang pinto ay nakaharap sa kanang hallway.
- Sa loob: desk na may dalawang monitor, **CCTV wall** na may apat na camera (isa para kina Aria, Blaze, Nova at Cipher — ACTIVE / IDLE / PAUSED / NO SIGNAL ayon sa totoong status nila), **MISSED ITEMS** board, sofa, higaan ng aso 🐕, printer at cooler.
- Hindi siya umaalis sa office niya (hindi kasama sa meeting, coffee, kainan at arcade — nagbabantay siya habang wala ang iba) at may sarili siyang mga linya habang nagtatrabaho.

## Safety
- Lahat ng bagong table ay service-only (hindi mababasa gamit ang public key); ang screen ay dumadaan sa `watchdog-admin` na may password.
- Hindi sumusunod ang X bot sa utos na nakasulat sa loob ng mention (untrusted text).
- Hindi kailanman nagre-reply nang dalawang beses: `comment_id` ang primary key.
- Ang X rules ay nagbabawal ng spammy automation — nasa 30 sagot/oras ang limit at sumasagot lang sa mga nag-mention sa iyo.
