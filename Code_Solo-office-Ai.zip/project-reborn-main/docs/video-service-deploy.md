# Game video: bakit may "walang ffmpeg" at paano ito ayusin

**Bakit:** ang Netlify ay walang `ffmpeg`, kaya hindi ito makakagawa ng video mismo. Ang ginagawa ng app: ipinapasa niya ang trabaho sa
**video-editor-service** (maliit na server na may ffmpeg) sa pamamagitan ng `VIDEO_EDITOR_API_URL`.
Hangga't wala iyon, lalabas ang error na "walang ffmpeg sa server (VIDEO_EDITOR_API_URL is not set)".

## Mga hakbang (≈10 minuto)
1. **Render.com → New → Blueprint** → piliin ang repo na ito. Nakita nito ang `render.yaml` at gagawa ng service na `video-editor-service`.
   (Kung Railway / Fly ang gamit mo: i-build ang `video-editor-service/Dockerfile` mula sa ROOT ng repo.)
2. Sa Render → ang service → **Environment**: kopyahin ang nabuong `VIDEO_EDITOR_API_KEY`.
   (Hindi na kailangan ang `PUBLIC_BASE_URL` sa Render; kusa nitong ginagamit ang address ng service. Sa ibang host, i-set ito sa https address ng service.)
3. Subukan sa browser: `https://<service>/health` → dapat `{"ok":true}`.
4. **Netlify → Site configuration → Environment variables** (scope: Builds + Functions + Runtime):
   - `VIDEO_EDITOR_API_URL` = `https://<service>/edit`
   - `VIDEO_EDITOR_API_KEY` = parehong key sa Render
5. **Deploys → Trigger deploy → Clear cache and deploy site.**
6. Content Studio → Video → **Gumawa ng video** ulit.

## Kung ayaw mo munang mag-deploy
I-on ang **Dry run** sa Video Studio: tatakbo ang buong daloy (approval, caption, atbp.) pero **walang totoong video** na gagawin.

## Hindi na kailangan ang ffmpeg sa Netlify
Huwag mag-set ng `FFMPEG_PATH`, `VIDEO_MEDIA_DIR` o `VIDEO_FONT_FILE` sa Netlify.
