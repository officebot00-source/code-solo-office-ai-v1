<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Players discover the games and go play them

## Metric

Visitors who reach a game through a tracked post link each week
