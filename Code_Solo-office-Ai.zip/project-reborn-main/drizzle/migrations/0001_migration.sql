-- Website is read-only: remove any write privileges the public roles may hold (writes go through the password-checked server).
revoke insert, update, delete, truncate on
  public.games, public.posts, public.invite_rules, public.bot_logs, public.integrations, public.bot_settings,
  public.scheduled_posts, public.invite_queue, public.ab_results, public.employee_bots, public.bot_action_logs,
  public.idea_lab_brain, public.brain_sync_events
from anon, authenticated;