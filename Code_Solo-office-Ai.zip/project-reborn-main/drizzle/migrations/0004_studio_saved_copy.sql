-- Saved post copy for the AI Content Studio (Save button in Preview & Schedule).
-- One row per game (or the "All Games" post). Private: only the server (service_role) can read/write.
create table if not exists public.studio_saved_copy (
  id uuid primary key default gen_random_uuid(),
  copy_key text not null unique,
  content text not null default '',
  hashtags text not null default '',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table public.studio_saved_copy enable row level security;
revoke all on public.studio_saved_copy from anon, authenticated;
grant all on public.studio_saved_copy to service_role;
