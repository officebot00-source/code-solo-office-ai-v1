DROP POLICY IF EXISTS public_read_games ON public.games;
REVOKE ALL ON public.games FROM anon, authenticated;
GRANT ALL ON public.games TO service_role;