"""
REAL implementations of the two tools used by run_ai_social_media_office():
    post_to_social_media(...)  -> posts to your Facebook Page
    reply_to_comment(...)      -> posts a public reply under a comment

Env vars:  FB_PAGE_ID, FB_PAGE_TOKEN   (Page access token: pages_manage_posts, pages_manage_engagement, pages_read_engagement)
Both functions RETURN A STRING (what Claude receives as the tool_result) and never raise, so Claude can report errors.
"""
import os
import re
import requests

GRAPH = "https://graph.facebook.com/v21.0"
TIMEOUT = 20


def _fb_error(res: requests.Response) -> str:
    try:
        return res.json().get("error", {}).get("message", res.text[:200])
    except ValueError:
        return res.text[:200]


def post_to_social_media(platform: str, content: str) -> str:
    """Publish `content` to the Page feed. (Assumed signature: platform, content — adjust if yours differs.)"""
    if platform.lower() != "facebook":
        return f"ERROR: platform '{platform}' is not implemented yet (only facebook)."
    page_id, token = os.getenv("FB_PAGE_ID", ""), os.getenv("FB_PAGE_TOKEN", "")
    if not page_id or not token:
        return "ERROR: FB_PAGE_ID / FB_PAGE_TOKEN are not set."
    try:
        res = requests.post(f"{GRAPH}/{page_id}/feed",
                            data={"message": content, "access_token": token}, timeout=TIMEOUT)
    except requests.RequestException as e:
        return f"ERROR: network problem — {e}"
    if not res.ok:
        return f"ERROR: Facebook {res.status_code}: {_fb_error(res)}"
    post_id = res.json().get("id", "")
    return f"SUCCESS: posted live. post_id={post_id} url=https://www.facebook.com/{post_id}"


def reply_to_comment(platform: str, post_id: str, comment_id: str, comment_text: str, user_name: str) -> str:
    """
    Publish a public reply under `comment_id`.
    NOTE: `comment_text` is the REPLY that Claude wrote (as your script's comment says), not the customer's comment.
    """
    if platform.lower() != "facebook":
        return f"ERROR: platform '{platform}' is not implemented yet (only facebook)."
    token = os.getenv("FB_PAGE_TOKEN", "")
    if not token:
        return "ERROR: FB_PAGE_TOKEN is not set."
    if not re.fullmatch(r"[0-9_]+", comment_id or ""):
        return "ERROR: invalid comment_id (real Facebook ids are digits/underscore)."
    if not comment_text.strip():
        return "ERROR: empty reply."
    try:
        res = requests.post(f"{GRAPH}/{comment_id}/comments",
                            data={"message": comment_text[:1000], "access_token": token}, timeout=TIMEOUT)
    except requests.RequestException as e:
        return f"ERROR: network problem — {e}"
    if not res.ok:
        return f"ERROR: Facebook {res.status_code}: {_fb_error(res)}"
    return f"SUCCESS: replied to {user_name} (reply_id={res.json().get('id', '')})"
